package com.google.firebase;

import android.content.Context;
import android.text.TextUtils;
import com.google.android.gms.common.internal.C0854b;
import com.google.android.gms.common.internal.C0861f;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.p022a.C0802i;

/* renamed from: com.google.firebase.b */
public final class C1090b {
    /* renamed from: a */
    private final String f2274a;
    /* renamed from: b */
    private final String f2275b;
    /* renamed from: c */
    private final String f2276c;
    /* renamed from: d */
    private final String f2277d;
    /* renamed from: e */
    private final String f2278e;
    /* renamed from: f */
    private final String f2279f;

    private C1090b(String str, String str2, String str3, String str4, String str5, String str6) {
        C0854b.m3432a(!C0802i.m3252a(str), (Object) "ApplicationId must be set.");
        this.f2275b = str;
        this.f2274a = str2;
        this.f2276c = str3;
        this.f2277d = str4;
        this.f2278e = str5;
        this.f2279f = str6;
    }

    /* renamed from: a */
    public static C1090b m4610a(Context context) {
        C0861f c0861f = new C0861f(context);
        Object a = c0861f.m3499a("google_app_id");
        return TextUtils.isEmpty(a) ? null : new C1090b(a, c0861f.m3499a("google_api_key"), c0861f.m3499a("firebase_database_url"), c0861f.m3499a("ga_trackingId"), c0861f.m3499a("gcm_defaultSenderId"), c0861f.m3499a("google_storage_bucket"));
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C1090b)) {
            return false;
        }
        C1090b c1090b = (C1090b) obj;
        return ab.m3426a(this.f2275b, c1090b.f2275b) && ab.m3426a(this.f2274a, c1090b.f2274a) && ab.m3426a(this.f2276c, c1090b.f2276c) && ab.m3426a(this.f2277d, c1090b.f2277d) && ab.m3426a(this.f2278e, c1090b.f2278e) && ab.m3426a(this.f2279f, c1090b.f2279f);
    }

    public int hashCode() {
        return ab.m3424a(this.f2275b, this.f2274a, this.f2276c, this.f2277d, this.f2278e, this.f2279f);
    }

    public String toString() {
        return ab.m3425a((Object) this).m3423a("applicationId", this.f2275b).m3423a("apiKey", this.f2274a).m3423a("databaseUrl", this.f2276c).m3423a("gcmSenderId", this.f2278e).m3423a("storageBucket", this.f2279f).toString();
    }
}

package com.google.firebase;

import android.annotation.TargetApi;
import android.app.Application;
import android.content.Context;
import android.support.v4.p011e.C0222a;
import android.util.Log;
import com.google.android.gms.common.internal.C0854b;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.p022a.C0800g;
import com.google.android.gms.p023d.C0934a;
import com.google.android.gms.p023d.C0951b;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

/* renamed from: com.google.firebase.a */
public class C1089a {
    /* renamed from: a */
    static final Map<String, C1089a> f2260a = new C0222a();
    /* renamed from: b */
    private static final List<String> f2261b = Arrays.asList(new String[]{"com.google.firebase.auth.FirebaseAuth", "com.google.firebase.iid.FirebaseInstanceId"});
    /* renamed from: c */
    private static final List<String> f2262c = Collections.singletonList("com.google.firebase.crash.FirebaseCrash");
    /* renamed from: d */
    private static final List<String> f2263d = Arrays.asList(new String[]{"com.google.android.gms.measurement.AppMeasurement"});
    /* renamed from: e */
    private static final Set<String> f2264e = Collections.emptySet();
    /* renamed from: f */
    private static final Object f2265f = new Object();
    /* renamed from: g */
    private final Context f2266g;
    /* renamed from: h */
    private final String f2267h;
    /* renamed from: i */
    private final C1090b f2268i;
    /* renamed from: j */
    private final AtomicBoolean f2269j = new AtomicBoolean(true);
    /* renamed from: k */
    private final AtomicBoolean f2270k = new AtomicBoolean();
    /* renamed from: l */
    private final List<Object> f2271l = new CopyOnWriteArrayList();
    /* renamed from: m */
    private final List<C1088a> f2272m = new CopyOnWriteArrayList();
    /* renamed from: n */
    private final List<Object> f2273n = new CopyOnWriteArrayList();

    /* renamed from: com.google.firebase.a$a */
    public interface C1088a {
        /* renamed from: a */
        void m4597a(boolean z);
    }

    protected C1089a(Context context, String str, C1090b c1090b) {
        this.f2266g = (Context) C0854b.m3427a((Object) context);
        this.f2267h = C0854b.m3429a(str);
        this.f2268i = (C1090b) C0854b.m3427a((Object) c1090b);
    }

    /* renamed from: a */
    public static C1089a m4598a(Context context) {
        C1090b a = C1090b.m4610a(context);
        return a == null ? null : C1089a.m4599a(context, a);
    }

    /* renamed from: a */
    public static C1089a m4599a(Context context, C1090b c1090b) {
        return C1089a.m4600a(context, c1090b, "[DEFAULT]");
    }

    /* renamed from: a */
    public static C1089a m4600a(Context context, C1090b c1090b, String str) {
        Object c1089a;
        C0951b a = C0951b.m3908a(context);
        C1089a.m4604b(context);
        String a2 = C1089a.m4601a(str);
        Object applicationContext = context.getApplicationContext();
        synchronized (f2265f) {
            C0854b.m3432a(!f2260a.containsKey(a2), new StringBuilder(String.valueOf(a2).length() + 33).append("FirebaseApp name ").append(a2).append(" already exists!").toString());
            C0854b.m3428a(applicationContext, (Object) "Application context cannot be null.");
            c1089a = new C1089a(applicationContext, a2, c1090b);
            f2260a.put(a2, c1089a);
        }
        a.m3909a((C1089a) c1089a);
        C1089a.m4602a(C1089a.class, c1089a, f2261b);
        if (c1089a.m4609c()) {
            C1089a.m4602a(C1089a.class, c1089a, f2262c);
            C1089a.m4602a(Context.class, c1089a.m4607a(), f2263d);
        }
        return c1089a;
    }

    /* renamed from: a */
    private static String m4601a(String str) {
        return str.trim();
    }

    /* renamed from: a */
    private static <T> void m4602a(Class<T> cls, T t, Iterable<String> iterable) {
        for (String str : iterable) {
            String str2;
            try {
                Class cls2 = Class.forName(str2);
                Method method = cls2.getMethod("getInstance", new Class[]{cls});
                if ((method.getModifiers() & 9) == 9) {
                    method.invoke(null, new Object[]{t});
                }
                String valueOf = String.valueOf(cls2);
                Log.d("FirebaseApp", new StringBuilder(String.valueOf(valueOf).length() + 13).append("Initialized ").append(valueOf).append(".").toString());
            } catch (ClassNotFoundException e) {
                if (f2264e.contains(str2)) {
                    throw new IllegalStateException(String.valueOf(str2).concat(" is missing, but is required. Check if it has been removed by Proguard."));
                }
                Log.d("FirebaseApp", String.valueOf(str2).concat(" is not linked. Skipping initialization."));
            } catch (NoSuchMethodException e2) {
                throw new IllegalStateException(String.valueOf(str2).concat("#getInstance has been removed by Proguard. Add keep rule to prevent it."));
            } catch (Throwable e3) {
                Log.wtf("FirebaseApp", "Firebase API initialization failure.", e3);
            } catch (Throwable e4) {
                String str3 = "FirebaseApp";
                String str4 = "Failed to initialize ";
                str2 = String.valueOf(str2);
                Log.wtf(str3, str2.length() != 0 ? str4.concat(str2) : new String(str4), e4);
            }
        }
    }

    /* renamed from: a */
    public static void m4603a(boolean z) {
        synchronized (f2265f) {
            Iterator it = new ArrayList(f2260a.values()).iterator();
            while (it.hasNext()) {
                C1089a c1089a = (C1089a) it.next();
                if (c1089a.f2269j.get()) {
                    c1089a.m4605b(z);
                }
            }
        }
    }

    @TargetApi(14)
    /* renamed from: b */
    private static void m4604b(Context context) {
        if (C0800g.m3244c() && (context.getApplicationContext() instanceof Application)) {
            C0934a.m3819a((Application) context.getApplicationContext());
        }
    }

    /* renamed from: b */
    private void m4605b(boolean z) {
        Log.d("FirebaseApp", "Notifying background state change listeners.");
        for (C1088a a : this.f2272m) {
            a.m4597a(z);
        }
    }

    /* renamed from: d */
    private void m4606d() {
        C0854b.m3432a(!this.f2270k.get(), (Object) "FirebaseApp was deleted");
    }

    /* renamed from: a */
    public Context m4607a() {
        m4606d();
        return this.f2266g;
    }

    /* renamed from: b */
    public String m4608b() {
        m4606d();
        return this.f2267h;
    }

    /* renamed from: c */
    public boolean m4609c() {
        return "[DEFAULT]".equals(m4608b());
    }

    public boolean equals(Object obj) {
        return !(obj instanceof C1089a) ? false : this.f2267h.equals(((C1089a) obj).m4608b());
    }

    public int hashCode() {
        return this.f2267h.hashCode();
    }

    public String toString() {
        return ab.m3425a((Object) this).m3423a("name", this.f2267h).m3423a("options", this.f2268i).toString();
    }
}

package com.google.android.gms.location.internal;

import android.location.Location;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.C1031c;
import com.google.android.gms.location.C1036g;

/* renamed from: com.google.android.gms.location.internal.c */
public class C1043c implements C1031c {
    /* renamed from: a */
    public Location mo1053a(GoogleApiClient googleApiClient) {
        try {
            return C1036g.m4367a(googleApiClient).mo907k();
        } catch (Exception e) {
            return null;
        }
    }
}

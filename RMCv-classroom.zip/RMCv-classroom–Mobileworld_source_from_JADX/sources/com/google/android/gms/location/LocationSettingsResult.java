package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.C0809e;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public final class LocationSettingsResult extends AbstractSafeParcelable implements C0809e {
    public static final Creator<LocationSettingsResult> CREATOR = new C1076p();
    /* renamed from: a */
    private final int f2175a;
    /* renamed from: b */
    private final Status f2176b;
    /* renamed from: c */
    private final LocationSettingsStates f2177c;

    LocationSettingsResult(int i, Status status, LocationSettingsStates locationSettingsStates) {
        this.f2175a = i;
        this.f2176b = status;
        this.f2177c = locationSettingsStates;
    }

    /* renamed from: a */
    public Status mo890a() {
        return this.f2176b;
    }

    /* renamed from: b */
    public int m4343b() {
        return this.f2175a;
    }

    /* renamed from: c */
    public LocationSettingsStates m4344c() {
        return this.f2177c;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1076p.m4529a(this, parcel, i);
    }
}

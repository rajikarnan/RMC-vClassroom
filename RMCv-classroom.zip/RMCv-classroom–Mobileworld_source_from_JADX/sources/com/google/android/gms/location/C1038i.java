package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.WorkSource;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;

/* renamed from: com.google.android.gms.location.i */
public class C1038i implements Creator<ActivityRecognitionRequest> {
    /* renamed from: a */
    static void m4368a(ActivityRecognitionRequest activityRecognitionRequest, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3647a(parcel, 1, activityRecognitionRequest.m4311a());
        C0907b.m3655a(parcel, 2, activityRecognitionRequest.m4312b());
        C0907b.m3650a(parcel, 3, activityRecognitionRequest.m4313c(), i, false);
        C0907b.m3652a(parcel, 4, activityRecognitionRequest.m4314d(), false);
        C0907b.m3656a(parcel, 5, activityRecognitionRequest.m4315e(), false);
        C0907b.m3655a(parcel, 6, activityRecognitionRequest.m4316f());
        C0907b.m3652a(parcel, 7, activityRecognitionRequest.m4317g(), false);
        C0907b.m3646a(parcel, 1000, activityRecognitionRequest.m4318h());
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public ActivityRecognitionRequest m4369a(Parcel parcel) {
        boolean z = false;
        String str = null;
        int b = C0906a.m3626b(parcel);
        long j = 0;
        int[] iArr = null;
        String str2 = null;
        WorkSource workSource = null;
        boolean z2 = false;
        int i = 0;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    j = C0906a.m3634g(parcel, a);
                    break;
                case 2:
                    z2 = C0906a.m3630c(parcel, a);
                    break;
                case 3:
                    workSource = (WorkSource) C0906a.m3623a(parcel, a, WorkSource.CREATOR);
                    break;
                case 4:
                    str2 = C0906a.m3637j(parcel, a);
                    break;
                case 5:
                    iArr = C0906a.m3640m(parcel, a);
                    break;
                case 6:
                    z = C0906a.m3630c(parcel, a);
                    break;
                case 7:
                    str = C0906a.m3637j(parcel, a);
                    break;
                case 1000:
                    i = C0906a.m3632e(parcel, a);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new ActivityRecognitionRequest(i, j, z2, workSource, str2, iArr, z, str);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public ActivityRecognitionRequest[] m4370a(int i) {
        return new ActivityRecognitionRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4369a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4370a(i);
    }
}

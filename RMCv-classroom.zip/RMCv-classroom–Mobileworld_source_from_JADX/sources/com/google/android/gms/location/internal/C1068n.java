package com.google.android.gms.location.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;

/* renamed from: com.google.android.gms.location.internal.n */
public class C1068n implements Creator<ParcelableGeofence> {
    /* renamed from: a */
    static void m4511a(ParcelableGeofence parcelableGeofence, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3652a(parcel, 1, parcelableGeofence.m4391f(), false);
        C0907b.m3647a(parcel, 2, parcelableGeofence.m4392g());
        C0907b.m3654a(parcel, 3, parcelableGeofence.m4387b());
        C0907b.m3644a(parcel, 4, parcelableGeofence.m4388c());
        C0907b.m3644a(parcel, 5, parcelableGeofence.m4389d());
        C0907b.m3645a(parcel, 6, parcelableGeofence.m4390e());
        C0907b.m3646a(parcel, 7, parcelableGeofence.m4393h());
        C0907b.m3646a(parcel, 1000, parcelableGeofence.m4386a());
        C0907b.m3646a(parcel, 8, parcelableGeofence.m4394i());
        C0907b.m3646a(parcel, 9, parcelableGeofence.m4395j());
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public ParcelableGeofence m4512a(Parcel parcel) {
        int b = C0906a.m3626b(parcel);
        int i = 0;
        String str = null;
        int i2 = 0;
        short s = (short) 0;
        double d = 0.0d;
        double d2 = 0.0d;
        float f = 0.0f;
        long j = 0;
        int i3 = 0;
        int i4 = -1;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    str = C0906a.m3637j(parcel, a);
                    break;
                case 2:
                    j = C0906a.m3634g(parcel, a);
                    break;
                case 3:
                    s = C0906a.m3631d(parcel, a);
                    break;
                case 4:
                    d = C0906a.m3636i(parcel, a);
                    break;
                case 5:
                    d2 = C0906a.m3636i(parcel, a);
                    break;
                case 6:
                    f = C0906a.m3635h(parcel, a);
                    break;
                case 7:
                    i2 = C0906a.m3632e(parcel, a);
                    break;
                case 8:
                    i3 = C0906a.m3632e(parcel, a);
                    break;
                case 9:
                    i4 = C0906a.m3632e(parcel, a);
                    break;
                case 1000:
                    i = C0906a.m3632e(parcel, a);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new ParcelableGeofence(i, str, i2, s, d, d2, f, j, i3, i4);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public ParcelableGeofence[] m4513a(int i) {
        return new ParcelableGeofence[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4512a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4513a(i);
    }
}

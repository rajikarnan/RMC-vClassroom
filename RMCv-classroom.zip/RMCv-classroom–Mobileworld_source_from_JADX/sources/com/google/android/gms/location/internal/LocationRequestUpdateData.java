package com.google.android.gms.location.internal;

import android.app.PendingIntent;
import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.location.C1058l;
import com.google.android.gms.location.C1058l.C1059a;
import com.google.android.gms.location.C1061m;
import com.google.android.gms.location.C1061m.C1062a;
import com.google.android.gms.location.internal.C1046f.C1048a;

public class LocationRequestUpdateData extends AbstractSafeParcelable {
    public static final C1067m CREATOR = new C1067m();
    /* renamed from: a */
    int f2204a;
    /* renamed from: b */
    LocationRequestInternal f2205b;
    /* renamed from: c */
    C1061m f2206c;
    /* renamed from: d */
    PendingIntent f2207d;
    /* renamed from: e */
    C1058l f2208e;
    /* renamed from: f */
    C1046f f2209f;
    /* renamed from: g */
    private final int f2210g;

    LocationRequestUpdateData(int i, int i2, LocationRequestInternal locationRequestInternal, IBinder iBinder, PendingIntent pendingIntent, IBinder iBinder2, IBinder iBinder3) {
        C1046f c1046f = null;
        this.f2210g = i;
        this.f2204a = i2;
        this.f2205b = locationRequestInternal;
        this.f2206c = iBinder == null ? null : C1062a.m4497a(iBinder);
        this.f2207d = pendingIntent;
        this.f2208e = iBinder2 == null ? null : C1059a.m4492a(iBinder2);
        if (iBinder3 != null) {
            c1046f = C1048a.m4416a(iBinder3);
        }
        this.f2209f = c1046f;
    }

    /* renamed from: a */
    public static LocationRequestUpdateData m4375a(C1058l c1058l, C1046f c1046f) {
        return new LocationRequestUpdateData(1, 2, null, null, null, c1058l.asBinder(), c1046f != null ? c1046f.asBinder() : null);
    }

    /* renamed from: a */
    public static LocationRequestUpdateData m4376a(C1061m c1061m, C1046f c1046f) {
        return new LocationRequestUpdateData(1, 2, null, c1061m.asBinder(), null, null, c1046f != null ? c1046f.asBinder() : null);
    }

    /* renamed from: a */
    int m4377a() {
        return this.f2210g;
    }

    /* renamed from: b */
    IBinder m4378b() {
        return this.f2206c == null ? null : this.f2206c.asBinder();
    }

    /* renamed from: c */
    IBinder m4379c() {
        return this.f2208e == null ? null : this.f2208e.asBinder();
    }

    /* renamed from: d */
    IBinder m4380d() {
        return this.f2209f == null ? null : this.f2209f.asBinder();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1067m.m4508a(this, parcel, i);
    }
}

package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;
import java.util.List;

/* renamed from: com.google.android.gms.location.o */
public class C1075o implements Creator<LocationSettingsRequest> {
    /* renamed from: a */
    static void m4526a(LocationSettingsRequest locationSettingsRequest, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3661b(parcel, 1, locationSettingsRequest.m4339b(), false);
        C0907b.m3655a(parcel, 2, locationSettingsRequest.m4340c());
        C0907b.m3655a(parcel, 3, locationSettingsRequest.m4341d());
        C0907b.m3646a(parcel, 1000, locationSettingsRequest.m4338a());
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public LocationSettingsRequest m4527a(Parcel parcel) {
        boolean z = false;
        int b = C0906a.m3626b(parcel);
        List list = null;
        boolean z2 = false;
        int i = 0;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    list = C0906a.m3629c(parcel, a, LocationRequest.CREATOR);
                    break;
                case 2:
                    z2 = C0906a.m3630c(parcel, a);
                    break;
                case 3:
                    z = C0906a.m3630c(parcel, a);
                    break;
                case 1000:
                    i = C0906a.m3632e(parcel, a);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new LocationSettingsRequest(i, list, z2, z);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public LocationSettingsRequest[] m4528a(int i) {
        return new LocationSettingsRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4527a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4528a(i);
    }
}

package com.google.android.gms.location.internal;

import android.os.DeadObjectException;
import android.os.IInterface;

/* renamed from: com.google.android.gms.location.internal.o */
public interface C1039o<T extends IInterface> {
    /* renamed from: a */
    void mo1050a();

    /* renamed from: c */
    T mo1051c() throws DeadObjectException;
}

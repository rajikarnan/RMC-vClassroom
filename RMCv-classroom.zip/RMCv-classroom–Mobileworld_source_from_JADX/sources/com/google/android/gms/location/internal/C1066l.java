package com.google.android.gms.location.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;
import com.google.android.gms.location.LocationRequest;
import java.util.List;

/* renamed from: com.google.android.gms.location.internal.l */
public class C1066l implements Creator<LocationRequestInternal> {
    /* renamed from: a */
    static void m4505a(LocationRequestInternal locationRequestInternal, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3650a(parcel, 1, locationRequestInternal.f2198b, i, false);
        C0907b.m3655a(parcel, 4, locationRequestInternal.f2199c);
        C0907b.m3661b(parcel, 5, locationRequestInternal.f2200d, false);
        C0907b.m3652a(parcel, 6, locationRequestInternal.f2201e, false);
        C0907b.m3655a(parcel, 7, locationRequestInternal.f2202f);
        C0907b.m3646a(parcel, 1000, locationRequestInternal.m4374a());
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public LocationRequestInternal m4506a(Parcel parcel) {
        String str = null;
        boolean z = false;
        int b = C0906a.m3626b(parcel);
        boolean z2 = true;
        List list = LocationRequestInternal.f2197a;
        LocationRequest locationRequest = null;
        int i = 0;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    locationRequest = (LocationRequest) C0906a.m3623a(parcel, a, LocationRequest.CREATOR);
                    break;
                case 4:
                    z2 = C0906a.m3630c(parcel, a);
                    break;
                case 5:
                    list = C0906a.m3629c(parcel, a, ClientIdentity.CREATOR);
                    break;
                case 6:
                    str = C0906a.m3637j(parcel, a);
                    break;
                case 7:
                    z = C0906a.m3630c(parcel, a);
                    break;
                case 1000:
                    i = C0906a.m3632e(parcel, a);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new LocationRequestInternal(i, locationRequest, z2, list, str, z);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public LocationRequestInternal[] m4507a(int i) {
        return new LocationRequestInternal[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4506a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4507a(i);
    }
}

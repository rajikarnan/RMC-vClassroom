package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;
import com.google.android.gms.location.internal.ParcelableGeofence;
import java.util.List;

/* renamed from: com.google.android.gms.location.j */
public class C1070j implements Creator<GeofencingRequest> {
    /* renamed from: a */
    static void m4514a(GeofencingRequest geofencingRequest, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3661b(parcel, 1, geofencingRequest.m4328b(), false);
        C0907b.m3646a(parcel, 2, geofencingRequest.m4329c());
        C0907b.m3646a(parcel, 1000, geofencingRequest.m4327a());
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public GeofencingRequest m4515a(Parcel parcel) {
        int i = 0;
        int b = C0906a.m3626b(parcel);
        List list = null;
        int i2 = 0;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    list = C0906a.m3629c(parcel, a, ParcelableGeofence.CREATOR);
                    break;
                case 2:
                    i = C0906a.m3632e(parcel, a);
                    break;
                case 1000:
                    i2 = C0906a.m3632e(parcel, a);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new GeofencingRequest(i2, list, i);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public GeofencingRequest[] m4516a(int i) {
        return new GeofencingRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4515a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4516a(i);
    }
}

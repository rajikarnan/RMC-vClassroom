package com.google.android.gms.location.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;

/* renamed from: com.google.android.gms.location.internal.b */
public class C1042b implements Creator<ClientIdentity> {
    /* renamed from: a */
    static void m4407a(ClientIdentity clientIdentity, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3646a(parcel, 1, clientIdentity.f2191a);
        C0907b.m3652a(parcel, 2, clientIdentity.f2192b, false);
        C0907b.m3646a(parcel, 1000, clientIdentity.m4371a());
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public ClientIdentity m4408a(Parcel parcel) {
        int i = 0;
        int b = C0906a.m3626b(parcel);
        String str = null;
        int i2 = 0;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    i = C0906a.m3632e(parcel, a);
                    break;
                case 2:
                    str = C0906a.m3637j(parcel, a);
                    break;
                case 1000:
                    i2 = C0906a.m3632e(parcel, a);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new ClientIdentity(i2, i, str);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public ClientIdentity[] m4409a(int i) {
        return new ClientIdentity[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4408a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4409a(i);
    }
}

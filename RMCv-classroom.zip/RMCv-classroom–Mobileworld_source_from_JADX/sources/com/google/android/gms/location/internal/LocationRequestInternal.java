package com.google.android.gms.location.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.location.LocationRequest;
import java.util.Collections;
import java.util.List;

public class LocationRequestInternal extends AbstractSafeParcelable {
    public static final C1066l CREATOR = new C1066l();
    /* renamed from: a */
    static final List<ClientIdentity> f2197a = Collections.emptyList();
    /* renamed from: b */
    LocationRequest f2198b;
    /* renamed from: c */
    boolean f2199c;
    /* renamed from: d */
    List<ClientIdentity> f2200d;
    /* renamed from: e */
    String f2201e;
    /* renamed from: f */
    boolean f2202f;
    /* renamed from: g */
    private final int f2203g;

    LocationRequestInternal(int i, LocationRequest locationRequest, boolean z, List<ClientIdentity> list, String str, boolean z2) {
        this.f2203g = i;
        this.f2198b = locationRequest;
        this.f2199c = z;
        this.f2200d = list;
        this.f2201e = str;
        this.f2202f = z2;
    }

    /* renamed from: a */
    int m4374a() {
        return this.f2203g;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof LocationRequestInternal)) {
            return false;
        }
        LocationRequestInternal locationRequestInternal = (LocationRequestInternal) obj;
        return ab.m3426a(this.f2198b, locationRequestInternal.f2198b) && this.f2199c == locationRequestInternal.f2199c && this.f2202f == locationRequestInternal.f2202f && ab.m3426a(this.f2200d, locationRequestInternal.f2200d);
    }

    public int hashCode() {
        return this.f2198b.hashCode();
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.f2198b.toString());
        if (this.f2201e != null) {
            stringBuilder.append(" tag=").append(this.f2201e);
        }
        stringBuilder.append(" trigger=").append(this.f2199c);
        stringBuilder.append(" hideAppOps=").append(this.f2202f);
        stringBuilder.append(" clients=").append(this.f2200d);
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1066l.m4505a(this, parcel, i);
    }
}

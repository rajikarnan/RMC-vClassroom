package com.google.android.gms.location.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;

/* renamed from: com.google.android.gms.location.internal.d */
public class C1044d implements Creator<FusedLocationProviderResult> {
    /* renamed from: a */
    static void m4411a(FusedLocationProviderResult fusedLocationProviderResult, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3650a(parcel, 1, fusedLocationProviderResult.mo890a(), i, false);
        C0907b.m3646a(parcel, 1000, fusedLocationProviderResult.m4373b());
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public FusedLocationProviderResult m4412a(Parcel parcel) {
        int b = C0906a.m3626b(parcel);
        int i = 0;
        Status status = null;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    status = (Status) C0906a.m3623a(parcel, a, Status.CREATOR);
                    break;
                case 1000:
                    i = C0906a.m3632e(parcel, a);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new FusedLocationProviderResult(i, status);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public FusedLocationProviderResult[] m4413a(int i) {
        return new FusedLocationProviderResult[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4412a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4413a(i);
    }
}

package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.location.internal.ParcelableGeofence;
import java.util.List;

public class GeofencingRequest extends AbstractSafeParcelable {
    public static final Creator<GeofencingRequest> CREATOR = new C1070j();
    /* renamed from: a */
    private final int f2145a;
    /* renamed from: b */
    private final List<ParcelableGeofence> f2146b;
    /* renamed from: c */
    private final int f2147c;

    GeofencingRequest(int i, List<ParcelableGeofence> list, int i2) {
        this.f2145a = i;
        this.f2146b = list;
        this.f2147c = i2;
    }

    /* renamed from: a */
    public int m4327a() {
        return this.f2145a;
    }

    /* renamed from: b */
    public List<ParcelableGeofence> m4328b() {
        return this.f2146b;
    }

    /* renamed from: c */
    public int m4329c() {
        return this.f2147c;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1070j.m4514a(this, parcel, i);
    }
}

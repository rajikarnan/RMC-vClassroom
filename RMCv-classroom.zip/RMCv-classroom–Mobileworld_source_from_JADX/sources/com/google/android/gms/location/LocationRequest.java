package com.google.android.gms.location;

import android.os.Parcel;
import android.os.SystemClock;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public final class LocationRequest extends AbstractSafeParcelable {
    public static final C1034f CREATOR = new C1034f();
    /* renamed from: a */
    int f2159a;
    /* renamed from: b */
    long f2160b;
    /* renamed from: c */
    long f2161c;
    /* renamed from: d */
    boolean f2162d;
    /* renamed from: e */
    long f2163e;
    /* renamed from: f */
    int f2164f;
    /* renamed from: g */
    float f2165g;
    /* renamed from: h */
    long f2166h;
    /* renamed from: i */
    private final int f2167i;

    public LocationRequest() {
        this.f2167i = 1;
        this.f2159a = 102;
        this.f2160b = 3600000;
        this.f2161c = 600000;
        this.f2162d = false;
        this.f2163e = Long.MAX_VALUE;
        this.f2164f = ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED;
        this.f2165g = 0.0f;
        this.f2166h = 0;
    }

    LocationRequest(int i, int i2, long j, long j2, boolean z, long j3, int i3, float f, long j4) {
        this.f2167i = i;
        this.f2159a = i2;
        this.f2160b = j;
        this.f2161c = j2;
        this.f2162d = z;
        this.f2163e = j3;
        this.f2164f = i3;
        this.f2165g = f;
        this.f2166h = j4;
    }

    /* renamed from: a */
    public static String m4334a(int i) {
        switch (i) {
            case 100:
                return "PRIORITY_HIGH_ACCURACY";
            case 102:
                return "PRIORITY_BALANCED_POWER_ACCURACY";
            case 104:
                return "PRIORITY_LOW_POWER";
            case 105:
                return "PRIORITY_NO_POWER";
            default:
                return "???";
        }
    }

    /* renamed from: a */
    int m4335a() {
        return this.f2167i;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof LocationRequest)) {
            return false;
        }
        LocationRequest locationRequest = (LocationRequest) obj;
        return this.f2159a == locationRequest.f2159a && this.f2160b == locationRequest.f2160b && this.f2161c == locationRequest.f2161c && this.f2162d == locationRequest.f2162d && this.f2163e == locationRequest.f2163e && this.f2164f == locationRequest.f2164f && this.f2165g == locationRequest.f2165g;
    }

    public int hashCode() {
        return ab.m3424a(Integer.valueOf(this.f2159a), Long.valueOf(this.f2160b), Long.valueOf(this.f2161c), Boolean.valueOf(this.f2162d), Long.valueOf(this.f2163e), Integer.valueOf(this.f2164f), Float.valueOf(this.f2165g));
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Request[").append(m4334a(this.f2159a));
        if (this.f2159a != 105) {
            stringBuilder.append(" requested=");
            stringBuilder.append(this.f2160b).append("ms");
        }
        stringBuilder.append(" fastest=");
        stringBuilder.append(this.f2161c).append("ms");
        if (this.f2166h > this.f2160b) {
            stringBuilder.append(" maxWait=");
            stringBuilder.append(this.f2166h).append("ms");
        }
        if (this.f2163e != Long.MAX_VALUE) {
            long elapsedRealtime = this.f2163e - SystemClock.elapsedRealtime();
            stringBuilder.append(" expireIn=");
            stringBuilder.append(elapsedRealtime).append("ms");
        }
        if (this.f2164f != ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED) {
            stringBuilder.append(" num=").append(this.f2164f);
        }
        stringBuilder.append(']');
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1034f.m4362a(this, parcel, i);
    }
}

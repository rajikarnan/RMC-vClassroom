package com.google.android.gms.location.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class ClientIdentity extends AbstractSafeParcelable {
    public static final C1042b CREATOR = new C1042b();
    /* renamed from: a */
    public final int f2191a;
    /* renamed from: b */
    public final String f2192b;
    /* renamed from: c */
    private final int f2193c;

    ClientIdentity(int i, int i2, String str) {
        this.f2193c = i;
        this.f2191a = i2;
        this.f2192b = str;
    }

    /* renamed from: a */
    int m4371a() {
        return this.f2193c;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj == null || !(obj instanceof ClientIdentity)) {
            return false;
        }
        ClientIdentity clientIdentity = (ClientIdentity) obj;
        return clientIdentity.f2191a == this.f2191a && ab.m3426a(clientIdentity.f2192b, this.f2192b);
    }

    public int hashCode() {
        return this.f2191a;
    }

    public String toString() {
        return String.format("%d:%s", new Object[]{Integer.valueOf(this.f2191a), this.f2192b});
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1042b.m4407a(this, parcel, i);
    }
}

package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Collections;
import java.util.List;

public final class LocationSettingsRequest extends AbstractSafeParcelable {
    public static final Creator<LocationSettingsRequest> CREATOR = new C1075o();
    /* renamed from: a */
    private final int f2171a;
    /* renamed from: b */
    private final List<LocationRequest> f2172b;
    /* renamed from: c */
    private final boolean f2173c;
    /* renamed from: d */
    private final boolean f2174d;

    LocationSettingsRequest(int i, List<LocationRequest> list, boolean z, boolean z2) {
        this.f2171a = i;
        this.f2172b = list;
        this.f2173c = z;
        this.f2174d = z2;
    }

    /* renamed from: a */
    public int m4338a() {
        return this.f2171a;
    }

    /* renamed from: b */
    public List<LocationRequest> m4339b() {
        return Collections.unmodifiableList(this.f2172b);
    }

    /* renamed from: c */
    public boolean m4340c() {
        return this.f2173c;
    }

    /* renamed from: d */
    public boolean m4341d() {
        return this.f2174d;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1075o.m4526a(this, parcel, i);
    }
}

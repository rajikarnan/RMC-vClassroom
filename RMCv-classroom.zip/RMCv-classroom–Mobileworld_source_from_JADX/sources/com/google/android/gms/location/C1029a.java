package com.google.android.gms.location;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;
import java.util.List;

/* renamed from: com.google.android.gms.location.a */
public class C1029a implements Creator<ActivityRecognitionResult> {
    /* renamed from: a */
    static void m4352a(ActivityRecognitionResult activityRecognitionResult, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3661b(parcel, 1, activityRecognitionResult.f2133a, false);
        C0907b.m3647a(parcel, 2, activityRecognitionResult.f2134b);
        C0907b.m3647a(parcel, 3, activityRecognitionResult.f2135c);
        C0907b.m3646a(parcel, 4, activityRecognitionResult.f2136d);
        C0907b.m3648a(parcel, 5, activityRecognitionResult.f2137e, false);
        C0907b.m3646a(parcel, 1000, activityRecognitionResult.m4320a());
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public ActivityRecognitionResult m4353a(Parcel parcel) {
        long j = 0;
        Bundle bundle = null;
        int i = 0;
        int b = C0906a.m3626b(parcel);
        long j2 = 0;
        List list = null;
        int i2 = 0;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    list = C0906a.m3629c(parcel, a, DetectedActivity.CREATOR);
                    break;
                case 2:
                    j2 = C0906a.m3634g(parcel, a);
                    break;
                case 3:
                    j = C0906a.m3634g(parcel, a);
                    break;
                case 4:
                    i = C0906a.m3632e(parcel, a);
                    break;
                case 5:
                    bundle = C0906a.m3639l(parcel, a);
                    break;
                case 1000:
                    i2 = C0906a.m3632e(parcel, a);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new ActivityRecognitionResult(i2, list, j2, j, i, bundle);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public ActivityRecognitionResult[] m4354a(int i) {
        return new ActivityRecognitionResult[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4353a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4354a(i);
    }
}

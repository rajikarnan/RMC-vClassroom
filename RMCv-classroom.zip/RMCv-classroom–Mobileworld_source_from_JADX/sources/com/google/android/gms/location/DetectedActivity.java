package com.google.android.gms.location;

import android.os.Parcel;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Comparator;

public class DetectedActivity extends AbstractSafeParcelable {
    public static final C1030b CREATOR = new C1030b();
    /* renamed from: a */
    public static final Comparator<DetectedActivity> f2139a = new C10281();
    /* renamed from: b */
    public static final int[] f2140b = new int[]{9, 10};
    /* renamed from: c */
    public static final int[] f2141c = new int[]{0, 1, 2, 4, 5, 6, 7, 8, 10, 11, 12, 13, 14};
    /* renamed from: d */
    int f2142d;
    /* renamed from: e */
    int f2143e;
    /* renamed from: f */
    private final int f2144f;

    /* renamed from: com.google.android.gms.location.DetectedActivity$1 */
    class C10281 implements Comparator<DetectedActivity> {
        C10281() {
        }

        /* renamed from: a */
        public int m4321a(DetectedActivity detectedActivity, DetectedActivity detectedActivity2) {
            int compareTo = Integer.valueOf(detectedActivity2.m4325b()).compareTo(Integer.valueOf(detectedActivity.m4325b()));
            return compareTo == 0 ? Integer.valueOf(detectedActivity.m4324a()).compareTo(Integer.valueOf(detectedActivity2.m4324a())) : compareTo;
        }

        public /* synthetic */ int compare(Object obj, Object obj2) {
            return m4321a((DetectedActivity) obj, (DetectedActivity) obj2);
        }
    }

    public DetectedActivity(int i, int i2, int i3) {
        this.f2144f = i;
        this.f2142d = i2;
        this.f2143e = i3;
    }

    /* renamed from: a */
    public static String m4322a(int i) {
        switch (i) {
            case 0:
                return "IN_VEHICLE";
            case 1:
                return "ON_BICYCLE";
            case 2:
                return "ON_FOOT";
            case 3:
                return "STILL";
            case 4:
                return "UNKNOWN";
            case 5:
                return "TILTING";
            case 7:
                return "WALKING";
            case 8:
                return "RUNNING";
            default:
                return Integer.toString(i);
        }
    }

    /* renamed from: b */
    private int m4323b(int i) {
        return i > 15 ? 4 : i;
    }

    /* renamed from: a */
    public int m4324a() {
        return m4323b(this.f2142d);
    }

    /* renamed from: b */
    public int m4325b() {
        return this.f2143e;
    }

    /* renamed from: c */
    public int m4326c() {
        return this.f2144f;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        DetectedActivity detectedActivity = (DetectedActivity) obj;
        return this.f2142d == detectedActivity.f2142d && this.f2143e == detectedActivity.f2143e;
    }

    public int hashCode() {
        return ab.m3424a(Integer.valueOf(this.f2142d), Integer.valueOf(this.f2143e));
    }

    public String toString() {
        String valueOf = String.valueOf(m4322a(m4324a()));
        return new StringBuilder(String.valueOf(valueOf).length() + 48).append("DetectedActivity [type=").append(valueOf).append(", confidence=").append(this.f2143e).append("]").toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1030b.m4355a(this, parcel, i);
    }
}

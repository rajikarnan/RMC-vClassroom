package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public final class LocationSettingsStates extends AbstractSafeParcelable {
    public static final Creator<LocationSettingsStates> CREATOR = new C1077q();
    /* renamed from: a */
    private final int f2178a;
    /* renamed from: b */
    private final boolean f2179b;
    /* renamed from: c */
    private final boolean f2180c;
    /* renamed from: d */
    private final boolean f2181d;
    /* renamed from: e */
    private final boolean f2182e;
    /* renamed from: f */
    private final boolean f2183f;
    /* renamed from: g */
    private final boolean f2184g;

    LocationSettingsStates(int i, boolean z, boolean z2, boolean z3, boolean z4, boolean z5, boolean z6) {
        this.f2178a = i;
        this.f2179b = z;
        this.f2180c = z2;
        this.f2181d = z3;
        this.f2182e = z4;
        this.f2183f = z5;
        this.f2184g = z6;
    }

    /* renamed from: a */
    public int m4345a() {
        return this.f2178a;
    }

    /* renamed from: b */
    public boolean m4346b() {
        return this.f2179b;
    }

    /* renamed from: c */
    public boolean m4347c() {
        return this.f2182e;
    }

    /* renamed from: d */
    public boolean m4348d() {
        return this.f2180c;
    }

    /* renamed from: e */
    public boolean m4349e() {
        return this.f2183f;
    }

    /* renamed from: f */
    public boolean m4350f() {
        return this.f2181d;
    }

    /* renamed from: g */
    public boolean m4351g() {
        return this.f2184g;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1077q.m4532a(this, parcel, i);
    }
}

package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;

/* renamed from: com.google.android.gms.location.b */
public class C1030b implements Creator<DetectedActivity> {
    /* renamed from: a */
    static void m4355a(DetectedActivity detectedActivity, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3646a(parcel, 1, detectedActivity.f2142d);
        C0907b.m3646a(parcel, 2, detectedActivity.f2143e);
        C0907b.m3646a(parcel, 1000, detectedActivity.m4326c());
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public DetectedActivity m4356a(Parcel parcel) {
        int i = 0;
        int b = C0906a.m3626b(parcel);
        int i2 = 0;
        int i3 = 0;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    i2 = C0906a.m3632e(parcel, a);
                    break;
                case 2:
                    i = C0906a.m3632e(parcel, a);
                    break;
                case 1000:
                    i3 = C0906a.m3632e(parcel, a);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new DetectedActivity(i3, i2, i);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public DetectedActivity[] m4357a(int i) {
        return new DetectedActivity[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4356a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4357a(i);
    }
}

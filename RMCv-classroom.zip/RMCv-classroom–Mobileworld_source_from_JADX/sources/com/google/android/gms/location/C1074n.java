package com.google.android.gms.location;

import android.location.Location;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;
import java.util.List;

/* renamed from: com.google.android.gms.location.n */
public class C1074n implements Creator<LocationResult> {
    /* renamed from: a */
    static void m4523a(LocationResult locationResult, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3661b(parcel, 1, locationResult.m4336a(), false);
        C0907b.m3646a(parcel, 1000, locationResult.m4337b());
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public LocationResult m4524a(Parcel parcel) {
        int b = C0906a.m3626b(parcel);
        int i = 0;
        List list = LocationResult.f2168a;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    list = C0906a.m3629c(parcel, a, Location.CREATOR);
                    break;
                case 1000:
                    i = C0906a.m3632e(parcel, a);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new LocationResult(i, list);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public LocationResult[] m4525a(int i) {
        return new LocationResult[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4524a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4525a(i);
    }
}

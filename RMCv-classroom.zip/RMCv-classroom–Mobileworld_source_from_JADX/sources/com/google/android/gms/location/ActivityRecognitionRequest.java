package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.WorkSource;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class ActivityRecognitionRequest extends AbstractSafeParcelable {
    public static final Creator<ActivityRecognitionRequest> CREATOR = new C1038i();
    /* renamed from: a */
    private final int f2125a;
    /* renamed from: b */
    private long f2126b;
    /* renamed from: c */
    private boolean f2127c;
    /* renamed from: d */
    private WorkSource f2128d;
    /* renamed from: e */
    private String f2129e;
    /* renamed from: f */
    private int[] f2130f;
    /* renamed from: g */
    private boolean f2131g;
    /* renamed from: h */
    private String f2132h;

    ActivityRecognitionRequest(int i, long j, boolean z, WorkSource workSource, String str, int[] iArr, boolean z2, String str2) {
        this.f2125a = i;
        this.f2126b = j;
        this.f2127c = z;
        this.f2128d = workSource;
        this.f2129e = str;
        this.f2130f = iArr;
        this.f2131g = z2;
        this.f2132h = str2;
    }

    /* renamed from: a */
    public long m4311a() {
        return this.f2126b;
    }

    /* renamed from: b */
    public boolean m4312b() {
        return this.f2127c;
    }

    /* renamed from: c */
    public WorkSource m4313c() {
        return this.f2128d;
    }

    /* renamed from: d */
    public String m4314d() {
        return this.f2129e;
    }

    /* renamed from: e */
    public int[] m4315e() {
        return this.f2130f;
    }

    /* renamed from: f */
    public boolean m4316f() {
        return this.f2131g;
    }

    /* renamed from: g */
    public String m4317g() {
        return this.f2132h;
    }

    /* renamed from: h */
    int m4318h() {
        return this.f2125a;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1038i.m4368a(this, parcel, i);
    }
}

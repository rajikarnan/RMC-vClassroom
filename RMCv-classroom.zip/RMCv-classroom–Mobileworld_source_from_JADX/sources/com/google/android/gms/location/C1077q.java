package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;

/* renamed from: com.google.android.gms.location.q */
public class C1077q implements Creator<LocationSettingsStates> {
    /* renamed from: a */
    static void m4532a(LocationSettingsStates locationSettingsStates, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3655a(parcel, 1, locationSettingsStates.m4346b());
        C0907b.m3655a(parcel, 2, locationSettingsStates.m4348d());
        C0907b.m3655a(parcel, 3, locationSettingsStates.m4350f());
        C0907b.m3655a(parcel, 4, locationSettingsStates.m4347c());
        C0907b.m3655a(parcel, 5, locationSettingsStates.m4349e());
        C0907b.m3655a(parcel, 6, locationSettingsStates.m4351g());
        C0907b.m3646a(parcel, 1000, locationSettingsStates.m4345a());
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public LocationSettingsStates m4533a(Parcel parcel) {
        boolean z = false;
        int b = C0906a.m3626b(parcel);
        boolean z2 = false;
        boolean z3 = false;
        boolean z4 = false;
        boolean z5 = false;
        boolean z6 = false;
        int i = 0;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    z6 = C0906a.m3630c(parcel, a);
                    break;
                case 2:
                    z5 = C0906a.m3630c(parcel, a);
                    break;
                case 3:
                    z4 = C0906a.m3630c(parcel, a);
                    break;
                case 4:
                    z3 = C0906a.m3630c(parcel, a);
                    break;
                case 5:
                    z2 = C0906a.m3630c(parcel, a);
                    break;
                case 6:
                    z = C0906a.m3630c(parcel, a);
                    break;
                case 1000:
                    i = C0906a.m3632e(parcel, a);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new LocationSettingsStates(i, z6, z5, z4, z3, z2, z);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public LocationSettingsStates[] m4534a(int i) {
        return new LocationSettingsStates[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4533a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4534a(i);
    }
}

package com.google.android.gms.location.internal;

import android.annotation.SuppressLint;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Locale;

public class ParcelableGeofence extends AbstractSafeParcelable {
    public static final C1068n CREATOR = new C1068n();
    /* renamed from: a */
    private final int f2211a;
    /* renamed from: b */
    private final String f2212b;
    /* renamed from: c */
    private final long f2213c;
    /* renamed from: d */
    private final short f2214d;
    /* renamed from: e */
    private final double f2215e;
    /* renamed from: f */
    private final double f2216f;
    /* renamed from: g */
    private final float f2217g;
    /* renamed from: h */
    private final int f2218h;
    /* renamed from: i */
    private final int f2219i;
    /* renamed from: j */
    private final int f2220j;

    public ParcelableGeofence(int i, String str, int i2, short s, double d, double d2, float f, long j, int i3, int i4) {
        m4384a(str);
        m4383a(f);
        m4382a(d, d2);
        int a = m4381a(i2);
        this.f2211a = i;
        this.f2214d = s;
        this.f2212b = str;
        this.f2215e = d;
        this.f2216f = d2;
        this.f2217g = f;
        this.f2213c = j;
        this.f2218h = a;
        this.f2219i = i3;
        this.f2220j = i4;
    }

    /* renamed from: a */
    private static int m4381a(int i) {
        int i2 = i & 7;
        if (i2 != 0) {
            return i2;
        }
        throw new IllegalArgumentException("No supported transition specified: " + i);
    }

    /* renamed from: a */
    private static void m4382a(double d, double d2) {
        if (d > 90.0d || d < -90.0d) {
            throw new IllegalArgumentException("invalid latitude: " + d);
        } else if (d2 > 180.0d || d2 < -180.0d) {
            throw new IllegalArgumentException("invalid longitude: " + d2);
        }
    }

    /* renamed from: a */
    private static void m4383a(float f) {
        if (f <= 0.0f) {
            throw new IllegalArgumentException("invalid radius: " + f);
        }
    }

    /* renamed from: a */
    private static void m4384a(String str) {
        if (str == null || str.length() > 100) {
            String str2 = "requestId is null or too long: ";
            String valueOf = String.valueOf(str);
            throw new IllegalArgumentException(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
        }
    }

    @SuppressLint({"DefaultLocale"})
    /* renamed from: b */
    private static String m4385b(int i) {
        switch (i) {
            case 1:
                return "CIRCLE";
            default:
                return null;
        }
    }

    /* renamed from: a */
    public int m4386a() {
        return this.f2211a;
    }

    /* renamed from: b */
    public short m4387b() {
        return this.f2214d;
    }

    /* renamed from: c */
    public double m4388c() {
        return this.f2215e;
    }

    /* renamed from: d */
    public double m4389d() {
        return this.f2216f;
    }

    /* renamed from: e */
    public float m4390e() {
        return this.f2217g;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof ParcelableGeofence)) {
            return false;
        }
        ParcelableGeofence parcelableGeofence = (ParcelableGeofence) obj;
        return this.f2217g != parcelableGeofence.f2217g ? false : this.f2215e != parcelableGeofence.f2215e ? false : this.f2216f != parcelableGeofence.f2216f ? false : this.f2214d == parcelableGeofence.f2214d;
    }

    /* renamed from: f */
    public String m4391f() {
        return this.f2212b;
    }

    /* renamed from: g */
    public long m4392g() {
        return this.f2213c;
    }

    /* renamed from: h */
    public int m4393h() {
        return this.f2218h;
    }

    public int hashCode() {
        long doubleToLongBits = Double.doubleToLongBits(this.f2215e);
        int i = ((int) (doubleToLongBits ^ (doubleToLongBits >>> 32))) + 31;
        long doubleToLongBits2 = Double.doubleToLongBits(this.f2216f);
        return (((((((i * 31) + ((int) (doubleToLongBits2 ^ (doubleToLongBits2 >>> 32)))) * 31) + Float.floatToIntBits(this.f2217g)) * 31) + this.f2214d) * 31) + this.f2218h;
    }

    /* renamed from: i */
    public int m4394i() {
        return this.f2219i;
    }

    /* renamed from: j */
    public int m4395j() {
        return this.f2220j;
    }

    public String toString() {
        return String.format(Locale.US, "Geofence[%s id:%s transitions:%d %.6f, %.6f %.0fm, resp=%ds, dwell=%dms, @%d]", new Object[]{m4385b(this.f2214d), this.f2212b, Integer.valueOf(this.f2218h), Double.valueOf(this.f2215e), Double.valueOf(this.f2216f), Float.valueOf(this.f2217g), Integer.valueOf(this.f2219i / 1000), Integer.valueOf(this.f2220j), Long.valueOf(this.f2213c)});
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1068n c1068n = CREATOR;
        C1068n.m4511a(this, parcel, i);
    }
}

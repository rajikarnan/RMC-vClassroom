package com.google.android.gms.location;

import android.location.Location;
import com.google.android.gms.common.api.GoogleApiClient;

/* renamed from: com.google.android.gms.location.c */
public interface C1031c {
    /* renamed from: a */
    Location mo1053a(GoogleApiClient googleApiClient);
}

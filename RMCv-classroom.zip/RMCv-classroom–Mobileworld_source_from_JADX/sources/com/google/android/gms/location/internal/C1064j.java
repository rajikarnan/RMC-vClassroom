package com.google.android.gms.location.internal;

import android.content.ContentProviderClient;
import android.content.Context;
import android.location.Location;
import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.location.C1058l;
import com.google.android.gms.location.C1058l.C1059a;
import com.google.android.gms.location.C1061m;
import com.google.android.gms.location.C1061m.C1062a;
import com.google.android.gms.location.LocationAvailability;
import com.google.android.gms.location.LocationResult;
import java.util.HashMap;
import java.util.Map;

/* renamed from: com.google.android.gms.location.internal.j */
public class C1064j {
    /* renamed from: a */
    private final C1039o<C1052h> f2230a;
    /* renamed from: b */
    private final Context f2231b;
    /* renamed from: c */
    private ContentProviderClient f2232c = null;
    /* renamed from: d */
    private boolean f2233d = false;
    /* renamed from: e */
    private Map<Object, C1063b> f2234e = new HashMap();
    /* renamed from: f */
    private Map<Object, C1060a> f2235f = new HashMap();

    /* renamed from: com.google.android.gms.location.internal.j$a */
    private static class C1060a extends C1059a {
        /* renamed from: a */
        private Handler f2228a;

        /* renamed from: a */
        private void m4493a(int i, Object obj) {
            if (this.f2228a == null) {
                Log.e("LocationClientHelper", "Received a data in client after calling removeLocationUpdates.");
                return;
            }
            Message obtain = Message.obtain();
            obtain.what = i;
            obtain.obj = obj;
            this.f2228a.sendMessage(obtain);
        }

        /* renamed from: a */
        public void mo1090a(LocationAvailability locationAvailability) {
            m4493a(1, locationAvailability);
        }

        /* renamed from: a */
        public void mo1091a(LocationResult locationResult) {
            m4493a(0, locationResult);
        }
    }

    /* renamed from: com.google.android.gms.location.internal.j$b */
    private static class C1063b extends C1062a {
        /* renamed from: a */
        private Handler f2229a;

        /* renamed from: a */
        public void mo1092a(Location location) {
            if (this.f2229a == null) {
                Log.e("LocationClientHelper", "Received a location in client after calling removeLocationUpdates.");
                return;
            }
            Message obtain = Message.obtain();
            obtain.what = 1;
            obtain.obj = location;
            this.f2229a.sendMessage(obtain);
        }
    }

    public C1064j(Context context, C1039o<C1052h> c1039o) {
        this.f2231b = context;
        this.f2230a = c1039o;
    }

    /* renamed from: a */
    public Location m4499a() {
        this.f2230a.mo1050a();
        try {
            return ((C1052h) this.f2230a.mo1051c()).mo1082b(this.f2231b.getPackageName());
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    /* renamed from: a */
    public void m4500a(boolean z) throws RemoteException {
        this.f2230a.mo1050a();
        ((C1052h) this.f2230a.mo1051c()).mo1080a(z);
        this.f2233d = z;
    }

    /* renamed from: b */
    public void m4501b() {
        try {
            synchronized (this.f2234e) {
                for (C1061m c1061m : this.f2234e.values()) {
                    if (c1061m != null) {
                        ((C1052h) this.f2230a.mo1051c()).mo1075a(LocationRequestUpdateData.m4376a(c1061m, null));
                    }
                }
                this.f2234e.clear();
            }
            synchronized (this.f2235f) {
                for (C1058l c1058l : this.f2235f.values()) {
                    if (c1058l != null) {
                        ((C1052h) this.f2230a.mo1051c()).mo1075a(LocationRequestUpdateData.m4375a(c1058l, null));
                    }
                }
                this.f2235f.clear();
            }
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    /* renamed from: c */
    public void m4502c() {
        if (this.f2233d) {
            try {
                m4500a(false);
            } catch (Throwable e) {
                throw new IllegalStateException(e);
            }
        }
    }
}

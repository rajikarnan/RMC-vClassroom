package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;

/* renamed from: com.google.android.gms.location.f */
public class C1034f implements Creator<LocationRequest> {
    /* renamed from: a */
    static void m4362a(LocationRequest locationRequest, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3646a(parcel, 1, locationRequest.f2159a);
        C0907b.m3647a(parcel, 2, locationRequest.f2160b);
        C0907b.m3647a(parcel, 3, locationRequest.f2161c);
        C0907b.m3655a(parcel, 4, locationRequest.f2162d);
        C0907b.m3647a(parcel, 5, locationRequest.f2163e);
        C0907b.m3646a(parcel, 6, locationRequest.f2164f);
        C0907b.m3645a(parcel, 7, locationRequest.f2165g);
        C0907b.m3646a(parcel, 1000, locationRequest.m4335a());
        C0907b.m3647a(parcel, 8, locationRequest.f2166h);
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public LocationRequest m4363a(Parcel parcel) {
        int b = C0906a.m3626b(parcel);
        int i = 0;
        int i2 = 102;
        long j = 3600000;
        long j2 = 600000;
        boolean z = false;
        long j3 = Long.MAX_VALUE;
        int i3 = ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED;
        float f = 0.0f;
        long j4 = 0;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    i2 = C0906a.m3632e(parcel, a);
                    break;
                case 2:
                    j = C0906a.m3634g(parcel, a);
                    break;
                case 3:
                    j2 = C0906a.m3634g(parcel, a);
                    break;
                case 4:
                    z = C0906a.m3630c(parcel, a);
                    break;
                case 5:
                    j3 = C0906a.m3634g(parcel, a);
                    break;
                case 6:
                    i3 = C0906a.m3632e(parcel, a);
                    break;
                case 7:
                    f = C0906a.m3635h(parcel, a);
                    break;
                case 8:
                    j4 = C0906a.m3634g(parcel, a);
                    break;
                case 1000:
                    i = C0906a.m3632e(parcel, a);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new LocationRequest(i, i2, j, j2, z, j3, i3, f, j4);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public LocationRequest[] m4364a(int i) {
        return new LocationRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4363a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4364a(i);
    }
}

package com.google.android.gms.location;

import android.os.Bundle;
import android.os.Parcel;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.List;

public class ActivityRecognitionResult extends AbstractSafeParcelable {
    public static final C1029a CREATOR = new C1029a();
    /* renamed from: a */
    List<DetectedActivity> f2133a;
    /* renamed from: b */
    long f2134b;
    /* renamed from: c */
    long f2135c;
    /* renamed from: d */
    int f2136d;
    /* renamed from: e */
    Bundle f2137e;
    /* renamed from: f */
    private final int f2138f;

    public ActivityRecognitionResult(int i, List<DetectedActivity> list, long j, long j2, int i2, Bundle bundle) {
        this.f2138f = i;
        this.f2133a = list;
        this.f2134b = j;
        this.f2135c = j2;
        this.f2136d = i2;
        this.f2137e = bundle;
    }

    /* renamed from: a */
    private static boolean m4319a(Bundle bundle, Bundle bundle2) {
        if (bundle == null && bundle2 == null) {
            return true;
        }
        if ((bundle == null && bundle2 != null) || (bundle != null && bundle2 == null)) {
            return false;
        }
        if (bundle.size() != bundle2.size()) {
            return false;
        }
        for (String str : bundle.keySet()) {
            if (!bundle2.containsKey(str)) {
                return false;
            }
            if (bundle.get(str) == null) {
                if (bundle2.get(str) != null) {
                    return false;
                }
            } else if (bundle.get(str) instanceof Bundle) {
                if (!m4319a(bundle.getBundle(str), bundle2.getBundle(str))) {
                    return false;
                }
            } else if (!bundle.get(str).equals(bundle2.get(str))) {
                return false;
            }
        }
        return true;
    }

    /* renamed from: a */
    public int m4320a() {
        return this.f2138f;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        ActivityRecognitionResult activityRecognitionResult = (ActivityRecognitionResult) obj;
        return this.f2134b == activityRecognitionResult.f2134b && this.f2135c == activityRecognitionResult.f2135c && this.f2136d == activityRecognitionResult.f2136d && ab.m3426a(this.f2133a, activityRecognitionResult.f2133a) && m4319a(this.f2137e, activityRecognitionResult.f2137e);
    }

    public int hashCode() {
        return ab.m3424a(Long.valueOf(this.f2134b), Long.valueOf(this.f2135c), Integer.valueOf(this.f2136d), this.f2133a, this.f2137e);
    }

    public String toString() {
        String valueOf = String.valueOf(this.f2133a);
        long j = this.f2134b;
        return new StringBuilder(String.valueOf(valueOf).length() + 124).append("ActivityRecognitionResult [probableActivities=").append(valueOf).append(", timeMillis=").append(j).append(", elapsedRealtimeMillis=").append(this.f2135c).append("]").toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1029a.m4352a(this, parcel, i);
    }
}

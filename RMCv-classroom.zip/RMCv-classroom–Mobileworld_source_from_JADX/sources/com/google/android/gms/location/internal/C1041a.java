package com.google.android.gms.location.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import com.google.android.gms.common.api.GoogleApiClient.C0807b;
import com.google.android.gms.common.api.GoogleApiClient.C0808c;
import com.google.android.gms.common.internal.C0859p;
import com.google.android.gms.common.internal.C0890l;
import com.google.android.gms.location.internal.C1052h.C1054a;

/* renamed from: com.google.android.gms.location.internal.a */
public class C1041a extends C0859p<C1052h> {
    /* renamed from: d */
    protected final C1039o<C1052h> f2222d = new C10401(this);
    /* renamed from: e */
    private final String f2223e;

    /* renamed from: com.google.android.gms.location.internal.a$1 */
    class C10401 implements C1039o<C1052h> {
        /* renamed from: a */
        final /* synthetic */ C1041a f2221a;

        C10401(C1041a c1041a) {
            this.f2221a = c1041a;
        }

        /* renamed from: a */
        public void mo1050a() {
            this.f2221a.m3481r();
        }

        /* renamed from: b */
        public C1052h m4399b() throws DeadObjectException {
            return (C1052h) this.f2221a.m3483t();
        }

        /* renamed from: c */
        public /* synthetic */ IInterface mo1051c() throws DeadObjectException {
            return m4399b();
        }
    }

    public C1041a(Context context, Looper looper, C0807b c0807b, C0808c c0808c, String str, C0890l c0890l) {
        super(context, looper, 23, c0890l, c0807b, c0808c);
        this.f2223e = str;
    }

    /* renamed from: a */
    protected /* synthetic */ IInterface mo903a(IBinder iBinder) {
        return m4403b(iBinder);
    }

    /* renamed from: b */
    protected C1052h m4403b(IBinder iBinder) {
        return C1054a.m4486a(iBinder);
    }

    /* renamed from: i */
    protected String mo905i() {
        return "com.google.android.location.internal.GoogleLocationManagerService.START";
    }

    /* renamed from: j */
    protected String mo906j() {
        return "com.google.android.gms.location.internal.IGoogleLocationManagerService";
    }

    /* renamed from: q */
    protected Bundle mo1052q() {
        Bundle bundle = new Bundle();
        bundle.putString("client_name", this.f2223e);
        return bundle;
    }
}

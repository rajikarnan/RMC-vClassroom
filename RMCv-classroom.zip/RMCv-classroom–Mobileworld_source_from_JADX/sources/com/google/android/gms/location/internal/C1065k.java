package com.google.android.gms.location.internal;

import android.content.Context;
import android.location.Location;
import android.os.Looper;
import android.util.Log;
import com.google.android.gms.common.api.GoogleApiClient.C0807b;
import com.google.android.gms.common.api.GoogleApiClient.C0808c;
import com.google.android.gms.common.internal.C0890l;

/* renamed from: com.google.android.gms.location.internal.k */
public class C1065k extends C1041a {
    /* renamed from: e */
    private final C1064j f2236e;

    public C1065k(Context context, Looper looper, C0807b c0807b, C0808c c0808c, String str, C0890l c0890l) {
        super(context, looper, c0807b, c0808c, str, c0890l);
        this.f2236e = new C1064j(context, this.d);
    }

    /* renamed from: a */
    public void mo1093a() {
        synchronized (this.f2236e) {
            if (m3467b()) {
                try {
                    this.f2236e.m4501b();
                    this.f2236e.m4502c();
                } catch (Throwable e) {
                    Log.e("LocationClientImpl", "Client disconnected before listeners could be cleaned up", e);
                }
            }
            super.mo1093a();
        }
    }

    /* renamed from: k */
    public Location mo907k() {
        return this.f2236e.m4499a();
    }
}

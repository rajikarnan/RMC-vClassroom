package com.google.android.gms.location;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

/* renamed from: com.google.android.gms.location.l */
public interface C1058l extends IInterface {

    /* renamed from: com.google.android.gms.location.l$a */
    public static abstract class C1059a extends Binder implements C1058l {

        /* renamed from: com.google.android.gms.location.l$a$a */
        private static class C1072a implements C1058l {
            /* renamed from: a */
            private IBinder f2237a;

            C1072a(IBinder iBinder) {
                this.f2237a = iBinder;
            }

            /* renamed from: a */
            public void mo1090a(LocationAvailability locationAvailability) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.ILocationCallback");
                    if (locationAvailability != null) {
                        obtain.writeInt(1);
                        locationAvailability.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.f2237a.transact(2, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            /* renamed from: a */
            public void mo1091a(LocationResult locationResult) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.ILocationCallback");
                    if (locationResult != null) {
                        obtain.writeInt(1);
                        locationResult.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.f2237a.transact(1, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public IBinder asBinder() {
                return this.f2237a;
            }
        }

        /* renamed from: a */
        public static C1058l m4492a(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.location.ILocationCallback");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof C1058l)) ? new C1072a(iBinder) : (C1058l) queryLocalInterface;
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            LocationAvailability locationAvailability = null;
            switch (i) {
                case 1:
                    LocationResult locationResult;
                    parcel.enforceInterface("com.google.android.gms.location.ILocationCallback");
                    if (parcel.readInt() != 0) {
                        locationResult = (LocationResult) LocationResult.CREATOR.createFromParcel(parcel);
                    }
                    mo1091a(locationResult);
                    return true;
                case 2:
                    parcel.enforceInterface("com.google.android.gms.location.ILocationCallback");
                    if (parcel.readInt() != 0) {
                        locationAvailability = (LocationAvailability) LocationAvailability.CREATOR.createFromParcel(parcel);
                    }
                    mo1090a(locationAvailability);
                    return true;
                case 1598968902:
                    parcel2.writeString("com.google.android.gms.location.ILocationCallback");
                    return true;
                default:
                    return super.onTransact(i, parcel, parcel2, i2);
            }
        }
    }

    /* renamed from: a */
    void mo1090a(LocationAvailability locationAvailability) throws RemoteException;

    /* renamed from: a */
    void mo1091a(LocationResult locationResult) throws RemoteException;
}

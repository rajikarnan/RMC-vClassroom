package com.google.android.gms.location.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.C0809e;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public final class FusedLocationProviderResult extends AbstractSafeParcelable implements C0809e {
    public static final Creator<FusedLocationProviderResult> CREATOR = new C1044d();
    /* renamed from: a */
    public static final FusedLocationProviderResult f2194a = new FusedLocationProviderResult(Status.f1568a);
    /* renamed from: b */
    private final int f2195b;
    /* renamed from: c */
    private final Status f2196c;

    FusedLocationProviderResult(int i, Status status) {
        this.f2195b = i;
        this.f2196c = status;
    }

    public FusedLocationProviderResult(Status status) {
        this(1, status);
    }

    /* renamed from: a */
    public Status mo890a() {
        return this.f2196c;
    }

    /* renamed from: b */
    public int m4373b() {
        return this.f2195b;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1044d.m4411a(this, parcel, i);
    }
}

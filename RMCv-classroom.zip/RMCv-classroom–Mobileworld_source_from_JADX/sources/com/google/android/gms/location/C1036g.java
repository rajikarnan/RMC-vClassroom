package com.google.android.gms.location;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.api.C0824a;
import com.google.android.gms.common.api.C0824a.C0810a.C0813b;
import com.google.android.gms.common.api.C0824a.C0816b;
import com.google.android.gms.common.api.C0824a.C0819f;
import com.google.android.gms.common.api.C0824a.C0820g;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.C0807b;
import com.google.android.gms.common.api.GoogleApiClient.C0808c;
import com.google.android.gms.common.internal.C0854b;
import com.google.android.gms.common.internal.C0890l;
import com.google.android.gms.location.internal.C1043c;
import com.google.android.gms.location.internal.C1045e;
import com.google.android.gms.location.internal.C1065k;
import com.google.android.gms.location.internal.C1069p;

/* renamed from: com.google.android.gms.location.g */
public class C1036g {
    /* renamed from: a */
    public static final C0824a<C0813b> f2185a = new C0824a("LocationServices.API", f2190f, f2189e);
    /* renamed from: b */
    public static final C1031c f2186b = new C1043c();
    /* renamed from: c */
    public static final C1032d f2187c = new C1045e();
    /* renamed from: d */
    public static final C1037h f2188d = new C1069p();
    /* renamed from: e */
    private static final C0820g<C1065k> f2189e = new C0820g();
    /* renamed from: f */
    private static final C0816b<C1065k, C0813b> f2190f = new C10351();

    /* renamed from: com.google.android.gms.location.g$1 */
    class C10351 extends C0816b<C1065k, C0813b> {
        C10351() {
        }

        /* renamed from: a */
        public /* synthetic */ C0819f mo987a(Context context, Looper looper, C0890l c0890l, Object obj, C0807b c0807b, C0808c c0808c) {
            return m4366a(context, looper, c0890l, (C0813b) obj, c0807b, c0808c);
        }

        /* renamed from: a */
        public C1065k m4366a(Context context, Looper looper, C0890l c0890l, C0813b c0813b, C0807b c0807b, C0808c c0808c) {
            return new C1065k(context, looper, c0807b, c0808c, "locationServices", c0890l);
        }
    }

    /* renamed from: a */
    public static C1065k m4367a(GoogleApiClient googleApiClient) {
        boolean z = true;
        C0854b.m3436b(googleApiClient != null, "GoogleApiClient parameter is required.");
        C1065k c1065k = (C1065k) googleApiClient.mo1038a(f2189e);
        if (c1065k == null) {
            z = false;
        }
        C0854b.m3432a(z, (Object) "GoogleApiClient is not configured to use the LocationServices.API Api. Pass thisinto GoogleApiClient.Builder#addApi() to use this feature.");
        return c1065k;
    }
}

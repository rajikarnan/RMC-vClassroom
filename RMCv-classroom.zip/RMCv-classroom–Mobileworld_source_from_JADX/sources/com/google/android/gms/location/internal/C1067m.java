package com.google.android.gms.location.internal;

import android.app.PendingIntent;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;

/* renamed from: com.google.android.gms.location.internal.m */
public class C1067m implements Creator<LocationRequestUpdateData> {
    /* renamed from: a */
    static void m4508a(LocationRequestUpdateData locationRequestUpdateData, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3646a(parcel, 1, locationRequestUpdateData.f2204a);
        C0907b.m3650a(parcel, 2, locationRequestUpdateData.f2205b, i, false);
        C0907b.m3649a(parcel, 3, locationRequestUpdateData.m4378b(), false);
        C0907b.m3650a(parcel, 4, locationRequestUpdateData.f2207d, i, false);
        C0907b.m3649a(parcel, 5, locationRequestUpdateData.m4379c(), false);
        C0907b.m3649a(parcel, 6, locationRequestUpdateData.m4380d(), false);
        C0907b.m3646a(parcel, 1000, locationRequestUpdateData.m4377a());
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public LocationRequestUpdateData m4509a(Parcel parcel) {
        IBinder iBinder = null;
        int b = C0906a.m3626b(parcel);
        int i = 0;
        int i2 = 1;
        IBinder iBinder2 = null;
        PendingIntent pendingIntent = null;
        IBinder iBinder3 = null;
        LocationRequestInternal locationRequestInternal = null;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    i2 = C0906a.m3632e(parcel, a);
                    break;
                case 2:
                    locationRequestInternal = (LocationRequestInternal) C0906a.m3623a(parcel, a, LocationRequestInternal.CREATOR);
                    break;
                case 3:
                    iBinder3 = C0906a.m3638k(parcel, a);
                    break;
                case 4:
                    pendingIntent = (PendingIntent) C0906a.m3623a(parcel, a, PendingIntent.CREATOR);
                    break;
                case 5:
                    iBinder2 = C0906a.m3638k(parcel, a);
                    break;
                case 6:
                    iBinder = C0906a.m3638k(parcel, a);
                    break;
                case 1000:
                    i = C0906a.m3632e(parcel, a);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new LocationRequestUpdateData(i, i2, locationRequestInternal, iBinder3, pendingIntent, iBinder2, iBinder);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public LocationRequestUpdateData[] m4510a(int i) {
        return new LocationRequestUpdateData[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4509a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4510a(i);
    }
}

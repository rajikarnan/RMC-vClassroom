package com.google.android.gms.location;

import android.os.Parcel;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public final class LocationAvailability extends AbstractSafeParcelable {
    public static final C1033e CREATOR = new C1033e();
    /* renamed from: a */
    int f2154a;
    /* renamed from: b */
    int f2155b;
    /* renamed from: c */
    long f2156c;
    /* renamed from: d */
    int f2157d;
    /* renamed from: e */
    private final int f2158e;

    LocationAvailability(int i, int i2, int i3, int i4, long j) {
        this.f2158e = i;
        this.f2157d = i2;
        this.f2154a = i3;
        this.f2155b = i4;
        this.f2156c = j;
    }

    /* renamed from: a */
    public boolean m4332a() {
        return this.f2157d < 1000;
    }

    /* renamed from: b */
    int m4333b() {
        return this.f2158e;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof LocationAvailability)) {
            return false;
        }
        LocationAvailability locationAvailability = (LocationAvailability) obj;
        return this.f2157d == locationAvailability.f2157d && this.f2154a == locationAvailability.f2154a && this.f2155b == locationAvailability.f2155b && this.f2156c == locationAvailability.f2156c;
    }

    public int hashCode() {
        return ab.m3424a(Integer.valueOf(this.f2157d), Integer.valueOf(this.f2154a), Integer.valueOf(this.f2155b), Long.valueOf(this.f2156c));
    }

    public String toString() {
        return "LocationAvailability[isLocationAvailable: " + m4332a() + "]";
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1033e.m4359a(this, parcel, i);
    }
}

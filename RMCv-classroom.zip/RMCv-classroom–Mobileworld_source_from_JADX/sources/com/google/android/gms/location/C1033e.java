package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;

/* renamed from: com.google.android.gms.location.e */
public class C1033e implements Creator<LocationAvailability> {
    /* renamed from: a */
    static void m4359a(LocationAvailability locationAvailability, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3646a(parcel, 1, locationAvailability.f2154a);
        C0907b.m3646a(parcel, 2, locationAvailability.f2155b);
        C0907b.m3647a(parcel, 3, locationAvailability.f2156c);
        C0907b.m3646a(parcel, 4, locationAvailability.f2157d);
        C0907b.m3646a(parcel, 1000, locationAvailability.m4333b());
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public LocationAvailability m4360a(Parcel parcel) {
        int i = 1;
        int b = C0906a.m3626b(parcel);
        int i2 = 0;
        int i3 = 1000;
        long j = 0;
        int i4 = 1;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    i4 = C0906a.m3632e(parcel, a);
                    break;
                case 2:
                    i = C0906a.m3632e(parcel, a);
                    break;
                case 3:
                    j = C0906a.m3634g(parcel, a);
                    break;
                case 4:
                    i3 = C0906a.m3632e(parcel, a);
                    break;
                case 1000:
                    i2 = C0906a.m3632e(parcel, a);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new LocationAvailability(i2, i3, i4, i, j);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public LocationAvailability[] m4361a(int i) {
        return new LocationAvailability[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4360a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4361a(i);
    }
}

package com.google.android.gms.p023d;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

/* renamed from: com.google.android.gms.d.v */
public final class C1013v extends BroadcastReceiver {
    /* renamed from: a */
    protected Context f2084a;
    /* renamed from: b */
    private final C0967a f2085b;

    /* renamed from: com.google.android.gms.d.v$a */
    public static abstract class C0967a {
        /* renamed from: a */
        public abstract void mo1009a();
    }

    public C1013v(C0967a c0967a) {
        this.f2085b = c0967a;
    }

    /* renamed from: a */
    public synchronized void m4242a() {
        if (this.f2084a != null) {
            this.f2084a.unregisterReceiver(this);
        }
        this.f2084a = null;
    }

    /* renamed from: a */
    public void m4243a(Context context) {
        this.f2084a = context;
    }

    public void onReceive(Context context, Intent intent) {
        Uri data = intent.getData();
        Object obj = null;
        if (data != null) {
            obj = data.getSchemeSpecificPart();
        }
        if ("com.google.android.gms".equals(obj)) {
            this.f2085b.mo1009a();
            m4242a();
        }
    }
}

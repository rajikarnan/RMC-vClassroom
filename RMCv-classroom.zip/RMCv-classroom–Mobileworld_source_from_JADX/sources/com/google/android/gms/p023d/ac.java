package com.google.android.gms.p023d;

/* renamed from: com.google.android.gms.d.ac */
public interface ac {
    /* renamed from: a */
    Object m3830a();
}

package com.google.android.gms.p023d;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* renamed from: com.google.android.gms.d.t */
public abstract class C1007t {
    /* renamed from: a */
    private static final ExecutorService f2049a = Executors.newFixedThreadPool(2, new am("GAC_Executor"));

    /* renamed from: a */
    public static ExecutorService m4187a() {
        return f2049a;
    }
}

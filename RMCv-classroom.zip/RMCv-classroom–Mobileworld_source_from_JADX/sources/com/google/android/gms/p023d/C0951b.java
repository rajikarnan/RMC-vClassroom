package com.google.android.gms.p023d;

import android.content.Context;
import com.google.firebase.C1089a;
import java.util.concurrent.atomic.AtomicReference;

/* renamed from: com.google.android.gms.d.b */
public class C0951b {
    /* renamed from: a */
    private static final AtomicReference<C0951b> f1898a = new AtomicReference();

    C0951b(Context context) {
    }

    /* renamed from: a */
    public static C0951b m3908a(Context context) {
        f1898a.compareAndSet(null, new C0951b(context));
        return (C0951b) f1898a.get();
    }

    /* renamed from: a */
    public void m3909a(C1089a c1089a) {
    }
}

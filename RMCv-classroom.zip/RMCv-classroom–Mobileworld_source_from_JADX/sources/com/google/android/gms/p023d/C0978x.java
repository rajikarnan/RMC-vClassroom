package com.google.android.gms.p023d;

import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0809e;
import com.google.android.gms.common.api.C0824a.C0817c;
import com.google.android.gms.p023d.C0965h.C0964a;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* renamed from: com.google.android.gms.d.x */
public interface C0978x {

    /* renamed from: com.google.android.gms.d.x$a */
    public interface C0975a {
        /* renamed from: a */
        void mo1012a(int i, boolean z);

        /* renamed from: a */
        void mo1013a(Bundle bundle);

        /* renamed from: a */
        void mo1014a(ConnectionResult connectionResult);
    }

    /* renamed from: a */
    <A extends C0817c, T extends C0964a<? extends C0809e, A>> T mo1015a(T t);

    /* renamed from: a */
    void mo1016a();

    /* renamed from: a */
    void mo1017a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    /* renamed from: b */
    void mo1018b();

    /* renamed from: c */
    boolean mo1019c();

    /* renamed from: d */
    void mo1020d();
}

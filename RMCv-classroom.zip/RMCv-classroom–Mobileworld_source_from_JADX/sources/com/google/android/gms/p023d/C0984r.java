package com.google.android.gms.p023d;

import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0809e;
import com.google.android.gms.common.api.C0824a;
import com.google.android.gms.common.api.C0824a.C0817c;
import com.google.android.gms.p023d.C0965h.C0964a;

/* renamed from: com.google.android.gms.d.r */
public interface C0984r {
    /* renamed from: a */
    <A extends C0817c, T extends C0964a<? extends C0809e, A>> T mo1022a(T t);

    /* renamed from: a */
    void mo1023a();

    /* renamed from: a */
    void mo1024a(int i);

    /* renamed from: a */
    void mo1025a(Bundle bundle);

    /* renamed from: a */
    void mo1026a(ConnectionResult connectionResult, C0824a<?> c0824a, int i);

    /* renamed from: b */
    boolean mo1027b();

    /* renamed from: c */
    void mo1028c();
}

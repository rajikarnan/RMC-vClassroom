package com.google.android.gms.p023d;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* renamed from: com.google.android.gms.d.z */
public class C0959z {
    /* renamed from: d */
    protected final aa f1909d;

    protected C0959z(aa aaVar) {
        this.f1909d = aaVar;
    }

    /* renamed from: b */
    protected static aa m3932b(C1017y c1017y) {
        return c1017y.m4247a() ? ai.m3839a(c1017y.m4249c()) : ab.m3824a(c1017y.m4248b());
    }

    /* renamed from: a */
    public void mo997a() {
    }

    /* renamed from: a */
    public void mo998a(int i, int i2, Intent intent) {
    }

    /* renamed from: a */
    public void mo999a(Bundle bundle) {
    }

    /* renamed from: a */
    public void mo1003a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
    }

    /* renamed from: b */
    public void mo1000b() {
    }

    /* renamed from: b */
    public void mo1001b(Bundle bundle) {
    }

    /* renamed from: e */
    public Activity m3939e() {
        return this.f1909d.mo978a();
    }
}

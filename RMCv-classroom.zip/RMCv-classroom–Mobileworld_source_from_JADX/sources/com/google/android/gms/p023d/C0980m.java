package com.google.android.gms.p023d;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0835l;
import java.util.Iterator;

/* renamed from: com.google.android.gms.d.m */
public class C0980m extends C0960i {
    /* renamed from: a */
    protected void mo1002a(ConnectionResult connectionResult, int i) {
        C1012u c1012u = null;
        c1012u.m4241b(connectionResult, i);
    }

    /* renamed from: b */
    public void mo1000b() {
        Object obj = null;
        super.mo1000b();
        Iterator it = obj.iterator();
        while (it.hasNext()) {
            ((C0835l) it.next()).m3332a();
        }
        obj.clear();
        obj.m4238a(this);
    }

    /* renamed from: c */
    protected void mo1004c() {
        C1012u c1012u = null;
        c1012u.m4240b();
    }
}

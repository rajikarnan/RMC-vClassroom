package com.google.android.gms.p023d;

import android.os.Handler;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.api.C0809e;
import com.google.android.gms.common.api.C0827c;
import com.google.android.gms.common.api.C0828d;
import com.google.android.gms.common.api.C0829f;
import com.google.android.gms.common.api.C0830g;
import com.google.android.gms.common.api.C0831h;
import com.google.android.gms.common.api.C0832i;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C0854b;
import java.lang.ref.WeakReference;

/* renamed from: com.google.android.gms.d.aj */
public class aj<R extends C0809e> extends C0832i<R> implements C0829f<R> {
    /* renamed from: a */
    private C0831h<? super R, ? extends C0809e> f1850a;
    /* renamed from: b */
    private aj<? extends C0809e> f1851b;
    /* renamed from: c */
    private volatile C0830g<? super R> f1852c;
    /* renamed from: d */
    private C0827c<R> f1853d;
    /* renamed from: e */
    private final Object f1854e;
    /* renamed from: f */
    private Status f1855f;
    /* renamed from: g */
    private final WeakReference<GoogleApiClient> f1856g;
    /* renamed from: h */
    private final C0938a f1857h;
    /* renamed from: i */
    private boolean f1858i;

    /* renamed from: com.google.android.gms.d.aj$a */
    private final class C0938a extends Handler {
        /* renamed from: a */
        final /* synthetic */ aj f1849a;

        public void handleMessage(Message message) {
            switch (message.what) {
                case 0:
                    C0827c c0827c = (C0827c) message.obj;
                    synchronized (this.f1849a.f1854e) {
                        if (c0827c == null) {
                            this.f1849a.f1851b.m3847a(new Status(13, "Transform returned null"));
                        } else if (c0827c instanceof ag) {
                            this.f1849a.f1851b.m3847a(((ag) c0827c).m3836b());
                        } else {
                            this.f1849a.f1851b.m3859a(c0827c);
                        }
                    }
                    return;
                case 1:
                    RuntimeException runtimeException = (RuntimeException) message.obj;
                    String str = "TransformedResultImpl";
                    String str2 = "Runtime exception on the transformation worker thread: ";
                    String valueOf = String.valueOf(runtimeException.getMessage());
                    Log.e(str, valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
                    throw runtimeException;
                default:
                    Log.e("TransformedResultImpl", "TransformationResultHandler received unknown message type: " + message.what);
                    return;
            }
        }
    }

    /* renamed from: a */
    private void m3847a(Status status) {
        synchronized (this.f1854e) {
            this.f1855f = status;
            m3852b(this.f1855f);
        }
    }

    /* renamed from: b */
    private void m3851b() {
        if (this.f1850a != null || this.f1852c != null) {
            GoogleApiClient googleApiClient = (GoogleApiClient) this.f1856g.get();
            if (!(this.f1858i || this.f1850a == null || googleApiClient == null)) {
                googleApiClient.mo1042a(this);
                this.f1858i = true;
            }
            if (this.f1855f != null) {
                m3852b(this.f1855f);
            } else if (this.f1853d != null) {
                this.f1853d.mo982a(this);
            }
        }
    }

    /* renamed from: b */
    private void m3852b(Status status) {
        synchronized (this.f1854e) {
            if (this.f1850a != null) {
                Status a = this.f1850a.m3329a(status);
                C0854b.m3428a((Object) a, (Object) "onFailure must not return null");
                this.f1851b.m3847a(a);
            } else if (m3855c()) {
                this.f1852c.m3327a(status);
            }
        }
    }

    /* renamed from: b */
    private void m3853b(C0809e c0809e) {
        if (c0809e instanceof C0828d) {
            try {
                ((C0828d) c0809e).m3325a();
            } catch (Throwable e) {
                String valueOf = String.valueOf(c0809e);
                Log.w("TransformedResultImpl", new StringBuilder(String.valueOf(valueOf).length() + 18).append("Unable to release ").append(valueOf).toString(), e);
            }
        }
    }

    /* renamed from: c */
    private boolean m3855c() {
        return (this.f1852c == null || ((GoogleApiClient) this.f1856g.get()) == null) ? false : true;
    }

    /* renamed from: a */
    void m3858a() {
        this.f1852c = null;
    }

    /* renamed from: a */
    public void m3859a(C0827c<?> c0827c) {
        synchronized (this.f1854e) {
            this.f1853d = c0827c;
            m3851b();
        }
    }

    /* renamed from: a */
    public void mo984a(final R r) {
        synchronized (this.f1854e) {
            if (!r.mo890a().m3293e()) {
                m3847a(r.mo890a());
                m3853b((C0809e) r);
            } else if (this.f1850a != null) {
                af.m3833a().submit(new Runnable(this) {
                    /* renamed from: b */
                    final /* synthetic */ aj f1848b;

                    public void run() {
                        GoogleApiClient googleApiClient;
                        try {
                            C0962j.f1917a.set(Boolean.valueOf(true));
                            this.f1848b.f1857h.sendMessage(this.f1848b.f1857h.obtainMessage(0, this.f1848b.f1850a.m3330a(r)));
                            C0962j.f1917a.set(Boolean.valueOf(false));
                            this.f1848b.m3853b(r);
                            googleApiClient = (GoogleApiClient) this.f1848b.f1856g.get();
                            if (googleApiClient != null) {
                                googleApiClient.mo1045b(this.f1848b);
                            }
                        } catch (RuntimeException e) {
                            this.f1848b.f1857h.sendMessage(this.f1848b.f1857h.obtainMessage(1, e));
                            C0962j.f1917a.set(Boolean.valueOf(false));
                            this.f1848b.m3853b(r);
                            googleApiClient = (GoogleApiClient) this.f1848b.f1856g.get();
                            if (googleApiClient != null) {
                                googleApiClient.mo1045b(this.f1848b);
                            }
                        } catch (Throwable th) {
                            Throwable th2 = th;
                            C0962j.f1917a.set(Boolean.valueOf(false));
                            this.f1848b.m3853b(r);
                            googleApiClient = (GoogleApiClient) this.f1848b.f1856g.get();
                            if (googleApiClient != null) {
                                googleApiClient.mo1045b(this.f1848b);
                            }
                        }
                    }
                });
            } else if (m3855c()) {
                this.f1852c.m3328b(r);
            }
        }
    }
}

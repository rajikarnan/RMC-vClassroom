package com.google.android.gms.p023d;

/* renamed from: com.google.android.gms.d.ah */
public interface ah {
    /* renamed from: a */
    void m3837a();
}

package com.google.android.gms.p023d;

import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0824a;
import com.google.android.gms.common.api.GoogleApiClient.C0807b;
import com.google.android.gms.common.api.GoogleApiClient.C0808c;
import com.google.android.gms.common.internal.C0854b;

/* renamed from: com.google.android.gms.d.k */
public class C0973k implements C0807b, C0808c {
    /* renamed from: a */
    public final C0824a<?> f1941a;
    /* renamed from: b */
    private final int f1942b;
    /* renamed from: c */
    private C1006s f1943c;

    public C0973k(C0824a<?> c0824a, int i) {
        this.f1941a = c0824a;
        this.f1942b = i;
    }

    /* renamed from: a */
    private void m3996a() {
        C0854b.m3428a(this.f1943c, (Object) "Callbacks must be attached to a GoogleApiClient instance before connecting the client.");
    }

    /* renamed from: a */
    public void mo1010a(int i) {
        m3996a();
        this.f1943c.m4174a(i);
    }

    /* renamed from: a */
    public void mo1011a(Bundle bundle) {
        m3996a();
        this.f1943c.m4175a(bundle);
    }

    /* renamed from: a */
    public void mo996a(ConnectionResult connectionResult) {
        m3996a();
        this.f1943c.m4177a(connectionResult, this.f1941a, this.f1942b);
    }

    /* renamed from: a */
    public void m4000a(C1006s c1006s) {
        this.f1943c = c1006s;
    }
}

package com.google.android.gms.p023d;

import android.app.Activity;
import android.content.Intent;

/* renamed from: com.google.android.gms.d.aa */
public interface aa {
    /* renamed from: a */
    Activity mo978a();

    /* renamed from: a */
    <T extends C0959z> T mo979a(String str, Class<T> cls);

    /* renamed from: a */
    void mo980a(String str, C0959z c0959z);

    void startActivityForResult(Intent intent, int i);
}

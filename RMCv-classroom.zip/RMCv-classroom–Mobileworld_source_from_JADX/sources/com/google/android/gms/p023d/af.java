package com.google.android.gms.p023d;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* renamed from: com.google.android.gms.d.af */
public abstract class af {
    /* renamed from: a */
    private static final ExecutorService f1838a = new ThreadPoolExecutor(0, 4, 60, TimeUnit.SECONDS, new LinkedBlockingQueue(), new am("GAC_Transform"));

    /* renamed from: a */
    public static ExecutorService m3833a() {
        return f1838a;
    }
}

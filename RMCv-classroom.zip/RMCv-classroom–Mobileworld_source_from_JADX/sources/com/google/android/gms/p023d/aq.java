package com.google.android.gms.p023d;

import android.content.Context;
import android.os.Bundle;
import android.os.Looper;
import android.support.v4.app.ag;
import com.google.android.gms.common.api.C0824a;
import com.google.android.gms.common.api.C0824a.C0810a.C0811a;
import com.google.android.gms.common.api.C0824a.C0816b;
import com.google.android.gms.common.api.C0824a.C0820g;
import com.google.android.gms.common.api.GoogleApiClient.C0807b;
import com.google.android.gms.common.api.GoogleApiClient.C0808c;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.C0890l;
import com.google.android.gms.signin.internal.C1085g;

/* renamed from: com.google.android.gms.d.aq */
public final class aq {
    /* renamed from: a */
    public static final C0820g<C1085g> f1883a = new C0820g();
    /* renamed from: b */
    public static final C0820g<C1085g> f1884b = new C0820g();
    /* renamed from: c */
    public static final C0816b<C1085g, as> f1885c = new C09461();
    /* renamed from: d */
    static final C0816b<C1085g, C0948a> f1886d = new C09472();
    /* renamed from: e */
    public static final Scope f1887e = new Scope("profile");
    /* renamed from: f */
    public static final Scope f1888f = new Scope(ag.CATEGORY_EMAIL);
    /* renamed from: g */
    public static final C0824a<as> f1889g = new C0824a("SignIn.API", f1885c, f1883a);
    /* renamed from: h */
    public static final C0824a<C0948a> f1890h = new C0824a("SignIn.INTERNAL_API", f1886d, f1884b);

    /* renamed from: com.google.android.gms.d.aq$1 */
    class C09461 extends C0816b<C1085g, as> {
        C09461() {
        }

        /* renamed from: a */
        public C1085g m3893a(Context context, Looper looper, C0890l c0890l, as asVar, C0807b c0807b, C0808c c0808c) {
            return new C1085g(context, looper, true, c0890l, asVar == null ? as.f1891a : asVar, c0807b, c0808c);
        }
    }

    /* renamed from: com.google.android.gms.d.aq$2 */
    class C09472 extends C0816b<C1085g, C0948a> {
        C09472() {
        }

        /* renamed from: a */
        public C1085g m3895a(Context context, Looper looper, C0890l c0890l, C0948a c0948a, C0807b c0807b, C0808c c0808c) {
            return new C1085g(context, looper, false, c0890l, c0948a.m3896a(), c0807b, c0808c);
        }
    }

    /* renamed from: com.google.android.gms.d.aq$a */
    public static class C0948a implements C0811a {
        /* renamed from: a */
        public Bundle m3896a() {
            return null;
        }
    }
}

package com.google.android.gms.p023d;

import android.app.PendingIntent;
import android.content.Context;
import android.os.Bundle;
import android.os.Looper;
import android.support.v4.p011e.C0222a;
import android.util.Log;
import com.google.android.gms.common.C0839j;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0809e;
import com.google.android.gms.common.api.C0824a;
import com.google.android.gms.common.api.C0824a.C0816b;
import com.google.android.gms.common.api.C0824a.C0817c;
import com.google.android.gms.common.api.C0824a.C0818d;
import com.google.android.gms.common.api.C0824a.C0819f;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C0854b;
import com.google.android.gms.common.internal.C0890l;
import com.google.android.gms.p023d.C0965h.C0964a;
import com.google.android.gms.p023d.C0978x.C0975a;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.locks.Lock;

/* renamed from: com.google.android.gms.d.l */
final class C0979l implements C0978x {
    /* renamed from: a */
    private final Context f1947a;
    /* renamed from: b */
    private final C1004q f1948b;
    /* renamed from: c */
    private final Looper f1949c;
    /* renamed from: d */
    private final C1006s f1950d;
    /* renamed from: e */
    private final C1006s f1951e;
    /* renamed from: f */
    private final Map<C0818d<?>, C1006s> f1952f;
    /* renamed from: g */
    private final Set<ah> f1953g = Collections.newSetFromMap(new WeakHashMap());
    /* renamed from: h */
    private final C0819f f1954h;
    /* renamed from: i */
    private Bundle f1955i;
    /* renamed from: j */
    private ConnectionResult f1956j = null;
    /* renamed from: k */
    private ConnectionResult f1957k = null;
    /* renamed from: l */
    private boolean f1958l = false;
    /* renamed from: m */
    private final Lock f1959m;
    /* renamed from: n */
    private int f1960n = 0;

    /* renamed from: com.google.android.gms.d.l$1 */
    class C09741 implements Runnable {
        /* renamed from: a */
        final /* synthetic */ C0979l f1944a;

        public void run() {
            this.f1944a.f1959m.lock();
            try {
                this.f1944a.m4034g();
            } finally {
                this.f1944a.f1959m.unlock();
            }
        }
    }

    /* renamed from: com.google.android.gms.d.l$a */
    private class C0976a implements C0975a {
        /* renamed from: a */
        final /* synthetic */ C0979l f1945a;

        private C0976a(C0979l c0979l) {
            this.f1945a = c0979l;
        }

        /* renamed from: a */
        public void mo1012a(int i, boolean z) {
            this.f1945a.f1959m.lock();
            try {
                if (this.f1945a.f1958l || this.f1945a.f1957k == null || !this.f1945a.f1957k.m3227b()) {
                    this.f1945a.f1958l = false;
                    this.f1945a.m4019a(i, z);
                    return;
                }
                this.f1945a.f1958l = true;
                this.f1945a.f1951e.m4174a(i);
                this.f1945a.f1959m.unlock();
            } finally {
                this.f1945a.f1959m.unlock();
            }
        }

        /* renamed from: a */
        public void mo1013a(Bundle bundle) {
            this.f1945a.f1959m.lock();
            try {
                this.f1945a.m4020a(bundle);
                this.f1945a.f1956j = ConnectionResult.f1531a;
                this.f1945a.m4034g();
            } finally {
                this.f1945a.f1959m.unlock();
            }
        }

        /* renamed from: a */
        public void mo1014a(ConnectionResult connectionResult) {
            this.f1945a.f1959m.lock();
            try {
                this.f1945a.f1956j = connectionResult;
                this.f1945a.m4034g();
            } finally {
                this.f1945a.f1959m.unlock();
            }
        }
    }

    /* renamed from: com.google.android.gms.d.l$b */
    private class C0977b implements C0975a {
        /* renamed from: a */
        final /* synthetic */ C0979l f1946a;

        private C0977b(C0979l c0979l) {
            this.f1946a = c0979l;
        }

        /* renamed from: a */
        public void mo1012a(int i, boolean z) {
            this.f1946a.f1959m.lock();
            try {
                if (this.f1946a.f1958l) {
                    this.f1946a.f1958l = false;
                    this.f1946a.m4019a(i, z);
                    return;
                }
                this.f1946a.f1958l = true;
                this.f1946a.f1950d.m4174a(i);
                this.f1946a.f1959m.unlock();
            } finally {
                this.f1946a.f1959m.unlock();
            }
        }

        /* renamed from: a */
        public void mo1013a(Bundle bundle) {
            this.f1946a.f1959m.lock();
            try {
                this.f1946a.f1957k = ConnectionResult.f1531a;
                this.f1946a.m4034g();
            } finally {
                this.f1946a.f1959m.unlock();
            }
        }

        /* renamed from: a */
        public void mo1014a(ConnectionResult connectionResult) {
            this.f1946a.f1959m.lock();
            try {
                this.f1946a.f1957k = connectionResult;
                this.f1946a.m4034g();
            } finally {
                this.f1946a.f1959m.unlock();
            }
        }
    }

    private C0979l(Context context, C1004q c1004q, Lock lock, Looper looper, C0839j c0839j, Map<C0818d<?>, C0819f> map, Map<C0818d<?>, C0819f> map2, C0890l c0890l, C0816b<? extends ar, as> c0816b, C0819f c0819f, ArrayList<C0973k> arrayList, ArrayList<C0973k> arrayList2, Map<C0824a<?>, Integer> map3, Map<C0824a<?>, Integer> map4) {
        this.f1947a = context;
        this.f1948b = c1004q;
        this.f1959m = lock;
        this.f1949c = looper;
        this.f1954h = c0819f;
        this.f1950d = new C1006s(context, this.f1948b, lock, looper, c0839j, map2, null, map4, null, arrayList2, new C0976a());
        this.f1951e = new C1006s(context, this.f1948b, lock, looper, c0839j, map, c0890l, map3, c0816b, arrayList, new C0977b());
        Map c0222a = new C0222a();
        for (C0818d put : map2.keySet()) {
            c0222a.put(put, this.f1950d);
        }
        for (C0818d put2 : map.keySet()) {
            c0222a.put(put2, this.f1951e);
        }
        this.f1952f = Collections.unmodifiableMap(c0222a);
    }

    /* renamed from: a */
    public static C0979l m4017a(Context context, C1004q c1004q, Lock lock, Looper looper, C0839j c0839j, Map<C0818d<?>, C0819f> map, C0890l c0890l, Map<C0824a<?>, Integer> map2, C0816b<? extends ar, as> c0816b, ArrayList<C0973k> arrayList) {
        C0819f c0819f = null;
        Map c0222a = new C0222a();
        Map c0222a2 = new C0222a();
        for (Entry entry : map.entrySet()) {
            C0819f c0819f2 = (C0819f) entry.getValue();
            if (c0819f2.m3306f()) {
                c0819f = c0819f2;
            }
            if (c0819f2.mo1106d()) {
                c0222a.put((C0818d) entry.getKey(), c0819f2);
            } else {
                c0222a2.put((C0818d) entry.getKey(), c0819f2);
            }
        }
        C0854b.m3432a(!c0222a.isEmpty(), (Object) "CompositeGoogleApiClient should not be used without any APIs that require sign-in.");
        Map c0222a3 = new C0222a();
        Map c0222a4 = new C0222a();
        for (C0824a c0824a : map2.keySet()) {
            C0818d d = c0824a.m3318d();
            if (c0222a.containsKey(d)) {
                c0222a3.put(c0824a, (Integer) map2.get(c0824a));
            } else if (c0222a2.containsKey(d)) {
                c0222a4.put(c0824a, (Integer) map2.get(c0824a));
            } else {
                throw new IllegalStateException("Each API in the apiTypeMap must have a corresponding client in the clients map.");
            }
        }
        ArrayList arrayList2 = new ArrayList();
        ArrayList arrayList3 = new ArrayList();
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            C0973k c0973k = (C0973k) it.next();
            if (c0222a3.containsKey(c0973k.f1941a)) {
                arrayList2.add(c0973k);
            } else if (c0222a4.containsKey(c0973k.f1941a)) {
                arrayList3.add(c0973k);
            } else {
                throw new IllegalStateException("Each ClientCallbacks must have a corresponding API in the apiTypeMap");
            }
        }
        return new C0979l(context, c1004q, lock, looper, c0839j, c0222a, c0222a2, c0890l, c0816b, c0819f, arrayList2, arrayList3, c0222a3, c0222a4);
    }

    /* renamed from: a */
    private void m4019a(int i, boolean z) {
        this.f1948b.mo1012a(i, z);
        this.f1957k = null;
        this.f1956j = null;
    }

    /* renamed from: a */
    private void m4020a(Bundle bundle) {
        if (this.f1955i == null) {
            this.f1955i = bundle;
        } else if (bundle != null) {
            this.f1955i.putAll(bundle);
        }
    }

    /* renamed from: a */
    private void m4021a(ConnectionResult connectionResult) {
        switch (this.f1960n) {
            case 1:
                break;
            case 2:
                this.f1948b.mo1014a(connectionResult);
                break;
            default:
                Log.wtf("CompositeGAC", "Attempted to call failure callbacks in CONNECTION_MODE_NONE. Callbacks should be disabled via GmsClientSupervisor", new Exception());
                break;
        }
        m4036i();
        this.f1960n = 0;
    }

    /* renamed from: b */
    private static boolean m4027b(ConnectionResult connectionResult) {
        return connectionResult != null && connectionResult.m3227b();
    }

    /* renamed from: b */
    private boolean m4028b(C0964a<? extends C0809e, ? extends C0817c> c0964a) {
        C0818d b = c0964a.mo1006b();
        C0854b.m3436b(this.f1952f.containsKey(b), "GoogleApiClient is not configured to use the API required for this call.");
        return ((C1006s) this.f1952f.get(b)).equals(this.f1951e);
    }

    /* renamed from: f */
    private void m4033f() {
        this.f1957k = null;
        this.f1956j = null;
        this.f1950d.mo1016a();
        this.f1951e.mo1016a();
    }

    /* renamed from: g */
    private void m4034g() {
        if (C0979l.m4027b(this.f1956j)) {
            if (C0979l.m4027b(this.f1957k) || m4037j()) {
                m4035h();
            } else if (this.f1957k == null) {
            } else {
                if (this.f1960n == 1) {
                    m4036i();
                    return;
                }
                m4021a(this.f1957k);
                this.f1950d.mo1018b();
            }
        } else if (this.f1956j != null && C0979l.m4027b(this.f1957k)) {
            this.f1951e.mo1018b();
            m4021a(this.f1956j);
        } else if (this.f1956j != null && this.f1957k != null) {
            ConnectionResult connectionResult = this.f1956j;
            if (this.f1951e.f2039f < this.f1950d.f2039f) {
                connectionResult = this.f1957k;
            }
            m4021a(connectionResult);
        }
    }

    /* renamed from: h */
    private void m4035h() {
        switch (this.f1960n) {
            case 1:
                break;
            case 2:
                this.f1948b.mo1013a(this.f1955i);
                break;
            default:
                Log.wtf("CompositeGAC", "Attempted to call success callbacks in CONNECTION_MODE_NONE. Callbacks should be disabled via GmsClientSupervisor", new AssertionError());
                break;
        }
        m4036i();
        this.f1960n = 0;
    }

    /* renamed from: i */
    private void m4036i() {
        for (ah a : this.f1953g) {
            a.m3837a();
        }
        this.f1953g.clear();
    }

    /* renamed from: j */
    private boolean m4037j() {
        return this.f1957k != null && this.f1957k.m3228c() == 4;
    }

    /* renamed from: k */
    private PendingIntent m4038k() {
        return this.f1954h == null ? null : PendingIntent.getActivity(this.f1947a, this.f1948b.m4169i(), this.f1954h.m3307g(), 134217728);
    }

    /* renamed from: a */
    public <A extends C0817c, T extends C0964a<? extends C0809e, A>> T mo1015a(T t) {
        if (!m4028b((C0964a) t)) {
            return this.f1950d.mo1015a((C0964a) t);
        }
        if (!m4037j()) {
            return this.f1951e.mo1015a((C0964a) t);
        }
        t.m3981a(new Status(4, null, m4038k()));
        return t;
    }

    /* renamed from: a */
    public void mo1016a() {
        this.f1960n = 2;
        this.f1958l = false;
        m4033f();
    }

    /* renamed from: a */
    public void mo1017a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        printWriter.append(str).append("authClient").println(":");
        this.f1951e.mo1017a(String.valueOf(str).concat("  "), fileDescriptor, printWriter, strArr);
        printWriter.append(str).append("anonClient").println(":");
        this.f1950d.mo1017a(String.valueOf(str).concat("  "), fileDescriptor, printWriter, strArr);
    }

    /* renamed from: b */
    public void mo1018b() {
        this.f1957k = null;
        this.f1956j = null;
        this.f1960n = 0;
        this.f1950d.mo1018b();
        this.f1951e.mo1018b();
        m4036i();
    }

    /* renamed from: c */
    public boolean mo1019c() {
        boolean z = true;
        this.f1959m.lock();
        try {
            if (!(this.f1950d.mo1019c() && (m4045e() || m4037j() || this.f1960n == 1))) {
                z = false;
            }
            this.f1959m.unlock();
            return z;
        } catch (Throwable th) {
            this.f1959m.unlock();
        }
    }

    /* renamed from: d */
    public void mo1020d() {
        this.f1950d.mo1020d();
        this.f1951e.mo1020d();
    }

    /* renamed from: e */
    public boolean m4045e() {
        return this.f1951e.mo1019c();
    }
}

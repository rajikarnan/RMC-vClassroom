package com.google.android.gms.p023d;

import android.content.Context;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;
import android.os.Process;
import android.support.v4.p011e.C0222a;
import android.util.Log;
import android.util.SparseArray;
import com.google.android.gms.common.C0840b;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0824a;
import com.google.android.gms.common.api.C0824a.C0810a;
import com.google.android.gms.common.api.C0824a.C0817c;
import com.google.android.gms.common.api.C0824a.C0819f;
import com.google.android.gms.common.api.C0824a.C0822i;
import com.google.android.gms.common.api.C0835l;
import com.google.android.gms.common.api.GoogleApiClient.C0807b;
import com.google.android.gms.common.api.GoogleApiClient.C0808c;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C0857i.C0869f;
import com.google.android.gms.common.internal.C0860e;
import com.google.android.gms.common.internal.C0890l;
import com.google.android.gms.p023d.C0955d.C0956a;
import com.google.android.gms.p023d.C0965h.C0964a;
import java.lang.ref.PhantomReference;
import java.lang.ref.ReferenceQueue;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/* renamed from: com.google.android.gms.d.u */
public class C1012u implements Callback {
    /* renamed from: d */
    private static final Object f2068d = new Object();
    /* renamed from: e */
    private static C1012u f2069e;
    /* renamed from: a */
    private long f2070a;
    /* renamed from: b */
    private long f2071b;
    /* renamed from: c */
    private long f2072c;
    /* renamed from: f */
    private final Context f2073f;
    /* renamed from: g */
    private final C0840b f2074g;
    /* renamed from: h */
    private int f2075h;
    /* renamed from: i */
    private final SparseArray<C1010c<?>> f2076i;
    /* renamed from: j */
    private final Map<C0957e<?>, C1010c<?>> f2077j;
    /* renamed from: k */
    private C0980m f2078k;
    /* renamed from: l */
    private final Set<C0957e<?>> f2079l;
    /* renamed from: m */
    private final Handler f2080m;
    /* renamed from: n */
    private final ReferenceQueue<C0835l<?>> f2081n;
    /* renamed from: o */
    private final SparseArray<C1008a> f2082o;
    /* renamed from: p */
    private C1009b f2083p;

    /* renamed from: com.google.android.gms.d.u$a */
    private final class C1008a extends PhantomReference<C0835l<?>> {
        /* renamed from: a */
        final /* synthetic */ C1012u f2050a;
        /* renamed from: b */
        private final int f2051b;

        public C1008a(C1012u c1012u, C0835l c0835l, int i, ReferenceQueue<C0835l<?>> referenceQueue) {
            this.f2050a = c1012u;
            super(c0835l, referenceQueue);
            this.f2051b = i;
        }

        /* renamed from: a */
        public void m4189a() {
            this.f2050a.f2080m.sendMessage(this.f2050a.f2080m.obtainMessage(2, this.f2051b, 2));
        }
    }

    /* renamed from: com.google.android.gms.d.u$b */
    private static final class C1009b extends Thread {
        /* renamed from: a */
        private final ReferenceQueue<C0835l<?>> f2052a;
        /* renamed from: b */
        private final SparseArray<C1008a> f2053b;
        /* renamed from: c */
        private final AtomicBoolean f2054c = new AtomicBoolean();

        public C1009b(ReferenceQueue<C0835l<?>> referenceQueue, SparseArray<C1008a> sparseArray) {
            super("GoogleApiCleanup");
            this.f2052a = referenceQueue;
            this.f2053b = sparseArray;
        }

        public void run() {
            this.f2054c.set(true);
            Process.setThreadPriority(10);
            while (this.f2054c.get()) {
                try {
                    C1008a c1008a = (C1008a) this.f2052a.remove();
                    this.f2053b.remove(c1008a.f2051b);
                    c1008a.m4189a();
                } catch (InterruptedException e) {
                } finally {
                    this.f2054c.set(false);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.d.u$c */
    private class C1010c<O extends C0810a> implements C0807b, C0808c {
        /* renamed from: a */
        final /* synthetic */ C1012u f2055a;
        /* renamed from: b */
        private final Queue<C0955d> f2056b = new LinkedList();
        /* renamed from: c */
        private final C0819f f2057c;
        /* renamed from: d */
        private final C0817c f2058d;
        /* renamed from: e */
        private final C0957e<O> f2059e;
        /* renamed from: f */
        private final SparseArray<ak> f2060f = new SparseArray();
        /* renamed from: g */
        private final Set<C0963g> f2061g = new HashSet();
        /* renamed from: h */
        private final SparseArray<Map<Object, C0964a>> f2062h = new SparseArray();
        /* renamed from: i */
        private boolean f2063i;
        /* renamed from: j */
        private ConnectionResult f2064j = null;

        public C1010c(C1012u c1012u, C0835l<O> c0835l) {
            this.f2055a = c1012u;
            this.f2057c = m4191a((C0835l) c0835l);
            if (this.f2057c instanceof C0860e) {
                this.f2058d = ((C0860e) this.f2057c).mo907k();
            } else {
                this.f2058d = this.f2057c;
            }
            this.f2059e = c0835l.m3335d();
        }

        /* renamed from: a */
        private C0819f m4191a(C0835l c0835l) {
            C0824a b = c0835l.m3333b();
            if (!b.m3319e()) {
                return c0835l.m3333b().m3316b().mo987a(c0835l.m3336e(), this.f2055a.f2080m.getLooper(), C0890l.m3557a(c0835l.m3336e()), c0835l.m3334c(), this, this);
            }
            C0822i c = b.m3317c();
            return new C0860e(c0835l.m3336e(), this.f2055a.f2080m.getLooper(), c.m3313b(), this, this, C0890l.m3557a(c0835l.m3336e()), c.m3314b(c0835l.m3334c()));
        }

        /* renamed from: a */
        private void m4192a(Status status) {
            for (C0955d a : this.f2056b) {
                a.mo993a(status);
            }
            this.f2056b.clear();
        }

        /* renamed from: b */
        private void m4195b(ConnectionResult connectionResult) {
            for (C0963g a : this.f2061g) {
                a.m3977a(this.f2059e, connectionResult);
            }
            this.f2061g.clear();
        }

        /* renamed from: b */
        private void m4196b(C0955d c0955d) {
            c0955d.mo992a(this.f2060f);
            Map map;
            if (c0955d.f1901b == 3) {
                try {
                    Map map2;
                    map = (Map) this.f2062h.get(c0955d.f1900a);
                    if (map == null) {
                        C0222a c0222a = new C0222a(1);
                        this.f2062h.put(c0955d.f1900a, c0222a);
                        map2 = c0222a;
                    } else {
                        map2 = map;
                    }
                    C0964a c0964a = ((C0956a) c0955d).f1902c;
                    map2.put(((ac) c0964a).m3830a(), c0964a);
                } catch (ClassCastException e) {
                    throw new IllegalStateException("Listener registration methods must implement ListenerApiMethod");
                }
            } else if (c0955d.f1901b == 4) {
                try {
                    map = (Map) this.f2062h.get(c0955d.f1900a);
                    ac acVar = (ac) ((C0956a) c0955d).f1902c;
                    if (map != null) {
                        map.remove(acVar.m3830a());
                    } else {
                        Log.w("GoogleApiManager", "Received call to unregister a listener without a matching registration call.");
                    }
                } catch (ClassCastException e2) {
                    throw new IllegalStateException("Listener unregistration methods must implement ListenerApiMethod");
                }
            }
            try {
                c0955d.mo994a(this.f2058d);
            } catch (DeadObjectException e3) {
                this.f2057c.mo1093a();
                mo1010a(1);
            }
        }

        /* renamed from: e */
        private void m4200e() {
            if (this.f2063i) {
                m4205j();
            }
        }

        /* renamed from: f */
        private void m4201f() {
            if (this.f2063i) {
                this.f2055a.f2080m.removeMessages(9, this.f2059e);
                this.f2055a.f2080m.removeMessages(8, this.f2059e);
                this.f2063i = false;
            }
        }

        /* renamed from: g */
        private void m4202g() {
            if (this.f2063i) {
                m4201f();
                m4192a(this.f2055a.f2074g.mo891a(this.f2055a.f2073f) == 18 ? new Status(8, "Connection timed out while waiting for Google Play services update to complete.") : new Status(8, "API failed to connect while resuming due to an unknown error."));
                this.f2057c.mo1093a();
            }
        }

        /* renamed from: h */
        private void m4203h() {
            this.f2055a.f2080m.removeMessages(10, this.f2059e);
            this.f2055a.f2080m.sendMessageDelayed(this.f2055a.f2080m.obtainMessage(10, this.f2059e), this.f2055a.f2072c);
        }

        /* renamed from: i */
        private void m4204i() {
            if (this.f2057c.m3302b() && this.f2062h.size() == 0) {
                for (int i = 0; i < this.f2060f.size(); i++) {
                    if (((ak) this.f2060f.get(this.f2060f.keyAt(i))).m3871c()) {
                        m4203h();
                        return;
                    }
                }
                this.f2057c.mo1093a();
            }
        }

        /* renamed from: j */
        private void m4205j() {
            if (!this.f2057c.m3302b() && !this.f2057c.m3303c()) {
                if (this.f2057c.m3305e() && this.f2055a.f2075h != 0) {
                    this.f2055a.f2075h = this.f2055a.f2074g.mo891a(this.f2055a.f2073f);
                    if (this.f2055a.f2075h != 0) {
                        mo996a(new ConnectionResult(this.f2055a.f2075h, null));
                        return;
                    }
                }
                this.f2057c.m3299a(new C1011d(this.f2055a, this.f2057c, this.f2059e));
            }
        }

        /* renamed from: a */
        public void m4206a() {
            while (this.f2057c.m3302b() && !this.f2056b.isEmpty()) {
                m4196b((C0955d) this.f2056b.remove());
            }
        }

        /* renamed from: a */
        public void mo1010a(int i) {
            m4213b();
            this.f2063i = true;
            this.f2055a.f2080m.sendMessageDelayed(Message.obtain(this.f2055a.f2080m, 8, this.f2059e), this.f2055a.f2070a);
            this.f2055a.f2080m.sendMessageDelayed(Message.obtain(this.f2055a.f2080m, 9, this.f2059e), this.f2055a.f2071b);
            this.f2055a.f2075h = -1;
        }

        /* renamed from: a */
        public void m4208a(int i, boolean z) {
            Iterator it = this.f2056b.iterator();
            while (it.hasNext()) {
                C0955d c0955d = (C0955d) it.next();
                if (c0955d.f1900a == i && c0955d.f1901b != 1 && c0955d.mo995a()) {
                    it.remove();
                }
            }
            ((ak) this.f2060f.get(i)).m3867a();
            this.f2062h.delete(i);
            if (!z) {
                this.f2060f.remove(i);
                this.f2055a.f2082o.remove(i);
                if (this.f2060f.size() == 0 && this.f2056b.isEmpty()) {
                    m4201f();
                    this.f2057c.mo1093a();
                    this.f2055a.f2077j.remove(this.f2059e);
                    synchronized (C1012u.f2068d) {
                        this.f2055a.f2079l.remove(this.f2059e);
                    }
                }
            }
        }

        /* renamed from: a */
        public void mo1011a(Bundle bundle) {
            m4213b();
            m4195b(ConnectionResult.f1531a);
            m4201f();
            for (int i = 0; i < this.f2062h.size(); i++) {
                for (C0964a a : ((Map) this.f2062h.get(this.f2062h.keyAt(i))).values()) {
                    try {
                        a.m3982a(this.f2058d);
                    } catch (DeadObjectException e) {
                        this.f2057c.mo1093a();
                        mo1010a(1);
                    }
                }
            }
            m4206a();
            m4203h();
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        /* renamed from: a */
        public void mo996a(com.google.android.gms.common.ConnectionResult r6) {
            /*
            r5 = this;
            r5.m4213b();
            r0 = r5.f2055a;
            r1 = -1;
            r0.f2075h = r1;
            r5.m4195b(r6);
            r0 = r5.f2060f;
            r1 = 0;
            r0 = r0.keyAt(r1);
            r1 = r5.f2056b;
            r1 = r1.isEmpty();
            if (r1 == 0) goto L_0x001e;
        L_0x001b:
            r5.f2064j = r6;
        L_0x001d:
            return;
        L_0x001e:
            r1 = com.google.android.gms.p023d.C1012u.f2068d;
            monitor-enter(r1);
            r2 = r5.f2055a;	 Catch:{ all -> 0x0044 }
            r2 = null;	 Catch:{ all -> 0x0044 }
            if (r2 == 0) goto L_0x0047;
        L_0x002b:
            r2 = r5.f2055a;	 Catch:{ all -> 0x0044 }
            r2 = r2.f2079l;	 Catch:{ all -> 0x0044 }
            r3 = r5.f2059e;	 Catch:{ all -> 0x0044 }
            r2 = r2.contains(r3);	 Catch:{ all -> 0x0044 }
            if (r2 == 0) goto L_0x0047;
        L_0x0039:
            r2 = r5.f2055a;	 Catch:{ all -> 0x0044 }
            r2 = null;	 Catch:{ all -> 0x0044 }
            r2.m3948b(r6, r0);	 Catch:{ all -> 0x0044 }
            monitor-exit(r1);	 Catch:{ all -> 0x0044 }
            goto L_0x001d;
        L_0x0044:
            r0 = move-exception;
            monitor-exit(r1);	 Catch:{ all -> 0x0044 }
            throw r0;
        L_0x0047:
            monitor-exit(r1);	 Catch:{ all -> 0x0044 }
            r1 = r5.f2055a;
            r0 = r1.m4239a(r6, r0);
            if (r0 != 0) goto L_0x001d;
        L_0x0050:
            r0 = r6.m3228c();
            r1 = 18;
            if (r0 != r1) goto L_0x005b;
        L_0x0058:
            r0 = 1;
            r5.f2063i = r0;
        L_0x005b:
            r0 = r5.f2063i;
            if (r0 == 0) goto L_0x007d;
        L_0x005f:
            r0 = r5.f2055a;
            r0 = r0.f2080m;
            r1 = r5.f2055a;
            r1 = r1.f2080m;
            r2 = 8;
            r3 = r5.f2059e;
            r1 = android.os.Message.obtain(r1, r2, r3);
            r2 = r5.f2055a;
            r2 = r2.f2070a;
            r0.sendMessageDelayed(r1, r2);
            goto L_0x001d;
        L_0x007d:
            r0 = new com.google.android.gms.common.api.Status;
            r1 = 17;
            r2 = r5.f2059e;
            r2 = r2.m3928b();
            r2 = java.lang.String.valueOf(r2);
            r3 = new java.lang.StringBuilder;
            r4 = java.lang.String.valueOf(r2);
            r4 = r4.length();
            r4 = r4 + 38;
            r3.<init>(r4);
            r4 = "API: ";
            r3 = r3.append(r4);
            r2 = r3.append(r2);
            r3 = " is not available on this device.";
            r2 = r2.append(r3);
            r2 = r2.toString();
            r0.<init>(r1, r2);
            r5.m4192a(r0);
            goto L_0x001d;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.d.u.c.a(com.google.android.gms.common.ConnectionResult):void");
        }

        /* renamed from: a */
        public void m4211a(C0955d c0955d) {
            if (this.f2057c.m3302b()) {
                m4196b(c0955d);
                m4203h();
                return;
            }
            this.f2056b.add(c0955d);
            if (this.f2064j == null || !this.f2064j.m3226a()) {
                m4205j();
            } else {
                mo996a(this.f2064j);
            }
        }

        /* renamed from: a */
        public void m4212a(C0963g c0963g) {
            this.f2061g.add(c0963g);
        }

        /* renamed from: b */
        public void m4213b() {
            this.f2064j = null;
        }

        /* renamed from: b */
        public void m4214b(int i) {
            this.f2060f.put(i, new ak(this.f2059e.m3927a(), this.f2057c));
        }

        /* renamed from: c */
        ConnectionResult m4215c() {
            return this.f2064j;
        }

        /* renamed from: d */
        boolean m4216d() {
            return this.f2057c.m3302b();
        }
    }

    /* renamed from: com.google.android.gms.d.u$d */
    private class C1011d implements C0869f {
        /* renamed from: a */
        final /* synthetic */ C1012u f2065a;
        /* renamed from: b */
        private final C0819f f2066b;
        /* renamed from: c */
        private final C0957e<?> f2067c;

        public C1011d(C1012u c1012u, C0819f c0819f, C0957e<?> c0957e) {
            this.f2065a = c1012u;
            this.f2066b = c0819f;
            this.f2067c = c0957e;
        }

        /* renamed from: a */
        public void mo912a(ConnectionResult connectionResult) {
            if (connectionResult.m3227b()) {
                this.f2066b.m3300a(null, Collections.emptySet());
            } else {
                ((C1010c) this.f2065a.f2077j.get(this.f2067c)).mo996a(connectionResult);
            }
        }
    }

    /* renamed from: a */
    public static C1012u m4220a() {
        C1012u c1012u;
        synchronized (f2068d) {
            c1012u = f2069e;
        }
        return c1012u;
    }

    /* renamed from: a */
    private void m4221a(C0835l<?> c0835l, int i) {
        C0957e d = c0835l.m3335d();
        if (!this.f2077j.containsKey(d)) {
            this.f2077j.put(d, new C1010c(this, c0835l));
        }
        C1010c c1010c = (C1010c) this.f2077j.get(d);
        c1010c.m4214b(i);
        this.f2076i.put(i, c1010c);
        c1010c.m4205j();
        this.f2082o.put(i, new C1008a(this, c0835l, i, this.f2081n));
        if (this.f2083p == null || !this.f2083p.f2054c.get()) {
            this.f2083p = new C1009b(this.f2081n, this.f2082o);
            this.f2083p.start();
        }
    }

    /* renamed from: a */
    private void m4222a(C0955d c0955d) {
        ((C1010c) this.f2076i.get(c0955d.f1900a)).m4211a(c0955d);
    }

    /* renamed from: b */
    private void m4224b(int i, boolean z) {
        C1010c c1010c = (C1010c) this.f2076i.get(i);
        if (c1010c != null) {
            if (!z) {
                this.f2076i.delete(i);
            }
            c1010c.m4208a(i, z);
            return;
        }
        Log.wtf("GoogleApiManager", "onRelease received for unknown instance: " + i, new Exception());
    }

    /* renamed from: d */
    private void m4228d() {
        for (C1010c c1010c : this.f2077j.values()) {
            c1010c.m4213b();
            c1010c.m4205j();
        }
    }

    /* renamed from: a */
    public void m4236a(int i, boolean z) {
        this.f2080m.sendMessage(this.f2080m.obtainMessage(7, i, z ? 1 : 2));
    }

    /* renamed from: a */
    public void m4237a(C0963g c0963g) {
        for (C0957e c0957e : c0963g.mo1006b()) {
            C1010c c1010c = (C1010c) this.f2077j.get(c0957e);
            if (c1010c == null) {
                c0963g.m3970g();
                return;
            } else if (c1010c.m4216d()) {
                c0963g.m3977a(c0957e, ConnectionResult.f1531a);
            } else if (c1010c.m4215c() != null) {
                c0963g.m3977a(c0957e, c1010c.m4215c());
            } else {
                c1010c.m4212a(c0963g);
            }
        }
    }

    /* renamed from: a */
    public void m4238a(C0980m c0980m) {
        synchronized (f2068d) {
            if (c0980m == null) {
                this.f2078k = null;
                this.f2079l.clear();
            }
        }
    }

    /* renamed from: a */
    boolean m4239a(ConnectionResult connectionResult, int i) {
        if (!connectionResult.m3226a() && !this.f2074g.mo895a(connectionResult.m3228c())) {
            return false;
        }
        this.f2074g.m3363a(this.f2073f, connectionResult, i);
        return true;
    }

    /* renamed from: b */
    public void m4240b() {
        this.f2080m.sendMessage(this.f2080m.obtainMessage(3));
    }

    /* renamed from: b */
    public void m4241b(ConnectionResult connectionResult, int i) {
        if (!m4239a(connectionResult, i)) {
            this.f2080m.sendMessage(this.f2080m.obtainMessage(5, i, 0));
        }
    }

    public boolean handleMessage(Message message) {
        boolean z = false;
        switch (message.what) {
            case 1:
                m4237a((C0963g) message.obj);
                break;
            case 2:
            case 7:
                int i = message.arg1;
                if (message.arg2 == 1) {
                    z = true;
                }
                m4224b(i, z);
                break;
            case 3:
                m4228d();
                break;
            case 4:
                m4222a((C0955d) message.obj);
                break;
            case 5:
                if (this.f2076i.get(message.arg1) != null) {
                    ((C1010c) this.f2076i.get(message.arg1)).m4192a(new Status(17, "Error resolution was canceled by the user."));
                    break;
                }
                break;
            case 6:
                m4221a((C0835l) message.obj, message.arg1);
                break;
            case 8:
                if (this.f2077j.containsKey(message.obj)) {
                    ((C1010c) this.f2077j.get(message.obj)).m4200e();
                    break;
                }
                break;
            case 9:
                if (this.f2077j.containsKey(message.obj)) {
                    ((C1010c) this.f2077j.get(message.obj)).m4202g();
                    break;
                }
                break;
            case 10:
                if (this.f2077j.containsKey(message.obj)) {
                    ((C1010c) this.f2077j.get(message.obj)).m4204i();
                    break;
                }
                break;
            default:
                Log.w("GoogleApiManager", "Unknown message id: " + message.what);
                return false;
        }
        return true;
    }
}

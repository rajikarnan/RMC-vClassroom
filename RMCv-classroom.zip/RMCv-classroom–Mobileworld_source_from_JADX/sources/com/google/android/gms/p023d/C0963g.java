package com.google.android.gms.p023d;

import android.support.v4.p011e.C0222a;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0809e;
import com.google.android.gms.common.api.C0833k;
import com.google.android.gms.common.api.C0834j;
import com.google.android.gms.common.api.Status;
import java.util.Set;

/* renamed from: com.google.android.gms.d.g */
public final class C0963g extends C0962j<C0833k> {
    /* renamed from: d */
    private int f1932d;
    /* renamed from: e */
    private boolean f1933e;

    /* renamed from: a */
    private void m3975a(ConnectionResult connectionResult) {
        C0222a c0222a = null;
        for (int i = 0; i < c0222a.size(); i++) {
            m3977a((C0957e) c0222a.m820b(i), connectionResult);
        }
    }

    /* renamed from: a */
    protected C0833k m3976a(Status status) {
        C0833k c0833k;
        synchronized (null) {
            try {
                m3975a(new ConnectionResult(8));
                C0222a c0222a = null;
                if (c0222a.size() != 1) {
                    c0833k = new C0833k(status, null);
                }
            } finally {
            }
        }
        return c0833k;
    }

    /* renamed from: a */
    public void m3977a(C0957e<?> c0957e, ConnectionResult connectionResult) {
        synchronized (null) {
            C0222a c0222a = null;
            try {
                c0222a.put(c0957e, connectionResult);
                this.f1932d--;
                boolean b = connectionResult.m3227b();
                if (!b) {
                    this.f1933e = b;
                }
                if (this.f1932d == 0) {
                    Status status = this.f1933e ? new Status(13) : Status.f1568a;
                    c0222a = null;
                    m3966b(c0222a.size() == 1 ? new C0834j(status, null) : new C0833k(status, null));
                }
            } finally {
            }
        }
    }

    /* renamed from: b */
    protected /* synthetic */ C0809e mo1005b(Status status) {
        return m3976a(status);
    }

    /* renamed from: b */
    public Set<C0957e<?>> mo1006b() {
        C0222a c0222a = null;
        return c0222a.keySet();
    }
}

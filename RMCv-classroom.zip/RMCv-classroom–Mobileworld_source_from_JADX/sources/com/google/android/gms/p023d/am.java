package com.google.android.gms.p023d;

import com.google.android.gms.common.internal.C0854b;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/* renamed from: com.google.android.gms.d.am */
public class am implements ThreadFactory {
    /* renamed from: a */
    private final String f1874a;
    /* renamed from: b */
    private final int f1875b;
    /* renamed from: c */
    private final AtomicInteger f1876c;
    /* renamed from: d */
    private final ThreadFactory f1877d;

    public am(String str) {
        this(str, 0);
    }

    public am(String str, int i) {
        this.f1876c = new AtomicInteger();
        this.f1877d = Executors.defaultThreadFactory();
        this.f1874a = (String) C0854b.m3428a((Object) str, (Object) "Name must not be null");
        this.f1875b = i;
    }

    public Thread newThread(Runnable runnable) {
        Thread newThread = this.f1877d.newThread(new an(runnable, this.f1875b));
        String str = this.f1874a;
        newThread.setName(new StringBuilder(String.valueOf(str).length() + 13).append(str).append("[").append(this.f1876c.getAndIncrement()).append("]").toString());
        return newThread;
    }
}

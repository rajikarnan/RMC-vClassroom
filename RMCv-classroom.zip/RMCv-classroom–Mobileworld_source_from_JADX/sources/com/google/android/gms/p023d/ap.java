package com.google.android.gms.p023d;

import android.content.Context;

/* renamed from: com.google.android.gms.d.ap */
public class ap {
    /* renamed from: b */
    private static ap f1881b = new ap();
    /* renamed from: a */
    private ao f1882a = null;

    /* renamed from: b */
    public static ao m3890b(Context context) {
        return f1881b.m3891a(context);
    }

    /* renamed from: a */
    public synchronized ao m3891a(Context context) {
        if (this.f1882a == null) {
            if (context.getApplicationContext() != null) {
                context = context.getApplicationContext();
            }
            this.f1882a = new ao(context);
        }
        return this.f1882a;
    }
}

package com.google.android.gms.p023d;

import android.util.Log;
import android.util.SparseArray;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.C0808c;
import com.google.android.gms.common.internal.C0854b;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* renamed from: com.google.android.gms.d.f */
public class C0961f extends C0960i {
    /* renamed from: e */
    private final SparseArray<C0958a> f1916e = new SparseArray();

    /* renamed from: com.google.android.gms.d.f$a */
    private class C0958a implements C0808c {
        /* renamed from: a */
        public final int f1905a;
        /* renamed from: b */
        public final GoogleApiClient f1906b;
        /* renamed from: c */
        public final C0808c f1907c;
        /* renamed from: d */
        final /* synthetic */ C0961f f1908d;

        public C0958a(C0961f c0961f, int i, GoogleApiClient googleApiClient, C0808c c0808c) {
            this.f1908d = c0961f;
            this.f1905a = i;
            this.f1906b = googleApiClient;
            this.f1907c = c0808c;
            googleApiClient.mo1041a((C0808c) this);
        }

        /* renamed from: a */
        public void m3929a() {
            this.f1906b.mo1044b((C0808c) this);
            this.f1906b.disconnect();
        }

        /* renamed from: a */
        public void mo996a(ConnectionResult connectionResult) {
            String valueOf = String.valueOf(connectionResult);
            Log.d("AutoManageHelper", new StringBuilder(String.valueOf(valueOf).length() + 27).append("beginFailureResolution for ").append(valueOf).toString());
            this.f1908d.m3948b(connectionResult, this.f1905a);
        }

        /* renamed from: a */
        public void m3931a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
            printWriter.append(str).append("GoogleApiClient #").print(this.f1905a);
            printWriter.println(":");
            this.f1906b.mo1043a(String.valueOf(str).concat("  "), fileDescriptor, printWriter, strArr);
        }
    }

    private C0961f(aa aaVar) {
        super(aaVar);
        this.d.mo980a("AutoManageHelper", (C0959z) this);
    }

    /* renamed from: a */
    public static C0961f m3951a(C1017y c1017y) {
        aa b = C0959z.m3932b(c1017y);
        C0961f c0961f = (C0961f) b.mo979a("AutoManageHelper", C0961f.class);
        return c0961f != null ? c0961f : new C0961f(b);
    }

    /* renamed from: a */
    public void mo997a() {
        super.mo997a();
        boolean z = this.a;
        String valueOf = String.valueOf(this.f1916e);
        Log.d("AutoManageHelper", new StringBuilder(String.valueOf(valueOf).length() + 14).append("onStart ").append(z).append(" ").append(valueOf).toString());
        if (!this.b) {
            for (int i = 0; i < this.f1916e.size(); i++) {
                ((C0958a) this.f1916e.valueAt(i)).f1906b.connect();
            }
        }
    }

    /* renamed from: a */
    public void m3953a(int i) {
        C0958a c0958a = (C0958a) this.f1916e.get(i);
        this.f1916e.remove(i);
        if (c0958a != null) {
            c0958a.m3929a();
        }
    }

    /* renamed from: a */
    public void m3954a(int i, GoogleApiClient googleApiClient, C0808c c0808c) {
        C0854b.m3428a((Object) googleApiClient, (Object) "GoogleApiClient instance cannot be null");
        C0854b.m3432a(this.f1916e.indexOfKey(i) < 0, "Already managing a GoogleApiClient with id " + i);
        Log.d("AutoManageHelper", "starting AutoManage for client " + i + " " + this.a + " " + this.b);
        this.f1916e.put(i, new C0958a(this, i, googleApiClient, c0808c));
        if (this.a && !this.b) {
            String valueOf = String.valueOf(googleApiClient);
            Log.d("AutoManageHelper", new StringBuilder(String.valueOf(valueOf).length() + 11).append("connecting ").append(valueOf).toString());
            googleApiClient.connect();
        }
    }

    /* renamed from: a */
    protected void mo1002a(ConnectionResult connectionResult, int i) {
        Log.w("AutoManageHelper", "Unresolved error while connecting client. Stopping auto-manage.");
        if (i < 0) {
            Log.wtf("AutoManageHelper", "AutoManageLifecycleHelper received onErrorResolutionFailed callback but no failing client ID is set", new Exception());
            return;
        }
        C0958a c0958a = (C0958a) this.f1916e.get(i);
        if (c0958a != null) {
            m3953a(i);
            C0808c c0808c = c0958a.f1907c;
            if (c0808c != null) {
                c0808c.mo996a(connectionResult);
            }
        }
    }

    /* renamed from: a */
    public void mo1003a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        for (int i = 0; i < this.f1916e.size(); i++) {
            ((C0958a) this.f1916e.valueAt(i)).m3931a(str, fileDescriptor, printWriter, strArr);
        }
    }

    /* renamed from: b */
    public void mo1000b() {
        super.mo1000b();
        for (int i = 0; i < this.f1916e.size(); i++) {
            ((C0958a) this.f1916e.valueAt(i)).f1906b.disconnect();
        }
    }

    /* renamed from: c */
    protected void mo1004c() {
        for (int i = 0; i < this.f1916e.size(); i++) {
            ((C0958a) this.f1916e.valueAt(i)).f1906b.connect();
        }
    }
}

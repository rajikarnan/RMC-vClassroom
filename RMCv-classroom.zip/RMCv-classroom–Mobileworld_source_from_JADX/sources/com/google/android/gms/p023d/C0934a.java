package com.google.android.gms.p023d;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Application;
import android.app.Application.ActivityLifecycleCallbacks;
import android.content.ComponentCallbacks2;
import android.content.res.Configuration;
import android.os.Bundle;
import com.google.firebase.C1089a;
import java.util.concurrent.atomic.AtomicBoolean;

@TargetApi(14)
/* renamed from: com.google.android.gms.d.a */
public class C0934a implements ActivityLifecycleCallbacks, ComponentCallbacks2 {
    /* renamed from: a */
    private static final C0934a f1826a = new C0934a();
    /* renamed from: b */
    private final AtomicBoolean f1827b = new AtomicBoolean();
    /* renamed from: c */
    private boolean f1828c;

    private C0934a() {
    }

    /* renamed from: a */
    public static void m3819a(Application application) {
        application.registerActivityLifecycleCallbacks(f1826a);
        application.registerComponentCallbacks(f1826a);
        f1826a.f1828c = true;
    }

    public void onActivityCreated(Activity activity, Bundle bundle) {
        if (this.f1827b.compareAndSet(true, false)) {
            C1089a.m4603a(false);
        }
    }

    public void onActivityDestroyed(Activity activity) {
    }

    public void onActivityPaused(Activity activity) {
    }

    public void onActivityResumed(Activity activity) {
        if (this.f1827b.compareAndSet(true, false)) {
            C1089a.m4603a(false);
        }
    }

    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    public void onActivityStarted(Activity activity) {
    }

    public void onActivityStopped(Activity activity) {
    }

    public void onConfigurationChanged(Configuration configuration) {
    }

    public void onLowMemory() {
    }

    public void onTrimMemory(int i) {
        if (i == 20 && this.f1827b.compareAndSet(false, true)) {
            C1089a.m4603a(true);
        }
    }
}

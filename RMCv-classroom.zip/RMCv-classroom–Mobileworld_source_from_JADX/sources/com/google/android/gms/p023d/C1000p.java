package com.google.android.gms.p023d;

import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0809e;
import com.google.android.gms.common.api.C0824a;
import com.google.android.gms.common.api.C0824a.C0817c;
import com.google.android.gms.p023d.C0965h.C0964a;
import java.util.Collections;

/* renamed from: com.google.android.gms.d.p */
public class C1000p implements C0984r {
    /* renamed from: a */
    private final C1006s f2005a;

    public C1000p(C1006s c1006s) {
        this.f2005a = c1006s;
    }

    /* renamed from: a */
    public <A extends C0817c, T extends C0964a<? extends C0809e, A>> T mo1022a(T t) {
        throw new IllegalStateException("GoogleApiClient is not connected yet.");
    }

    /* renamed from: a */
    public void mo1023a() {
        this.f2005a.m4186g();
        this.f2005a.f2040g.f2012d = Collections.emptySet();
    }

    /* renamed from: a */
    public void mo1024a(int i) {
    }

    /* renamed from: a */
    public void mo1025a(Bundle bundle) {
    }

    /* renamed from: a */
    public void mo1026a(ConnectionResult connectionResult, C0824a<?> c0824a, int i) {
    }

    /* renamed from: b */
    public boolean mo1027b() {
        return true;
    }

    /* renamed from: c */
    public void mo1028c() {
        this.f2005a.m4184e();
    }
}

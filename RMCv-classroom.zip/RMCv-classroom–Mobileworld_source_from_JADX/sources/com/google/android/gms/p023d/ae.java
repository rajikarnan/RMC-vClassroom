package com.google.android.gms.p023d;

import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

/* renamed from: com.google.android.gms.d.ae */
public class ae {
    /* renamed from: a */
    private final Set<ad<?>> f1837a = Collections.newSetFromMap(new WeakHashMap());

    /* renamed from: a */
    public void m3832a() {
        for (ad a : this.f1837a) {
            a.m3831a();
        }
        this.f1837a.clear();
    }
}

package com.google.android.gms.p023d;

import android.os.DeadObjectException;
import android.os.RemoteException;
import com.google.android.gms.common.api.C0809e;
import com.google.android.gms.common.api.C0824a;
import com.google.android.gms.common.api.C0824a.C0817c;
import com.google.android.gms.common.api.C0824a.C0818d;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C0854b;
import com.google.android.gms.p023d.ak.C0939b;
import java.util.concurrent.atomic.AtomicReference;

/* renamed from: com.google.android.gms.d.h */
public class C0965h {

    /* renamed from: com.google.android.gms.d.h$a */
    public static abstract class C0964a<R extends C0809e, A extends C0817c> extends C0962j<R> {
        /* renamed from: d */
        private final C0818d<A> f1934d;
        /* renamed from: e */
        private final C0824a<?> f1935e;
        /* renamed from: f */
        private AtomicReference<C0939b> f1936f;

        /* renamed from: a */
        private void m3980a(RemoteException remoteException) {
            m3981a(new Status(8, remoteException.getLocalizedMessage(), null));
        }

        /* renamed from: a */
        public final void m3981a(Status status) {
            C0854b.m3436b(!status.m3293e(), "Failed result must not be success");
            C0809e b = mo1005b(status);
            m3966b(b);
            mo1007a(b);
        }

        /* renamed from: a */
        public final void m3982a(A a) throws DeadObjectException {
            try {
                m3986b(a);
            } catch (RemoteException e) {
                m3980a(e);
                throw e;
            } catch (RemoteException e2) {
                m3980a(e2);
            }
        }

        /* renamed from: a */
        protected void mo1007a(R r) {
        }

        /* renamed from: a */
        public void m3984a(C0939b c0939b) {
            this.f1936f.set(c0939b);
        }

        /* renamed from: b */
        public final C0818d<A> mo1006b() {
            return this.f1934d;
        }

        /* renamed from: b */
        protected abstract void m3986b(A a) throws RemoteException;

        /* renamed from: c */
        public final C0824a<?> m3987c() {
            return this.f1935e;
        }

        /* renamed from: d */
        public void m3988d() {
            mo982a(null);
        }

        /* renamed from: e */
        protected void mo1008e() {
            C0939b c0939b = (C0939b) this.f1936f.getAndSet(null);
            if (c0939b != null) {
                c0939b.mo985a(this);
            }
        }
    }
}

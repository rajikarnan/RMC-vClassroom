package com.google.android.gms.p023d;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.C0840b;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0809e;
import com.google.android.gms.common.api.C0824a;
import com.google.android.gms.common.api.C0824a.C0816b;
import com.google.android.gms.common.api.C0824a.C0817c;
import com.google.android.gms.common.api.C0824a.C0818d;
import com.google.android.gms.common.api.C0824a.C0819f;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.C0807b;
import com.google.android.gms.common.api.GoogleApiClient.C0808c;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C0854b;
import com.google.android.gms.common.internal.C0890l;
import com.google.android.gms.common.internal.C0899q;
import com.google.android.gms.common.internal.C0899q.C0858a;
import com.google.android.gms.p023d.C0965h.C0964a;
import com.google.android.gms.p023d.C0978x.C0975a;
import com.google.android.gms.p023d.C1013v.C0967a;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.locks.Lock;

/* renamed from: com.google.android.gms.d.q */
public final class C1004q extends GoogleApiClient implements C0975a {
    /* renamed from: a */
    final Queue<C0964a<?, ?>> f2009a = new LinkedList();
    /* renamed from: b */
    C1013v f2010b;
    /* renamed from: c */
    final Map<C0818d<?>, C0819f> f2011c;
    /* renamed from: d */
    Set<Scope> f2012d = new HashSet();
    /* renamed from: e */
    final C0890l f2013e;
    /* renamed from: f */
    final Map<C0824a<?>, Integer> f2014f;
    /* renamed from: g */
    final C0816b<? extends ar, as> f2015g;
    /* renamed from: h */
    Set<aj> f2016h = null;
    /* renamed from: i */
    final ak f2017i;
    /* renamed from: j */
    private final Lock f2018j;
    /* renamed from: k */
    private final C0899q f2019k;
    /* renamed from: l */
    private C0978x f2020l = null;
    /* renamed from: m */
    private final int f2021m;
    /* renamed from: n */
    private final Context f2022n;
    /* renamed from: o */
    private final Looper f2023o;
    /* renamed from: p */
    private volatile boolean f2024p;
    /* renamed from: q */
    private long f2025q = 120000;
    /* renamed from: r */
    private long f2026r = 5000;
    /* renamed from: s */
    private final C1002a f2027s;
    /* renamed from: t */
    private final C0840b f2028t;
    /* renamed from: u */
    private final ae f2029u = new ae();
    /* renamed from: v */
    private final ArrayList<C0973k> f2030v;
    /* renamed from: w */
    private Integer f2031w = null;
    /* renamed from: x */
    private final C0858a f2032x = new C10011(this);

    /* renamed from: com.google.android.gms.d.q$1 */
    class C10011 implements C0858a {
        /* renamed from: a */
        final /* synthetic */ C1004q f2006a;

        C10011(C1004q c1004q) {
            this.f2006a = c1004q;
        }

        /* renamed from: b */
        public boolean mo1035b() {
            return this.f2006a.m4163c();
        }

        /* renamed from: s */
        public Bundle mo1036s() {
            return null;
        }
    }

    /* renamed from: com.google.android.gms.d.q$a */
    final class C1002a extends Handler {
        /* renamed from: a */
        final /* synthetic */ C1004q f2007a;

        C1002a(C1004q c1004q, Looper looper) {
            this.f2007a = c1004q;
            super(looper);
        }

        public void handleMessage(Message message) {
            switch (message.what) {
                case 1:
                    this.f2007a.m4149l();
                    return;
                case 2:
                    this.f2007a.m4148k();
                    return;
                default:
                    Log.w("GoogleApiClientImpl", "Unknown message id: " + message.what);
                    return;
            }
        }
    }

    /* renamed from: com.google.android.gms.d.q$b */
    static class C1003b extends C0967a {
        /* renamed from: a */
        private WeakReference<C1004q> f2008a;

        C1003b(C1004q c1004q) {
            this.f2008a = new WeakReference(c1004q);
        }

        /* renamed from: a */
        public void mo1009a() {
            C1004q c1004q = (C1004q) this.f2008a.get();
            if (c1004q != null) {
                c1004q.m4148k();
            }
        }
    }

    public C1004q(Context context, Lock lock, Looper looper, C0890l c0890l, C0840b c0840b, C0816b<? extends ar, as> c0816b, Map<C0824a<?>, Integer> map, List<C0807b> list, List<C0808c> list2, Map<C0818d<?>, C0819f> map2, int i, int i2, ArrayList<C0973k> arrayList) {
        this.f2022n = context;
        this.f2018j = lock;
        this.f2019k = new C0899q(looper, this.f2032x);
        this.f2023o = looper;
        this.f2027s = new C1002a(this, looper);
        this.f2028t = c0840b;
        this.f2021m = i;
        if (this.f2021m >= 0) {
            this.f2031w = Integer.valueOf(i2);
        }
        this.f2014f = map;
        this.f2011c = map2;
        this.f2030v = arrayList;
        this.f2017i = new ak(this.f2011c);
        for (C0807b a : list) {
            this.f2019k.m3590a(a);
        }
        for (C0808c a2 : list2) {
            this.f2019k.m3591a(a2);
        }
        this.f2013e = c0890l;
        this.f2015g = c0816b;
    }

    /* renamed from: a */
    public static int m4142a(Iterable<C0819f> iterable, boolean z) {
        int i = 0;
        int i2 = 0;
        for (C0819f c0819f : iterable) {
            if (c0819f.mo1106d()) {
                i2 = 1;
            }
            i = c0819f.m3306f() ? 1 : i;
        }
        return i2 != 0 ? (i == 0 || !z) ? 1 : 2 : 3;
    }

    /* renamed from: b */
    static String m4144b(int i) {
        switch (i) {
            case 1:
                return "SIGN_IN_MODE_REQUIRED";
            case 2:
                return "SIGN_IN_MODE_OPTIONAL";
            case 3:
                return "SIGN_IN_MODE_NONE";
            default:
                return "UNKNOWN";
        }
    }

    /* renamed from: c */
    private void m4146c(int i) {
        if (this.f2031w == null) {
            this.f2031w = Integer.valueOf(i);
        } else if (this.f2031w.intValue() != i) {
            String valueOf = String.valueOf(C1004q.m4144b(i));
            String valueOf2 = String.valueOf(C1004q.m4144b(this.f2031w.intValue()));
            throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 51) + String.valueOf(valueOf2).length()).append("Cannot use sign-in mode: ").append(valueOf).append(". Mode was already set to ").append(valueOf2).toString());
        }
        if (this.f2020l == null) {
            Object obj = null;
            Object obj2 = null;
            for (C0819f c0819f : this.f2011c.values()) {
                if (c0819f.mo1106d()) {
                    obj2 = 1;
                }
                obj = c0819f.m3306f() ? 1 : obj;
            }
            switch (this.f2031w.intValue()) {
                case 1:
                    if (obj2 == null) {
                        throw new IllegalStateException("SIGN_IN_MODE_REQUIRED cannot be used on a GoogleApiClient that does not contain any authenticated APIs. Use connect() instead.");
                    } else if (obj != null) {
                        throw new IllegalStateException("Cannot use SIGN_IN_MODE_REQUIRED with GOOGLE_SIGN_IN_API. Use connect(SIGN_IN_MODE_OPTIONAL) instead.");
                    }
                    break;
                case 2:
                    if (obj2 != null) {
                        this.f2020l = C0979l.m4017a(this.f2022n, this, this.f2018j, this.f2023o, this.f2028t, this.f2011c, this.f2013e, this.f2014f, this.f2015g, this.f2030v);
                        return;
                    }
                    break;
            }
            this.f2020l = new C1006s(this.f2022n, this, this.f2018j, this.f2023o, this.f2028t, this.f2011c, this.f2013e, this.f2014f, this.f2015g, this.f2030v, this);
        }
    }

    /* renamed from: j */
    private void m4147j() {
        this.f2019k.m3592b();
        this.f2020l.mo1016a();
    }

    /* renamed from: k */
    private void m4148k() {
        this.f2018j.lock();
        try {
            if (m4164d()) {
                m4147j();
            }
            this.f2018j.unlock();
        } catch (Throwable th) {
            this.f2018j.unlock();
        }
    }

    /* renamed from: l */
    private void m4149l() {
        this.f2018j.lock();
        try {
            if (m4166f()) {
                m4147j();
            }
            this.f2018j.unlock();
        } catch (Throwable th) {
            this.f2018j.unlock();
        }
    }

    /* renamed from: a */
    public Looper mo1037a() {
        return this.f2023o;
    }

    /* renamed from: a */
    public <C extends C0819f> C mo1038a(C0818d<C> c0818d) {
        Object obj = (C0819f) this.f2011c.get(c0818d);
        C0854b.m3428a(obj, (Object) "Appropriate Api was not requested.");
        return obj;
    }

    /* renamed from: a */
    public <A extends C0817c, T extends C0964a<? extends C0809e, A>> T mo1039a(T t) {
        C0854b.m3436b(t.mo1006b() != null, "This task can not be executed (it's probably a Batch or malformed)");
        boolean containsKey = this.f2011c.containsKey(t.mo1006b());
        String f = t.m3987c() != null ? t.m3987c().m3320f() : "the API";
        C0854b.m3436b(containsKey, new StringBuilder(String.valueOf(f).length() + 65).append("GoogleApiClient is not configured to use ").append(f).append(" required for this call.").toString());
        this.f2018j.lock();
        try {
            if (this.f2020l == null) {
                throw new IllegalStateException("GoogleApiClient is not connected yet.");
            }
            if (m4164d()) {
                this.f2009a.add(t);
                while (!this.f2009a.isEmpty()) {
                    C0964a c0964a = (C0964a) this.f2009a.remove();
                    this.f2017i.m3868a(c0964a);
                    c0964a.m3981a(Status.f1570c);
                }
            } else {
                t = this.f2020l.mo1015a(t);
                this.f2018j.unlock();
            }
            return t;
        } finally {
            this.f2018j.unlock();
        }
    }

    /* renamed from: a */
    public void mo1040a(int i) {
        boolean z = true;
        this.f2018j.lock();
        if (!(i == 3 || i == 1 || i == 2)) {
            z = false;
        }
        try {
            C0854b.m3436b(z, "Illegal sign-in mode: " + i);
            m4146c(i);
            m4147j();
        } finally {
            this.f2018j.unlock();
        }
    }

    /* renamed from: a */
    public void mo1012a(int i, boolean z) {
        if (i == 1 && !z) {
            m4165e();
        }
        this.f2017i.m3870b();
        this.f2019k.m3587a(i);
        this.f2019k.m3586a();
        if (i == 2) {
            m4147j();
        }
    }

    /* renamed from: a */
    public void mo1013a(Bundle bundle) {
        while (!this.f2009a.isEmpty()) {
            mo1039a((C0964a) this.f2009a.remove());
        }
        this.f2019k.m3588a(bundle);
    }

    /* renamed from: a */
    public void mo1014a(ConnectionResult connectionResult) {
        if (!this.f2028t.mo896a(this.f2022n, connectionResult.m3228c())) {
            m4166f();
        }
        if (!m4164d()) {
            this.f2019k.m3589a(connectionResult);
            this.f2019k.m3586a();
        }
    }

    /* renamed from: a */
    public void mo1041a(C0808c c0808c) {
        this.f2019k.m3591a(c0808c);
    }

    /* renamed from: a */
    public void mo1042a(aj ajVar) {
        this.f2018j.lock();
        try {
            if (this.f2016h == null) {
                this.f2016h = new HashSet();
            }
            this.f2016h.add(ajVar);
        } finally {
            this.f2018j.unlock();
        }
    }

    /* renamed from: a */
    public void mo1043a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        printWriter.append(str).append("mContext=").println(this.f2022n);
        printWriter.append(str).append("mResuming=").print(this.f2024p);
        printWriter.append(" mWorkQueue.size()=").print(this.f2009a.size());
        this.f2017i.m3869a(printWriter);
        if (this.f2020l != null) {
            this.f2020l.mo1017a(str, fileDescriptor, printWriter, strArr);
        }
    }

    /* renamed from: b */
    <C extends C0819f> C m4160b(C0818d<?> c0818d) {
        Object obj = (C0819f) this.f2011c.get(c0818d);
        C0854b.m3428a(obj, (Object) "Appropriate Api was not requested.");
        return obj;
    }

    /* renamed from: b */
    public void mo1044b(C0808c c0808c) {
        this.f2019k.m3593b(c0808c);
    }

    /* renamed from: b */
    public void mo1045b(aj ajVar) {
        this.f2018j.lock();
        try {
            if (this.f2016h == null) {
                Log.wtf("GoogleApiClientImpl", "Attempted to remove pending transform when no transforms are registered.", new Exception());
            } else if (!this.f2016h.remove(ajVar)) {
                Log.wtf("GoogleApiClientImpl", "Failed to remove pending transform - this may lead to memory leaks!", new Exception());
            } else if (!m4167g()) {
                this.f2020l.mo1020d();
            }
            this.f2018j.unlock();
        } catch (Throwable th) {
            this.f2018j.unlock();
        }
    }

    /* renamed from: c */
    public boolean m4163c() {
        return this.f2020l != null && this.f2020l.mo1019c();
    }

    public void connect() {
        boolean z = false;
        this.f2018j.lock();
        try {
            if (this.f2021m >= 0) {
                if (this.f2031w != null) {
                    z = true;
                }
                C0854b.m3432a(z, (Object) "Sign-in mode should have been set explicitly by auto-manage.");
            } else if (this.f2031w == null) {
                this.f2031w = Integer.valueOf(C1004q.m4142a(this.f2011c.values(), false));
            } else if (this.f2031w.intValue() == 2) {
                throw new IllegalStateException("Cannot call connect() when SignInMode is set to SIGN_IN_MODE_OPTIONAL. Call connect(SIGN_IN_MODE_OPTIONAL) instead.");
            }
            mo1040a(this.f2031w.intValue());
        } finally {
            this.f2018j.unlock();
        }
    }

    /* renamed from: d */
    boolean m4164d() {
        return this.f2024p;
    }

    public void disconnect() {
        this.f2018j.lock();
        try {
            this.f2017i.m3867a();
            if (this.f2020l != null) {
                this.f2020l.mo1018b();
            }
            this.f2029u.m3832a();
            for (C0964a c0964a : this.f2009a) {
                c0964a.m3984a(null);
                c0964a.m3970g();
            }
            this.f2009a.clear();
            if (this.f2020l != null) {
                m4166f();
                this.f2019k.m3586a();
                this.f2018j.unlock();
            }
        } finally {
            this.f2018j.unlock();
        }
    }

    /* renamed from: e */
    void m4165e() {
        if (!m4164d()) {
            this.f2024p = true;
            if (this.f2010b == null) {
                this.f2010b = this.f2028t.m3362a(this.f2022n.getApplicationContext(), new C1003b(this));
            }
            this.f2027s.sendMessageDelayed(this.f2027s.obtainMessage(1), this.f2025q);
            this.f2027s.sendMessageDelayed(this.f2027s.obtainMessage(2), this.f2026r);
        }
    }

    /* renamed from: f */
    boolean m4166f() {
        if (!m4164d()) {
            return false;
        }
        this.f2024p = false;
        this.f2027s.removeMessages(2);
        this.f2027s.removeMessages(1);
        if (this.f2010b != null) {
            this.f2010b.m4242a();
            this.f2010b = null;
        }
        return true;
    }

    /* renamed from: g */
    boolean m4167g() {
        boolean z = false;
        this.f2018j.lock();
        try {
            if (this.f2016h != null) {
                if (!this.f2016h.isEmpty()) {
                    z = true;
                }
                this.f2018j.unlock();
            }
            return z;
        } finally {
            this.f2018j.unlock();
        }
    }

    /* renamed from: h */
    String m4168h() {
        Writer stringWriter = new StringWriter();
        mo1043a("", null, new PrintWriter(stringWriter), null);
        return stringWriter.toString();
    }

    /* renamed from: i */
    public int m4169i() {
        return System.identityHashCode(this);
    }
}

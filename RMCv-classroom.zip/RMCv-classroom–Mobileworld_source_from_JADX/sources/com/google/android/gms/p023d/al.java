package com.google.android.gms.p023d;

/* renamed from: com.google.android.gms.d.al */
public abstract class al<T> {
    /* renamed from: c */
    private static final Object f1867c = new Object();
    /* renamed from: d */
    private static C0945a f1868d = null;
    /* renamed from: e */
    private static int f1869e = 0;
    /* renamed from: f */
    private static String f1870f = "com.google.android.providers.gsf.permission.READ_GSERVICES";
    /* renamed from: a */
    protected final String f1871a;
    /* renamed from: b */
    protected final T f1872b;
    /* renamed from: g */
    private T f1873g = null;

    /* renamed from: com.google.android.gms.d.al$1 */
    class C09421 extends al<Long> {
        C09421(String str, Long l) {
            super(str, l);
        }

        /* renamed from: a */
        protected /* synthetic */ Object mo986a(String str) {
            return m3879b(str);
        }

        /* renamed from: b */
        protected Long m3879b(String str) {
            return null.m3885a(this.a, (Long) this.b);
        }
    }

    /* renamed from: com.google.android.gms.d.al$2 */
    class C09432 extends al<Integer> {
        C09432(String str, Integer num) {
            super(str, num);
        }

        /* renamed from: a */
        protected /* synthetic */ Object mo986a(String str) {
            return m3881b(str);
        }

        /* renamed from: b */
        protected Integer m3881b(String str) {
            return null.m3884a(this.a, (Integer) this.b);
        }
    }

    /* renamed from: com.google.android.gms.d.al$3 */
    class C09443 extends al<String> {
        C09443(String str, String str2) {
            super(str, str2);
        }

        /* renamed from: a */
        protected /* synthetic */ Object mo986a(String str) {
            return m3883b(str);
        }

        /* renamed from: b */
        protected String m3883b(String str) {
            return null.m3886a(this.a, (String) this.b);
        }
    }

    /* renamed from: com.google.android.gms.d.al$a */
    private interface C0945a {
        /* renamed from: a */
        Integer m3884a(String str, Integer num);

        /* renamed from: a */
        Long m3885a(String str, Long l);

        /* renamed from: a */
        String m3886a(String str, String str2);
    }

    protected al(String str, T t) {
        this.f1871a = str;
        this.f1872b = t;
    }

    /* renamed from: a */
    public static al<Integer> m3872a(String str, Integer num) {
        return new C09432(str, num);
    }

    /* renamed from: a */
    public static al<Long> m3873a(String str, Long l) {
        return new C09421(str, l);
    }

    /* renamed from: a */
    public static al<String> m3874a(String str, String str2) {
        return new C09443(str, str2);
    }

    /* renamed from: a */
    public final T m3876a() {
        return mo986a(this.f1871a);
    }

    /* renamed from: a */
    protected abstract T mo986a(String str);
}

package com.google.android.gms.p023d;

import com.google.android.gms.common.api.C0824a.C0810a.C0814d;

/* renamed from: com.google.android.gms.d.as */
public final class as implements C0814d {
    /* renamed from: a */
    public static final as f1891a = new C0950a().m3901a();
    /* renamed from: b */
    private final boolean f1892b;
    /* renamed from: c */
    private final boolean f1893c;
    /* renamed from: d */
    private final String f1894d;
    /* renamed from: e */
    private final boolean f1895e;
    /* renamed from: f */
    private final String f1896f;
    /* renamed from: g */
    private final boolean f1897g;

    /* renamed from: com.google.android.gms.d.as$a */
    public static final class C0950a {
        /* renamed from: a */
        public as m3901a() {
            return new as(false, false, null, false, null, false);
        }
    }

    private as(boolean z, boolean z2, String str, boolean z3, String str2, boolean z4) {
        this.f1892b = z;
        this.f1893c = z2;
        this.f1894d = str;
        this.f1895e = z3;
        this.f1897g = z4;
        this.f1896f = str2;
    }

    /* renamed from: a */
    public boolean m3902a() {
        return this.f1892b;
    }

    /* renamed from: b */
    public boolean m3903b() {
        return this.f1893c;
    }

    /* renamed from: c */
    public String m3904c() {
        return this.f1894d;
    }

    /* renamed from: d */
    public boolean m3905d() {
        return this.f1895e;
    }

    /* renamed from: e */
    public String m3906e() {
        return this.f1896f;
    }

    /* renamed from: f */
    public boolean m3907f() {
        return this.f1897g;
    }
}

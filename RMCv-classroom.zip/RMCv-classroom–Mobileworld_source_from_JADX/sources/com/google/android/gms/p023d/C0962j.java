package com.google.android.gms.p023d;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.util.Pair;
import com.google.android.gms.common.api.C0809e;
import com.google.android.gms.common.api.C0827c;
import com.google.android.gms.common.api.C0827c.C0826a;
import com.google.android.gms.common.api.C0828d;
import com.google.android.gms.common.api.C0829f;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C0854b;
import com.google.android.gms.common.internal.C0910v;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CountDownLatch;

/* renamed from: com.google.android.gms.d.j */
public abstract class C0962j<R extends C0809e> extends C0827c<R> {
    /* renamed from: a */
    static final ThreadLocal<Boolean> f1917a = new C09701();
    /* renamed from: b */
    protected final C0971a<R> f1918b = new C0971a(Looper.getMainLooper());
    /* renamed from: c */
    protected final WeakReference<GoogleApiClient> f1919c = new WeakReference(null);
    /* renamed from: d */
    private final Object f1920d = new Object();
    /* renamed from: e */
    private final CountDownLatch f1921e = new CountDownLatch(1);
    /* renamed from: f */
    private final ArrayList<C0826a> f1922f = new ArrayList();
    /* renamed from: g */
    private C0829f<? super R> f1923g;
    /* renamed from: h */
    private R f1924h;
    /* renamed from: i */
    private C0972b f1925i;
    /* renamed from: j */
    private volatile boolean f1926j;
    /* renamed from: k */
    private boolean f1927k;
    /* renamed from: l */
    private boolean f1928l;
    /* renamed from: m */
    private C0910v f1929m;
    /* renamed from: n */
    private volatile aj<R> f1930n;
    /* renamed from: o */
    private boolean f1931o = false;

    /* renamed from: com.google.android.gms.d.j$1 */
    class C09701 extends ThreadLocal<Boolean> {
        C09701() {
        }

        /* renamed from: a */
        protected Boolean m3992a() {
            return Boolean.valueOf(false);
        }

        protected /* synthetic */ Object initialValue() {
            return m3992a();
        }
    }

    /* renamed from: com.google.android.gms.d.j$a */
    public static class C0971a<R extends C0809e> extends Handler {
        public C0971a() {
            this(Looper.getMainLooper());
        }

        public C0971a(Looper looper) {
            super(looper);
        }

        /* renamed from: a */
        public void m3993a() {
            removeMessages(2);
        }

        /* renamed from: a */
        public void m3994a(C0829f<? super R> c0829f, R r) {
            sendMessage(obtainMessage(1, new Pair(c0829f, r)));
        }

        /* renamed from: b */
        protected void m3995b(C0829f<? super R> c0829f, R r) {
            try {
                c0829f.mo984a(r);
            } catch (RuntimeException e) {
                C0962j.m3962c((C0809e) r);
                throw e;
            }
        }

        public void handleMessage(Message message) {
            switch (message.what) {
                case 1:
                    Pair pair = (Pair) message.obj;
                    m3995b((C0829f) pair.first, (C0809e) pair.second);
                    return;
                case 2:
                    ((C0962j) message.obj).m3967c(Status.f1571d);
                    return;
                default:
                    Log.wtf("BasePendingResult", "Don't know how to handle message: " + message.what, new Exception());
                    return;
            }
        }
    }

    /* renamed from: com.google.android.gms.d.j$b */
    private final class C0972b {
        /* renamed from: a */
        final /* synthetic */ C0962j f1940a;

        private C0972b(C0962j c0962j) {
            this.f1940a = c0962j;
        }

        protected void finalize() throws Throwable {
            C0962j.m3962c(this.f1940a.f1924h);
            super.finalize();
        }
    }

    @Deprecated
    C0962j() {
    }

    /* renamed from: a */
    private void mo1007a(R r) {
        this.f1924h = r;
        this.f1929m = null;
        this.f1921e.countDown();
        Status a = this.f1924h.mo890a();
        if (this.f1927k) {
            this.f1923g = null;
        } else if (this.f1923g != null) {
            this.f1918b.m3993a();
            this.f1918b.m3994a(this.f1923g, mo1006b());
        } else if (this.f1924h instanceof C0828d) {
            this.f1925i = new C0972b();
        }
        Iterator it = this.f1922f.iterator();
        while (it.hasNext()) {
            ((C0826a) it.next()).m3322a(a);
        }
        this.f1922f.clear();
    }

    /* renamed from: b */
    private R mo1006b() {
        R r;
        boolean z = true;
        synchronized (this.f1920d) {
            if (this.f1926j) {
                z = false;
            }
            C0854b.m3432a(z, (Object) "Result has already been consumed.");
            C0854b.m3432a(m3969f(), (Object) "Result is not ready.");
            r = this.f1924h;
            this.f1924h = null;
            this.f1923g = null;
            this.f1926j = true;
        }
        mo1008e();
        return r;
    }

    /* renamed from: c */
    public static void m3962c(C0809e c0809e) {
        if (c0809e instanceof C0828d) {
            try {
                ((C0828d) c0809e).m3325a();
            } catch (Throwable e) {
                String valueOf = String.valueOf(c0809e);
                Log.w("BasePendingResult", new StringBuilder(String.valueOf(valueOf).length() + 18).append("Unable to release ").append(valueOf).toString(), e);
            }
        }
    }

    /* renamed from: a */
    public Integer mo981a() {
        return null;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: a */
    public final void mo982a(com.google.android.gms.common.api.C0829f<? super R> r6) {
        /*
        r5 = this;
        r0 = 1;
        r1 = 0;
        r3 = r5.f1920d;
        monitor-enter(r3);
        if (r6 != 0) goto L_0x000c;
    L_0x0007:
        r0 = 0;
        r5.f1923g = r0;	 Catch:{ all -> 0x0027 }
        monitor-exit(r3);	 Catch:{ all -> 0x0027 }
    L_0x000b:
        return;
    L_0x000c:
        r2 = r5.f1926j;	 Catch:{ all -> 0x0027 }
        if (r2 != 0) goto L_0x002a;
    L_0x0010:
        r2 = r0;
    L_0x0011:
        r4 = "Result has already been consumed.";
        com.google.android.gms.common.internal.C0854b.m3432a(r2, r4);	 Catch:{ all -> 0x0027 }
        r2 = r5.f1930n;	 Catch:{ all -> 0x0027 }
        if (r2 != 0) goto L_0x002c;
    L_0x001a:
        r1 = "Cannot set callbacks if then() has been called.";
        com.google.android.gms.common.internal.C0854b.m3432a(r0, r1);	 Catch:{ all -> 0x0027 }
        r0 = r5.m3972i();	 Catch:{ all -> 0x0027 }
        if (r0 == 0) goto L_0x002e;
    L_0x0025:
        monitor-exit(r3);	 Catch:{ all -> 0x0027 }
        goto L_0x000b;
    L_0x0027:
        r0 = move-exception;
        monitor-exit(r3);	 Catch:{ all -> 0x0027 }
        throw r0;
    L_0x002a:
        r2 = r1;
        goto L_0x0011;
    L_0x002c:
        r0 = r1;
        goto L_0x001a;
    L_0x002e:
        r0 = r5.m3969f();	 Catch:{ all -> 0x0027 }
        if (r0 == 0) goto L_0x003f;
    L_0x0034:
        r0 = r5.f1918b;	 Catch:{ all -> 0x0027 }
        r1 = r5.mo1006b();	 Catch:{ all -> 0x0027 }
        r0.m3994a(r6, r1);	 Catch:{ all -> 0x0027 }
    L_0x003d:
        monitor-exit(r3);	 Catch:{ all -> 0x0027 }
        goto L_0x000b;
    L_0x003f:
        r5.f1923g = r6;	 Catch:{ all -> 0x0027 }
        goto L_0x003d;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.d.j.a(com.google.android.gms.common.api.f):void");
    }

    /* renamed from: b */
    protected abstract R mo1005b(Status status);

    /* renamed from: b */
    public final void m3966b(R r) {
        boolean z = true;
        synchronized (this.f1920d) {
            if (this.f1928l || this.f1927k || (m3969f() && m3974k())) {
                C0962j.m3962c((C0809e) r);
                return;
            }
            C0854b.m3432a(!m3969f(), (Object) "Results have already been set");
            if (this.f1926j) {
                z = false;
            }
            C0854b.m3432a(z, (Object) "Result has already been consumed");
            mo1007a((C0809e) r);
        }
    }

    /* renamed from: c */
    public final void m3967c(Status status) {
        synchronized (this.f1920d) {
            if (!m3969f()) {
                m3966b(mo1005b(status));
                this.f1928l = true;
            }
        }
    }

    /* renamed from: e */
    protected void mo1008e() {
    }

    /* renamed from: f */
    public final boolean m3969f() {
        return this.f1921e.getCount() == 0;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: g */
    public void m3970g() {
        /*
        r2 = this;
        r1 = r2.f1920d;
        monitor-enter(r1);
        r0 = r2.f1927k;	 Catch:{ all -> 0x0029 }
        if (r0 != 0) goto L_0x000b;
    L_0x0007:
        r0 = r2.f1926j;	 Catch:{ all -> 0x0029 }
        if (r0 == 0) goto L_0x000d;
    L_0x000b:
        monitor-exit(r1);	 Catch:{ all -> 0x0029 }
    L_0x000c:
        return;
    L_0x000d:
        r0 = r2.f1929m;	 Catch:{ all -> 0x0029 }
        if (r0 == 0) goto L_0x0016;
    L_0x0011:
        r0 = r2.f1929m;	 Catch:{ RemoteException -> 0x002c }
        r0.m3668a();	 Catch:{ RemoteException -> 0x002c }
    L_0x0016:
        r0 = r2.f1924h;	 Catch:{ all -> 0x0029 }
        com.google.android.gms.p023d.C0962j.m3962c(r0);	 Catch:{ all -> 0x0029 }
        r0 = 1;
        r2.f1927k = r0;	 Catch:{ all -> 0x0029 }
        r0 = com.google.android.gms.common.api.Status.f1572e;	 Catch:{ all -> 0x0029 }
        r0 = r2.mo1005b(r0);	 Catch:{ all -> 0x0029 }
        r2.mo1007a(r0);	 Catch:{ all -> 0x0029 }
        monitor-exit(r1);	 Catch:{ all -> 0x0029 }
        goto L_0x000c;
    L_0x0029:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x0029 }
        throw r0;
    L_0x002c:
        r0 = move-exception;
        goto L_0x0016;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.d.j.g():void");
    }

    /* renamed from: h */
    public boolean m3971h() {
        boolean i;
        synchronized (this.f1920d) {
            if (((GoogleApiClient) this.f1919c.get()) == null || !this.f1931o) {
                m3970g();
            }
            i = m3972i();
        }
        return i;
    }

    /* renamed from: i */
    public boolean m3972i() {
        boolean z;
        synchronized (this.f1920d) {
            z = this.f1927k;
        }
        return z;
    }

    /* renamed from: j */
    public void m3973j() {
        boolean z = this.f1931o || ((Boolean) f1917a.get()).booleanValue();
        this.f1931o = z;
    }

    /* renamed from: k */
    boolean m3974k() {
        return false;
    }
}

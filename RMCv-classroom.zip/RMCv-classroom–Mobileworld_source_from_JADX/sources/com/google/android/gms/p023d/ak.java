package com.google.android.gms.p023d;

import android.os.IBinder;
import android.os.IBinder.DeathRecipient;
import android.os.RemoteException;
import android.support.v4.p011e.C0222a;
import com.google.android.gms.common.api.C0809e;
import com.google.android.gms.common.api.C0824a.C0817c;
import com.google.android.gms.common.api.C0824a.C0818d;
import com.google.android.gms.common.api.C0824a.C0819f;
import com.google.android.gms.common.api.C0836m;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.p023d.C0965h.C0964a;
import java.io.PrintWriter;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

/* renamed from: com.google.android.gms.d.ak */
public class ak {
    /* renamed from: b */
    private static final C0964a<?, ?>[] f1863b = new C0964a[0];
    /* renamed from: a */
    final Set<C0964a<?, ?>> f1864a;
    /* renamed from: c */
    private final C0939b f1865c;
    /* renamed from: d */
    private final Map<C0818d<?>, C0819f> f1866d;

    /* renamed from: com.google.android.gms.d.ak$b */
    interface C0939b {
        /* renamed from: a */
        void mo985a(C0964a<?, ?> c0964a);
    }

    /* renamed from: com.google.android.gms.d.ak$1 */
    class C09401 implements C0939b {
        /* renamed from: a */
        final /* synthetic */ ak f1859a;

        C09401(ak akVar) {
            this.f1859a = akVar;
        }

        /* renamed from: a */
        public void mo985a(C0964a<?, ?> c0964a) {
            this.f1859a.f1864a.remove(c0964a);
            if (c0964a.mo981a() != null && null != null) {
                null.m3337a(c0964a.mo981a().intValue());
            }
        }
    }

    /* renamed from: com.google.android.gms.d.ak$a */
    private static class C0941a implements DeathRecipient, C0939b {
        /* renamed from: a */
        private final WeakReference<C0964a<?, ?>> f1860a;
        /* renamed from: b */
        private final WeakReference<C0836m> f1861b;
        /* renamed from: c */
        private final WeakReference<IBinder> f1862c;

        private C0941a(C0964a<?, ?> c0964a, C0836m c0836m, IBinder iBinder) {
            this.f1861b = new WeakReference(c0836m);
            this.f1860a = new WeakReference(c0964a);
            this.f1862c = new WeakReference(iBinder);
        }

        /* renamed from: a */
        private void m3863a() {
            C0964a c0964a = (C0964a) this.f1860a.get();
            C0836m c0836m = (C0836m) this.f1861b.get();
            if (!(c0836m == null || c0964a == null)) {
                c0836m.m3337a(c0964a.mo981a().intValue());
            }
            IBinder iBinder = (IBinder) this.f1862c.get();
            if (this.f1862c != null) {
                iBinder.unlinkToDeath(this, 0);
            }
        }

        /* renamed from: a */
        public void mo985a(C0964a<?, ?> c0964a) {
            m3863a();
        }

        public void binderDied() {
            m3863a();
        }
    }

    public ak(C0818d<?> c0818d, C0819f c0819f) {
        this.f1864a = Collections.synchronizedSet(Collections.newSetFromMap(new WeakHashMap()));
        this.f1865c = new C09401(this);
        this.f1866d = new C0222a();
        this.f1866d.put(c0818d, c0819f);
    }

    public ak(Map<C0818d<?>, C0819f> map) {
        this.f1864a = Collections.synchronizedSet(Collections.newSetFromMap(new WeakHashMap()));
        this.f1865c = new C09401(this);
        this.f1866d = map;
    }

    /* renamed from: a */
    private static void m3866a(C0964a<?, ?> c0964a, C0836m c0836m, IBinder iBinder) {
        if (c0964a.m3969f()) {
            c0964a.m3984a(new C0941a(c0964a, c0836m, iBinder));
        } else if (iBinder == null || !iBinder.isBinderAlive()) {
            c0964a.m3984a(null);
            c0964a.m3970g();
            c0836m.m3337a(c0964a.mo981a().intValue());
        } else {
            C0939b c0941a = new C0941a(c0964a, c0836m, iBinder);
            c0964a.m3984a(c0941a);
            try {
                iBinder.linkToDeath(c0941a, 0);
            } catch (RemoteException e) {
                c0964a.m3970g();
                c0836m.m3337a(c0964a.mo981a().intValue());
            }
        }
    }

    /* renamed from: a */
    public void m3867a() {
        for (C0964a c0964a : (C0964a[]) this.f1864a.toArray(f1863b)) {
            c0964a.m3984a(null);
            if (c0964a.mo981a() != null) {
                c0964a.m3988d();
                ak.m3866a(c0964a, null, ((C0819f) this.f1866d.get(c0964a.mo1006b())).m3308h());
                this.f1864a.remove(c0964a);
            } else if (c0964a.m3971h()) {
                this.f1864a.remove(c0964a);
            }
        }
    }

    /* renamed from: a */
    <A extends C0817c> void m3868a(C0964a<? extends C0809e, A> c0964a) {
        this.f1864a.add(c0964a);
        c0964a.m3984a(this.f1865c);
    }

    /* renamed from: a */
    public void m3869a(PrintWriter printWriter) {
        printWriter.append(" mUnconsumedApiCalls.size()=").println(this.f1864a.size());
    }

    /* renamed from: b */
    public void m3870b() {
        for (C0964a c : (C0964a[]) this.f1864a.toArray(f1863b)) {
            c.m3967c(new Status(8, "The connection to Google Play services was lost"));
        }
    }

    /* renamed from: c */
    public boolean m3871c() {
        for (C0964a f : (C0964a[]) this.f1864a.toArray(f1863b)) {
            if (!f.m3969f()) {
                return true;
            }
        }
        return false;
    }
}

package com.google.android.gms.p023d;

/* renamed from: com.google.android.gms.d.ad */
public final class ad<L> {
    /* renamed from: a */
    private volatile L f1836a;

    /* renamed from: a */
    public void m3831a() {
        this.f1836a = null;
    }
}

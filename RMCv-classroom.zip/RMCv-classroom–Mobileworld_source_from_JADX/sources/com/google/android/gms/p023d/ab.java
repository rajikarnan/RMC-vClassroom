package com.google.android.gms.p023d;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.p011e.C0222a;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.ref.WeakReference;
import java.util.Map;
import java.util.Map.Entry;
import java.util.WeakHashMap;

@TargetApi(11)
/* renamed from: com.google.android.gms.d.ab */
public final class ab extends Fragment implements aa {
    /* renamed from: a */
    private static WeakHashMap<Activity, WeakReference<ab>> f1832a = new WeakHashMap();
    /* renamed from: b */
    private Map<String, C0959z> f1833b = new C0222a();
    /* renamed from: c */
    private int f1834c = 0;
    /* renamed from: d */
    private Bundle f1835d;

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: a */
    public static com.google.android.gms.p023d.ab m3824a(android.app.Activity r3) {
        /*
        r0 = f1832a;
        r0 = r0.get(r3);
        r0 = (java.lang.ref.WeakReference) r0;
        if (r0 == 0) goto L_0x0013;
    L_0x000a:
        r0 = r0.get();
        r0 = (com.google.android.gms.p023d.ab) r0;
        if (r0 == 0) goto L_0x0013;
    L_0x0012:
        return r0;
    L_0x0013:
        r0 = r3.getFragmentManager();	 Catch:{ ClassCastException -> 0x0048 }
        r1 = "LifecycleFragmentImpl";
        r0 = r0.findFragmentByTag(r1);	 Catch:{ ClassCastException -> 0x0048 }
        r0 = (com.google.android.gms.p023d.ab) r0;	 Catch:{ ClassCastException -> 0x0048 }
        if (r0 == 0) goto L_0x0027;
    L_0x0021:
        r1 = r0.isRemoving();
        if (r1 == 0) goto L_0x003d;
    L_0x0027:
        r0 = new com.google.android.gms.d.ab;
        r0.<init>();
        r1 = r3.getFragmentManager();
        r1 = r1.beginTransaction();
        r2 = "LifecycleFragmentImpl";
        r1 = r1.add(r0, r2);
        r1.commitAllowingStateLoss();
    L_0x003d:
        r1 = f1832a;
        r2 = new java.lang.ref.WeakReference;
        r2.<init>(r0);
        r1.put(r3, r2);
        goto L_0x0012;
    L_0x0048:
        r0 = move-exception;
        r1 = new java.lang.IllegalStateException;
        r2 = "Fragment with tag LifecycleFragmentImpl is not a LifecycleFragmentImpl";
        r1.<init>(r2, r0);
        throw r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.d.ab.a(android.app.Activity):com.google.android.gms.d.ab");
    }

    /* renamed from: b */
    private void m3826b(final String str, final C0959z c0959z) {
        if (this.f1834c > 0) {
            new Handler(Looper.getMainLooper()).post(new Runnable(this) {
                /* renamed from: c */
                final /* synthetic */ ab f1831c;

                public void run() {
                    if (this.f1831c.f1834c >= 1) {
                        c0959z.mo999a(this.f1831c.f1835d != null ? this.f1831c.f1835d.getBundle(str) : null);
                    }
                    if (this.f1831c.f1834c >= 2) {
                        c0959z.mo997a();
                    }
                    if (this.f1831c.f1834c >= 3) {
                        c0959z.mo1000b();
                    }
                }
            });
        }
    }

    /* renamed from: a */
    public Activity mo978a() {
        return getActivity();
    }

    /* renamed from: a */
    public <T extends C0959z> T mo979a(String str, Class<T> cls) {
        return (C0959z) cls.cast(this.f1833b.get(str));
    }

    /* renamed from: a */
    public void mo980a(String str, C0959z c0959z) {
        if (this.f1833b.containsKey(str)) {
            throw new IllegalArgumentException(new StringBuilder(String.valueOf(str).length() + 59).append("LifecycleCallback with tag ").append(str).append(" already added to this fragment.").toString());
        }
        this.f1833b.put(str, c0959z);
        m3826b(str, c0959z);
    }

    public void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        for (C0959z a : this.f1833b.values()) {
            a.mo1003a(str, fileDescriptor, printWriter, strArr);
        }
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        for (C0959z a : this.f1833b.values()) {
            a.mo998a(i, i2, intent);
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f1834c = 1;
        this.f1835d = bundle;
        for (Entry entry : this.f1833b.entrySet()) {
            ((C0959z) entry.getValue()).mo999a(bundle != null ? bundle.getBundle((String) entry.getKey()) : null);
        }
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        if (bundle != null) {
            for (Entry entry : this.f1833b.entrySet()) {
                Bundle bundle2 = new Bundle();
                ((C0959z) entry.getValue()).mo1001b(bundle2);
                bundle.putBundle((String) entry.getKey(), bundle2);
            }
        }
    }

    public void onStart() {
        super.onStop();
        this.f1834c = 2;
        for (C0959z a : this.f1833b.values()) {
            a.mo997a();
        }
    }

    public void onStop() {
        super.onStop();
        this.f1834c = 3;
        for (C0959z b : this.f1833b.values()) {
            b.mo1000b();
        }
    }
}

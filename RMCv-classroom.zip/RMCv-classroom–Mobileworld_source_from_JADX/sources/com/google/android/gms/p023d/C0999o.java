package com.google.android.gms.p023d;

import android.content.Context;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import com.google.android.gms.common.C0839j;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0809e;
import com.google.android.gms.common.api.C0824a;
import com.google.android.gms.common.api.C0824a.C0816b;
import com.google.android.gms.common.api.C0824a.C0817c;
import com.google.android.gms.common.api.C0824a.C0818d;
import com.google.android.gms.common.api.C0824a.C0819f;
import com.google.android.gms.common.api.GoogleApiClient.C0807b;
import com.google.android.gms.common.api.GoogleApiClient.C0808c;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.C0849u;
import com.google.android.gms.common.internal.C0854b;
import com.google.android.gms.common.internal.C0857i.C0869f;
import com.google.android.gms.common.internal.C0890l;
import com.google.android.gms.common.internal.C0890l.C0889a;
import com.google.android.gms.common.internal.ResolveAccountResponse;
import com.google.android.gms.p023d.C0965h.C0964a;
import com.google.android.gms.p023d.C1006s.C0981a;
import com.google.android.gms.signin.internal.C0996b;
import com.google.android.gms.signin.internal.SignInResponse;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Future;
import java.util.concurrent.locks.Lock;

/* renamed from: com.google.android.gms.d.o */
public class C0999o implements C0984r {
    /* renamed from: a */
    private final C1006s f1984a;
    /* renamed from: b */
    private final Lock f1985b;
    /* renamed from: c */
    private final Context f1986c;
    /* renamed from: d */
    private final C0839j f1987d;
    /* renamed from: e */
    private ConnectionResult f1988e;
    /* renamed from: f */
    private int f1989f;
    /* renamed from: g */
    private int f1990g = 0;
    /* renamed from: h */
    private int f1991h;
    /* renamed from: i */
    private final Bundle f1992i = new Bundle();
    /* renamed from: j */
    private final Set<C0818d> f1993j = new HashSet();
    /* renamed from: k */
    private ar f1994k;
    /* renamed from: l */
    private int f1995l;
    /* renamed from: m */
    private boolean f1996m;
    /* renamed from: n */
    private boolean f1997n;
    /* renamed from: o */
    private C0849u f1998o;
    /* renamed from: p */
    private boolean f1999p;
    /* renamed from: q */
    private boolean f2000q;
    /* renamed from: r */
    private final C0890l f2001r;
    /* renamed from: s */
    private final Map<C0824a<?>, Integer> f2002s;
    /* renamed from: t */
    private final C0816b<? extends ar, as> f2003t;
    /* renamed from: u */
    private ArrayList<Future<?>> f2004u = new ArrayList();

    /* renamed from: com.google.android.gms.d.o$1 */
    class C09861 implements Runnable {
        /* renamed from: a */
        final /* synthetic */ C0999o f1966a;

        C09861(C0999o c0999o) {
            this.f1966a = c0999o;
        }

        public void run() {
            this.f1966a.f1987d.m3354b(this.f1966a.f1986c);
        }
    }

    /* renamed from: com.google.android.gms.d.o$a */
    private static class C0987a implements C0869f {
        /* renamed from: a */
        private final WeakReference<C0999o> f1967a;
        /* renamed from: b */
        private final C0824a<?> f1968b;
        /* renamed from: c */
        private final int f1969c;

        public C0987a(C0999o c0999o, C0824a<?> c0824a, int i) {
            this.f1967a = new WeakReference(c0999o);
            this.f1968b = c0824a;
            this.f1969c = i;
        }

        /* renamed from: a */
        public void mo912a(ConnectionResult connectionResult) {
            boolean z = false;
            C0999o c0999o = (C0999o) this.f1967a.get();
            if (c0999o != null) {
                if (Looper.myLooper() == c0999o.f1984a.f2040g.mo1037a()) {
                    z = true;
                }
                C0854b.m3432a(z, (Object) "onReportServiceBinding must be called on the GoogleApiClient handler thread");
                c0999o.f1985b.lock();
                try {
                    if (c0999o.m4104b(0)) {
                        if (!connectionResult.m3227b()) {
                            c0999o.m4103b(connectionResult, this.f1968b, this.f1969c);
                        }
                        if (c0999o.m4111d()) {
                            c0999o.m4112e();
                        }
                        c0999o.f1985b.unlock();
                    }
                } finally {
                    c0999o.f1985b.unlock();
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.d.o$f */
    private abstract class C0990f implements Runnable {
        /* renamed from: b */
        final /* synthetic */ C0999o f1974b;

        private C0990f(C0999o c0999o) {
            this.f1974b = c0999o;
        }

        /* renamed from: a */
        protected abstract void mo1029a();

        public void run() {
            this.f1974b.f1985b.lock();
            try {
                if (!Thread.interrupted()) {
                    mo1029a();
                    this.f1974b.f1985b.unlock();
                }
            } catch (RuntimeException e) {
                this.f1974b.f1984a.m4179a(e);
            } finally {
                this.f1974b.f1985b.unlock();
            }
        }
    }

    /* renamed from: com.google.android.gms.d.o$b */
    private class C0991b extends C0990f {
        /* renamed from: a */
        final /* synthetic */ C0999o f1975a;
        /* renamed from: c */
        private final Map<C0819f, C0987a> f1976c;

        public C0991b(C0999o c0999o, Map<C0819f, C0987a> map) {
            this.f1975a = c0999o;
            super();
            this.f1976c = map;
        }

        /* renamed from: a */
        public void mo1029a() {
            int i;
            int i2 = 1;
            int i3 = 0;
            int i4 = 1;
            int i5 = 0;
            for (C0819f c0819f : this.f1976c.keySet()) {
                if (!c0819f.m3305e()) {
                    i = 0;
                    i4 = i5;
                } else if (((C0987a) this.f1976c.get(c0819f)).f1969c == 0) {
                    i = 1;
                    break;
                } else {
                    i = i4;
                    i4 = 1;
                }
                i5 = i4;
                i4 = i;
            }
            i2 = i5;
            i = 0;
            if (i2 != 0) {
                i3 = this.f1975a.f1987d.mo891a(this.f1975a.f1986c);
            }
            if (i3 == 0 || (r0 == 0 && i4 == 0)) {
                if (this.f1975a.f1996m) {
                    this.f1975a.f1994k.mo1107l();
                }
                for (C0819f c0819f2 : this.f1976c.keySet()) {
                    final C0869f c0869f = (C0869f) this.f1976c.get(c0819f2);
                    if (!c0819f2.m3305e() || i3 == 0) {
                        c0819f2.m3299a(c0869f);
                    } else {
                        this.f1975a.f1984a.m4178a(new C0981a(this, this.f1975a) {
                            /* renamed from: b */
                            final /* synthetic */ C0991b f1973b;

                            /* renamed from: a */
                            public void mo1021a() {
                                c0869f.mo912a(new ConnectionResult(16, null));
                            }
                        });
                    }
                }
                return;
            }
            final ConnectionResult connectionResult = new ConnectionResult(i3, null);
            this.f1975a.f1984a.m4178a(new C0981a(this, this.f1975a) {
                /* renamed from: b */
                final /* synthetic */ C0991b f1971b;

                /* renamed from: a */
                public void mo1021a() {
                    this.f1971b.f1975a.m4109c(connectionResult);
                }
            });
        }
    }

    /* renamed from: com.google.android.gms.d.o$c */
    private class C0992c extends C0990f {
        /* renamed from: a */
        final /* synthetic */ C0999o f1977a;
        /* renamed from: c */
        private final ArrayList<C0819f> f1978c;

        public C0992c(C0999o c0999o, ArrayList<C0819f> arrayList) {
            this.f1977a = c0999o;
            super();
            this.f1978c = arrayList;
        }

        /* renamed from: a */
        public void mo1029a() {
            this.f1977a.f1984a.f2040g.f2012d = this.f1977a.m4122j();
            Iterator it = this.f1978c.iterator();
            while (it.hasNext()) {
                ((C0819f) it.next()).m3300a(this.f1977a.f1998o, this.f1977a.f1984a.f2040g.f2012d);
            }
        }
    }

    /* renamed from: com.google.android.gms.d.o$d */
    private static class C0997d extends C0996b {
        /* renamed from: a */
        private final WeakReference<C0999o> f1982a;

        C0997d(C0999o c0999o) {
            this.f1982a = new WeakReference(c0999o);
        }

        /* renamed from: a */
        public void mo1033a(final SignInResponse signInResponse) {
            final C0999o c0999o = (C0999o) this.f1982a.get();
            if (c0999o != null) {
                c0999o.f1984a.m4178a(new C0981a(this, c0999o) {
                    /* renamed from: c */
                    final /* synthetic */ C0997d f1981c;

                    /* renamed from: a */
                    public void mo1021a() {
                        c0999o.m4097a(signInResponse);
                    }
                });
            }
        }
    }

    /* renamed from: com.google.android.gms.d.o$e */
    private class C0998e implements C0807b, C0808c {
        /* renamed from: a */
        final /* synthetic */ C0999o f1983a;

        private C0998e(C0999o c0999o) {
            this.f1983a = c0999o;
        }

        /* renamed from: a */
        public void mo1010a(int i) {
        }

        /* renamed from: a */
        public void mo1011a(Bundle bundle) {
            this.f1983a.f1994k.mo1105a(new C0997d(this.f1983a));
        }

        /* renamed from: a */
        public void mo996a(ConnectionResult connectionResult) {
            this.f1983a.f1985b.lock();
            try {
                if (this.f1983a.m4105b(connectionResult)) {
                    this.f1983a.m4119h();
                    this.f1983a.m4112e();
                } else {
                    this.f1983a.m4109c(connectionResult);
                }
                this.f1983a.f1985b.unlock();
            } catch (Throwable th) {
                this.f1983a.f1985b.unlock();
            }
        }
    }

    public C0999o(C1006s c1006s, C0890l c0890l, Map<C0824a<?>, Integer> map, C0839j c0839j, C0816b<? extends ar, as> c0816b, Lock lock, Context context) {
        this.f1984a = c1006s;
        this.f2001r = c0890l;
        this.f2002s = map;
        this.f1987d = c0839j;
        this.f2003t = c0816b;
        this.f1985b = lock;
        this.f1986c = context;
    }

    /* renamed from: a */
    private void m4097a(SignInResponse signInResponse) {
        if (m4104b(0)) {
            ConnectionResult a = signInResponse.m4542a();
            if (a.m3227b()) {
                ResolveAccountResponse b = signInResponse.m4543b();
                ConnectionResult b2 = b.m3410b();
                if (b2.m3227b()) {
                    this.f1997n = true;
                    this.f1998o = b.m3409a();
                    this.f1999p = b.m3411c();
                    this.f2000q = b.m3412d();
                    m4112e();
                    return;
                }
                String valueOf = String.valueOf(b2);
                Log.wtf("GoogleApiClientConnecting", new StringBuilder(String.valueOf(valueOf).length() + 48).append("Sign-in succeeded with resolve account failure: ").append(valueOf).toString(), new Exception());
                m4109c(b2);
            } else if (m4105b(a)) {
                m4119h();
                m4112e();
            } else {
                m4109c(a);
            }
        }
    }

    /* renamed from: a */
    private void m4098a(boolean z) {
        if (this.f1994k != null) {
            if (this.f1994k.m3302b() && z) {
                this.f1994k.mo907k();
            }
            this.f1994k.mo1093a();
            this.f1998o = null;
        }
    }

    /* renamed from: a */
    private boolean m4099a(int i, int i2, ConnectionResult connectionResult) {
        return (i2 != 1 || m4100a(connectionResult)) ? this.f1988e == null || i < this.f1989f : false;
    }

    /* renamed from: a */
    private boolean m4100a(ConnectionResult connectionResult) {
        return connectionResult.m3226a() || this.f1987d.mo897b(connectionResult.m3228c()) != null;
    }

    /* renamed from: b */
    private void m4103b(ConnectionResult connectionResult, C0824a<?> c0824a, int i) {
        if (i != 2) {
            int a = c0824a.m3315a().m3295a();
            if (m4099a(a, i, connectionResult)) {
                this.f1988e = connectionResult;
                this.f1989f = a;
            }
        }
        this.f1984a.f2035b.put(c0824a.m3318d(), connectionResult);
    }

    /* renamed from: b */
    private boolean m4104b(int i) {
        if (this.f1990g == i) {
            return true;
        }
        Log.i("GoogleApiClientConnecting", this.f1984a.f2040g.m4168h());
        String valueOf = String.valueOf(m4107c(this.f1990g));
        String valueOf2 = String.valueOf(m4107c(i));
        Log.wtf("GoogleApiClientConnecting", new StringBuilder((String.valueOf(valueOf).length() + 70) + String.valueOf(valueOf2).length()).append("GoogleApiClient connecting is in step ").append(valueOf).append(" but received callback for step ").append(valueOf2).toString(), new Exception());
        m4109c(new ConnectionResult(8, null));
        return false;
    }

    /* renamed from: b */
    private boolean m4105b(ConnectionResult connectionResult) {
        return this.f1995l != 2 ? this.f1995l == 1 && !connectionResult.m3226a() : true;
    }

    /* renamed from: c */
    private String m4107c(int i) {
        switch (i) {
            case 0:
                return "STEP_SERVICE_BINDINGS_AND_SIGN_IN";
            case 1:
                return "STEP_GETTING_REMOTE_SERVICE";
            default:
                return "UNKNOWN";
        }
    }

    /* renamed from: c */
    private void m4109c(ConnectionResult connectionResult) {
        m4120i();
        m4098a(!connectionResult.m3226a());
        this.f1984a.m4176a(connectionResult);
        this.f1984a.f2041h.mo1014a(connectionResult);
    }

    /* renamed from: d */
    private boolean m4111d() {
        this.f1991h--;
        if (this.f1991h > 0) {
            return false;
        }
        if (this.f1991h < 0) {
            Log.i("GoogleApiClientConnecting", this.f1984a.f2040g.m4168h());
            Log.wtf("GoogleApiClientConnecting", "GoogleApiClient received too many callbacks for the given step. Clients may be in an unexpected state; GoogleApiClient will now disconnect.", new Exception());
            m4109c(new ConnectionResult(8, null));
            return false;
        } else if (this.f1988e == null) {
            return true;
        } else {
            this.f1984a.f2039f = this.f1989f;
            m4109c(this.f1988e);
            return false;
        }
    }

    /* renamed from: e */
    private void m4112e() {
        if (this.f1991h == 0) {
            if (!this.f1996m || this.f1997n) {
                m4115f();
            }
        }
    }

    /* renamed from: f */
    private void m4115f() {
        ArrayList arrayList = new ArrayList();
        this.f1990g = 1;
        this.f1991h = this.f1984a.f2034a.size();
        for (C0818d c0818d : this.f1984a.f2034a.keySet()) {
            if (!this.f1984a.f2035b.containsKey(c0818d)) {
                arrayList.add((C0819f) this.f1984a.f2034a.get(c0818d));
            } else if (m4111d()) {
                m4117g();
            }
        }
        if (!arrayList.isEmpty()) {
            this.f2004u.add(C1007t.m4187a().submit(new C0992c(this, arrayList)));
        }
    }

    /* renamed from: g */
    private void m4117g() {
        this.f1984a.m4185f();
        C1007t.m4187a().execute(new C09861(this));
        if (this.f1994k != null) {
            if (this.f1999p) {
                this.f1994k.mo1104a(this.f1998o, this.f2000q);
            }
            m4098a(false);
        }
        for (C0818d c0818d : this.f1984a.f2035b.keySet()) {
            ((C0819f) this.f1984a.f2034a.get(c0818d)).mo1093a();
        }
        this.f1984a.f2041h.mo1013a(this.f1992i.isEmpty() ? null : this.f1992i);
    }

    /* renamed from: h */
    private void m4119h() {
        this.f1996m = false;
        this.f1984a.f2040g.f2012d = Collections.emptySet();
        for (C0818d c0818d : this.f1993j) {
            if (!this.f1984a.f2035b.containsKey(c0818d)) {
                this.f1984a.f2035b.put(c0818d, new ConnectionResult(17, null));
            }
        }
    }

    /* renamed from: i */
    private void m4120i() {
        Iterator it = this.f2004u.iterator();
        while (it.hasNext()) {
            ((Future) it.next()).cancel(true);
        }
        this.f2004u.clear();
    }

    /* renamed from: j */
    private Set<Scope> m4122j() {
        if (this.f2001r == null) {
            return Collections.emptySet();
        }
        Set<Scope> hashSet = new HashSet(this.f2001r.m3561c());
        Map e = this.f2001r.m3563e();
        for (C0824a c0824a : e.keySet()) {
            if (!this.f1984a.f2035b.containsKey(c0824a.m3318d())) {
                hashSet.addAll(((C0889a) e.get(c0824a)).f1720a);
            }
        }
        return hashSet;
    }

    /* renamed from: a */
    public <A extends C0817c, T extends C0964a<? extends C0809e, A>> T mo1022a(T t) {
        throw new IllegalStateException("GoogleApiClient is not connected yet.");
    }

    /* renamed from: a */
    public void mo1023a() {
        this.f1984a.f2035b.clear();
        this.f1996m = false;
        this.f1988e = null;
        this.f1990g = 0;
        this.f1995l = 2;
        this.f1997n = false;
        this.f1999p = false;
        Map hashMap = new HashMap();
        int i = 0;
        for (C0824a c0824a : this.f2002s.keySet()) {
            C0819f c0819f = (C0819f) this.f1984a.f2034a.get(c0824a.m3318d());
            int intValue = ((Integer) this.f2002s.get(c0824a)).intValue();
            int i2 = (c0824a.m3315a().m3295a() == 1 ? 1 : 0) | i;
            if (c0819f.mo1106d()) {
                this.f1996m = true;
                if (intValue < this.f1995l) {
                    this.f1995l = intValue;
                }
                if (intValue != 0) {
                    this.f1993j.add(c0824a.m3318d());
                }
            }
            hashMap.put(c0819f, new C0987a(this, c0824a, intValue));
            i = i2;
        }
        if (i != 0) {
            this.f1996m = false;
        }
        if (this.f1996m) {
            this.f2001r.m3559a(Integer.valueOf(this.f1984a.f2040g.m4169i()));
            C0807b c0998e = new C0998e();
            this.f1994k = (ar) this.f2003t.mo987a(this.f1986c, this.f1984a.f2040g.mo1037a(), this.f2001r, this.f2001r.m3566h(), c0998e, c0998e);
        }
        this.f1991h = this.f1984a.f2034a.size();
        this.f2004u.add(C1007t.m4187a().submit(new C0991b(this, hashMap)));
    }

    /* renamed from: a */
    public void mo1024a(int i) {
        m4109c(new ConnectionResult(8, null));
    }

    /* renamed from: a */
    public void mo1025a(Bundle bundle) {
        if (m4104b(1)) {
            if (bundle != null) {
                this.f1992i.putAll(bundle);
            }
            if (m4111d()) {
                m4117g();
            }
        }
    }

    /* renamed from: a */
    public void mo1026a(ConnectionResult connectionResult, C0824a<?> c0824a, int i) {
        if (m4104b(1)) {
            m4103b(connectionResult, c0824a, i);
            if (m4111d()) {
                m4117g();
            }
        }
    }

    /* renamed from: b */
    public boolean mo1027b() {
        m4120i();
        m4098a(true);
        this.f1984a.m4176a(null);
        return true;
    }

    /* renamed from: c */
    public void mo1028c() {
    }
}

package com.google.android.gms.p023d;

import android.app.Activity;
import android.support.v4.app.C0154q;

/* renamed from: com.google.android.gms.d.y */
public class C1017y {
    /* renamed from: a */
    private final Object f2087a;

    /* renamed from: a */
    public boolean m4247a() {
        return this.f2087a instanceof C0154q;
    }

    /* renamed from: b */
    public Activity m4248b() {
        return (Activity) this.f2087a;
    }

    /* renamed from: c */
    public C0154q m4249c() {
        return (C0154q) this.f2087a;
    }
}

package com.google.android.gms.p023d;

import android.os.DeadObjectException;
import android.util.SparseArray;
import com.google.android.gms.common.api.C0809e;
import com.google.android.gms.common.api.C0824a.C0817c;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.p023d.C0965h.C0964a;

/* renamed from: com.google.android.gms.d.d */
public abstract class C0955d {
    /* renamed from: a */
    public final int f1900a;
    /* renamed from: b */
    public final int f1901b;

    /* renamed from: com.google.android.gms.d.d$a */
    public static final class C0956a extends C0955d {
        /* renamed from: c */
        public final C0964a<? extends C0809e, C0817c> f1902c;

        /* renamed from: a */
        public void mo992a(SparseArray<ak> sparseArray) {
            ak akVar = (ak) sparseArray.get(this.a);
            if (akVar != null) {
                akVar.m3868a(this.f1902c);
            }
        }

        /* renamed from: a */
        public void mo993a(Status status) {
            this.f1902c.m3981a(status);
        }

        /* renamed from: a */
        public void mo994a(C0817c c0817c) throws DeadObjectException {
            this.f1902c.m3982a(c0817c);
        }

        /* renamed from: a */
        public boolean mo995a() {
            return this.f1902c.m3971h();
        }
    }

    /* renamed from: a */
    public void mo992a(SparseArray<ak> sparseArray) {
    }

    /* renamed from: a */
    public abstract void mo993a(Status status);

    /* renamed from: a */
    public abstract void mo994a(C0817c c0817c) throws DeadObjectException;

    /* renamed from: a */
    public boolean mo995a() {
        return true;
    }
}

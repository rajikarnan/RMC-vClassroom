package com.google.android.gms.p023d;

import com.google.android.gms.common.api.C0824a.C0819f;
import com.google.android.gms.common.internal.C0849u;
import com.google.android.gms.signin.internal.C0994d;

/* renamed from: com.google.android.gms.d.ar */
public interface ar extends C0819f {
    /* renamed from: a */
    void mo1104a(C0849u c0849u, boolean z);

    /* renamed from: a */
    void mo1105a(C0994d c0994d);

    /* renamed from: k */
    void mo907k();

    /* renamed from: l */
    void mo1107l();
}

package com.google.android.gms.p023d;

import android.os.Bundle;
import android.os.DeadObjectException;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0809e;
import com.google.android.gms.common.api.C0824a;
import com.google.android.gms.common.api.C0824a.C0817c;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C0860e;
import com.google.android.gms.p023d.C0965h.C0964a;
import com.google.android.gms.p023d.C1006s.C0981a;

/* renamed from: com.google.android.gms.d.n */
public class C0985n implements C0984r {
    /* renamed from: a */
    private final C1006s f1964a;
    /* renamed from: b */
    private boolean f1965b = false;

    public C0985n(C1006s c1006s) {
        this.f1964a = c1006s;
    }

    /* renamed from: b */
    private <A extends C0817c> void m4061b(C0964a<? extends C0809e, A> c0964a) throws DeadObjectException {
        this.f1964a.f2040g.f2017i.m3868a((C0964a) c0964a);
        C0817c b = this.f1964a.f2040g.m4160b(c0964a.mo1006b());
        if (b.m3302b() || !this.f1964a.f2035b.containsKey(c0964a.mo1006b())) {
            if (b instanceof C0860e) {
                b = ((C0860e) b).mo907k();
            }
            c0964a.m3982a(b);
            return;
        }
        c0964a.m3981a(new Status(17));
    }

    /* renamed from: a */
    public <A extends C0817c, T extends C0964a<? extends C0809e, A>> T mo1022a(T t) {
        try {
            m4061b(t);
        } catch (DeadObjectException e) {
            this.f1964a.m4178a(new C0981a(this, this) {
                /* renamed from: a */
                final /* synthetic */ C0985n f1962a;

                /* renamed from: a */
                public void mo1021a() {
                    this.f1962a.mo1024a(1);
                }
            });
        }
        return t;
    }

    /* renamed from: a */
    public void mo1023a() {
    }

    /* renamed from: a */
    public void mo1024a(int i) {
        this.f1964a.m4176a(null);
        this.f1964a.f2041h.mo1012a(i, this.f1965b);
    }

    /* renamed from: a */
    public void mo1025a(Bundle bundle) {
    }

    /* renamed from: a */
    public void mo1026a(ConnectionResult connectionResult, C0824a<?> c0824a, int i) {
    }

    /* renamed from: b */
    public boolean mo1027b() {
        if (this.f1965b) {
            return false;
        }
        if (this.f1964a.f2040g.m4167g()) {
            this.f1965b = true;
            for (aj a : this.f1964a.f2040g.f2016h) {
                a.m3858a();
            }
            return false;
        }
        this.f1964a.m4176a(null);
        return true;
    }

    /* renamed from: c */
    public void mo1028c() {
        if (this.f1965b) {
            this.f1965b = false;
            this.f1964a.m4178a(new C0981a(this, this) {
                /* renamed from: a */
                final /* synthetic */ C0985n f1963a;

                /* renamed from: a */
                public void mo1021a() {
                    this.f1963a.f1964a.f2041h.mo1013a(null);
                }
            });
        }
    }

    /* renamed from: d */
    void m4069d() {
        if (this.f1965b) {
            this.f1965b = false;
            this.f1964a.f2040g.f2017i.m3867a();
            mo1027b();
        }
    }
}

package com.google.android.gms.p023d;

import android.os.Process;

/* renamed from: com.google.android.gms.d.an */
class an implements Runnable {
    /* renamed from: a */
    private final Runnable f1878a;
    /* renamed from: b */
    private final int f1879b;

    public an(Runnable runnable, int i) {
        this.f1878a = runnable;
        this.f1879b = i;
    }

    public void run() {
        Process.setThreadPriority(this.f1879b);
        this.f1878a.run();
    }
}

package com.google.android.gms.p023d;

import com.google.android.gms.common.api.C0824a;
import com.google.android.gms.common.api.C0824a.C0810a;
import com.google.android.gms.common.api.C0824a.C0818d;
import com.google.android.gms.common.internal.ab;

/* renamed from: com.google.android.gms.d.e */
public final class C0957e<O extends C0810a> {
    /* renamed from: a */
    private final C0824a<O> f1903a;
    /* renamed from: b */
    private final O f1904b;

    /* renamed from: a */
    public C0818d<?> m3927a() {
        return this.f1903a.m3318d();
    }

    /* renamed from: b */
    public String m3928b() {
        return this.f1903a.m3320f();
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C0957e)) {
            return false;
        }
        C0957e c0957e = (C0957e) obj;
        return ab.m3426a(this.f1903a, c0957e.f1903a) && ab.m3426a(this.f1904b, c0957e.f1904b);
    }

    public int hashCode() {
        return ab.m3424a(this.f1903a, this.f1904b);
    }
}

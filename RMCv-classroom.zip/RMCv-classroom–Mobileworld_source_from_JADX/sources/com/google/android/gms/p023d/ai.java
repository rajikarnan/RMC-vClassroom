package com.google.android.gms.p023d;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.app.C0154q;
import android.support.v4.app.Fragment;
import android.support.v4.p011e.C0222a;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.ref.WeakReference;
import java.util.Map;
import java.util.Map.Entry;
import java.util.WeakHashMap;

/* renamed from: com.google.android.gms.d.ai */
public final class ai extends Fragment implements aa {
    /* renamed from: a */
    private static WeakHashMap<C0154q, WeakReference<ai>> f1843a = new WeakHashMap();
    /* renamed from: b */
    private Map<String, C0959z> f1844b = new C0222a();
    /* renamed from: c */
    private int f1845c = 0;
    /* renamed from: d */
    private Bundle f1846d;

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: a */
    public static com.google.android.gms.p023d.ai m3839a(android.support.v4.app.C0154q r3) {
        /*
        r0 = f1843a;
        r0 = r0.get(r3);
        r0 = (java.lang.ref.WeakReference) r0;
        if (r0 == 0) goto L_0x0013;
    L_0x000a:
        r0 = r0.get();
        r0 = (com.google.android.gms.p023d.ai) r0;
        if (r0 == 0) goto L_0x0013;
    L_0x0012:
        return r0;
    L_0x0013:
        r0 = r3.getSupportFragmentManager();	 Catch:{ ClassCastException -> 0x0048 }
        r1 = "SupportLifecycleFragmentImpl";
        r0 = r0.mo129a(r1);	 Catch:{ ClassCastException -> 0x0048 }
        r0 = (com.google.android.gms.p023d.ai) r0;	 Catch:{ ClassCastException -> 0x0048 }
        if (r0 == 0) goto L_0x0027;
    L_0x0021:
        r1 = r0.isRemoving();
        if (r1 == 0) goto L_0x003d;
    L_0x0027:
        r0 = new com.google.android.gms.d.ai;
        r0.<init>();
        r1 = r3.getSupportFragmentManager();
        r1 = r1.mo130a();
        r2 = "SupportLifecycleFragmentImpl";
        r1 = r1.mo97a(r0, r2);
        r1.mo99c();
    L_0x003d:
        r1 = f1843a;
        r2 = new java.lang.ref.WeakReference;
        r2.<init>(r0);
        r1.put(r3, r2);
        goto L_0x0012;
    L_0x0048:
        r0 = move-exception;
        r1 = new java.lang.IllegalStateException;
        r2 = "Fragment with tag SupportLifecycleFragmentImpl is not a SupportLifecycleFragmentImpl";
        r1.<init>(r2, r0);
        throw r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.d.ai.a(android.support.v4.app.q):com.google.android.gms.d.ai");
    }

    /* renamed from: b */
    private void m3841b(final String str, final C0959z c0959z) {
        if (this.f1845c > 0) {
            new Handler(Looper.getMainLooper()).post(new Runnable(this) {
                /* renamed from: c */
                final /* synthetic */ ai f1842c;

                public void run() {
                    if (this.f1842c.f1845c >= 1) {
                        c0959z.mo999a(this.f1842c.f1846d != null ? this.f1842c.f1846d.getBundle(str) : null);
                    }
                    if (this.f1842c.f1845c >= 2) {
                        c0959z.mo997a();
                    }
                    if (this.f1842c.f1845c >= 3) {
                        c0959z.mo1000b();
                    }
                }
            });
        }
    }

    /* renamed from: a */
    public /* synthetic */ Activity mo978a() {
        return m3845b();
    }

    /* renamed from: a */
    public <T extends C0959z> T mo979a(String str, Class<T> cls) {
        return (C0959z) cls.cast(this.f1844b.get(str));
    }

    /* renamed from: a */
    public void mo980a(String str, C0959z c0959z) {
        if (this.f1844b.containsKey(str)) {
            throw new IllegalArgumentException(new StringBuilder(String.valueOf(str).length() + 59).append("LifecycleCallback with tag ").append(str).append(" already added to this fragment.").toString());
        }
        this.f1844b.put(str, c0959z);
        m3841b(str, c0959z);
    }

    /* renamed from: b */
    public C0154q m3845b() {
        return getActivity();
    }

    public void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        for (C0959z a : this.f1844b.values()) {
            a.mo1003a(str, fileDescriptor, printWriter, strArr);
        }
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        for (C0959z a : this.f1844b.values()) {
            a.mo998a(i, i2, intent);
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f1845c = 1;
        this.f1846d = bundle;
        for (Entry entry : this.f1844b.entrySet()) {
            ((C0959z) entry.getValue()).mo999a(bundle != null ? bundle.getBundle((String) entry.getKey()) : null);
        }
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        if (bundle != null) {
            for (Entry entry : this.f1844b.entrySet()) {
                Bundle bundle2 = new Bundle();
                ((C0959z) entry.getValue()).mo1001b(bundle2);
                bundle.putBundle((String) entry.getKey(), bundle2);
            }
        }
    }

    public void onStart() {
        super.onStop();
        this.f1845c = 2;
        for (C0959z a : this.f1844b.values()) {
            a.mo997a();
        }
    }

    public void onStop() {
        super.onStop();
        this.f1845c = 3;
        for (C0959z b : this.f1844b.values()) {
            b.mo1000b();
        }
    }
}

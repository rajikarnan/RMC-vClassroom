package com.google.android.gms.p023d;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.C0839j;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0809e;
import com.google.android.gms.common.api.C0824a;
import com.google.android.gms.common.api.C0824a.C0816b;
import com.google.android.gms.common.api.C0824a.C0817c;
import com.google.android.gms.common.api.C0824a.C0818d;
import com.google.android.gms.common.api.C0824a.C0819f;
import com.google.android.gms.common.internal.C0890l;
import com.google.android.gms.p023d.C0965h.C0964a;
import com.google.android.gms.p023d.C0978x.C0975a;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

/* renamed from: com.google.android.gms.d.s */
public class C1006s implements C0978x {
    /* renamed from: a */
    final Map<C0818d<?>, C0819f> f2034a;
    /* renamed from: b */
    final Map<C0818d<?>, ConnectionResult> f2035b = new HashMap();
    /* renamed from: c */
    final C0890l f2036c;
    /* renamed from: d */
    final Map<C0824a<?>, Integer> f2037d;
    /* renamed from: e */
    final C0816b<? extends ar, as> f2038e;
    /* renamed from: f */
    int f2039f;
    /* renamed from: g */
    final C1004q f2040g;
    /* renamed from: h */
    final C0975a f2041h;
    /* renamed from: i */
    private final Lock f2042i;
    /* renamed from: j */
    private final Condition f2043j;
    /* renamed from: k */
    private final Context f2044k;
    /* renamed from: l */
    private final C0839j f2045l;
    /* renamed from: m */
    private final C1005b f2046m;
    /* renamed from: n */
    private volatile C0984r f2047n;
    /* renamed from: o */
    private ConnectionResult f2048o = null;

    /* renamed from: com.google.android.gms.d.s$a */
    static abstract class C0981a {
        /* renamed from: a */
        private final C0984r f1961a;

        protected C0981a(C0984r c0984r) {
            this.f1961a = c0984r;
        }

        /* renamed from: a */
        protected abstract void mo1021a();

        /* renamed from: a */
        public final void m4050a(C1006s c1006s) {
            c1006s.f2042i.lock();
            try {
                if (c1006s.f2047n == this.f1961a) {
                    mo1021a();
                    c1006s.f2042i.unlock();
                }
            } finally {
                c1006s.f2042i.unlock();
            }
        }
    }

    /* renamed from: com.google.android.gms.d.s$b */
    final class C1005b extends Handler {
        /* renamed from: a */
        final /* synthetic */ C1006s f2033a;

        C1005b(C1006s c1006s, Looper looper) {
            this.f2033a = c1006s;
            super(looper);
        }

        public void handleMessage(Message message) {
            switch (message.what) {
                case 1:
                    ((C0981a) message.obj).m4050a(this.f2033a);
                    return;
                case 2:
                    throw ((RuntimeException) message.obj);
                default:
                    Log.w("GACStateManager", "Unknown message id: " + message.what);
                    return;
            }
        }
    }

    public C1006s(Context context, C1004q c1004q, Lock lock, Looper looper, C0839j c0839j, Map<C0818d<?>, C0819f> map, C0890l c0890l, Map<C0824a<?>, Integer> map2, C0816b<? extends ar, as> c0816b, ArrayList<C0973k> arrayList, C0975a c0975a) {
        this.f2044k = context;
        this.f2042i = lock;
        this.f2045l = c0839j;
        this.f2034a = map;
        this.f2036c = c0890l;
        this.f2037d = map2;
        this.f2038e = c0816b;
        this.f2040g = c1004q;
        this.f2041h = c0975a;
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            ((C0973k) it.next()).m4000a(this);
        }
        this.f2046m = new C1005b(this, looper);
        this.f2043j = lock.newCondition();
        this.f2047n = new C1000p(this);
    }

    /* renamed from: a */
    public <A extends C0817c, T extends C0964a<? extends C0809e, A>> T mo1015a(T t) {
        t.m3973j();
        return this.f2047n.mo1022a((C0964a) t);
    }

    /* renamed from: a */
    public void mo1016a() {
        this.f2047n.mo1028c();
    }

    /* renamed from: a */
    public void m4174a(int i) {
        this.f2042i.lock();
        try {
            this.f2047n.mo1024a(i);
        } finally {
            this.f2042i.unlock();
        }
    }

    /* renamed from: a */
    public void m4175a(Bundle bundle) {
        this.f2042i.lock();
        try {
            this.f2047n.mo1025a(bundle);
        } finally {
            this.f2042i.unlock();
        }
    }

    /* renamed from: a */
    void m4176a(ConnectionResult connectionResult) {
        this.f2042i.lock();
        try {
            this.f2048o = connectionResult;
            this.f2047n = new C1000p(this);
            this.f2047n.mo1023a();
            this.f2043j.signalAll();
        } finally {
            this.f2042i.unlock();
        }
    }

    /* renamed from: a */
    public void m4177a(ConnectionResult connectionResult, C0824a<?> c0824a, int i) {
        this.f2042i.lock();
        try {
            this.f2047n.mo1026a(connectionResult, c0824a, i);
        } finally {
            this.f2042i.unlock();
        }
    }

    /* renamed from: a */
    void m4178a(C0981a c0981a) {
        this.f2046m.sendMessage(this.f2046m.obtainMessage(1, c0981a));
    }

    /* renamed from: a */
    void m4179a(RuntimeException runtimeException) {
        this.f2046m.sendMessage(this.f2046m.obtainMessage(2, runtimeException));
    }

    /* renamed from: a */
    public void mo1017a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        String concat = String.valueOf(str).concat("  ");
        for (C0824a c0824a : this.f2037d.keySet()) {
            printWriter.append(str).append(c0824a.m3320f()).println(":");
            ((C0819f) this.f2034a.get(c0824a.m3318d())).m3301a(concat, fileDescriptor, printWriter, strArr);
        }
    }

    /* renamed from: b */
    public void mo1018b() {
        if (this.f2047n.mo1027b()) {
            this.f2035b.clear();
        }
    }

    /* renamed from: c */
    public boolean mo1019c() {
        return this.f2047n instanceof C0985n;
    }

    /* renamed from: d */
    public void mo1020d() {
        if (mo1019c()) {
            ((C0985n) this.f2047n).m4069d();
        }
    }

    /* renamed from: e */
    void m4184e() {
        this.f2042i.lock();
        try {
            this.f2047n = new C0999o(this, this.f2036c, this.f2037d, this.f2045l, this.f2038e, this.f2042i, this.f2044k);
            this.f2047n.mo1023a();
            this.f2043j.signalAll();
        } finally {
            this.f2042i.unlock();
        }
    }

    /* renamed from: f */
    void m4185f() {
        this.f2042i.lock();
        try {
            this.f2040g.m4166f();
            this.f2047n = new C0985n(this);
            this.f2047n.mo1023a();
            this.f2043j.signalAll();
        } finally {
            this.f2042i.unlock();
        }
    }

    /* renamed from: g */
    void m4186g() {
        for (C0819f a : this.f2034a.values()) {
            a.mo1093a();
        }
    }
}

package com.google.android.gms.p023d;

import android.annotation.TargetApi;
import android.app.AppOpsManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import com.google.android.gms.common.p022a.C0800g;

/* renamed from: com.google.android.gms.d.ao */
public class ao {
    /* renamed from: a */
    protected final Context f1880a;

    public ao(Context context) {
        this.f1880a = context;
    }

    /* renamed from: a */
    public ApplicationInfo m3887a(String str, int i) throws NameNotFoundException {
        return this.f1880a.getPackageManager().getApplicationInfo(str, i);
    }

    @TargetApi(19)
    /* renamed from: a */
    public boolean m3888a(int i, String str) {
        if (C0800g.m3247f()) {
            try {
                ((AppOpsManager) this.f1880a.getSystemService("appops")).checkPackage(i, str);
                return true;
            } catch (SecurityException e) {
                return false;
            }
        }
        String[] packagesForUid = this.f1880a.getPackageManager().getPackagesForUid(i);
        if (str == null || packagesForUid == null) {
            return false;
        }
        for (Object equals : packagesForUid) {
            if (str.equals(equals)) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: b */
    public PackageInfo m3889b(String str, int i) throws NameNotFoundException {
        return this.f1880a.getPackageManager().getPackageInfo(str, i);
    }
}

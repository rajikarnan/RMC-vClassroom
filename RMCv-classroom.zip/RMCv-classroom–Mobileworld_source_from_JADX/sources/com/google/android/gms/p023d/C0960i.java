package com.google.android.gms.p023d;

import android.app.Dialog;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import com.google.android.gms.common.C0840b;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiActivity;
import com.google.android.gms.p023d.C1013v.C0967a;

/* renamed from: com.google.android.gms.d.i */
public abstract class C0960i extends C0959z implements OnCancelListener {
    /* renamed from: a */
    protected boolean f1910a;
    /* renamed from: b */
    protected boolean f1911b;
    /* renamed from: c */
    protected final C0840b f1912c;
    /* renamed from: e */
    private ConnectionResult f1913e;
    /* renamed from: f */
    private int f1914f;
    /* renamed from: g */
    private final Handler f1915g;

    /* renamed from: com.google.android.gms.d.i$a */
    private class C0969a implements Runnable {
        /* renamed from: a */
        final /* synthetic */ C0960i f1939a;

        private C0969a(C0960i c0960i) {
            this.f1939a = c0960i;
        }

        public void run() {
            if (!this.f1939a.f1910a) {
                return;
            }
            if (this.f1939a.f1913e.m3226a()) {
                this.f1939a.d.startActivityForResult(GoogleApiActivity.m3262b(this.f1939a.m3939e(), this.f1939a.f1913e.m3229d(), this.f1939a.f1914f, false), 1);
            } else if (this.f1939a.f1912c.mo895a(this.f1939a.f1913e.m3228c())) {
                this.f1939a.f1912c.m3366a(this.f1939a.m3939e(), this.f1939a.d, this.f1939a.f1913e.m3228c(), 2, this.f1939a);
            } else if (this.f1939a.f1913e.m3228c() == 18) {
                final Dialog a = this.f1939a.f1912c.m3357a(this.f1939a.m3939e(), this.f1939a);
                this.f1939a.f1912c.m3362a(this.f1939a.m3939e().getApplicationContext(), new C0967a(this) {
                    /* renamed from: b */
                    final /* synthetic */ C0969a f1938b;

                    /* renamed from: a */
                    public void mo1009a() {
                        this.f1938b.f1939a.m3950d();
                        if (a.isShowing()) {
                            a.dismiss();
                        }
                    }
                });
            } else {
                this.f1939a.mo1002a(this.f1939a.f1913e, this.f1939a.f1914f);
            }
        }
    }

    protected C0960i(aa aaVar) {
        this(aaVar, C0840b.m3355a());
    }

    C0960i(aa aaVar, C0840b c0840b) {
        super(aaVar);
        this.f1914f = -1;
        this.f1915g = new Handler(Looper.getMainLooper());
        this.f1912c = c0840b;
    }

    /* renamed from: a */
    public void mo997a() {
        super.mo997a();
        this.f1910a = true;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: a */
    public void mo998a(int r6, int r7, android.content.Intent r8) {
        /*
        r5 = this;
        r4 = 18;
        r2 = 13;
        r0 = 1;
        r1 = 0;
        switch(r6) {
            case 1: goto L_0x0027;
            case 2: goto L_0x0010;
            default: goto L_0x0009;
        };
    L_0x0009:
        r0 = r1;
    L_0x000a:
        if (r0 == 0) goto L_0x003d;
    L_0x000c:
        r5.m3950d();
    L_0x000f:
        return;
    L_0x0010:
        r2 = r5.f1912c;
        r3 = r5.m3939e();
        r2 = r2.mo891a(r3);
        if (r2 != 0) goto L_0x0047;
    L_0x001c:
        r1 = r5.f1913e;
        r1 = r1.m3228c();
        if (r1 != r4) goto L_0x000a;
    L_0x0024:
        if (r2 != r4) goto L_0x000a;
    L_0x0026:
        goto L_0x000f;
    L_0x0027:
        r3 = -1;
        if (r7 == r3) goto L_0x000a;
    L_0x002a:
        if (r7 != 0) goto L_0x0009;
    L_0x002c:
        if (r8 == 0) goto L_0x0045;
    L_0x002e:
        r0 = "<<ResolutionFailureErrorDetail>>";
        r0 = r8.getIntExtra(r0, r2);
    L_0x0034:
        r2 = new com.google.android.gms.common.ConnectionResult;
        r3 = 0;
        r2.<init>(r0, r3);
        r5.f1913e = r2;
        goto L_0x0009;
    L_0x003d:
        r0 = r5.f1913e;
        r1 = r5.f1914f;
        r5.mo1002a(r0, r1);
        goto L_0x000f;
    L_0x0045:
        r0 = r2;
        goto L_0x0034;
    L_0x0047:
        r0 = r1;
        goto L_0x001c;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.d.i.a(int, int, android.content.Intent):void");
    }

    /* renamed from: a */
    public void mo999a(Bundle bundle) {
        super.mo999a(bundle);
        if (bundle != null) {
            this.f1911b = bundle.getBoolean("resolving_error", false);
            if (this.f1911b) {
                this.f1914f = bundle.getInt("failed_client_id", -1);
                this.f1913e = new ConnectionResult(bundle.getInt("failed_status"), (PendingIntent) bundle.getParcelable("failed_resolution"));
            }
        }
    }

    /* renamed from: a */
    protected abstract void mo1002a(ConnectionResult connectionResult, int i);

    /* renamed from: b */
    public void mo1000b() {
        super.mo1000b();
        this.f1910a = false;
    }

    /* renamed from: b */
    public void mo1001b(Bundle bundle) {
        super.mo1001b(bundle);
        bundle.putBoolean("resolving_error", this.f1911b);
        if (this.f1911b) {
            bundle.putInt("failed_client_id", this.f1914f);
            bundle.putInt("failed_status", this.f1913e.m3228c());
            bundle.putParcelable("failed_resolution", this.f1913e.m3229d());
        }
    }

    /* renamed from: b */
    public void m3948b(ConnectionResult connectionResult, int i) {
        if (!this.f1911b) {
            this.f1911b = true;
            this.f1914f = i;
            this.f1913e = connectionResult;
            this.f1915g.post(new C0969a());
        }
    }

    /* renamed from: c */
    protected abstract void mo1004c();

    /* renamed from: d */
    protected void m3950d() {
        this.f1914f = -1;
        this.f1911b = false;
        this.f1913e = null;
        mo1004c();
    }

    public void onCancel(DialogInterface dialogInterface) {
        mo1002a(new ConnectionResult(13, null), this.f1914f);
        m3950d();
    }
}

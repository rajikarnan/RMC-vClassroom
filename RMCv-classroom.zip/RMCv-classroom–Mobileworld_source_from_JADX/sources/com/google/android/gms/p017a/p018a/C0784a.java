package com.google.android.gms.p017a.p018a;

import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager.NameNotFoundException;
import android.util.Log;
import com.google.android.gms.common.C0839j;
import com.google.android.gms.common.C0841c;
import com.google.android.gms.common.C0843d;
import com.google.android.gms.common.C0847h;
import com.google.android.gms.common.internal.C0854b;
import com.google.android.gms.common.stats.C0929b;
import com.google.android.gms.p023d.C0952c;
import com.google.android.gms.p023d.C0952c.C0954a;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/* renamed from: com.google.android.gms.a.a.a */
public class C0784a {
    /* renamed from: a */
    C0847h f1494a;
    /* renamed from: b */
    C0952c f1495b;
    /* renamed from: c */
    boolean f1496c;
    /* renamed from: d */
    Object f1497d = new Object();
    /* renamed from: e */
    C0783b f1498e;
    /* renamed from: f */
    final long f1499f;
    /* renamed from: g */
    private final Context f1500g;

    /* renamed from: com.google.android.gms.a.a.a$a */
    public static final class C0782a {
        /* renamed from: a */
        private final String f1488a;
        /* renamed from: b */
        private final boolean f1489b;

        public C0782a(String str, boolean z) {
            this.f1488a = str;
            this.f1489b = z;
        }

        /* renamed from: a */
        public String m3174a() {
            return this.f1488a;
        }

        /* renamed from: b */
        public boolean m3175b() {
            return this.f1489b;
        }

        public String toString() {
            String str = this.f1488a;
            return new StringBuilder(String.valueOf(str).length() + 7).append("{").append(str).append("}").append(this.f1489b).toString();
        }
    }

    /* renamed from: com.google.android.gms.a.a.a$b */
    static class C0783b extends Thread {
        /* renamed from: a */
        CountDownLatch f1490a = new CountDownLatch(1);
        /* renamed from: b */
        boolean f1491b = false;
        /* renamed from: c */
        private WeakReference<C0784a> f1492c;
        /* renamed from: d */
        private long f1493d;

        public C0783b(C0784a c0784a, long j) {
            this.f1492c = new WeakReference(c0784a);
            this.f1493d = j;
            start();
        }

        /* renamed from: c */
        private void m3176c() {
            C0784a c0784a = (C0784a) this.f1492c.get();
            if (c0784a != null) {
                c0784a.m3185b();
                this.f1491b = true;
            }
        }

        /* renamed from: a */
        public void m3177a() {
            this.f1490a.countDown();
        }

        /* renamed from: b */
        public boolean m3178b() {
            return this.f1491b;
        }

        public void run() {
            try {
                if (!this.f1490a.await(this.f1493d, TimeUnit.MILLISECONDS)) {
                    m3176c();
                }
            } catch (InterruptedException e) {
                m3176c();
            }
        }
    }

    public C0784a(Context context, long j) {
        C0854b.m3427a((Object) context);
        this.f1500g = context;
        this.f1496c = false;
        this.f1499f = j;
    }

    /* renamed from: a */
    static C0847h m3179a(Context context) throws IOException, C0841c, C0843d {
        try {
            context.getPackageManager().getPackageInfo("com.android.vending", 0);
            switch (C0839j.m3344b().mo891a(context)) {
                case 0:
                case 2:
                    ServiceConnection c0847h = new C0847h();
                    Intent intent = new Intent("com.google.android.gms.ads.identifier.service.START");
                    intent.setPackage("com.google.android.gms");
                    try {
                        if (C0929b.m3800a().m3813a(context, intent, c0847h, 1)) {
                            return c0847h;
                        }
                        throw new IOException("Connection failure");
                    } catch (Throwable th) {
                        IOException iOException = new IOException(th);
                    }
                default:
                    throw new IOException("Google Play services not available");
            }
        } catch (NameNotFoundException e) {
            throw new C0841c(9);
        }
    }

    /* renamed from: a */
    static C0952c m3180a(Context context, C0847h c0847h) throws IOException {
        try {
            return C0954a.m3918a(c0847h.m3396a(10000, TimeUnit.MILLISECONDS));
        } catch (InterruptedException e) {
            throw new IOException("Interrupted exception");
        } catch (Throwable th) {
            IOException iOException = new IOException(th);
        }
    }

    /* renamed from: b */
    public static C0782a m3181b(Context context) throws IOException, IllegalStateException, C0841c, C0843d {
        C0784a c0784a = new C0784a(context, -1);
        try {
            c0784a.m3184a(false);
            C0782a a = c0784a.m3183a();
            return a;
        } finally {
            c0784a.m3185b();
        }
    }

    /* renamed from: c */
    private void m3182c() {
        synchronized (this.f1497d) {
            if (this.f1498e != null) {
                this.f1498e.m3177a();
                try {
                    this.f1498e.join();
                } catch (InterruptedException e) {
                }
            }
            if (this.f1499f > 0) {
                this.f1498e = new C0783b(this, this.f1499f);
            }
        }
    }

    /* renamed from: a */
    public C0782a m3183a() throws IOException {
        C0782a c0782a;
        C0854b.m3434b("Calling this from your main thread can lead to deadlock");
        synchronized (this) {
            if (!this.f1496c) {
                synchronized (this.f1497d) {
                    if (this.f1498e == null || !this.f1498e.m3178b()) {
                        throw new IOException("AdvertisingIdClient is not connected.");
                    }
                }
                try {
                    m3184a(false);
                    if (!this.f1496c) {
                        throw new IOException("AdvertisingIdClient cannot reconnect.");
                    }
                } catch (Throwable e) {
                    Log.i("AdvertisingIdClient", "GMS remote exception ", e);
                    throw new IOException("Remote exception");
                } catch (Throwable e2) {
                    throw new IOException("AdvertisingIdClient cannot reconnect.", e2);
                }
            }
            C0854b.m3427a(this.f1494a);
            C0854b.m3427a(this.f1495b);
            c0782a = new C0782a(this.f1495b.mo988a(), this.f1495b.mo991a(true));
        }
        m3182c();
        return c0782a;
    }

    /* renamed from: a */
    protected void m3184a(boolean z) throws IOException, IllegalStateException, C0841c, C0843d {
        C0854b.m3434b("Calling this from your main thread can lead to deadlock");
        synchronized (this) {
            if (this.f1496c) {
                m3185b();
            }
            this.f1494a = C0784a.m3179a(this.f1500g);
            this.f1495b = C0784a.m3180a(this.f1500g, this.f1494a);
            this.f1496c = true;
            if (z) {
                m3182c();
            }
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: b */
    public void m3185b() {
        /*
        r3 = this;
        r0 = "Calling this from your main thread can lead to deadlock";
        com.google.android.gms.common.internal.C0854b.m3434b(r0);
        monitor-enter(r3);
        r0 = r3.f1500g;	 Catch:{ all -> 0x002a }
        if (r0 == 0) goto L_0x000e;
    L_0x000a:
        r0 = r3.f1494a;	 Catch:{ all -> 0x002a }
        if (r0 != 0) goto L_0x0010;
    L_0x000e:
        monitor-exit(r3);	 Catch:{ all -> 0x002a }
    L_0x000f:
        return;
    L_0x0010:
        r0 = r3.f1496c;	 Catch:{ IllegalArgumentException -> 0x002d }
        if (r0 == 0) goto L_0x001f;
    L_0x0014:
        r0 = com.google.android.gms.common.stats.C0929b.m3800a();	 Catch:{ IllegalArgumentException -> 0x002d }
        r1 = r3.f1500g;	 Catch:{ IllegalArgumentException -> 0x002d }
        r2 = r3.f1494a;	 Catch:{ IllegalArgumentException -> 0x002d }
        r0.m3811a(r1, r2);	 Catch:{ IllegalArgumentException -> 0x002d }
    L_0x001f:
        r0 = 0;
        r3.f1496c = r0;	 Catch:{ all -> 0x002a }
        r0 = 0;
        r3.f1495b = r0;	 Catch:{ all -> 0x002a }
        r0 = 0;
        r3.f1494a = r0;	 Catch:{ all -> 0x002a }
        monitor-exit(r3);	 Catch:{ all -> 0x002a }
        goto L_0x000f;
    L_0x002a:
        r0 = move-exception;
        monitor-exit(r3);	 Catch:{ all -> 0x002a }
        throw r0;
    L_0x002d:
        r0 = move-exception;
        r1 = "AdvertisingIdClient";
        r2 = "AdvertisingIdClient unbindService failed.";
        android.util.Log.i(r1, r2, r0);	 Catch:{ all -> 0x002a }
        goto L_0x001f;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.a.a.a.b():void");
    }

    protected void finalize() throws Throwable {
        m3185b();
        super.finalize();
    }
}

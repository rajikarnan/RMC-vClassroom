package com.google.android.gms.iid;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ResolveInfo;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.ConditionVariable;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcelable;
import android.os.Process;
import android.os.RemoteException;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import java.io.IOException;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.interfaces.RSAPrivateKey;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/* renamed from: com.google.android.gms.iid.e */
public class C1026e {
    /* renamed from: a */
    static String f2108a = null;
    /* renamed from: b */
    static int f2109b = 0;
    /* renamed from: c */
    static int f2110c = 0;
    /* renamed from: d */
    static int f2111d = 0;
    /* renamed from: e */
    Context f2112e;
    /* renamed from: f */
    Map<String, Object> f2113f = new HashMap();
    /* renamed from: g */
    Messenger f2114g;
    /* renamed from: h */
    Messenger f2115h;
    /* renamed from: i */
    MessengerCompat f2116i;
    /* renamed from: j */
    PendingIntent f2117j;
    /* renamed from: k */
    long f2118k;
    /* renamed from: l */
    long f2119l;
    /* renamed from: m */
    int f2120m;
    /* renamed from: n */
    int f2121n;
    /* renamed from: o */
    long f2122o;

    public C1026e(Context context) {
        this.f2112e = context;
    }

    /* renamed from: a */
    public static String m4278a(Context context) {
        if (f2108a != null) {
            return f2108a;
        }
        f2109b = Process.myUid();
        PackageManager packageManager = context.getPackageManager();
        for (ResolveInfo resolveInfo : packageManager.queryIntentServices(new Intent("com.google.android.c2dm.intent.REGISTER"), 0)) {
            if (packageManager.checkPermission("com.google.android.c2dm.permission.RECEIVE", resolveInfo.serviceInfo.packageName) == 0) {
                try {
                    ApplicationInfo applicationInfo = packageManager.getApplicationInfo(resolveInfo.serviceInfo.packageName, 0);
                    Log.w("InstanceID/Rpc", "Found " + applicationInfo.uid);
                    f2110c = applicationInfo.uid;
                    f2108a = resolveInfo.serviceInfo.packageName;
                    return f2108a;
                } catch (NameNotFoundException e) {
                }
            } else {
                String valueOf = String.valueOf(resolveInfo.serviceInfo.packageName);
                String valueOf2 = String.valueOf("com.google.android.c2dm.intent.REGISTER");
                Log.w("InstanceID/Rpc", new StringBuilder((String.valueOf(valueOf).length() + 56) + String.valueOf(valueOf2).length()).append("Possible malicious package ").append(valueOf).append(" declares ").append(valueOf2).append(" without permission").toString());
            }
        }
        Log.w("InstanceID/Rpc", "Failed to resolve REGISTER intent, falling back");
        ApplicationInfo applicationInfo2;
        try {
            applicationInfo2 = packageManager.getApplicationInfo("com.google.android.gms", 0);
            f2108a = applicationInfo2.packageName;
            f2110c = applicationInfo2.uid;
            return f2108a;
        } catch (NameNotFoundException e2) {
            try {
                applicationInfo2 = packageManager.getApplicationInfo("com.google.android.gsf", 0);
                f2108a = applicationInfo2.packageName;
                f2110c = applicationInfo2.uid;
                return f2108a;
            } catch (NameNotFoundException e3) {
                Log.w("InstanceID/Rpc", "Both Google Play Services and legacy GSF package are missing");
                return null;
            }
        }
    }

    /* renamed from: a */
    static String m4279a(KeyPair keyPair, String... strArr) {
        String str = null;
        try {
            byte[] bytes = TextUtils.join("\n", strArr).getBytes("UTF-8");
            try {
                PrivateKey privateKey = keyPair.getPrivate();
                Signature instance = Signature.getInstance(privateKey instanceof RSAPrivateKey ? "SHA256withRSA" : "SHA256withECDSA");
                instance.initSign(privateKey);
                instance.update(bytes);
                str = C1019a.m4257a(instance.sign());
            } catch (Throwable e) {
                Log.e("InstanceID/Rpc", "Unable to sign registration request", e);
            }
        } catch (Throwable e2) {
            Log.e("InstanceID/Rpc", "Unable to encode string", e2);
        }
        return str;
    }

    /* renamed from: a */
    private void m4280a(Object obj) {
        synchronized (getClass()) {
            for (String str : this.f2113f.keySet()) {
                Object obj2 = this.f2113f.get(str);
                this.f2113f.put(str, obj);
                m4281a(obj2, obj);
            }
        }
    }

    /* renamed from: a */
    private void m4281a(Object obj, Object obj2) {
        if (obj instanceof ConditionVariable) {
            ((ConditionVariable) obj).open();
        }
        if (obj instanceof Messenger) {
            Messenger messenger = (Messenger) obj;
            Message obtain = Message.obtain();
            obtain.obj = obj2;
            try {
                messenger.send(obtain);
            } catch (RemoteException e) {
                String valueOf = String.valueOf(e);
                Log.w("InstanceID/Rpc", new StringBuilder(String.valueOf(valueOf).length() + 24).append("Failed to send response ").append(valueOf).toString());
            }
        }
    }

    /* renamed from: a */
    private void m4282a(String str) {
        if ("com.google.android.gsf".equals(f2108a)) {
            this.f2120m++;
            if (this.f2120m >= 3) {
                if (this.f2120m == 3) {
                    this.f2121n = new Random().nextInt(1000) + 1000;
                }
                this.f2121n *= 2;
                this.f2122o = SystemClock.elapsedRealtime() + ((long) this.f2121n);
                Log.w("InstanceID/Rpc", new StringBuilder(String.valueOf(str).length() + 31).append("Backoff due to ").append(str).append(" for ").append(this.f2121n).toString());
            }
        }
    }

    /* renamed from: a */
    private void m4283a(String str, Object obj) {
        synchronized (getClass()) {
            Object obj2 = this.f2113f.get(str);
            this.f2113f.put(str, obj);
            m4281a(obj2, obj);
        }
    }

    /* renamed from: b */
    private static int m4284b(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(C1026e.m4278a(context), 0).versionCode;
        } catch (NameNotFoundException e) {
            return -1;
        }
    }

    /* renamed from: b */
    private Intent m4285b(Bundle bundle, KeyPair keyPair) throws IOException {
        Intent intent;
        ConditionVariable conditionVariable = new ConditionVariable();
        String b = C1026e.m4286b();
        synchronized (getClass()) {
            this.f2113f.put(b, conditionVariable);
        }
        m4291a(bundle, keyPair, b);
        conditionVariable.block(30000);
        synchronized (getClass()) {
            Object remove = this.f2113f.remove(b);
            if (remove instanceof Intent) {
                intent = (Intent) remove;
            } else if (remove instanceof String) {
                throw new IOException((String) remove);
            } else {
                String valueOf = String.valueOf(remove);
                Log.w("InstanceID/Rpc", new StringBuilder(String.valueOf(valueOf).length() + 12).append("No response ").append(valueOf).toString());
                throw new IOException("TIMEOUT");
            }
        }
        return intent;
    }

    /* renamed from: b */
    public static synchronized String m4286b() {
        String num;
        synchronized (C1026e.class) {
            int i = f2111d;
            f2111d = i + 1;
            num = Integer.toString(i);
        }
        return num;
    }

    /* renamed from: a */
    Intent m4287a(Bundle bundle, KeyPair keyPair) throws IOException {
        Intent b = m4285b(bundle, keyPair);
        return (b == null || !b.hasExtra("google.messenger")) ? b : m4285b(bundle, keyPair);
    }

    /* renamed from: a */
    void m4288a() {
        if (this.f2114g == null) {
            C1026e.m4278a(this.f2112e);
            this.f2114g = new Messenger(new Handler(this, Looper.getMainLooper()) {
                /* renamed from: a */
                final /* synthetic */ C1026e f2107a;

                public void handleMessage(Message message) {
                    this.f2107a.m4292a(message);
                }
            });
        }
    }

    /* renamed from: a */
    synchronized void m4289a(Intent intent) {
        if (this.f2117j == null) {
            Intent intent2 = new Intent();
            intent2.setPackage("com.google.example.invalidpackage");
            this.f2117j = PendingIntent.getBroadcast(this.f2112e, 0, intent2, 0);
        }
        intent.putExtra("app", this.f2117j);
    }

    /* renamed from: a */
    protected void m4290a(Intent intent, String str) {
        this.f2118k = SystemClock.elapsedRealtime();
        intent.putExtra("kid", new StringBuilder(String.valueOf(str).length() + 5).append("|ID|").append(str).append("|").toString());
        intent.putExtra("X-kid", new StringBuilder(String.valueOf(str).length() + 5).append("|ID|").append(str).append("|").toString());
        boolean equals = "com.google.android.gsf".equals(f2108a);
        String stringExtra = intent.getStringExtra("useGsf");
        if (stringExtra != null) {
            equals = "1".equals(stringExtra);
        }
        if (Log.isLoggable("InstanceID/Rpc", 3)) {
            String valueOf = String.valueOf(intent.getExtras());
            Log.d("InstanceID/Rpc", new StringBuilder(String.valueOf(valueOf).length() + 8).append("Sending ").append(valueOf).toString());
        }
        if (this.f2115h != null) {
            intent.putExtra("google.messenger", this.f2114g);
            Message obtain = Message.obtain();
            obtain.obj = intent;
            try {
                this.f2115h.send(obtain);
                return;
            } catch (RemoteException e) {
                if (Log.isLoggable("InstanceID/Rpc", 3)) {
                    Log.d("InstanceID/Rpc", "Messenger failed, fallback to startService");
                }
            }
        }
        if (equals) {
            Intent intent2 = new Intent("com.google.android.gms.iid.InstanceID");
            intent2.setPackage(this.f2112e.getPackageName());
            intent2.putExtra("GSF", intent);
            this.f2112e.startService(intent2);
            return;
        }
        intent.putExtra("google.messenger", this.f2114g);
        intent.putExtra("messenger2", "1");
        if (this.f2116i != null) {
            Message obtain2 = Message.obtain();
            obtain2.obj = intent;
            try {
                this.f2116i.m4253a(obtain2);
                return;
            } catch (RemoteException e2) {
                if (Log.isLoggable("InstanceID/Rpc", 3)) {
                    Log.d("InstanceID/Rpc", "Messenger failed, fallback to startService");
                }
            }
        }
        this.f2112e.startService(intent);
    }

    /* renamed from: a */
    void m4291a(Bundle bundle, KeyPair keyPair, String str) throws IOException {
        long elapsedRealtime = SystemClock.elapsedRealtime();
        if (this.f2122o == 0 || elapsedRealtime > this.f2122o) {
            m4288a();
            if (f2108a == null) {
                throw new IOException("MISSING_INSTANCEID_SERVICE");
            }
            this.f2118k = SystemClock.elapsedRealtime();
            Intent intent = new Intent("com.google.android.c2dm.intent.REGISTER");
            intent.setPackage(f2108a);
            bundle.putString("gmsv", Integer.toString(C1026e.m4284b(this.f2112e)));
            bundle.putString("osv", Integer.toString(VERSION.SDK_INT));
            bundle.putString("app_ver", Integer.toString(C1019a.m4254a(this.f2112e)));
            bundle.putString("app_ver_name", C1019a.m4258b(this.f2112e));
            bundle.putString("cliv", "1");
            bundle.putString("appid", C1019a.m4256a(keyPair));
            bundle.putString("pub2", C1019a.m4257a(keyPair.getPublic().getEncoded()));
            bundle.putString("sig", C1026e.m4279a(keyPair, this.f2112e.getPackageName(), r1));
            intent.putExtras(bundle);
            m4289a(intent);
            m4290a(intent, str);
            return;
        }
        elapsedRealtime = this.f2122o - elapsedRealtime;
        Log.w("InstanceID/Rpc", "Backoff mode, next request attempt: " + elapsedRealtime + " interval: " + this.f2121n);
        throw new IOException("RETRY_LATER");
    }

    /* renamed from: a */
    public void m4292a(Message message) {
        if (message != null) {
            if (message.obj instanceof Intent) {
                Intent intent = (Intent) message.obj;
                intent.setExtrasClassLoader(MessengerCompat.class.getClassLoader());
                if (intent.hasExtra("google.messenger")) {
                    Parcelable parcelableExtra = intent.getParcelableExtra("google.messenger");
                    if (parcelableExtra instanceof MessengerCompat) {
                        this.f2116i = (MessengerCompat) parcelableExtra;
                    }
                    if (parcelableExtra instanceof Messenger) {
                        this.f2115h = (Messenger) parcelableExtra;
                    }
                }
                m4295d((Intent) message.obj);
                return;
            }
            Log.w("InstanceID/Rpc", "Dropping invalid message");
        }
    }

    /* renamed from: b */
    String m4293b(Intent intent) throws IOException {
        if (intent == null) {
            throw new IOException("SERVICE_NOT_AVAILABLE");
        }
        String stringExtra = intent.getStringExtra("registration_id");
        if (stringExtra == null) {
            stringExtra = intent.getStringExtra("unregistered");
        }
        intent.getLongExtra("Retry-After", 0);
        String valueOf;
        if (stringExtra != null) {
            if (stringExtra == null) {
                return stringExtra;
            }
            stringExtra = intent.getStringExtra("error");
            if (stringExtra == null) {
                throw new IOException(stringExtra);
            }
            valueOf = String.valueOf(intent.getExtras());
            Log.w("InstanceID/Rpc", new StringBuilder(String.valueOf(valueOf).length() + 29).append("Unexpected response from GCM ").append(valueOf).toString(), new Throwable());
            throw new IOException("SERVICE_NOT_AVAILABLE");
        } else if (stringExtra == null) {
            return stringExtra;
        } else {
            stringExtra = intent.getStringExtra("error");
            if (stringExtra == null) {
                valueOf = String.valueOf(intent.getExtras());
                Log.w("InstanceID/Rpc", new StringBuilder(String.valueOf(valueOf).length() + 29).append("Unexpected response from GCM ").append(valueOf).toString(), new Throwable());
                throw new IOException("SERVICE_NOT_AVAILABLE");
            }
            throw new IOException(stringExtra);
        }
    }

    /* renamed from: c */
    void m4294c(Intent intent) {
        String stringExtra = intent.getStringExtra("error");
        if (stringExtra == null) {
            String valueOf = String.valueOf(intent.getExtras());
            Log.w("InstanceID/Rpc", new StringBuilder(String.valueOf(valueOf).length() + 49).append("Unexpected response, no error or registration id ").append(valueOf).toString());
            return;
        }
        if (Log.isLoggable("InstanceID/Rpc", 3)) {
            valueOf = "InstanceID/Rpc";
            String str = "Received InstanceID error ";
            String valueOf2 = String.valueOf(stringExtra);
            Log.d(valueOf, valueOf2.length() != 0 ? str.concat(valueOf2) : new String(str));
        }
        if (stringExtra.startsWith("|")) {
            String[] split = stringExtra.split("\\|");
            if (!"ID".equals(split[1])) {
                String str2 = "InstanceID/Rpc";
                String str3 = "Unexpected structured response ";
                valueOf2 = String.valueOf(stringExtra);
                Log.w(str2, valueOf2.length() != 0 ? str3.concat(valueOf2) : new String(str3));
            }
            if (split.length > 2) {
                valueOf2 = split[2];
                valueOf = split[3];
                if (valueOf.startsWith(":")) {
                    valueOf = valueOf.substring(1);
                }
            } else {
                valueOf = "UNKNOWN";
                valueOf2 = null;
            }
            intent.putExtra("error", valueOf);
        } else {
            valueOf2 = null;
            valueOf = stringExtra;
        }
        if (valueOf2 == null) {
            m4280a((Object) valueOf);
        } else {
            m4283a(valueOf2, (Object) valueOf);
        }
        long longExtra = intent.getLongExtra("Retry-After", 0);
        if (longExtra > 0) {
            this.f2119l = SystemClock.elapsedRealtime();
            this.f2121n = ((int) longExtra) * 1000;
            this.f2122o = SystemClock.elapsedRealtime() + ((long) this.f2121n);
            Log.w("InstanceID/Rpc", "Explicit request from server to backoff: " + this.f2121n);
        } else if ("SERVICE_NOT_AVAILABLE".equals(valueOf) || "AUTHENTICATION_FAILED".equals(valueOf)) {
            m4282a(valueOf);
        }
    }

    /* renamed from: d */
    public void m4295d(Intent intent) {
        if (intent != null) {
            String action = intent.getAction();
            String stringExtra;
            String valueOf;
            if ("com.google.android.c2dm.intent.REGISTRATION".equals(action) || "com.google.android.gms.iid.InstanceID".equals(action)) {
                action = intent.getStringExtra("registration_id");
                stringExtra = action == null ? intent.getStringExtra("unregistered") : action;
                if (stringExtra == null) {
                    m4294c(intent);
                    return;
                }
                this.f2118k = SystemClock.elapsedRealtime();
                this.f2122o = 0;
                this.f2120m = 0;
                this.f2121n = 0;
                if (Log.isLoggable("InstanceID/Rpc", 3)) {
                    valueOf = String.valueOf(intent.getExtras());
                    Log.d("InstanceID/Rpc", new StringBuilder((String.valueOf(stringExtra).length() + 16) + String.valueOf(valueOf).length()).append("AppIDResponse: ").append(stringExtra).append(" ").append(valueOf).toString());
                }
                action = null;
                if (stringExtra.startsWith("|")) {
                    String[] split = stringExtra.split("\\|");
                    if (!"ID".equals(split[1])) {
                        String str = "InstanceID/Rpc";
                        String str2 = "Unexpected structured response ";
                        action = String.valueOf(stringExtra);
                        Log.w(str, action.length() != 0 ? str2.concat(action) : new String(str2));
                    }
                    stringExtra = split[2];
                    if (split.length > 4) {
                        if ("SYNC".equals(split[3])) {
                            C1020b.m4267a(this.f2112e);
                        } else if ("RST".equals(split[3])) {
                            C1020b.m4268a(this.f2112e, C1019a.m4259c(this.f2112e).m4264c());
                            intent.removeExtra("registration_id");
                            m4283a(stringExtra, (Object) intent);
                            return;
                        }
                    }
                    action = split[split.length - 1];
                    if (action.startsWith(":")) {
                        action = action.substring(1);
                    }
                    intent.putExtra("registration_id", action);
                    action = stringExtra;
                }
                if (action == null) {
                    m4280a((Object) intent);
                } else {
                    m4283a(action, (Object) intent);
                }
            } else if (Log.isLoggable("InstanceID/Rpc", 3)) {
                stringExtra = "InstanceID/Rpc";
                valueOf = "Unexpected response ";
                action = String.valueOf(intent.getAction());
                Log.d(stringExtra, action.length() != 0 ? valueOf.concat(action) : new String(valueOf));
            }
        } else if (Log.isLoggable("InstanceID/Rpc", 3)) {
            Log.d("InstanceID/Rpc", "Unexpected response: null");
        }
    }
}

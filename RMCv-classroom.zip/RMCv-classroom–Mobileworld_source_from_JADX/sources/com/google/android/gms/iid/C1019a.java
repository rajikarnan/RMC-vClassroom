package com.google.android.gms.iid;

import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.os.Looper;
import android.util.Base64;
import android.util.Log;
import java.io.IOException;
import java.security.KeyPair;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

/* renamed from: com.google.android.gms.iid.a */
public class C1019a {
    /* renamed from: a */
    static Map<String, C1019a> f2090a = new HashMap();
    /* renamed from: f */
    static String f2091f;
    /* renamed from: g */
    private static C1027f f2092g;
    /* renamed from: h */
    private static C1026e f2093h;
    /* renamed from: b */
    Context f2094b;
    /* renamed from: c */
    KeyPair f2095c;
    /* renamed from: d */
    String f2096d = "";
    /* renamed from: e */
    long f2097e;

    protected C1019a(Context context, String str, Bundle bundle) {
        this.f2094b = context.getApplicationContext();
        this.f2096d = str;
    }

    /* renamed from: a */
    static int m4254a(Context context) {
        int i = 0;
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (NameNotFoundException e) {
            String valueOf = String.valueOf(e);
            Log.w("InstanceID", new StringBuilder(String.valueOf(valueOf).length() + 38).append("Never happens: can't find own package ").append(valueOf).toString());
            return i;
        }
    }

    /* renamed from: a */
    public static synchronized C1019a m4255a(Context context, Bundle bundle) {
        C1019a c1019a;
        synchronized (C1019a.class) {
            String string = bundle == null ? "" : bundle.getString("subtype");
            String str = string == null ? "" : string;
            Context applicationContext = context.getApplicationContext();
            if (f2092g == null) {
                f2092g = new C1027f(applicationContext);
                f2093h = new C1026e(applicationContext);
            }
            f2091f = Integer.toString(C1019a.m4254a(applicationContext));
            c1019a = (C1019a) f2090a.get(str);
            if (c1019a == null) {
                c1019a = new C1019a(applicationContext, str, bundle);
                f2090a.put(str, c1019a);
            }
        }
        return c1019a;
    }

    /* renamed from: a */
    static String m4256a(KeyPair keyPair) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA1").digest(keyPair.getPublic().getEncoded());
            digest[0] = (byte) (((digest[0] & 15) + 112) & 255);
            return Base64.encodeToString(digest, 0, 8, 11);
        } catch (NoSuchAlgorithmException e) {
            Log.w("InstanceID", "Unexpected error, device missing required alghorithms");
            return null;
        }
    }

    /* renamed from: a */
    static String m4257a(byte[] bArr) {
        return Base64.encodeToString(bArr, 11);
    }

    /* renamed from: b */
    static String m4258b(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
        } catch (NameNotFoundException e) {
            String valueOf = String.valueOf(e);
            Log.w("InstanceID", new StringBuilder(String.valueOf(valueOf).length() + 38).append("Never happens: can't find own package ").append(valueOf).toString());
            return null;
        }
    }

    /* renamed from: c */
    public static C1019a m4259c(Context context) {
        return C1019a.m4255a(context, null);
    }

    /* renamed from: a */
    public String m4260a(String str, String str2, Bundle bundle) throws IOException {
        Object obj = null;
        if (Looper.getMainLooper() == Looper.myLooper()) {
            throw new IOException("MAIN_THREAD");
        }
        Object obj2 = 1;
        String a = m4266e() ? null : f2092g.m4300a(this.f2096d, str, str2);
        if (a == null) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            if (bundle.getString("ttl") != null) {
                obj2 = null;
            }
            if (!"jwt".equals(bundle.getString("type"))) {
                obj = obj2;
            }
            a = m4262b(str, str2, bundle);
            if (!(a == null || r1 == null)) {
                f2092g.m4303a(this.f2096d, str, str2, a, f2091f);
            }
        }
        return a;
    }

    /* renamed from: a */
    KeyPair m4261a() {
        if (this.f2095c == null) {
            this.f2095c = f2092g.m4307c(this.f2096d);
        }
        if (this.f2095c == null) {
            this.f2097e = System.currentTimeMillis();
            this.f2095c = f2092g.m4301a(this.f2096d, this.f2097e);
        }
        return this.f2095c;
    }

    /* renamed from: b */
    public String m4262b(String str, String str2, Bundle bundle) throws IOException {
        if (str2 != null) {
            bundle.putString("scope", str2);
        }
        bundle.putString("sender", str);
        String str3 = "".equals(this.f2096d) ? str : this.f2096d;
        if (!bundle.containsKey("legacy.register")) {
            bundle.putString("subscription", str);
            bundle.putString("subtype", str3);
            bundle.putString("X-subscription", str);
            bundle.putString("X-subtype", str3);
        }
        return f2093h.m4293b(f2093h.m4287a(bundle, m4261a()));
    }

    /* renamed from: b */
    public void m4263b() {
        this.f2097e = 0;
        f2092g.m4308d(this.f2096d);
        this.f2095c = null;
    }

    /* renamed from: c */
    public C1027f m4264c() {
        return f2092g;
    }

    /* renamed from: d */
    public C1026e m4265d() {
        return f2093h;
    }

    /* renamed from: e */
    boolean m4266e() {
        String a = f2092g.m4298a("appVersion");
        if (a == null || !a.equals(f2091f)) {
            return true;
        }
        a = f2092g.m4298a("lastToken");
        if (a == null) {
            return true;
        }
        return (System.currentTimeMillis() / 1000) - Long.valueOf(Long.parseLong(a)).longValue() > 604800;
    }
}

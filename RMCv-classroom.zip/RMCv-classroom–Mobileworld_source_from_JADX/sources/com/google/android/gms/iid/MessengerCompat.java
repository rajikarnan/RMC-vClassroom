package com.google.android.gms.iid;

import android.os.Build.VERSION;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import com.google.android.gms.iid.C1022d.C1024a;

public class MessengerCompat implements Parcelable {
    public static final Creator<MessengerCompat> CREATOR = new C10181();
    /* renamed from: a */
    Messenger f2088a;
    /* renamed from: b */
    C1022d f2089b;

    /* renamed from: com.google.android.gms.iid.MessengerCompat$1 */
    class C10181 implements Creator<MessengerCompat> {
        C10181() {
        }

        /* renamed from: a */
        public MessengerCompat m4250a(Parcel parcel) {
            IBinder readStrongBinder = parcel.readStrongBinder();
            return readStrongBinder != null ? new MessengerCompat(readStrongBinder) : null;
        }

        /* renamed from: a */
        public MessengerCompat[] m4251a(int i) {
            return new MessengerCompat[i];
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m4250a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m4251a(i);
        }
    }

    public MessengerCompat(IBinder iBinder) {
        if (VERSION.SDK_INT >= 21) {
            this.f2088a = new Messenger(iBinder);
        } else {
            this.f2089b = C1024a.m4277a(iBinder);
        }
    }

    /* renamed from: a */
    public IBinder m4252a() {
        return this.f2088a != null ? this.f2088a.getBinder() : this.f2089b.asBinder();
    }

    /* renamed from: a */
    public void m4253a(Message message) throws RemoteException {
        if (this.f2088a != null) {
            this.f2088a.send(message);
        } else {
            this.f2089b.mo1049a(message);
        }
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        boolean z = false;
        if (obj != null) {
            try {
                z = m4252a().equals(((MessengerCompat) obj).m4252a());
            } catch (ClassCastException e) {
            }
        }
        return z;
    }

    public int hashCode() {
        return m4252a().hashCode();
    }

    public void writeToParcel(Parcel parcel, int i) {
        if (this.f2088a != null) {
            parcel.writeStrongBinder(this.f2088a.getBinder());
        } else {
            parcel.writeStrongBinder(this.f2089b.asBinder());
        }
    }
}

package com.google.android.gms.p020b;

import android.os.IBinder;
import com.google.android.gms.p020b.C0789a.C0790a;
import java.lang.reflect.Field;

/* renamed from: com.google.android.gms.b.b */
public final class C0791b<T> extends C0790a {
    /* renamed from: a */
    private final T f1519a;

    private C0791b(T t) {
        this.f1519a = t;
    }

    /* renamed from: a */
    public static <T> C0789a m3210a(T t) {
        return new C0791b(t);
    }

    /* renamed from: a */
    public static <T> T m3211a(C0789a c0789a) {
        if (c0789a instanceof C0791b) {
            return ((C0791b) c0789a).f1519a;
        }
        IBinder asBinder = c0789a.asBinder();
        Field[] declaredFields = asBinder.getClass().getDeclaredFields();
        if (declaredFields.length == 1) {
            Field field = declaredFields[0];
            if (field.isAccessible()) {
                throw new IllegalArgumentException("The concrete class implementing IObjectWrapper must have exactly one declared *private* field for the wrapped object. Preferably, this is an instance of the ObjectWrapper<T> class.");
            }
            field.setAccessible(true);
            try {
                return field.get(asBinder);
            } catch (Throwable e) {
                throw new IllegalArgumentException("Binder object is null.", e);
            } catch (Throwable e2) {
                throw new IllegalArgumentException("remoteBinder is the wrong class.", e2);
            } catch (Throwable e22) {
                throw new IllegalArgumentException("Could not access the field in remoteBinder.", e22);
            }
        }
        throw new IllegalArgumentException("The concrete class implementing IObjectWrapper must have exactly *one* declared private field for the wrapped object.  Preferably, this is an instance of the ObjectWrapper<T> class.");
    }
}

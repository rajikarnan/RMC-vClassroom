package com.google.android.gms.p020b;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

/* renamed from: com.google.android.gms.b.a */
public interface C0789a extends IInterface {

    /* renamed from: com.google.android.gms.b.a$a */
    public static abstract class C0790a extends Binder implements C0789a {
        public C0790a() {
            attachInterface(this, "com.google.android.gms.dynamic.IObjectWrapper");
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            switch (i) {
                case 1598968902:
                    parcel2.writeString("com.google.android.gms.dynamic.IObjectWrapper");
                    return true;
                default:
                    return super.onTransact(i, parcel, parcel2, i2);
            }
        }
    }
}

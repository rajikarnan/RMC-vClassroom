package com.google.android.gms.auth.api.signin;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.app.ag;
import android.text.TextUtils;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.C0854b;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.p022a.C0796c;
import com.google.android.gms.common.p022a.C0797d;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GoogleSignInAccount extends AbstractSafeParcelable {
    public static final Creator<GoogleSignInAccount> CREATOR = new C0788a();
    /* renamed from: a */
    public static C0796c f1501a = C0797d.m3235b();
    /* renamed from: n */
    private static Comparator<Scope> f1502n = new C07861();
    /* renamed from: b */
    final int f1503b;
    /* renamed from: c */
    List<Scope> f1504c;
    /* renamed from: d */
    private String f1505d;
    /* renamed from: e */
    private String f1506e;
    /* renamed from: f */
    private String f1507f;
    /* renamed from: g */
    private String f1508g;
    /* renamed from: h */
    private Uri f1509h;
    /* renamed from: i */
    private String f1510i;
    /* renamed from: j */
    private long f1511j;
    /* renamed from: k */
    private String f1512k;
    /* renamed from: l */
    private String f1513l;
    /* renamed from: m */
    private String f1514m;

    /* renamed from: com.google.android.gms.auth.api.signin.GoogleSignInAccount$1 */
    class C07861 implements Comparator<Scope> {
        C07861() {
        }

        /* renamed from: a */
        public int m3186a(Scope scope, Scope scope2) {
            return scope.m3286a().compareTo(scope2.m3286a());
        }

        public /* synthetic */ int compare(Object obj, Object obj2) {
            return m3186a((Scope) obj, (Scope) obj2);
        }
    }

    GoogleSignInAccount(int i, String str, String str2, String str3, String str4, Uri uri, String str5, long j, String str6, List<Scope> list, String str7, String str8) {
        this.f1503b = i;
        this.f1505d = str;
        this.f1506e = str2;
        this.f1507f = str3;
        this.f1508g = str4;
        this.f1509h = uri;
        this.f1510i = str5;
        this.f1511j = j;
        this.f1512k = str6;
        this.f1504c = list;
        this.f1513l = str7;
        this.f1514m = str8;
    }

    /* renamed from: a */
    public static GoogleSignInAccount m3187a(String str) throws JSONException {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        JSONObject jSONObject = new JSONObject(str);
        Object optString = jSONObject.optString("photoUrl", null);
        Uri parse = !TextUtils.isEmpty(optString) ? Uri.parse(optString) : null;
        long parseLong = Long.parseLong(jSONObject.getString("expirationTime"));
        Set hashSet = new HashSet();
        JSONArray jSONArray = jSONObject.getJSONArray("grantedScopes");
        int length = jSONArray.length();
        for (int i = 0; i < length; i++) {
            hashSet.add(new Scope(jSONArray.getString(i)));
        }
        return m3188a(jSONObject.optString("id"), jSONObject.optString("tokenId", null), jSONObject.optString(ag.CATEGORY_EMAIL, null), jSONObject.optString("displayName", null), jSONObject.optString("givenName", null), jSONObject.optString("familyName", null), parse, Long.valueOf(parseLong), jSONObject.getString("obfuscatedIdentifier"), hashSet).m3191b(jSONObject.optString("serverAuthCode", null));
    }

    /* renamed from: a */
    public static GoogleSignInAccount m3188a(String str, String str2, String str3, String str4, String str5, String str6, Uri uri, Long l, String str7, Set<Scope> set) {
        if (l == null) {
            l = Long.valueOf(f1501a.mo889a() / 1000);
        }
        return new GoogleSignInAccount(3, str, str2, str3, str4, uri, null, l.longValue(), C0854b.m3429a(str7), new ArrayList((Collection) C0854b.m3427a((Object) set)), str5, str6);
    }

    /* renamed from: l */
    private JSONObject m3189l() {
        JSONObject jSONObject = new JSONObject();
        try {
            if (m3190a() != null) {
                jSONObject.put("id", m3190a());
            }
            if (m3192b() != null) {
                jSONObject.put("tokenId", m3192b());
            }
            if (m3193c() != null) {
                jSONObject.put(ag.CATEGORY_EMAIL, m3193c());
            }
            if (m3194d() != null) {
                jSONObject.put("displayName", m3194d());
            }
            if (m3195e() != null) {
                jSONObject.put("givenName", m3195e());
            }
            if (m3196f() != null) {
                jSONObject.put("familyName", m3196f());
            }
            if (m3197g() != null) {
                jSONObject.put("photoUrl", m3197g().toString());
            }
            if (m3198h() != null) {
                jSONObject.put("serverAuthCode", m3198h());
            }
            jSONObject.put("expirationTime", this.f1511j);
            jSONObject.put("obfuscatedIdentifier", m3200j());
            JSONArray jSONArray = new JSONArray();
            Collections.sort(this.f1504c, f1502n);
            for (Scope a : this.f1504c) {
                jSONArray.put(a.m3286a());
            }
            jSONObject.put("grantedScopes", jSONArray);
            return jSONObject;
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    /* renamed from: a */
    public String m3190a() {
        return this.f1505d;
    }

    /* renamed from: b */
    public GoogleSignInAccount m3191b(String str) {
        this.f1510i = str;
        return this;
    }

    /* renamed from: b */
    public String m3192b() {
        return this.f1506e;
    }

    /* renamed from: c */
    public String m3193c() {
        return this.f1507f;
    }

    /* renamed from: d */
    public String m3194d() {
        return this.f1508g;
    }

    /* renamed from: e */
    public String m3195e() {
        return this.f1513l;
    }

    public boolean equals(Object obj) {
        return !(obj instanceof GoogleSignInAccount) ? false : ((GoogleSignInAccount) obj).m3201k().equals(m3201k());
    }

    /* renamed from: f */
    public String m3196f() {
        return this.f1514m;
    }

    /* renamed from: g */
    public Uri m3197g() {
        return this.f1509h;
    }

    /* renamed from: h */
    public String m3198h() {
        return this.f1510i;
    }

    /* renamed from: i */
    public long m3199i() {
        return this.f1511j;
    }

    /* renamed from: j */
    public String m3200j() {
        return this.f1512k;
    }

    /* renamed from: k */
    public String m3201k() {
        return m3189l().toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0788a.m3207a(this, parcel, i);
    }
}

package com.google.android.gms.auth.api.signin.p019a;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.internal.C0854b;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import org.json.JSONException;

/* renamed from: com.google.android.gms.auth.api.signin.a.a */
public class C0787a {
    /* renamed from: a */
    private static final Lock f1515a = new ReentrantLock();
    /* renamed from: b */
    private static C0787a f1516b;
    /* renamed from: c */
    private final Lock f1517c = new ReentrantLock();
    /* renamed from: d */
    private final SharedPreferences f1518d;

    C0787a(Context context) {
        this.f1518d = context.getSharedPreferences("com.google.android.gms.signin", 0);
    }

    /* renamed from: a */
    public static C0787a m3202a(Context context) {
        C0854b.m3427a((Object) context);
        f1515a.lock();
        try {
            if (f1516b == null) {
                f1516b = new C0787a(context.getApplicationContext());
            }
            C0787a c0787a = f1516b;
            return c0787a;
        } finally {
            f1515a.unlock();
        }
    }

    /* renamed from: a */
    private String m3203a(String str, String str2) {
        String valueOf = String.valueOf(":");
        return new StringBuilder(((String.valueOf(str).length() + 0) + String.valueOf(valueOf).length()) + String.valueOf(str2).length()).append(str).append(valueOf).append(str2).toString();
    }

    /* renamed from: a */
    public GoogleSignInAccount m3204a() {
        return m3205a(m3206b("defaultGoogleSignInAccount"));
    }

    /* renamed from: a */
    GoogleSignInAccount m3205a(String str) {
        GoogleSignInAccount googleSignInAccount = null;
        if (!TextUtils.isEmpty(str)) {
            String b = m3206b(m3203a("googleSignInAccount", str));
            if (b != null) {
                try {
                    googleSignInAccount = GoogleSignInAccount.m3187a(b);
                } catch (JSONException e) {
                }
            }
        }
        return googleSignInAccount;
    }

    /* renamed from: b */
    protected String m3206b(String str) {
        this.f1517c.lock();
        try {
            String string = this.f1518d.getString(str, null);
            return string;
        } finally {
            this.f1517c.unlock();
        }
    }
}

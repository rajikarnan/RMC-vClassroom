package com.google.android.gms.auth.api.signin;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;
import java.util.List;

/* renamed from: com.google.android.gms.auth.api.signin.a */
public class C0788a implements Creator<GoogleSignInAccount> {
    /* renamed from: a */
    static void m3207a(GoogleSignInAccount googleSignInAccount, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3646a(parcel, 1, googleSignInAccount.f1503b);
        C0907b.m3652a(parcel, 2, googleSignInAccount.m3190a(), false);
        C0907b.m3652a(parcel, 3, googleSignInAccount.m3192b(), false);
        C0907b.m3652a(parcel, 4, googleSignInAccount.m3193c(), false);
        C0907b.m3652a(parcel, 5, googleSignInAccount.m3194d(), false);
        C0907b.m3650a(parcel, 6, googleSignInAccount.m3197g(), i, false);
        C0907b.m3652a(parcel, 7, googleSignInAccount.m3198h(), false);
        C0907b.m3647a(parcel, 8, googleSignInAccount.m3199i());
        C0907b.m3652a(parcel, 9, googleSignInAccount.m3200j(), false);
        C0907b.m3661b(parcel, 10, googleSignInAccount.f1504c, false);
        C0907b.m3652a(parcel, 11, googleSignInAccount.m3195e(), false);
        C0907b.m3652a(parcel, 12, googleSignInAccount.m3196f(), false);
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public GoogleSignInAccount m3208a(Parcel parcel) {
        int b = C0906a.m3626b(parcel);
        int i = 0;
        String str = null;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        Uri uri = null;
        String str5 = null;
        long j = 0;
        String str6 = null;
        List list = null;
        String str7 = null;
        String str8 = null;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    i = C0906a.m3632e(parcel, a);
                    break;
                case 2:
                    str = C0906a.m3637j(parcel, a);
                    break;
                case 3:
                    str2 = C0906a.m3637j(parcel, a);
                    break;
                case 4:
                    str3 = C0906a.m3637j(parcel, a);
                    break;
                case 5:
                    str4 = C0906a.m3637j(parcel, a);
                    break;
                case 6:
                    uri = (Uri) C0906a.m3623a(parcel, a, Uri.CREATOR);
                    break;
                case 7:
                    str5 = C0906a.m3637j(parcel, a);
                    break;
                case 8:
                    j = C0906a.m3634g(parcel, a);
                    break;
                case 9:
                    str6 = C0906a.m3637j(parcel, a);
                    break;
                case 10:
                    list = C0906a.m3629c(parcel, a, Scope.CREATOR);
                    break;
                case 11:
                    str7 = C0906a.m3637j(parcel, a);
                    break;
                case 12:
                    str8 = C0906a.m3637j(parcel, a);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new GoogleSignInAccount(i, str, str2, str3, str4, uri, str5, j, str6, list, str7, str8);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public GoogleSignInAccount[] m3209a(int i) {
        return new GoogleSignInAccount[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m3208a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m3209a(i);
    }
}

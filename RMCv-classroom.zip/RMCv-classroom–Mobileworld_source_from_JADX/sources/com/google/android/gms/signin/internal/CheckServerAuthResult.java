package com.google.android.gms.signin.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.List;

public class CheckServerAuthResult extends AbstractSafeParcelable {
    public static final Creator<CheckServerAuthResult> CREATOR = new C1079c();
    /* renamed from: a */
    final int f2242a;
    /* renamed from: b */
    final boolean f2243b;
    /* renamed from: c */
    final List<Scope> f2244c;

    CheckServerAuthResult(int i, boolean z, List<Scope> list) {
        this.f2242a = i;
        this.f2243b = z;
        this.f2244c = list;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1079c.m4547a(this, parcel, i);
    }
}

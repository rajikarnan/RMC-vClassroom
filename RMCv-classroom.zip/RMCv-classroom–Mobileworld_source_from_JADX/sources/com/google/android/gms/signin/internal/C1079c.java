package com.google.android.gms.signin.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;
import java.util.List;

/* renamed from: com.google.android.gms.signin.internal.c */
public class C1079c implements Creator<CheckServerAuthResult> {
    /* renamed from: a */
    static void m4547a(CheckServerAuthResult checkServerAuthResult, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3646a(parcel, 1, checkServerAuthResult.f2242a);
        C0907b.m3655a(parcel, 2, checkServerAuthResult.f2243b);
        C0907b.m3661b(parcel, 3, checkServerAuthResult.f2244c, false);
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public CheckServerAuthResult m4548a(Parcel parcel) {
        boolean z = false;
        int b = C0906a.m3626b(parcel);
        List list = null;
        int i = 0;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    i = C0906a.m3632e(parcel, a);
                    break;
                case 2:
                    z = C0906a.m3630c(parcel, a);
                    break;
                case 3:
                    list = C0906a.m3629c(parcel, a, Scope.CREATOR);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new CheckServerAuthResult(i, z, list);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public CheckServerAuthResult[] m4549a(int i) {
        return new CheckServerAuthResult[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4548a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4549a(i);
    }
}

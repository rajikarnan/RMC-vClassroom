package com.google.android.gms.signin.internal;

import android.accounts.Account;
import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.p019a.C0787a;
import com.google.android.gms.common.api.GoogleApiClient.C0807b;
import com.google.android.gms.common.api.GoogleApiClient.C0808c;
import com.google.android.gms.common.internal.C0849u;
import com.google.android.gms.common.internal.C0854b;
import com.google.android.gms.common.internal.C0857i.C0874i;
import com.google.android.gms.common.internal.C0859p;
import com.google.android.gms.common.internal.C0890l;
import com.google.android.gms.common.internal.ResolveAccountRequest;
import com.google.android.gms.p023d.ar;
import com.google.android.gms.p023d.as;
import com.google.android.gms.signin.internal.C1081e.C1083a;

/* renamed from: com.google.android.gms.signin.internal.g */
public class C1085g extends C0859p<C1081e> implements ar {
    /* renamed from: d */
    private final boolean f2256d;
    /* renamed from: e */
    private final C0890l f2257e;
    /* renamed from: f */
    private final Bundle f2258f;
    /* renamed from: g */
    private Integer f2259g;

    public C1085g(Context context, Looper looper, boolean z, C0890l c0890l, Bundle bundle, C0807b c0807b, C0808c c0808c) {
        super(context, looper, 44, c0890l, c0807b, c0808c);
        this.f2256d = z;
        this.f2257e = c0890l;
        this.f2258f = bundle;
        this.f2259g = c0890l.m3567i();
    }

    public C1085g(Context context, Looper looper, boolean z, C0890l c0890l, as asVar, C0807b c0807b, C0808c c0808c) {
        this(context, looper, z, c0890l, C1085g.m4579a(c0890l), c0807b, c0808c);
    }

    /* renamed from: a */
    public static Bundle m4579a(C0890l c0890l) {
        as h = c0890l.m3566h();
        Integer i = c0890l.m3567i();
        Bundle bundle = new Bundle();
        bundle.putParcelable("com.google.android.gms.signin.internal.clientRequestedAccount", c0890l.m3558a());
        if (i != null) {
            bundle.putInt("com.google.android.gms.common.internal.ClientSettings.sessionId", i.intValue());
        }
        if (h != null) {
            bundle.putBoolean("com.google.android.gms.signin.internal.offlineAccessRequested", h.m3902a());
            bundle.putBoolean("com.google.android.gms.signin.internal.idTokenRequested", h.m3903b());
            bundle.putString("com.google.android.gms.signin.internal.serverClientId", h.m3904c());
            bundle.putBoolean("com.google.android.gms.signin.internal.usePromptModeForAuthCode", true);
            bundle.putBoolean("com.google.android.gms.signin.internal.forceCodeForRefreshToken", h.m3905d());
            bundle.putString("com.google.android.gms.signin.internal.hostedDomain", h.m3906e());
            bundle.putBoolean("com.google.android.gms.signin.internal.waitForAccessTokenRefresh", h.m3907f());
        }
        return bundle;
    }

    /* renamed from: w */
    private ResolveAccountRequest m4580w() {
        Account b = this.f2257e.m3560b();
        GoogleSignInAccount googleSignInAccount = null;
        if ("<<default account>>".equals(b.name)) {
            googleSignInAccount = C0787a.m3202a(m3477n()).m3204a();
        }
        return new ResolveAccountRequest(b, this.f2259g.intValue(), googleSignInAccount);
    }

    /* renamed from: a */
    protected /* synthetic */ IInterface mo903a(IBinder iBinder) {
        return m4584b(iBinder);
    }

    /* renamed from: a */
    public void mo1104a(C0849u c0849u, boolean z) {
        try {
            ((C1081e) m3483t()).mo1098a(c0849u, this.f2259g.intValue(), z);
        } catch (RemoteException e) {
            Log.w("SignInClientImpl", "Remote service probably died when saveDefaultAccount is called");
        }
    }

    /* renamed from: a */
    public void mo1105a(C0994d c0994d) {
        C0854b.m3428a((Object) c0994d, (Object) "Expecting a valid ISignInCallbacks");
        try {
            ((C1081e) m3483t()).mo1101a(new SignInRequest(m4580w()), c0994d);
        } catch (Throwable e) {
            Log.w("SignInClientImpl", "Remote service probably died when signIn is called");
            try {
                c0994d.mo1033a(new SignInResponse(8));
            } catch (RemoteException e2) {
                Log.wtf("SignInClientImpl", "ISignInCallbacks#onSignInComplete should be executed from the same process, unexpected RemoteException.", e);
            }
        }
    }

    /* renamed from: b */
    protected C1081e m4584b(IBinder iBinder) {
        return C1083a.m4575a(iBinder);
    }

    /* renamed from: d */
    public boolean mo1106d() {
        return this.f2256d;
    }

    /* renamed from: i */
    protected String mo905i() {
        return "com.google.android.gms.signin.service.START";
    }

    /* renamed from: j */
    protected String mo906j() {
        return "com.google.android.gms.signin.internal.ISignInService";
    }

    /* renamed from: k */
    public void mo907k() {
        try {
            ((C1081e) m3483t()).mo1094a(this.f2259g.intValue());
        } catch (RemoteException e) {
            Log.w("SignInClientImpl", "Remote service probably died when clearAccountFromSessionStore is called");
        }
    }

    /* renamed from: l */
    public void mo1107l() {
        m3463a(new C0874i(this));
    }

    /* renamed from: q */
    protected Bundle mo1052q() {
        if (!m3477n().getPackageName().equals(this.f2257e.m3564f())) {
            this.f2258f.putString("com.google.android.gms.signin.internal.realClientPackageName", this.f2257e.m3564f());
        }
        return this.f2258f;
    }
}

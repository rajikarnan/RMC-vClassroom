package com.google.android.gms.signin.internal;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;

/* renamed from: com.google.android.gms.signin.internal.f */
public class C1084f implements Creator<RecordConsentRequest> {
    /* renamed from: a */
    static void m4576a(RecordConsentRequest recordConsentRequest, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3646a(parcel, 1, recordConsentRequest.f2245a);
        C0907b.m3650a(parcel, 2, recordConsentRequest.m4538a(), i, false);
        C0907b.m3657a(parcel, 3, recordConsentRequest.m4539b(), i, false);
        C0907b.m3652a(parcel, 4, recordConsentRequest.m4540c(), false);
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public RecordConsentRequest m4577a(Parcel parcel) {
        String str = null;
        int b = C0906a.m3626b(parcel);
        int i = 0;
        Scope[] scopeArr = null;
        Account account = null;
        while (parcel.dataPosition() < b) {
            Scope[] scopeArr2;
            Account account2;
            int e;
            String str2;
            int a = C0906a.m3621a(parcel);
            String str3;
            switch (C0906a.m3620a(a)) {
                case 1:
                    str3 = str;
                    scopeArr2 = scopeArr;
                    account2 = account;
                    e = C0906a.m3632e(parcel, a);
                    str2 = str3;
                    break;
                case 2:
                    e = i;
                    Scope[] scopeArr3 = scopeArr;
                    account2 = (Account) C0906a.m3623a(parcel, a, Account.CREATOR);
                    str2 = str;
                    scopeArr2 = scopeArr3;
                    break;
                case 3:
                    account2 = account;
                    e = i;
                    str3 = str;
                    scopeArr2 = (Scope[]) C0906a.m3628b(parcel, a, Scope.CREATOR);
                    str2 = str3;
                    break;
                case 4:
                    str2 = C0906a.m3637j(parcel, a);
                    scopeArr2 = scopeArr;
                    account2 = account;
                    e = i;
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    str2 = str;
                    scopeArr2 = scopeArr;
                    account2 = account;
                    e = i;
                    break;
            }
            i = e;
            account = account2;
            scopeArr = scopeArr2;
            str = str2;
        }
        if (parcel.dataPosition() == b) {
            return new RecordConsentRequest(i, account, scopeArr, str);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public RecordConsentRequest[] m4578a(int i) {
        return new RecordConsentRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4577a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4578a(i);
    }
}

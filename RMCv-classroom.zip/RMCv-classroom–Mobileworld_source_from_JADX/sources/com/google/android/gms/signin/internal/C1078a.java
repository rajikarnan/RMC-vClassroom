package com.google.android.gms.signin.internal;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;

/* renamed from: com.google.android.gms.signin.internal.a */
public class C1078a implements Creator<AuthAccountResult> {
    /* renamed from: a */
    static void m4544a(AuthAccountResult authAccountResult, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3646a(parcel, 1, authAccountResult.f2239a);
        C0907b.m3646a(parcel, 2, authAccountResult.m4536b());
        C0907b.m3650a(parcel, 3, authAccountResult.m4537c(), i, false);
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public AuthAccountResult m4545a(Parcel parcel) {
        int i = 0;
        int b = C0906a.m3626b(parcel);
        Intent intent = null;
        int i2 = 0;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    i2 = C0906a.m3632e(parcel, a);
                    break;
                case 2:
                    i = C0906a.m3632e(parcel, a);
                    break;
                case 3:
                    intent = (Intent) C0906a.m3623a(parcel, a, Intent.CREATOR);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new AuthAccountResult(i2, i, intent);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public AuthAccountResult[] m4546a(int i) {
        return new AuthAccountResult[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4545a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4546a(i);
    }
}

package com.google.android.gms.signin.internal;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class RecordConsentRequest extends AbstractSafeParcelable {
    public static final Creator<RecordConsentRequest> CREATOR = new C1084f();
    /* renamed from: a */
    final int f2245a;
    /* renamed from: b */
    private final Account f2246b;
    /* renamed from: c */
    private final Scope[] f2247c;
    /* renamed from: d */
    private final String f2248d;

    RecordConsentRequest(int i, Account account, Scope[] scopeArr, String str) {
        this.f2245a = i;
        this.f2246b = account;
        this.f2247c = scopeArr;
        this.f2248d = str;
    }

    /* renamed from: a */
    public Account m4538a() {
        return this.f2246b;
    }

    /* renamed from: b */
    public Scope[] m4539b() {
        return this.f2247c;
    }

    /* renamed from: c */
    public String m4540c() {
        return this.f2248d;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1084f.m4576a(this, parcel, i);
    }
}

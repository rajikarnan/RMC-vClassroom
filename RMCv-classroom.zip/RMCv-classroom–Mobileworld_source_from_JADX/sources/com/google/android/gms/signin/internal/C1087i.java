package com.google.android.gms.signin.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.ResolveAccountResponse;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;

/* renamed from: com.google.android.gms.signin.internal.i */
public class C1087i implements Creator<SignInResponse> {
    /* renamed from: a */
    static void m4594a(SignInResponse signInResponse, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3646a(parcel, 1, signInResponse.f2251a);
        C0907b.m3650a(parcel, 2, signInResponse.m4542a(), i, false);
        C0907b.m3650a(parcel, 3, signInResponse.m4543b(), i, false);
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public SignInResponse m4595a(Parcel parcel) {
        ResolveAccountResponse resolveAccountResponse = null;
        int b = C0906a.m3626b(parcel);
        int i = 0;
        ConnectionResult connectionResult = null;
        while (parcel.dataPosition() < b) {
            ConnectionResult connectionResult2;
            int e;
            ResolveAccountResponse resolveAccountResponse2;
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    ResolveAccountResponse resolveAccountResponse3 = resolveAccountResponse;
                    connectionResult2 = connectionResult;
                    e = C0906a.m3632e(parcel, a);
                    resolveAccountResponse2 = resolveAccountResponse3;
                    break;
                case 2:
                    e = i;
                    ConnectionResult connectionResult3 = (ConnectionResult) C0906a.m3623a(parcel, a, ConnectionResult.CREATOR);
                    resolveAccountResponse2 = resolveAccountResponse;
                    connectionResult2 = connectionResult3;
                    break;
                case 3:
                    resolveAccountResponse2 = (ResolveAccountResponse) C0906a.m3623a(parcel, a, ResolveAccountResponse.CREATOR);
                    connectionResult2 = connectionResult;
                    e = i;
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    resolveAccountResponse2 = resolveAccountResponse;
                    connectionResult2 = connectionResult;
                    e = i;
                    break;
            }
            i = e;
            connectionResult = connectionResult2;
            resolveAccountResponse = resolveAccountResponse2;
        }
        if (parcel.dataPosition() == b) {
            return new SignInResponse(i, connectionResult, resolveAccountResponse);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public SignInResponse[] m4596a(int i) {
        return new SignInResponse[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4595a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4596a(i);
    }
}

package com.google.android.gms.signin.internal;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.C0809e;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class AuthAccountResult extends AbstractSafeParcelable implements C0809e {
    public static final Creator<AuthAccountResult> CREATOR = new C1078a();
    /* renamed from: a */
    final int f2239a;
    /* renamed from: b */
    private int f2240b;
    /* renamed from: c */
    private Intent f2241c;

    public AuthAccountResult() {
        this(0, null);
    }

    AuthAccountResult(int i, int i2, Intent intent) {
        this.f2239a = i;
        this.f2240b = i2;
        this.f2241c = intent;
    }

    public AuthAccountResult(int i, Intent intent) {
        this(2, i, intent);
    }

    /* renamed from: a */
    public Status mo890a() {
        return this.f2240b == 0 ? Status.f1568a : Status.f1572e;
    }

    /* renamed from: b */
    public int m4536b() {
        return this.f2240b;
    }

    /* renamed from: c */
    public Intent m4537c() {
        return this.f2241c;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1078a.m4544a(this, parcel, i);
    }
}

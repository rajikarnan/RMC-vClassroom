package com.google.android.gms.signin.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.ResolveAccountResponse;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class SignInResponse extends AbstractSafeParcelable {
    public static final Creator<SignInResponse> CREATOR = new C1087i();
    /* renamed from: a */
    final int f2251a;
    /* renamed from: b */
    private final ConnectionResult f2252b;
    /* renamed from: c */
    private final ResolveAccountResponse f2253c;

    public SignInResponse(int i) {
        this(new ConnectionResult(i, null), null);
    }

    SignInResponse(int i, ConnectionResult connectionResult, ResolveAccountResponse resolveAccountResponse) {
        this.f2251a = i;
        this.f2252b = connectionResult;
        this.f2253c = resolveAccountResponse;
    }

    public SignInResponse(ConnectionResult connectionResult, ResolveAccountResponse resolveAccountResponse) {
        this(1, connectionResult, resolveAccountResponse);
    }

    /* renamed from: a */
    public ConnectionResult m4542a() {
        return this.f2252b;
    }

    /* renamed from: b */
    public ResolveAccountResponse m4543b() {
        return this.f2253c;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1087i.m4594a(this, parcel, i);
    }
}

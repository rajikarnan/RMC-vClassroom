package com.google.android.gms.signin.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.ResolveAccountRequest;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;

/* renamed from: com.google.android.gms.signin.internal.h */
public class C1086h implements Creator<SignInRequest> {
    /* renamed from: a */
    static void m4591a(SignInRequest signInRequest, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3646a(parcel, 1, signInRequest.f2249a);
        C0907b.m3650a(parcel, 2, signInRequest.m4541a(), i, false);
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public SignInRequest m4592a(Parcel parcel) {
        int b = C0906a.m3626b(parcel);
        int i = 0;
        ResolveAccountRequest resolveAccountRequest = null;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    i = C0906a.m3632e(parcel, a);
                    break;
                case 2:
                    resolveAccountRequest = (ResolveAccountRequest) C0906a.m3623a(parcel, a, ResolveAccountRequest.CREATOR);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new SignInRequest(i, resolveAccountRequest);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public SignInRequest[] m4593a(int i) {
        return new SignInRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4592a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4593a(i);
    }
}

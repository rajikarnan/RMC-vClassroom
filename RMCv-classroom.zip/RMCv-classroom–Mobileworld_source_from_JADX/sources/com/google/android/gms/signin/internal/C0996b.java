package com.google.android.gms.signin.internal;

import android.os.RemoteException;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.signin.internal.C0994d.C0995a;

/* renamed from: com.google.android.gms.signin.internal.b */
public class C0996b extends C0995a {
    /* renamed from: a */
    public void mo1030a(ConnectionResult connectionResult, AuthAccountResult authAccountResult) throws RemoteException {
    }

    /* renamed from: a */
    public void mo1031a(Status status) throws RemoteException {
    }

    /* renamed from: a */
    public void mo1032a(Status status, GoogleSignInAccount googleSignInAccount) throws RemoteException {
    }

    /* renamed from: a */
    public void mo1033a(SignInResponse signInResponse) throws RemoteException {
    }

    /* renamed from: b */
    public void mo1034b(Status status) throws RemoteException {
    }
}

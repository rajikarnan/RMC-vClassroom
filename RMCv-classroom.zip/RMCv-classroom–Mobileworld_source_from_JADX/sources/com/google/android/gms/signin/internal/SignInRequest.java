package com.google.android.gms.signin.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.ResolveAccountRequest;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class SignInRequest extends AbstractSafeParcelable {
    public static final Creator<SignInRequest> CREATOR = new C1086h();
    /* renamed from: a */
    final int f2249a;
    /* renamed from: b */
    final ResolveAccountRequest f2250b;

    SignInRequest(int i, ResolveAccountRequest resolveAccountRequest) {
        this.f2249a = i;
        this.f2250b = resolveAccountRequest;
    }

    public SignInRequest(ResolveAccountRequest resolveAccountRequest) {
        this(1, resolveAccountRequest);
    }

    /* renamed from: a */
    public ResolveAccountRequest m4541a() {
        return this.f2250b;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1086h.m4591a(this, parcel, i);
    }
}

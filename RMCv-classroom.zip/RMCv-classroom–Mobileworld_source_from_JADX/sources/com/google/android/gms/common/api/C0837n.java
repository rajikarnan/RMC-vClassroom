package com.google.android.gms.common.api;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;

/* renamed from: com.google.android.gms.common.api.n */
public class C0837n implements Creator<Scope> {
    /* renamed from: a */
    static void m3338a(Scope scope, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3646a(parcel, 1, scope.f1566a);
        C0907b.m3652a(parcel, 2, scope.m3286a(), false);
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public Scope m3339a(Parcel parcel) {
        int b = C0906a.m3626b(parcel);
        int i = 0;
        String str = null;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    i = C0906a.m3632e(parcel, a);
                    break;
                case 2:
                    str = C0906a.m3637j(parcel, a);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new Scope(i, str);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public Scope[] m3340a(int i) {
        return new Scope[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m3339a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m3340a(i);
    }
}

package com.google.android.gms.common.api;

import android.support.v4.p011e.C0222a;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.p023d.C0957e;

/* renamed from: com.google.android.gms.common.api.j */
public class C0834j extends C0833k {
    /* renamed from: a */
    private final ConnectionResult f1585a;

    public C0834j(Status status, C0222a<C0957e<?>, ConnectionResult> c0222a) {
        super(status, c0222a);
        this.f1585a = (ConnectionResult) c0222a.get(c0222a.m820b(0));
    }
}

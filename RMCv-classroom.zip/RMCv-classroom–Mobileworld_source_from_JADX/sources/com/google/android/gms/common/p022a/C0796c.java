package com.google.android.gms.common.p022a;

/* renamed from: com.google.android.gms.common.a.c */
public interface C0796c {
    /* renamed from: a */
    long mo889a();
}

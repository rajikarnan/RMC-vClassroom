package com.google.android.gms.common.api;

/* renamed from: com.google.android.gms.common.api.f */
public interface C0829f<R extends C0809e> {
    /* renamed from: a */
    void mo984a(R r);
}

package com.google.android.gms.common.internal;

import android.content.Context;
import android.content.ServiceConnection;

/* renamed from: com.google.android.gms.common.internal.r */
public abstract class C0900r {
    /* renamed from: a */
    private static final Object f1752a = new Object();
    /* renamed from: b */
    private static C0900r f1753b;

    /* renamed from: a */
    public static C0900r m3594a(Context context) {
        synchronized (f1752a) {
            if (f1753b == null) {
                f1753b = new C0904s(context.getApplicationContext());
            }
        }
        return f1753b;
    }

    /* renamed from: a */
    public abstract boolean mo922a(String str, String str2, ServiceConnection serviceConnection, String str3);

    /* renamed from: b */
    public abstract void mo923b(String str, String str2, ServiceConnection serviceConnection, String str3);
}

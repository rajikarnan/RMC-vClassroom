package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.api.GoogleApiClient.C0807b;
import com.google.android.gms.common.api.GoogleApiClient.C0808c;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicInteger;

/* renamed from: com.google.android.gms.common.internal.q */
public final class C0899q implements Callback {
    /* renamed from: a */
    final ArrayList<C0807b> f1743a = new ArrayList();
    /* renamed from: b */
    private final C0858a f1744b;
    /* renamed from: c */
    private final ArrayList<C0807b> f1745c = new ArrayList();
    /* renamed from: d */
    private final ArrayList<C0808c> f1746d = new ArrayList();
    /* renamed from: e */
    private volatile boolean f1747e = false;
    /* renamed from: f */
    private final AtomicInteger f1748f = new AtomicInteger(0);
    /* renamed from: g */
    private boolean f1749g = false;
    /* renamed from: h */
    private final Handler f1750h;
    /* renamed from: i */
    private final Object f1751i = new Object();

    /* renamed from: com.google.android.gms.common.internal.q$a */
    public interface C0858a {
        /* renamed from: b */
        boolean mo1035b();

        /* renamed from: s */
        Bundle mo1036s();
    }

    public C0899q(Looper looper, C0858a c0858a) {
        this.f1744b = c0858a;
        this.f1750h = new Handler(looper, this);
    }

    /* renamed from: a */
    public void m3586a() {
        this.f1747e = false;
        this.f1748f.incrementAndGet();
    }

    /* renamed from: a */
    public void m3587a(int i) {
        boolean z = false;
        if (Looper.myLooper() == this.f1750h.getLooper()) {
            z = true;
        }
        C0854b.m3432a(z, (Object) "onUnintentionalDisconnection must only be called on the Handler thread");
        this.f1750h.removeMessages(1);
        synchronized (this.f1751i) {
            this.f1749g = true;
            ArrayList arrayList = new ArrayList(this.f1745c);
            int i2 = this.f1748f.get();
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                C0807b c0807b = (C0807b) it.next();
                if (!this.f1747e || this.f1748f.get() != i2) {
                    break;
                } else if (this.f1745c.contains(c0807b)) {
                    c0807b.mo1010a(i);
                }
            }
            this.f1743a.clear();
            this.f1749g = false;
        }
    }

    /* renamed from: a */
    public void m3588a(Bundle bundle) {
        boolean z = true;
        C0854b.m3432a(Looper.myLooper() == this.f1750h.getLooper(), (Object) "onConnectionSuccess must only be called on the Handler thread");
        synchronized (this.f1751i) {
            C0854b.m3431a(!this.f1749g);
            this.f1750h.removeMessages(1);
            this.f1749g = true;
            if (this.f1743a.size() != 0) {
                z = false;
            }
            C0854b.m3431a(z);
            ArrayList arrayList = new ArrayList(this.f1745c);
            int i = this.f1748f.get();
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                C0807b c0807b = (C0807b) it.next();
                if (!this.f1747e || !this.f1744b.mo1035b() || this.f1748f.get() != i) {
                    break;
                } else if (!this.f1743a.contains(c0807b)) {
                    c0807b.mo1011a(bundle);
                }
            }
            this.f1743a.clear();
            this.f1749g = false;
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: a */
    public void m3589a(com.google.android.gms.common.ConnectionResult r6) {
        /*
        r5 = this;
        r1 = 1;
        r0 = android.os.Looper.myLooper();
        r2 = r5.f1750h;
        r2 = r2.getLooper();
        if (r0 != r2) goto L_0x0046;
    L_0x000d:
        r0 = r1;
    L_0x000e:
        r2 = "onConnectionFailure must only be called on the Handler thread";
        com.google.android.gms.common.internal.C0854b.m3432a(r0, r2);
        r0 = r5.f1750h;
        r0.removeMessages(r1);
        r1 = r5.f1751i;
        monitor-enter(r1);
        r0 = new java.util.ArrayList;	 Catch:{ all -> 0x0054 }
        r2 = r5.f1746d;	 Catch:{ all -> 0x0054 }
        r0.<init>(r2);	 Catch:{ all -> 0x0054 }
        r2 = r5.f1748f;	 Catch:{ all -> 0x0054 }
        r2 = r2.get();	 Catch:{ all -> 0x0054 }
        r3 = r0.iterator();	 Catch:{ all -> 0x0054 }
    L_0x002c:
        r0 = r3.hasNext();	 Catch:{ all -> 0x0054 }
        if (r0 == 0) goto L_0x0057;
    L_0x0032:
        r0 = r3.next();	 Catch:{ all -> 0x0054 }
        r0 = (com.google.android.gms.common.api.GoogleApiClient.C0808c) r0;	 Catch:{ all -> 0x0054 }
        r4 = r5.f1747e;	 Catch:{ all -> 0x0054 }
        if (r4 == 0) goto L_0x0044;
    L_0x003c:
        r4 = r5.f1748f;	 Catch:{ all -> 0x0054 }
        r4 = r4.get();	 Catch:{ all -> 0x0054 }
        if (r4 == r2) goto L_0x0048;
    L_0x0044:
        monitor-exit(r1);	 Catch:{ all -> 0x0054 }
    L_0x0045:
        return;
    L_0x0046:
        r0 = 0;
        goto L_0x000e;
    L_0x0048:
        r4 = r5.f1746d;	 Catch:{ all -> 0x0054 }
        r4 = r4.contains(r0);	 Catch:{ all -> 0x0054 }
        if (r4 == 0) goto L_0x002c;
    L_0x0050:
        r0.mo996a(r6);	 Catch:{ all -> 0x0054 }
        goto L_0x002c;
    L_0x0054:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x0054 }
        throw r0;
    L_0x0057:
        monitor-exit(r1);	 Catch:{ all -> 0x0054 }
        goto L_0x0045;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.common.internal.q.a(com.google.android.gms.common.ConnectionResult):void");
    }

    /* renamed from: a */
    public void m3590a(C0807b c0807b) {
        C0854b.m3427a((Object) c0807b);
        synchronized (this.f1751i) {
            if (this.f1745c.contains(c0807b)) {
                String valueOf = String.valueOf(c0807b);
                Log.w("GmsClientEvents", new StringBuilder(String.valueOf(valueOf).length() + 62).append("registerConnectionCallbacks(): listener ").append(valueOf).append(" is already registered").toString());
            } else {
                this.f1745c.add(c0807b);
            }
        }
        if (this.f1744b.mo1035b()) {
            this.f1750h.sendMessage(this.f1750h.obtainMessage(1, c0807b));
        }
    }

    /* renamed from: a */
    public void m3591a(C0808c c0808c) {
        C0854b.m3427a((Object) c0808c);
        synchronized (this.f1751i) {
            if (this.f1746d.contains(c0808c)) {
                String valueOf = String.valueOf(c0808c);
                Log.w("GmsClientEvents", new StringBuilder(String.valueOf(valueOf).length() + 67).append("registerConnectionFailedListener(): listener ").append(valueOf).append(" is already registered").toString());
            } else {
                this.f1746d.add(c0808c);
            }
        }
    }

    /* renamed from: b */
    public void m3592b() {
        this.f1747e = true;
    }

    /* renamed from: b */
    public void m3593b(C0808c c0808c) {
        C0854b.m3427a((Object) c0808c);
        synchronized (this.f1751i) {
            if (!this.f1746d.remove(c0808c)) {
                String valueOf = String.valueOf(c0808c);
                Log.w("GmsClientEvents", new StringBuilder(String.valueOf(valueOf).length() + 57).append("unregisterConnectionFailedListener(): listener ").append(valueOf).append(" not found").toString());
            }
        }
    }

    public boolean handleMessage(Message message) {
        if (message.what == 1) {
            C0807b c0807b = (C0807b) message.obj;
            synchronized (this.f1751i) {
                if (this.f1747e && this.f1744b.mo1035b() && this.f1745c.contains(c0807b)) {
                    c0807b.mo1011a(this.f1744b.mo1036s());
                }
            }
            return true;
        }
        Log.wtf("GmsClientEvents", "Don't know how to handle message: " + message.what, new Exception());
        return false;
    }
}

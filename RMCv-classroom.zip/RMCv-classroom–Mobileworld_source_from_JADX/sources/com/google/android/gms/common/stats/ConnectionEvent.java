package com.google.android.gms.common.stats;

import android.os.Parcel;
import android.os.Parcelable.Creator;

public final class ConnectionEvent extends StatsEvent {
    public static final Creator<ConnectionEvent> CREATOR = new C0928a();
    /* renamed from: a */
    final int f1785a;
    /* renamed from: b */
    private final long f1786b;
    /* renamed from: c */
    private int f1787c;
    /* renamed from: d */
    private final String f1788d;
    /* renamed from: e */
    private final String f1789e;
    /* renamed from: f */
    private final String f1790f;
    /* renamed from: g */
    private final String f1791g;
    /* renamed from: h */
    private final String f1792h;
    /* renamed from: i */
    private final String f1793i;
    /* renamed from: j */
    private final long f1794j;
    /* renamed from: k */
    private final long f1795k;
    /* renamed from: l */
    private long f1796l;

    ConnectionEvent(int i, long j, int i2, String str, String str2, String str3, String str4, String str5, String str6, long j2, long j3) {
        this.f1785a = i;
        this.f1786b = j;
        this.f1787c = i2;
        this.f1788d = str;
        this.f1789e = str2;
        this.f1790f = str3;
        this.f1791g = str4;
        this.f1796l = -1;
        this.f1792h = str5;
        this.f1793i = str6;
        this.f1794j = j2;
        this.f1795k = j3;
    }

    public ConnectionEvent(long j, int i, String str, String str2, String str3, String str4, String str5, String str6, long j2, long j3) {
        this(1, j, i, str, str2, str3, str4, str5, str6, j2, j3);
    }

    /* renamed from: a */
    public long mo974a() {
        return this.f1786b;
    }

    /* renamed from: b */
    public int mo975b() {
        return this.f1787c;
    }

    /* renamed from: c */
    public String m3787c() {
        return this.f1788d;
    }

    /* renamed from: d */
    public String m3788d() {
        return this.f1789e;
    }

    /* renamed from: e */
    public String m3789e() {
        return this.f1790f;
    }

    /* renamed from: f */
    public String m3790f() {
        return this.f1791g;
    }

    /* renamed from: g */
    public String m3791g() {
        return this.f1792h;
    }

    /* renamed from: h */
    public String m3792h() {
        return this.f1793i;
    }

    /* renamed from: i */
    public long mo976i() {
        return this.f1796l;
    }

    /* renamed from: j */
    public long m3794j() {
        return this.f1795k;
    }

    /* renamed from: k */
    public long m3795k() {
        return this.f1794j;
    }

    /* renamed from: l */
    public String mo977l() {
        String valueOf = String.valueOf("\t");
        String valueOf2 = String.valueOf(m3787c());
        String valueOf3 = String.valueOf(m3788d());
        String valueOf4 = String.valueOf("\t");
        String valueOf5 = String.valueOf(m3789e());
        String valueOf6 = String.valueOf(m3790f());
        String valueOf7 = String.valueOf("\t");
        String str = this.f1792h == null ? "" : this.f1792h;
        String valueOf8 = String.valueOf("\t");
        return new StringBuilder(((((((((String.valueOf(valueOf).length() + 22) + String.valueOf(valueOf2).length()) + String.valueOf(valueOf3).length()) + String.valueOf(valueOf4).length()) + String.valueOf(valueOf5).length()) + String.valueOf(valueOf6).length()) + String.valueOf(valueOf7).length()) + String.valueOf(str).length()) + String.valueOf(valueOf8).length()).append(valueOf).append(valueOf2).append("/").append(valueOf3).append(valueOf4).append(valueOf5).append("/").append(valueOf6).append(valueOf7).append(str).append(valueOf8).append(m3794j()).toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0928a.m3797a(this, parcel, i);
    }
}

package com.google.android.gms.common.internal;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import com.google.android.gms.common.api.C0824a.C0821h;
import com.google.android.gms.common.api.GoogleApiClient.C0807b;
import com.google.android.gms.common.api.GoogleApiClient.C0808c;

/* renamed from: com.google.android.gms.common.internal.e */
public class C0860e<T extends IInterface> extends C0859p<T> {
    /* renamed from: d */
    private final C0821h<T> f1679d;

    public C0860e(Context context, Looper looper, int i, C0807b c0807b, C0808c c0808c, C0890l c0890l, C0821h<T> c0821h) {
        super(context, looper, i, c0890l, c0807b, c0808c);
        this.f1679d = c0821h;
    }

    /* renamed from: a */
    protected T mo903a(IBinder iBinder) {
        return this.f1679d.m3309a(iBinder);
    }

    /* renamed from: a */
    protected void mo904a(int i, T t) {
        this.f1679d.m3311a(i, t);
    }

    /* renamed from: i */
    protected String mo905i() {
        return this.f1679d.m3310a();
    }

    /* renamed from: j */
    protected String mo906j() {
        return this.f1679d.m3312b();
    }

    /* renamed from: k */
    public C0821h<T> mo907k() {
        return this.f1679d;
    }
}

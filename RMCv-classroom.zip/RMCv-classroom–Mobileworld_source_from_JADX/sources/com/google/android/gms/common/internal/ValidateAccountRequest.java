package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

@Deprecated
public class ValidateAccountRequest extends AbstractSafeParcelable {
    public static final Creator<ValidateAccountRequest> CREATOR = new C0862g();
    /* renamed from: a */
    final int f1639a;
    /* renamed from: b */
    final IBinder f1640b;
    /* renamed from: c */
    private final int f1641c;
    /* renamed from: d */
    private final Scope[] f1642d;
    /* renamed from: e */
    private final Bundle f1643e;
    /* renamed from: f */
    private final String f1644f;

    ValidateAccountRequest(int i, int i2, IBinder iBinder, Scope[] scopeArr, Bundle bundle, String str) {
        this.f1639a = i;
        this.f1641c = i2;
        this.f1640b = iBinder;
        this.f1642d = scopeArr;
        this.f1643e = bundle;
        this.f1644f = str;
    }

    /* renamed from: a */
    public int m3413a() {
        return this.f1641c;
    }

    /* renamed from: b */
    public Scope[] m3414b() {
        return this.f1642d;
    }

    /* renamed from: c */
    public String m3415c() {
        return this.f1644f;
    }

    /* renamed from: d */
    public Bundle m3416d() {
        return this.f1643e;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0862g.m3500a(this, parcel, i);
    }
}

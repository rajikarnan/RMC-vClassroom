package com.google.android.gms.common;

import android.annotation.TargetApi;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller.SessionInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build;
import android.os.Bundle;
import android.os.UserManager;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.C0785a.C0781b;
import com.google.android.gms.common.C0926k.C0925d;
import com.google.android.gms.common.internal.C0877j;
import com.google.android.gms.common.p022a.C0798e;
import com.google.android.gms.common.p022a.C0799f;
import com.google.android.gms.common.p022a.C0800g;
import com.google.android.gms.common.p022a.C0804k;
import com.google.android.gms.p023d.ap;
import java.util.concurrent.atomic.AtomicBoolean;

/* renamed from: com.google.android.gms.common.l */
public class C0844l {
    /* renamed from: a */
    private static String f1602a = null;
    @Deprecated
    /* renamed from: b */
    public static final int f1603b = C0844l.m3373b();
    /* renamed from: c */
    public static boolean f1604c = false;
    /* renamed from: d */
    public static boolean f1605d = false;
    /* renamed from: e */
    static boolean f1606e = false;
    /* renamed from: f */
    static final AtomicBoolean f1607f = new AtomicBoolean();
    /* renamed from: g */
    private static int f1608g = 0;
    /* renamed from: h */
    private static boolean f1609h = false;
    /* renamed from: i */
    private static final AtomicBoolean f1610i = new AtomicBoolean();

    C0844l() {
    }

    /* renamed from: a */
    private static void m3369a(Context context) {
        if (!f1610i.get()) {
            C0844l.m3384h(context);
            if (f1608g == 0) {
                throw new IllegalStateException("A required meta-data tag in your app's AndroidManifest.xml does not exist.  You must have the following declaration within the <application> element:     <meta-data android:name=\"com.google.android.gms.version\" android:value=\"@integer/google_play_services_version\" />");
            } else if (f1608g != f1603b) {
                int i = f1603b;
                int i2 = f1608g;
                String valueOf = String.valueOf("com.google.android.gms.version");
                throw new IllegalStateException(new StringBuilder(String.valueOf(valueOf).length() + 290).append("The meta-data tag in your app's AndroidManifest.xml does not have the right value.  Expected ").append(i).append(" but found ").append(i2).append(".  You must have the following declaration within the <application> element:     <meta-data android:name=\"").append(valueOf).append("\" android:value=\"@integer/google_play_services_version\" />").toString());
            }
        }
    }

    @Deprecated
    /* renamed from: a */
    public static boolean m3370a() {
        return "user".equals(Build.TYPE);
    }

    /* renamed from: a */
    static boolean m3371a(int i) {
        switch (i) {
            case 1:
            case 2:
            case 3:
            case 18:
            case 42:
                return true;
            default:
                return false;
        }
    }

    @TargetApi(21)
    /* renamed from: a */
    static boolean m3372a(Context context, String str) {
        if (C0800g.m3249h()) {
            for (SessionInfo appPackageName : context.getPackageManager().getPackageInstaller().getAllSessions()) {
                if (str.equals(appPackageName.getAppPackageName())) {
                    return true;
                }
            }
        }
        if (C0844l.m3383g(context)) {
            return false;
        }
        try {
            return context.getPackageManager().getApplicationInfo(str, 8192).enabled;
        } catch (NameNotFoundException e) {
            return false;
        }
    }

    /* renamed from: b */
    private static int m3373b() {
        return C0877j.f1697a;
    }

    @Deprecated
    /* renamed from: b */
    public static int m3374b(Context context) {
        PackageManager packageManager = context.getPackageManager();
        try {
            context.getResources().getString(C0781b.common_google_play_services_unknown_issue);
        } catch (Throwable th) {
            Log.e("GooglePlayServicesUtil", "The Google Play services resources were not found. Check your project configuration to ensure that the resources are included.");
        }
        if (!"com.google.android.gms".equals(context.getPackageName())) {
            C0844l.m3369a(context);
        }
        try {
            PackageInfo packageInfo = packageManager.getPackageInfo("com.google.android.gms", 64);
            C0927m a = C0927m.m3777a(context);
            if (!C0798e.m3237a(context)) {
                try {
                    if (a.m3778a(packageManager.getPackageInfo("com.android.vending", 8256), C0925d.f1781a) == null) {
                        Log.w("GooglePlayServicesUtil", "Google Play Store signature invalid.");
                        return 9;
                    }
                    if (a.m3778a(packageInfo, a.m3778a(packageManager.getPackageInfo("com.android.vending", 8256), C0925d.f1781a)) == null) {
                        Log.w("GooglePlayServicesUtil", "Google Play services signature invalid.");
                        return 9;
                    }
                } catch (NameNotFoundException e) {
                    Log.w("GooglePlayServicesUtil", "Google Play Store is neither installed nor updating.");
                    return 9;
                }
            } else if (a.m3778a(packageInfo, C0925d.f1781a) == null) {
                Log.w("GooglePlayServicesUtil", "Google Play services signature invalid.");
                return 9;
            }
            if (C0799f.m3240a(packageInfo.versionCode) < C0799f.m3240a(f1603b)) {
                Log.w("GooglePlayServicesUtil", "Google Play services out of date.  Requires " + f1603b + " but found " + packageInfo.versionCode);
                return 2;
            }
            ApplicationInfo applicationInfo = packageInfo.applicationInfo;
            if (applicationInfo == null) {
                try {
                    applicationInfo = packageManager.getApplicationInfo("com.google.android.gms", 0);
                } catch (Throwable e2) {
                    Log.wtf("GooglePlayServicesUtil", "Google Play services missing when getting application info.", e2);
                    return 1;
                }
            }
            return !applicationInfo.enabled ? 3 : 0;
        } catch (NameNotFoundException e3) {
            Log.w("GooglePlayServicesUtil", "Google Play services is missing.");
            return 1;
        }
    }

    @Deprecated
    /* renamed from: b */
    public static PendingIntent m3375b(int i, Context context, int i2) {
        return C0839j.m3344b().mo892a(context, i, i2);
    }

    @Deprecated
    /* renamed from: b */
    public static boolean m3376b(int i) {
        switch (i) {
            case 1:
            case 2:
            case 3:
            case 9:
                return true;
            default:
                return false;
        }
    }

    @Deprecated
    /* renamed from: b */
    public static boolean m3377b(Context context, int i) {
        return C0804k.m3255a(context, i);
    }

    /* renamed from: c */
    public static boolean m3378c(Context context) {
        C0844l.m3384h(context);
        return f1606e;
    }

    @Deprecated
    /* renamed from: c */
    public static boolean m3379c(Context context, int i) {
        return i == 18 ? true : i == 1 ? C0844l.m3372a(context, "com.google.android.gms") : false;
    }

    /* renamed from: d */
    public static boolean m3380d(Context context) {
        return C0844l.m3378c(context) || !C0844l.m3370a();
    }

    @Deprecated
    /* renamed from: e */
    public static void m3381e(Context context) {
        if (!f1607f.getAndSet(true)) {
            try {
                ((NotificationManager) context.getSystemService("notification")).cancel(10436);
            } catch (SecurityException e) {
            }
        }
    }

    /* renamed from: f */
    public static String m3382f(Context context) {
        Object obj = context.getApplicationInfo().name;
        if (!TextUtils.isEmpty(obj)) {
            return obj;
        }
        ApplicationInfo a;
        String packageName = context.getPackageName();
        PackageManager packageManager = context.getApplicationContext().getPackageManager();
        try {
            a = ap.m3890b(context).m3887a(context.getPackageName(), 0);
        } catch (NameNotFoundException e) {
            a = null;
        }
        return a != null ? packageManager.getApplicationLabel(a).toString() : packageName;
    }

    @TargetApi(18)
    /* renamed from: g */
    public static boolean m3383g(Context context) {
        if (C0800g.m3246e()) {
            Bundle applicationRestrictions = ((UserManager) context.getSystemService("user")).getApplicationRestrictions(context.getPackageName());
            if (applicationRestrictions != null && "true".equals(applicationRestrictions.getString("restricted_profile"))) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: h */
    private static void m3384h(Context context) {
        if (!f1609h) {
            C0844l.m3385i(context);
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: i */
    private static void m3385i(android.content.Context r7) {
        /*
        r6 = 1;
        r0 = r7.getPackageName();	 Catch:{ NameNotFoundException -> 0x003a }
        f1602a = r0;	 Catch:{ NameNotFoundException -> 0x003a }
        r0 = com.google.android.gms.p023d.ap.m3890b(r7);	 Catch:{ NameNotFoundException -> 0x003a }
        r1 = com.google.android.gms.common.internal.aa.m3421a(r7);	 Catch:{ NameNotFoundException -> 0x003a }
        f1608g = r1;	 Catch:{ NameNotFoundException -> 0x003a }
        r1 = "com.google.android.gms";
        r2 = 64;
        r0 = r0.m3889b(r1, r2);	 Catch:{ NameNotFoundException -> 0x003a }
        if (r0 == 0) goto L_0x0036;
    L_0x001b:
        r1 = com.google.android.gms.common.C0927m.m3777a(r7);	 Catch:{ NameNotFoundException -> 0x003a }
        r2 = 1;
        r2 = new com.google.android.gms.common.C0926k.C0920a[r2];	 Catch:{ NameNotFoundException -> 0x003a }
        r3 = 0;
        r4 = com.google.android.gms.common.C0926k.C0925d.f1781a;	 Catch:{ NameNotFoundException -> 0x003a }
        r5 = 1;
        r4 = r4[r5];	 Catch:{ NameNotFoundException -> 0x003a }
        r2[r3] = r4;	 Catch:{ NameNotFoundException -> 0x003a }
        r0 = r1.m3778a(r0, r2);	 Catch:{ NameNotFoundException -> 0x003a }
        if (r0 == 0) goto L_0x0036;
    L_0x0030:
        r0 = 1;
        f1606e = r0;	 Catch:{ NameNotFoundException -> 0x003a }
    L_0x0033:
        f1609h = r6;
    L_0x0035:
        return;
    L_0x0036:
        r0 = 0;
        f1606e = r0;	 Catch:{ NameNotFoundException -> 0x003a }
        goto L_0x0033;
    L_0x003a:
        r0 = move-exception;
        r1 = "GooglePlayServicesUtil";
        r2 = "Cannot find Google Play services package name.";
        android.util.Log.w(r1, r2, r0);	 Catch:{ all -> 0x0045 }
        f1609h = r6;
        goto L_0x0035;
    L_0x0045:
        r0 = move-exception;
        f1609h = r6;
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.common.l.i(android.content.Context):void");
    }
}

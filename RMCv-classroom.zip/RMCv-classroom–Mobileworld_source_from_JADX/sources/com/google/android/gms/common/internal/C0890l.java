package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.content.Context;
import android.view.View;
import com.google.android.gms.common.api.C0824a;
import com.google.android.gms.common.api.GoogleApiClient.C0806a;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.p023d.as;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/* renamed from: com.google.android.gms.common.internal.l */
public final class C0890l {
    /* renamed from: a */
    private final Account f1722a;
    /* renamed from: b */
    private final Set<Scope> f1723b;
    /* renamed from: c */
    private final Set<Scope> f1724c;
    /* renamed from: d */
    private final Map<C0824a<?>, C0889a> f1725d;
    /* renamed from: e */
    private final int f1726e;
    /* renamed from: f */
    private final View f1727f;
    /* renamed from: g */
    private final String f1728g;
    /* renamed from: h */
    private final String f1729h;
    /* renamed from: i */
    private final as f1730i;
    /* renamed from: j */
    private Integer f1731j;

    /* renamed from: com.google.android.gms.common.internal.l$a */
    public static final class C0889a {
        /* renamed from: a */
        public final Set<Scope> f1720a;
        /* renamed from: b */
        public final boolean f1721b;
    }

    public C0890l(Account account, Set<Scope> set, Map<C0824a<?>, C0889a> map, int i, View view, String str, String str2, as asVar) {
        Map map2;
        this.f1722a = account;
        this.f1723b = set == null ? Collections.EMPTY_SET : Collections.unmodifiableSet(set);
        if (map == null) {
            map2 = Collections.EMPTY_MAP;
        }
        this.f1725d = map2;
        this.f1727f = view;
        this.f1726e = i;
        this.f1728g = str;
        this.f1729h = str2;
        this.f1730i = asVar;
        Set hashSet = new HashSet(this.f1723b);
        for (C0889a c0889a : this.f1725d.values()) {
            hashSet.addAll(c0889a.f1720a);
        }
        this.f1724c = Collections.unmodifiableSet(hashSet);
    }

    /* renamed from: a */
    public static C0890l m3557a(Context context) {
        return new C0806a(context).m3271a();
    }

    /* renamed from: a */
    public Account m3558a() {
        return this.f1722a;
    }

    /* renamed from: a */
    public void m3559a(Integer num) {
        this.f1731j = num;
    }

    /* renamed from: b */
    public Account m3560b() {
        return this.f1722a != null ? this.f1722a : new Account("<<default account>>", "com.google");
    }

    /* renamed from: c */
    public Set<Scope> m3561c() {
        return this.f1723b;
    }

    /* renamed from: d */
    public Set<Scope> m3562d() {
        return this.f1724c;
    }

    /* renamed from: e */
    public Map<C0824a<?>, C0889a> m3563e() {
        return this.f1725d;
    }

    /* renamed from: f */
    public String m3564f() {
        return this.f1728g;
    }

    /* renamed from: g */
    public String m3565g() {
        return this.f1729h;
    }

    /* renamed from: h */
    public as m3566h() {
        return this.f1730i;
    }

    /* renamed from: i */
    public Integer m3567i() {
        return this.f1731j;
    }
}

package com.google.android.gms.common;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Base64;
import android.util.Log;
import com.google.android.gms.common.C0926k.C0920a;
import com.google.android.gms.common.C0926k.C0921b;
import com.google.android.gms.common.C0926k.C0925d;
import com.google.android.gms.common.internal.C0854b;

/* renamed from: com.google.android.gms.common.m */
public class C0927m {
    /* renamed from: a */
    private static C0927m f1783a;
    /* renamed from: b */
    private final Context f1784b;

    private C0927m(Context context) {
        this.f1784b = context.getApplicationContext();
    }

    /* renamed from: a */
    public static C0927m m3777a(Context context) {
        C0854b.m3427a((Object) context);
        synchronized (C0927m.class) {
            if (f1783a == null) {
                C0926k.m3776a(context);
                f1783a = new C0927m(context);
            }
        }
        return f1783a;
    }

    /* renamed from: a */
    C0920a m3778a(PackageInfo packageInfo, C0920a... c0920aArr) {
        if (packageInfo.signatures == null) {
            return null;
        }
        if (packageInfo.signatures.length != 1) {
            Log.w("GoogleSignatureVerifier", "Package has more than one signature.");
            return null;
        }
        C0920a c0921b = new C0921b(packageInfo.signatures[0].toByteArray());
        for (int i = 0; i < c0920aArr.length; i++) {
            if (c0920aArr[i].equals(c0921b)) {
                return c0920aArr[i];
            }
        }
        String valueOf = String.valueOf(packageInfo.packageName);
        String valueOf2 = String.valueOf(Base64.encodeToString(c0921b.mo972c(), 0));
        Log.v("GoogleSignatureVerifier", new StringBuilder((String.valueOf(valueOf).length() + 31) + String.valueOf(valueOf2).length()).append(valueOf).append(" signature not valid.  Found: \n").append(valueOf2).toString());
        return null;
    }

    /* renamed from: a */
    public boolean m3779a(PackageInfo packageInfo, boolean z) {
        if (!(packageInfo == null || packageInfo.signatures == null)) {
            C0920a a;
            if (z) {
                a = m3778a(packageInfo, C0925d.f1781a);
            } else {
                a = m3778a(packageInfo, C0925d.f1781a[0]);
            }
            if (a != null) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: a */
    public boolean m3780a(PackageManager packageManager, PackageInfo packageInfo) {
        if (packageInfo == null) {
            return false;
        }
        if (C0844l.m3380d(this.f1784b)) {
            return m3779a(packageInfo, true);
        }
        boolean a = m3779a(packageInfo, false);
        if (a || !m3779a(packageInfo, true)) {
            return a;
        }
        Log.w("GoogleSignatureVerifier", "Test-keys aren't accepted on this build.");
        return a;
    }
}

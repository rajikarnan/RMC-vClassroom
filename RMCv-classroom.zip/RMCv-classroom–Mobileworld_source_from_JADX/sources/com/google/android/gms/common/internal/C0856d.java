package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;

/* renamed from: com.google.android.gms.common.internal.d */
public class C0856d implements Creator<ResolveAccountResponse> {
    /* renamed from: a */
    static void m3440a(ResolveAccountResponse resolveAccountResponse, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3646a(parcel, 1, resolveAccountResponse.f1634a);
        C0907b.m3649a(parcel, 2, resolveAccountResponse.f1635b, false);
        C0907b.m3650a(parcel, 3, resolveAccountResponse.m3410b(), i, false);
        C0907b.m3655a(parcel, 4, resolveAccountResponse.m3411c());
        C0907b.m3655a(parcel, 5, resolveAccountResponse.m3412d());
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public ResolveAccountResponse m3441a(Parcel parcel) {
        ConnectionResult connectionResult = null;
        boolean z = false;
        int b = C0906a.m3626b(parcel);
        boolean z2 = false;
        IBinder iBinder = null;
        int i = 0;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    i = C0906a.m3632e(parcel, a);
                    break;
                case 2:
                    iBinder = C0906a.m3638k(parcel, a);
                    break;
                case 3:
                    connectionResult = (ConnectionResult) C0906a.m3623a(parcel, a, ConnectionResult.CREATOR);
                    break;
                case 4:
                    z2 = C0906a.m3630c(parcel, a);
                    break;
                case 5:
                    z = C0906a.m3630c(parcel, a);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new ResolveAccountResponse(i, iBinder, connectionResult, z2, z);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public ResolveAccountResponse[] m3442a(int i) {
        return new ResolveAccountResponse[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m3441a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m3442a(i);
    }
}

package com.google.android.gms.common;

import android.annotation.TargetApi;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.FragmentManager;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.os.Bundle;
import com.google.android.gms.common.internal.C0854b;

@TargetApi(11)
/* renamed from: com.google.android.gms.common.a */
public class C0805a extends DialogFragment {
    /* renamed from: a */
    private Dialog f1544a = null;
    /* renamed from: b */
    private OnCancelListener f1545b = null;

    /* renamed from: a */
    public static C0805a m3257a(Dialog dialog, OnCancelListener onCancelListener) {
        C0805a c0805a = new C0805a();
        Dialog dialog2 = (Dialog) C0854b.m3428a((Object) dialog, (Object) "Cannot display null dialog");
        dialog2.setOnCancelListener(null);
        dialog2.setOnDismissListener(null);
        c0805a.f1544a = dialog2;
        if (onCancelListener != null) {
            c0805a.f1545b = onCancelListener;
        }
        return c0805a;
    }

    public void onCancel(DialogInterface dialogInterface) {
        if (this.f1545b != null) {
            this.f1545b.onCancel(dialogInterface);
        }
    }

    public Dialog onCreateDialog(Bundle bundle) {
        if (this.f1544a == null) {
            setShowsDialog(false);
        }
        return this.f1544a;
    }

    public void show(FragmentManager fragmentManager, String str) {
        super.show(fragmentManager, str);
    }
}

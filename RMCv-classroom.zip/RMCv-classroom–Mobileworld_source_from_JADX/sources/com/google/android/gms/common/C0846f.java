package com.google.android.gms.common;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.os.Bundle;
import android.support.v4.app.C0149p;
import android.support.v4.app.C0157u;
import com.google.android.gms.common.internal.C0854b;

/* renamed from: com.google.android.gms.common.f */
public class C0846f extends C0149p {
    /* renamed from: a */
    private Dialog f1612a = null;
    /* renamed from: b */
    private OnCancelListener f1613b = null;

    /* renamed from: a */
    public static C0846f m3395a(Dialog dialog, OnCancelListener onCancelListener) {
        C0846f c0846f = new C0846f();
        Dialog dialog2 = (Dialog) C0854b.m3428a((Object) dialog, (Object) "Cannot display null dialog");
        dialog2.setOnCancelListener(null);
        dialog2.setOnDismissListener(null);
        c0846f.f1612a = dialog2;
        if (onCancelListener != null) {
            c0846f.f1613b = onCancelListener;
        }
        return c0846f;
    }

    public void onCancel(DialogInterface dialogInterface) {
        if (this.f1613b != null) {
            this.f1613b.onCancel(dialogInterface);
        }
    }

    public Dialog onCreateDialog(Bundle bundle) {
        if (this.f1612a == null) {
            setShowsDialog(false);
        }
        return this.f1612a;
    }

    public void show(C0157u c0157u, String str) {
        super.show(c0157u, str);
    }
}

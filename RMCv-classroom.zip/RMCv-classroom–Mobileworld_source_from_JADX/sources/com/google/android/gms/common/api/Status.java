package com.google.android.gms.common.api;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public final class Status extends AbstractSafeParcelable implements C0809e {
    public static final Creator<Status> CREATOR = new C0838o();
    /* renamed from: a */
    public static final Status f1568a = new Status(0);
    /* renamed from: b */
    public static final Status f1569b = new Status(14);
    /* renamed from: c */
    public static final Status f1570c = new Status(8);
    /* renamed from: d */
    public static final Status f1571d = new Status(15);
    /* renamed from: e */
    public static final Status f1572e = new Status(16);
    /* renamed from: f */
    public static final Status f1573f = new Status(17);
    /* renamed from: g */
    private final int f1574g;
    /* renamed from: h */
    private final int f1575h;
    /* renamed from: i */
    private final String f1576i;
    /* renamed from: j */
    private final PendingIntent f1577j;

    public Status(int i) {
        this(i, null);
    }

    Status(int i, int i2, String str, PendingIntent pendingIntent) {
        this.f1574g = i;
        this.f1575h = i2;
        this.f1576i = str;
        this.f1577j = pendingIntent;
    }

    public Status(int i, String str) {
        this(1, i, str, null);
    }

    public Status(int i, String str, PendingIntent pendingIntent) {
        this(1, i, str, pendingIntent);
    }

    /* renamed from: g */
    private String m3288g() {
        return this.f1576i != null ? this.f1576i : C0825b.m3321a(this.f1575h);
    }

    /* renamed from: a */
    public Status mo890a() {
        return this;
    }

    /* renamed from: b */
    PendingIntent m3290b() {
        return this.f1577j;
    }

    /* renamed from: c */
    public String m3291c() {
        return this.f1576i;
    }

    /* renamed from: d */
    int m3292d() {
        return this.f1574g;
    }

    /* renamed from: e */
    public boolean m3293e() {
        return this.f1575h <= 0;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof Status)) {
            return false;
        }
        Status status = (Status) obj;
        return this.f1574g == status.f1574g && this.f1575h == status.f1575h && ab.m3426a(this.f1576i, status.f1576i) && ab.m3426a(this.f1577j, status.f1577j);
    }

    /* renamed from: f */
    public int m3294f() {
        return this.f1575h;
    }

    public int hashCode() {
        return ab.m3424a(Integer.valueOf(this.f1574g), Integer.valueOf(this.f1575h), this.f1576i, this.f1577j);
    }

    public String toString() {
        return ab.m3425a((Object) this).m3423a("statusCode", m3288g()).m3423a("resolution", this.f1577j).toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0838o.m3341a(this, parcel, i);
    }
}

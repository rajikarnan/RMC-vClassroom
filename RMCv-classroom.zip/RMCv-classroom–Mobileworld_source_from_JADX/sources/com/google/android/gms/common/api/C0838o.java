package com.google.android.gms.common.api;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;

/* renamed from: com.google.android.gms.common.api.o */
public class C0838o implements Creator<Status> {
    /* renamed from: a */
    static void m3341a(Status status, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3646a(parcel, 1, status.m3294f());
        C0907b.m3652a(parcel, 2, status.m3291c(), false);
        C0907b.m3650a(parcel, 3, status.m3290b(), i, false);
        C0907b.m3646a(parcel, 1000, status.m3292d());
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public Status m3342a(Parcel parcel) {
        PendingIntent pendingIntent = null;
        int i = 0;
        int b = C0906a.m3626b(parcel);
        String str = null;
        int i2 = 0;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    i = C0906a.m3632e(parcel, a);
                    break;
                case 2:
                    str = C0906a.m3637j(parcel, a);
                    break;
                case 3:
                    pendingIntent = (PendingIntent) C0906a.m3623a(parcel, a, PendingIntent.CREATOR);
                    break;
                case 1000:
                    i2 = C0906a.m3632e(parcel, a);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new Status(i2, i, str, pendingIntent);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public Status[] m3343a(int i) {
        return new Status[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m3342a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m3343a(i);
    }
}

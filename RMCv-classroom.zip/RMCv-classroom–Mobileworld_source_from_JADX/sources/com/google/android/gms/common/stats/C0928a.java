package com.google.android.gms.common.stats;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;

/* renamed from: com.google.android.gms.common.stats.a */
public class C0928a implements Creator<ConnectionEvent> {
    /* renamed from: a */
    static void m3797a(ConnectionEvent connectionEvent, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3646a(parcel, 1, connectionEvent.f1785a);
        C0907b.m3647a(parcel, 2, connectionEvent.mo974a());
        C0907b.m3652a(parcel, 4, connectionEvent.m3787c(), false);
        C0907b.m3652a(parcel, 5, connectionEvent.m3788d(), false);
        C0907b.m3652a(parcel, 6, connectionEvent.m3789e(), false);
        C0907b.m3652a(parcel, 7, connectionEvent.m3790f(), false);
        C0907b.m3652a(parcel, 8, connectionEvent.m3791g(), false);
        C0907b.m3647a(parcel, 10, connectionEvent.m3795k());
        C0907b.m3647a(parcel, 11, connectionEvent.m3794j());
        C0907b.m3646a(parcel, 12, connectionEvent.mo975b());
        C0907b.m3652a(parcel, 13, connectionEvent.m3792h(), false);
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public ConnectionEvent m3798a(Parcel parcel) {
        int b = C0906a.m3626b(parcel);
        int i = 0;
        long j = 0;
        int i2 = 0;
        String str = null;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        String str5 = null;
        String str6 = null;
        long j2 = 0;
        long j3 = 0;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    i = C0906a.m3632e(parcel, a);
                    break;
                case 2:
                    j = C0906a.m3634g(parcel, a);
                    break;
                case 4:
                    str = C0906a.m3637j(parcel, a);
                    break;
                case 5:
                    str2 = C0906a.m3637j(parcel, a);
                    break;
                case 6:
                    str3 = C0906a.m3637j(parcel, a);
                    break;
                case 7:
                    str4 = C0906a.m3637j(parcel, a);
                    break;
                case 8:
                    str5 = C0906a.m3637j(parcel, a);
                    break;
                case 10:
                    j2 = C0906a.m3634g(parcel, a);
                    break;
                case 11:
                    j3 = C0906a.m3634g(parcel, a);
                    break;
                case 12:
                    i2 = C0906a.m3632e(parcel, a);
                    break;
                case 13:
                    str6 = C0906a.m3637j(parcel, a);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new ConnectionEvent(i, j, i2, str, str2, str3, str4, str5, str6, j2, j3);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public ConnectionEvent[] m3799a(int i) {
        return new ConnectionEvent[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m3798a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m3799a(i);
    }
}

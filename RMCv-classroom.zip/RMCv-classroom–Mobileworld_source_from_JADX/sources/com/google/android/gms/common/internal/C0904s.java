package com.google.android.gms.common.internal;

import android.annotation.TargetApi;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.IBinder;
import android.os.Message;
import com.google.android.gms.common.stats.C0929b;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

/* renamed from: com.google.android.gms.common.internal.s */
final class C0904s extends C0900r implements Callback {
    /* renamed from: a */
    private final HashMap<C0901a, C0903b> f1766a = new HashMap();
    /* renamed from: b */
    private final Context f1767b;
    /* renamed from: c */
    private final Handler f1768c;
    /* renamed from: d */
    private final C0929b f1769d;
    /* renamed from: e */
    private final long f1770e;

    /* renamed from: com.google.android.gms.common.internal.s$a */
    private static final class C0901a {
        /* renamed from: a */
        private final String f1754a;
        /* renamed from: b */
        private final String f1755b;
        /* renamed from: c */
        private final ComponentName f1756c = null;

        public C0901a(String str, String str2) {
            this.f1754a = C0854b.m3429a(str);
            this.f1755b = C0854b.m3429a(str2);
        }

        /* renamed from: a */
        public Intent m3597a() {
            return this.f1754a != null ? new Intent(this.f1754a).setPackage(this.f1755b) : new Intent().setComponent(this.f1756c);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof C0901a)) {
                return false;
            }
            C0901a c0901a = (C0901a) obj;
            return ab.m3426a(this.f1754a, c0901a.f1754a) && ab.m3426a(this.f1756c, c0901a.f1756c);
        }

        public int hashCode() {
            return ab.m3424a(this.f1754a, this.f1756c);
        }

        public String toString() {
            return this.f1754a == null ? this.f1756c.flattenToString() : this.f1754a;
        }
    }

    /* renamed from: com.google.android.gms.common.internal.s$b */
    private final class C0903b {
        /* renamed from: a */
        final /* synthetic */ C0904s f1758a;
        /* renamed from: b */
        private final C0902a f1759b = new C0902a(this);
        /* renamed from: c */
        private final Set<ServiceConnection> f1760c = new HashSet();
        /* renamed from: d */
        private int f1761d = 2;
        /* renamed from: e */
        private boolean f1762e;
        /* renamed from: f */
        private IBinder f1763f;
        /* renamed from: g */
        private final C0901a f1764g;
        /* renamed from: h */
        private ComponentName f1765h;

        /* renamed from: com.google.android.gms.common.internal.s$b$a */
        public class C0902a implements ServiceConnection {
            /* renamed from: a */
            final /* synthetic */ C0903b f1757a;

            public C0902a(C0903b c0903b) {
                this.f1757a = c0903b;
            }

            public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
                synchronized (this.f1757a.f1758a.f1766a) {
                    this.f1757a.f1763f = iBinder;
                    this.f1757a.f1765h = componentName;
                    for (ServiceConnection onServiceConnected : this.f1757a.f1760c) {
                        onServiceConnected.onServiceConnected(componentName, iBinder);
                    }
                    this.f1757a.f1761d = 1;
                }
            }

            public void onServiceDisconnected(ComponentName componentName) {
                synchronized (this.f1757a.f1758a.f1766a) {
                    this.f1757a.f1763f = null;
                    this.f1757a.f1765h = componentName;
                    for (ServiceConnection onServiceDisconnected : this.f1757a.f1760c) {
                        onServiceDisconnected.onServiceDisconnected(componentName);
                    }
                    this.f1757a.f1761d = 2;
                }
            }
        }

        public C0903b(C0904s c0904s, C0901a c0901a) {
            this.f1758a = c0904s;
            this.f1764g = c0901a;
        }

        /* renamed from: a */
        public void m3603a(ServiceConnection serviceConnection, String str) {
            this.f1758a.f1769d.m3812a(this.f1758a.f1767b, serviceConnection, str, this.f1764g.m3597a());
            this.f1760c.add(serviceConnection);
        }

        @TargetApi(14)
        /* renamed from: a */
        public void m3604a(String str) {
            this.f1761d = 3;
            this.f1762e = this.f1758a.f1769d.m3814a(this.f1758a.f1767b, str, this.f1764g.m3597a(), this.f1759b, 129);
            if (!this.f1762e) {
                this.f1761d = 2;
                try {
                    this.f1758a.f1769d.m3811a(this.f1758a.f1767b, this.f1759b);
                } catch (IllegalArgumentException e) {
                }
            }
        }

        /* renamed from: a */
        public boolean m3605a() {
            return this.f1762e;
        }

        /* renamed from: a */
        public boolean m3606a(ServiceConnection serviceConnection) {
            return this.f1760c.contains(serviceConnection);
        }

        /* renamed from: b */
        public int m3607b() {
            return this.f1761d;
        }

        /* renamed from: b */
        public void m3608b(ServiceConnection serviceConnection, String str) {
            this.f1758a.f1769d.m3815b(this.f1758a.f1767b, serviceConnection);
            this.f1760c.remove(serviceConnection);
        }

        /* renamed from: b */
        public void m3609b(String str) {
            this.f1758a.f1769d.m3811a(this.f1758a.f1767b, this.f1759b);
            this.f1762e = false;
            this.f1761d = 2;
        }

        /* renamed from: c */
        public boolean m3610c() {
            return this.f1760c.isEmpty();
        }

        /* renamed from: d */
        public IBinder m3611d() {
            return this.f1763f;
        }

        /* renamed from: e */
        public ComponentName m3612e() {
            return this.f1765h;
        }
    }

    C0904s(Context context) {
        this.f1767b = context.getApplicationContext();
        this.f1768c = new Handler(context.getMainLooper(), this);
        this.f1769d = C0929b.m3800a();
        this.f1770e = 5000;
    }

    /* renamed from: a */
    private boolean m3614a(C0901a c0901a, ServiceConnection serviceConnection, String str) {
        boolean a;
        C0854b.m3428a((Object) serviceConnection, (Object) "ServiceConnection must not be null");
        synchronized (this.f1766a) {
            C0903b c0903b = (C0903b) this.f1766a.get(c0901a);
            if (c0903b != null) {
                this.f1768c.removeMessages(0, c0903b);
                if (!c0903b.m3606a(serviceConnection)) {
                    c0903b.m3603a(serviceConnection, str);
                    switch (c0903b.m3607b()) {
                        case 1:
                            serviceConnection.onServiceConnected(c0903b.m3612e(), c0903b.m3611d());
                            break;
                        case 2:
                            c0903b.m3604a(str);
                            break;
                        default:
                            break;
                    }
                }
                String valueOf = String.valueOf(c0901a);
                throw new IllegalStateException(new StringBuilder(String.valueOf(valueOf).length() + 81).append("Trying to bind a GmsServiceConnection that was already connected before.  config=").append(valueOf).toString());
            }
            c0903b = new C0903b(this, c0901a);
            c0903b.m3603a(serviceConnection, str);
            c0903b.m3604a(str);
            this.f1766a.put(c0901a, c0903b);
            a = c0903b.m3605a();
        }
        return a;
    }

    /* renamed from: b */
    private void m3616b(C0901a c0901a, ServiceConnection serviceConnection, String str) {
        C0854b.m3428a((Object) serviceConnection, (Object) "ServiceConnection must not be null");
        synchronized (this.f1766a) {
            C0903b c0903b = (C0903b) this.f1766a.get(c0901a);
            String valueOf;
            if (c0903b == null) {
                valueOf = String.valueOf(c0901a);
                throw new IllegalStateException(new StringBuilder(String.valueOf(valueOf).length() + 50).append("Nonexistent connection status for service config: ").append(valueOf).toString());
            } else if (c0903b.m3606a(serviceConnection)) {
                c0903b.m3608b(serviceConnection, str);
                if (c0903b.m3610c()) {
                    this.f1768c.sendMessageDelayed(this.f1768c.obtainMessage(0, c0903b), this.f1770e);
                }
            } else {
                valueOf = String.valueOf(c0901a);
                throw new IllegalStateException(new StringBuilder(String.valueOf(valueOf).length() + 76).append("Trying to unbind a GmsServiceConnection  that was not bound before.  config=").append(valueOf).toString());
            }
        }
    }

    /* renamed from: a */
    public boolean mo922a(String str, String str2, ServiceConnection serviceConnection, String str3) {
        return m3614a(new C0901a(str, str2), serviceConnection, str3);
    }

    /* renamed from: b */
    public void mo923b(String str, String str2, ServiceConnection serviceConnection, String str3) {
        m3616b(new C0901a(str, str2), serviceConnection, str3);
    }

    public boolean handleMessage(Message message) {
        switch (message.what) {
            case 0:
                C0903b c0903b = (C0903b) message.obj;
                synchronized (this.f1766a) {
                    if (c0903b.m3610c()) {
                        if (c0903b.m3605a()) {
                            c0903b.m3609b("GmsClientSupervisor");
                        }
                        this.f1766a.remove(c0903b.f1764g);
                    }
                }
                return true;
            default:
                return false;
        }
    }
}

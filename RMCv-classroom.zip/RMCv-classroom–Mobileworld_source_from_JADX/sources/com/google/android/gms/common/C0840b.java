package com.google.android.gms.common;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.view.View;
import android.widget.ProgressBar;
import com.google.android.gms.C0785a.C0781b;
import com.google.android.gms.common.api.GoogleApiActivity;
import com.google.android.gms.common.internal.C0892n;
import com.google.android.gms.common.p022a.C0798e;
import com.google.android.gms.p023d.C1013v;
import com.google.android.gms.p023d.C1013v.C0967a;
import com.google.android.gms.p023d.aa;

/* renamed from: com.google.android.gms.common.b */
public class C0840b extends C0839j {
    /* renamed from: a */
    public static final int f1599a = C0839j.f1598b;
    /* renamed from: c */
    private static final C0840b f1600c = new C0840b();

    C0840b() {
    }

    /* renamed from: a */
    public static C0840b m3355a() {
        return f1600c;
    }

    /* renamed from: a */
    public int mo891a(Context context) {
        return super.mo891a(context);
    }

    /* renamed from: a */
    public Dialog m3357a(Activity activity, OnCancelListener onCancelListener) {
        View progressBar = new ProgressBar(activity, null, 16842874);
        progressBar.setIndeterminate(true);
        progressBar.setVisibility(0);
        Builder builder = new Builder(activity);
        builder.setView(progressBar);
        String f = C0844l.m3382f(activity);
        builder.setMessage(activity.getResources().getString(C0781b.common_google_play_services_updating_text, new Object[]{f}));
        builder.setTitle(C0781b.common_google_play_services_updating_title);
        builder.setPositiveButton("", null);
        Dialog create = builder.create();
        C0845e.m3391a(activity, onCancelListener, "GooglePlayServicesUpdatingDialog", create);
        return create;
    }

    /* renamed from: a */
    public PendingIntent mo892a(Context context, int i, int i2) {
        return super.mo892a(context, i, i2);
    }

    /* renamed from: a */
    public PendingIntent mo893a(Context context, int i, int i2, String str) {
        return super.mo893a(context, i, i2, str);
    }

    /* renamed from: a */
    public PendingIntent m3360a(Context context, ConnectionResult connectionResult) {
        if (connectionResult.m3226a()) {
            return connectionResult.m3229d();
        }
        int c = connectionResult.m3228c();
        if (C0798e.m3237a(context) && c == 2) {
            c = 42;
        }
        return mo892a(context, c, 0);
    }

    /* renamed from: a */
    public Intent mo894a(Context context, int i, String str) {
        return super.mo894a(context, i, str);
    }

    /* renamed from: a */
    public C1013v m3362a(Context context, C0967a c0967a) {
        IntentFilter intentFilter = new IntentFilter("android.intent.action.PACKAGE_ADDED");
        intentFilter.addDataScheme("package");
        BroadcastReceiver c1013v = new C1013v(c0967a);
        context.registerReceiver(c1013v, intentFilter);
        c1013v.m4243a(context);
        if (m3352a(context, "com.google.android.gms")) {
            return c1013v;
        }
        c0967a.mo1009a();
        c1013v.m4242a();
        return null;
    }

    /* renamed from: a */
    public void m3363a(Context context, ConnectionResult connectionResult, int i) {
        PendingIntent a = m3360a(context, connectionResult);
        if (a != null) {
            C0845e.m3389a(connectionResult.m3228c(), context, GoogleApiActivity.m3258a(context, a, i));
        }
    }

    /* renamed from: a */
    public final boolean mo895a(int i) {
        return super.mo895a(i);
    }

    /* renamed from: a */
    public boolean m3365a(Activity activity, int i, int i2, OnCancelListener onCancelListener) {
        return C0845e.m3392a(i, activity, i2, onCancelListener);
    }

    /* renamed from: a */
    public boolean m3366a(Activity activity, aa aaVar, int i, int i2, OnCancelListener onCancelListener) {
        Dialog a = C0845e.m3387a(i, activity, C0892n.m3575a(aaVar, mo894a((Context) activity, i, "d"), i2), onCancelListener);
        if (a == null) {
            return false;
        }
        C0845e.m3391a(activity, onCancelListener, "GooglePlayServicesErrorDialog", a);
        return true;
    }

    /* renamed from: a */
    public boolean mo896a(Context context, int i) {
        return super.mo896a(context, i);
    }

    @Deprecated
    /* renamed from: b */
    public Intent mo897b(int i) {
        return super.mo897b(i);
    }
}

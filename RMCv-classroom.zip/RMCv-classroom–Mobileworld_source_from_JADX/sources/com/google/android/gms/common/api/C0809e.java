package com.google.android.gms.common.api;

/* renamed from: com.google.android.gms.common.api.e */
public interface C0809e {
    /* renamed from: a */
    Status mo890a();
}

package com.google.android.gms.common;

/* renamed from: com.google.android.gms.common.g */
public class C0842g extends Exception {
}

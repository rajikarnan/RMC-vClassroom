package com.google.android.gms.common;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.text.TextUtils;
import com.google.android.gms.common.internal.C0908t;
import com.google.android.gms.common.p022a.C0798e;

/* renamed from: com.google.android.gms.common.j */
public class C0839j {
    /* renamed from: a */
    private static final C0839j f1597a = new C0839j();
    /* renamed from: b */
    public static final int f1598b = C0844l.f1603b;

    C0839j() {
    }

    /* renamed from: b */
    public static C0839j m3344b() {
        return f1597a;
    }

    /* renamed from: b */
    private String m3345b(Context context, String str) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("gcore_");
        stringBuilder.append(f1598b);
        stringBuilder.append("-");
        if (!TextUtils.isEmpty(str)) {
            stringBuilder.append(str);
        }
        stringBuilder.append("-");
        if (context != null) {
            stringBuilder.append(context.getPackageName());
        }
        stringBuilder.append("-");
        if (context != null) {
            try {
                stringBuilder.append(context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode);
            } catch (NameNotFoundException e) {
            }
        }
        return stringBuilder.toString();
    }

    /* renamed from: a */
    public int mo891a(Context context) {
        int b = C0844l.m3374b(context);
        return C0844l.m3379c(context, b) ? 18 : b;
    }

    /* renamed from: a */
    public PendingIntent mo892a(Context context, int i, int i2) {
        return mo893a(context, i, i2, null);
    }

    /* renamed from: a */
    public PendingIntent mo893a(Context context, int i, int i2, String str) {
        if (C0798e.m3237a(context) && i == 2) {
            i = 42;
        }
        Intent a = mo894a(context, i, str);
        return a == null ? null : PendingIntent.getActivity(context, i2, a, 268435456);
    }

    /* renamed from: a */
    public Intent mo894a(Context context, int i, String str) {
        switch (i) {
            case 1:
            case 2:
                return C0908t.m3665a("com.google.android.gms", m3345b(context, str));
            case 3:
                return C0908t.m3664a("com.google.android.gms");
            case 42:
                return C0908t.m3663a();
            default:
                return null;
        }
    }

    /* renamed from: a */
    public boolean mo895a(int i) {
        return C0844l.m3376b(i);
    }

    /* renamed from: a */
    public boolean mo896a(Context context, int i) {
        return C0844l.m3379c(context, i);
    }

    /* renamed from: a */
    public boolean m3352a(Context context, String str) {
        return C0844l.m3372a(context, str);
    }

    @Deprecated
    /* renamed from: b */
    public Intent mo897b(int i) {
        return mo894a(null, i, null);
    }

    /* renamed from: b */
    public void m3354b(Context context) {
        C0844l.m3381e(context);
    }
}

package com.google.android.gms.common.api;

/* renamed from: com.google.android.gms.common.api.d */
public interface C0828d {
    /* renamed from: a */
    void m3325a();
}

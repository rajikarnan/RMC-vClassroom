package com.google.android.gms.common.stats;

import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Debug;
import android.os.Parcelable;
import android.os.Process;
import android.os.SystemClock;
import android.support.v4.app.ag;
import android.util.Log;
import com.google.android.gms.common.p022a.C0795b;
import com.google.android.gms.common.p022a.C0801h;
import com.google.android.gms.common.stats.C0931c.C0930a;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/* renamed from: com.google.android.gms.common.stats.b */
public class C0929b {
    /* renamed from: a */
    private static final Object f1797a = new Object();
    /* renamed from: b */
    private static C0929b f1798b;
    /* renamed from: h */
    private static Integer f1799h;
    /* renamed from: c */
    private final List<String> f1800c;
    /* renamed from: d */
    private final List<String> f1801d;
    /* renamed from: e */
    private final List<String> f1802e;
    /* renamed from: f */
    private final List<String> f1803f;
    /* renamed from: g */
    private C0933e f1804g;
    /* renamed from: i */
    private C0933e f1805i;

    private C0929b() {
        if (C0929b.m3810c() == C0932d.f1815b) {
            this.f1800c = Collections.EMPTY_LIST;
            this.f1801d = Collections.EMPTY_LIST;
            this.f1802e = Collections.EMPTY_LIST;
            this.f1803f = Collections.EMPTY_LIST;
            return;
        }
        String str = (String) C0930a.f1807b.m3876a();
        this.f1800c = str == null ? Collections.EMPTY_LIST : Arrays.asList(str.split(","));
        str = (String) C0930a.f1808c.m3876a();
        this.f1801d = str == null ? Collections.EMPTY_LIST : Arrays.asList(str.split(","));
        str = (String) C0930a.f1809d.m3876a();
        this.f1802e = str == null ? Collections.EMPTY_LIST : Arrays.asList(str.split(","));
        str = (String) C0930a.f1810e.m3876a();
        this.f1803f = str == null ? Collections.EMPTY_LIST : Arrays.asList(str.split(","));
        this.f1804g = new C0933e(1024, ((Long) C0930a.f1811f.m3876a()).longValue());
        this.f1805i = new C0933e(1024, ((Long) C0930a.f1811f.m3876a()).longValue());
    }

    /* renamed from: a */
    public static C0929b m3800a() {
        synchronized (f1797a) {
            if (f1798b == null) {
                f1798b = new C0929b();
            }
        }
        return f1798b;
    }

    /* renamed from: a */
    private static String m3801a(int i, int i2) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StringBuffer stringBuffer = new StringBuffer();
        int i3 = i2 + i;
        while (i < i3) {
            stringBuffer.append(C0929b.m3803a(stackTrace, i)).append(" ");
            i++;
        }
        return stringBuffer.toString();
    }

    /* renamed from: a */
    private String m3802a(ServiceConnection serviceConnection) {
        return String.valueOf((((long) Process.myPid()) << 32) | ((long) System.identityHashCode(serviceConnection)));
    }

    /* renamed from: a */
    private static String m3803a(StackTraceElement[] stackTraceElementArr, int i) {
        if (i + 4 >= stackTraceElementArr.length) {
            return "<bottom of call stack>";
        }
        StackTraceElement stackTraceElement = stackTraceElementArr[i + 4];
        String valueOf = String.valueOf(stackTraceElement.getClassName());
        String valueOf2 = String.valueOf(stackTraceElement.getMethodName());
        return new StringBuilder((String.valueOf(valueOf).length() + 13) + String.valueOf(valueOf2).length()).append(valueOf).append(".").append(valueOf2).append(":").append(stackTraceElement.getLineNumber()).toString();
    }

    /* renamed from: a */
    private void m3804a(Context context, String str, int i, String str2, String str3, String str4, String str5) {
        Parcelable connectionEvent;
        long currentTimeMillis = System.currentTimeMillis();
        String str6 = null;
        if (!((C0929b.m3810c() & C0932d.f1819f) == 0 || i == 13)) {
            str6 = C0929b.m3801a(3, 5);
        }
        long j = 0;
        if ((C0929b.m3810c() & C0932d.f1821h) != 0) {
            j = Debug.getNativeHeapAllocatedSize();
        }
        if (i == 1 || i == 4 || i == 14) {
            connectionEvent = new ConnectionEvent(currentTimeMillis, i, null, null, null, null, str6, str, SystemClock.elapsedRealtime(), j);
        } else {
            connectionEvent = new ConnectionEvent(currentTimeMillis, i, str2, str3, str4, str5, str6, str, SystemClock.elapsedRealtime(), j);
        }
        context.startService(new Intent().setComponent(C0932d.f1814a).putExtra("com.google.android.gms.common.stats.EXTRA_LOG_EVENT", connectionEvent));
    }

    /* renamed from: a */
    private void m3805a(Context context, String str, String str2, Intent intent, int i) {
        String str3 = null;
        if (m3809b() && this.f1804g != null) {
            String str4;
            String str5;
            if (i != 4 && i != 1) {
                ServiceInfo b = C0929b.m3808b(context, intent);
                if (b == null) {
                    Log.w("ConnectionTracker", String.format("Client %s made an invalid request %s", new Object[]{str2, intent.toUri(0)}));
                    return;
                }
                str4 = b.processName;
                str5 = b.name;
                str3 = C0801h.m3250a();
                if (m3807a(str3, str2, str4, str5)) {
                    this.f1804g.m3817a(str);
                } else {
                    return;
                }
            } else if (this.f1804g.m3818b(str)) {
                str5 = null;
                str4 = null;
            } else {
                return;
            }
            m3804a(context, str, i, str3, str2, str4, str5);
        }
    }

    /* renamed from: a */
    private boolean m3806a(Context context, Intent intent) {
        ComponentName component = intent.getComponent();
        return component != null ? C0795b.m3233a(context, component.getPackageName()) : false;
    }

    /* renamed from: a */
    private boolean m3807a(String str, String str2, String str3, String str4) {
        return (this.f1800c.contains(str) || this.f1801d.contains(str2) || this.f1802e.contains(str3) || this.f1803f.contains(str4) || (str3.equals(str) && (C0929b.m3810c() & C0932d.f1820g) != 0)) ? false : true;
    }

    /* renamed from: b */
    private static ServiceInfo m3808b(Context context, Intent intent) {
        List<ResolveInfo> queryIntentServices = context.getPackageManager().queryIntentServices(intent, ag.FLAG_HIGH_PRIORITY);
        if (queryIntentServices == null || queryIntentServices.size() == 0) {
            Log.w("ConnectionTracker", String.format("There are no handler of this intent: %s\n Stack trace: %s", new Object[]{intent.toUri(0), C0929b.m3801a(3, 20)}));
            return null;
        } else if (queryIntentServices.size() <= 1) {
            return ((ResolveInfo) queryIntentServices.get(0)).serviceInfo;
        } else {
            Log.w("ConnectionTracker", String.format("Multiple handlers found for this intent: %s\n Stack trace: %s", new Object[]{intent.toUri(0), C0929b.m3801a(3, 20)}));
            for (ResolveInfo resolveInfo : queryIntentServices) {
                Log.w("ConnectionTracker", resolveInfo.serviceInfo.name);
            }
            return null;
        }
    }

    /* renamed from: b */
    private boolean m3809b() {
        return false;
    }

    /* renamed from: c */
    private static int m3810c() {
        if (f1799h == null) {
            try {
                f1799h = Integer.valueOf(C0795b.m3232a() ? ((Integer) C0930a.f1806a.m3876a()).intValue() : C0932d.f1815b);
            } catch (SecurityException e) {
                f1799h = Integer.valueOf(C0932d.f1815b);
            }
        }
        return f1799h.intValue();
    }

    @SuppressLint({"UntrackedBindService"})
    /* renamed from: a */
    public void m3811a(Context context, ServiceConnection serviceConnection) {
        context.unbindService(serviceConnection);
        m3805a(context, m3802a(serviceConnection), null, null, 1);
    }

    /* renamed from: a */
    public void m3812a(Context context, ServiceConnection serviceConnection, String str, Intent intent) {
        m3805a(context, m3802a(serviceConnection), str, intent, 3);
    }

    /* renamed from: a */
    public boolean m3813a(Context context, Intent intent, ServiceConnection serviceConnection, int i) {
        return m3814a(context, context.getClass().getName(), intent, serviceConnection, i);
    }

    @SuppressLint({"UntrackedBindService"})
    /* renamed from: a */
    public boolean m3814a(Context context, String str, Intent intent, ServiceConnection serviceConnection, int i) {
        if (m3806a(context, intent)) {
            Log.w("ConnectionTracker", "Attempted to bind to a service in a STOPPED package.");
            return false;
        }
        boolean bindService = context.bindService(intent, serviceConnection, i);
        if (bindService) {
            m3805a(context, m3802a(serviceConnection), str, intent, 2);
        }
        return bindService;
    }

    /* renamed from: b */
    public void m3815b(Context context, ServiceConnection serviceConnection) {
        m3805a(context, m3802a(serviceConnection), null, null, 4);
    }
}

package com.google.android.gms.common.p022a;

import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;

/* renamed from: com.google.android.gms.common.a.b */
public class C0795b {
    /* renamed from: a */
    public static boolean m3232a() {
        return false;
    }

    /* renamed from: a */
    public static boolean m3233a(Context context, String str) {
        try {
            return (context.getPackageManager().getApplicationInfo(str, 0).flags & 2097152) != 0;
        } catch (NameNotFoundException e) {
            return false;
        }
    }
}

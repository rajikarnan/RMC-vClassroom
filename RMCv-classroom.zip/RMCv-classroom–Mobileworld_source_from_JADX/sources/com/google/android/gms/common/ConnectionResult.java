package com.google.android.gms.common;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public final class ConnectionResult extends AbstractSafeParcelable {
    public static final Creator<ConnectionResult> CREATOR = new C0848i();
    /* renamed from: a */
    public static final ConnectionResult f1531a = new ConnectionResult(0);
    /* renamed from: b */
    final int f1532b;
    /* renamed from: c */
    private final int f1533c;
    /* renamed from: d */
    private final PendingIntent f1534d;
    /* renamed from: e */
    private final String f1535e;

    public ConnectionResult(int i) {
        this(i, null, null);
    }

    ConnectionResult(int i, int i2, PendingIntent pendingIntent, String str) {
        this.f1532b = i;
        this.f1533c = i2;
        this.f1534d = pendingIntent;
        this.f1535e = str;
    }

    public ConnectionResult(int i, PendingIntent pendingIntent) {
        this(i, pendingIntent, null);
    }

    public ConnectionResult(int i, PendingIntent pendingIntent, String str) {
        this(1, i, pendingIntent, str);
    }

    /* renamed from: a */
    static String m3225a(int i) {
        switch (i) {
            case -1:
                return "UNKNOWN";
            case 0:
                return "SUCCESS";
            case 1:
                return "SERVICE_MISSING";
            case 2:
                return "SERVICE_VERSION_UPDATE_REQUIRED";
            case 3:
                return "SERVICE_DISABLED";
            case 4:
                return "SIGN_IN_REQUIRED";
            case 5:
                return "INVALID_ACCOUNT";
            case 6:
                return "RESOLUTION_REQUIRED";
            case 7:
                return "NETWORK_ERROR";
            case 8:
                return "INTERNAL_ERROR";
            case 9:
                return "SERVICE_INVALID";
            case 10:
                return "DEVELOPER_ERROR";
            case 11:
                return "LICENSE_CHECK_FAILED";
            case 13:
                return "CANCELED";
            case 14:
                return "TIMEOUT";
            case 15:
                return "INTERRUPTED";
            case 16:
                return "API_UNAVAILABLE";
            case 17:
                return "SIGN_IN_FAILED";
            case 18:
                return "SERVICE_UPDATING";
            case 19:
                return "SERVICE_MISSING_PERMISSION";
            case 20:
                return "RESTRICTED_PROFILE";
            case 21:
                return "API_VERSION_UPDATE_REQUIRED";
            case 42:
                return "UPDATE_ANDROID_WEAR";
            case 99:
                return "UNFINISHED";
            case 1500:
                return "DRIVE_EXTERNAL_STORAGE_REQUIRED";
            default:
                return "UNKNOWN_ERROR_CODE(" + i + ")";
        }
    }

    /* renamed from: a */
    public boolean m3226a() {
        return (this.f1533c == 0 || this.f1534d == null) ? false : true;
    }

    /* renamed from: b */
    public boolean m3227b() {
        return this.f1533c == 0;
    }

    /* renamed from: c */
    public int m3228c() {
        return this.f1533c;
    }

    /* renamed from: d */
    public PendingIntent m3229d() {
        return this.f1534d;
    }

    /* renamed from: e */
    public String m3230e() {
        return this.f1535e;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ConnectionResult)) {
            return false;
        }
        ConnectionResult connectionResult = (ConnectionResult) obj;
        return this.f1533c == connectionResult.f1533c && ab.m3426a(this.f1534d, connectionResult.f1534d) && ab.m3426a(this.f1535e, connectionResult.f1535e);
    }

    public int hashCode() {
        return ab.m3424a(Integer.valueOf(this.f1533c), this.f1534d, this.f1535e);
    }

    public String toString() {
        return ab.m3425a((Object) this).m3423a("statusCode", m3225a(this.f1533c)).m3423a("resolution", this.f1534d).m3423a("message", this.f1535e).toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0848i.m3397a(this, parcel, i);
    }
}

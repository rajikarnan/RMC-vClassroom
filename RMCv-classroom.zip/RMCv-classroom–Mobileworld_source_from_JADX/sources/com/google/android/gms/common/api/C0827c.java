package com.google.android.gms.common.api;

/* renamed from: com.google.android.gms.common.api.c */
public abstract class C0827c<R extends C0809e> {

    /* renamed from: com.google.android.gms.common.api.c$a */
    public interface C0826a {
        /* renamed from: a */
        void m3322a(Status status);
    }

    /* renamed from: a */
    public Integer mo981a() {
        throw new UnsupportedOperationException();
    }

    /* renamed from: a */
    public abstract void mo982a(C0829f<? super R> c0829f);
}

package com.google.android.gms.common.internal;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.util.Log;
import com.google.android.gms.p023d.aa;

/* renamed from: com.google.android.gms.common.internal.n */
public abstract class C0892n implements OnClickListener {

    /* renamed from: com.google.android.gms.common.internal.n$1 */
    class C08931 extends C0892n {
        /* renamed from: a */
        final /* synthetic */ Activity f1732a;
        /* renamed from: b */
        final /* synthetic */ Intent f1733b;
        /* renamed from: c */
        final /* synthetic */ int f1734c;

        C08931(Activity activity, Intent intent, int i) {
            this.f1732a = activity;
            this.f1733b = intent;
            this.f1734c = i;
        }

        /* renamed from: a */
        public void mo918a() {
            this.f1732a.startActivityForResult(this.f1733b, this.f1734c);
        }
    }

    /* renamed from: com.google.android.gms.common.internal.n$2 */
    class C08942 extends C0892n {
        /* renamed from: a */
        final /* synthetic */ Fragment f1735a;
        /* renamed from: b */
        final /* synthetic */ Intent f1736b;
        /* renamed from: c */
        final /* synthetic */ int f1737c;

        C08942(Fragment fragment, Intent intent, int i) {
            this.f1735a = fragment;
            this.f1736b = intent;
            this.f1737c = i;
        }

        /* renamed from: a */
        public void mo918a() {
            this.f1735a.startActivityForResult(this.f1736b, this.f1737c);
        }
    }

    /* renamed from: com.google.android.gms.common.internal.n$3 */
    class C08953 extends C0892n {
        /* renamed from: a */
        final /* synthetic */ aa f1738a;
        /* renamed from: b */
        final /* synthetic */ Intent f1739b;
        /* renamed from: c */
        final /* synthetic */ int f1740c;

        C08953(aa aaVar, Intent intent, int i) {
            this.f1738a = aaVar;
            this.f1739b = intent;
            this.f1740c = i;
        }

        @TargetApi(11)
        /* renamed from: a */
        public void mo918a() {
            this.f1738a.startActivityForResult(this.f1739b, this.f1740c);
        }
    }

    /* renamed from: a */
    public static C0892n m3573a(Activity activity, Intent intent, int i) {
        return new C08931(activity, intent, i);
    }

    /* renamed from: a */
    public static C0892n m3574a(Fragment fragment, Intent intent, int i) {
        return new C08942(fragment, intent, i);
    }

    /* renamed from: a */
    public static C0892n m3575a(aa aaVar, Intent intent, int i) {
        return new C08953(aaVar, intent, i);
    }

    /* renamed from: a */
    public abstract void mo918a();

    public void onClick(DialogInterface dialogInterface, int i) {
        try {
            mo918a();
            dialogInterface.dismiss();
        } catch (ActivityNotFoundException e) {
            Log.e("DialogRedirect", "Can't redirect to app settings for Google Play services");
        }
    }
}

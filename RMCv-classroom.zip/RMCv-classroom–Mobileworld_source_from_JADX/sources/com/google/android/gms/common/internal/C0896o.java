package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;

/* renamed from: com.google.android.gms.common.internal.o */
public class C0896o implements Creator<GetServiceRequest> {
    /* renamed from: a */
    static void m3580a(GetServiceRequest getServiceRequest, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3646a(parcel, 1, getServiceRequest.f1621a);
        C0907b.m3646a(parcel, 2, getServiceRequest.f1622b);
        C0907b.m3646a(parcel, 3, getServiceRequest.f1623c);
        C0907b.m3652a(parcel, 4, getServiceRequest.f1624d, false);
        C0907b.m3649a(parcel, 5, getServiceRequest.f1625e, false);
        C0907b.m3657a(parcel, 6, getServiceRequest.f1626f, i, false);
        C0907b.m3648a(parcel, 7, getServiceRequest.f1627g, false);
        C0907b.m3650a(parcel, 8, getServiceRequest.f1628h, i, false);
        C0907b.m3647a(parcel, 9, getServiceRequest.f1629i);
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public GetServiceRequest m3581a(Parcel parcel) {
        int i = 0;
        Account account = null;
        int b = C0906a.m3626b(parcel);
        long j = 0;
        Bundle bundle = null;
        Scope[] scopeArr = null;
        IBinder iBinder = null;
        String str = null;
        int i2 = 0;
        int i3 = 0;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    i3 = C0906a.m3632e(parcel, a);
                    break;
                case 2:
                    i2 = C0906a.m3632e(parcel, a);
                    break;
                case 3:
                    i = C0906a.m3632e(parcel, a);
                    break;
                case 4:
                    str = C0906a.m3637j(parcel, a);
                    break;
                case 5:
                    iBinder = C0906a.m3638k(parcel, a);
                    break;
                case 6:
                    scopeArr = (Scope[]) C0906a.m3628b(parcel, a, Scope.CREATOR);
                    break;
                case 7:
                    bundle = C0906a.m3639l(parcel, a);
                    break;
                case 8:
                    account = (Account) C0906a.m3623a(parcel, a, Account.CREATOR);
                    break;
                case 9:
                    j = C0906a.m3634g(parcel, a);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new GetServiceRequest(i3, i2, i, str, iBinder, scopeArr, bundle, account, j);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public GetServiceRequest[] m3582a(int i) {
        return new GetServiceRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m3581a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m3582a(i);
    }
}

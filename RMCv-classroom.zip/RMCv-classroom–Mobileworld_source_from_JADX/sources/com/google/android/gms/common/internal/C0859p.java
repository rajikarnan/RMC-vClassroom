package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.content.Context;
import android.os.Bundle;
import android.os.IInterface;
import android.os.Looper;
import com.google.android.gms.common.C0840b;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0824a.C0819f;
import com.google.android.gms.common.api.GoogleApiClient.C0807b;
import com.google.android.gms.common.api.GoogleApiClient.C0808c;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.C0857i.C0866b;
import com.google.android.gms.common.internal.C0857i.C0867c;
import com.google.android.gms.common.internal.C0899q.C0858a;
import java.util.Set;

/* renamed from: com.google.android.gms.common.internal.p */
public abstract class C0859p<T extends IInterface> extends C0857i<T> implements C0819f, C0858a {
    /* renamed from: d */
    private final C0890l f1676d;
    /* renamed from: e */
    private final Set<Scope> f1677e;
    /* renamed from: f */
    private final Account f1678f;

    /* renamed from: com.google.android.gms.common.internal.p$1 */
    class C08971 implements C0866b {
        /* renamed from: a */
        final /* synthetic */ C0807b f1741a;

        C08971(C0807b c0807b) {
            this.f1741a = c0807b;
        }

        /* renamed from: a */
        public void mo919a(int i) {
            this.f1741a.mo1010a(i);
        }

        /* renamed from: a */
        public void mo920a(Bundle bundle) {
            this.f1741a.mo1011a(bundle);
        }
    }

    /* renamed from: com.google.android.gms.common.internal.p$2 */
    class C08982 implements C0867c {
        /* renamed from: a */
        final /* synthetic */ C0808c f1742a;

        C08982(C0808c c0808c) {
            this.f1742a = c0808c;
        }

        /* renamed from: a */
        public void mo921a(ConnectionResult connectionResult) {
            this.f1742a.mo996a(connectionResult);
        }
    }

    protected C0859p(Context context, Looper looper, int i, C0890l c0890l, C0807b c0807b, C0808c c0808c) {
        this(context, looper, C0900r.m3594a(context), C0840b.m3355a(), i, c0890l, (C0807b) C0854b.m3427a((Object) c0807b), (C0808c) C0854b.m3427a((Object) c0808c));
    }

    protected C0859p(Context context, Looper looper, C0900r c0900r, C0840b c0840b, int i, C0890l c0890l, C0807b c0807b, C0808c c0808c) {
        super(context, looper, c0900r, c0840b, i, C0859p.m3488a(c0807b), C0859p.m3489a(c0808c), c0890l.m3565g());
        this.f1676d = c0890l;
        this.f1678f = c0890l.m3558a();
        this.f1677e = m3490b(c0890l.m3562d());
    }

    /* renamed from: a */
    private static C0866b m3488a(C0807b c0807b) {
        return c0807b == null ? null : new C08971(c0807b);
    }

    /* renamed from: a */
    private static C0867c m3489a(C0808c c0808c) {
        return c0808c == null ? null : new C08982(c0808c);
    }

    /* renamed from: b */
    private Set<Scope> m3490b(Set<Scope> set) {
        Set<Scope> a = m3491a((Set) set);
        for (Scope contains : a) {
            if (!set.contains(contains)) {
                throw new IllegalStateException("Expanding scopes is not permitted, use implied scopes instead");
            }
        }
        return a;
    }

    /* renamed from: a */
    protected Set<Scope> m3491a(Set<Scope> set) {
        return set;
    }

    /* renamed from: o */
    public final Account mo901o() {
        return this.f1678f;
    }

    /* renamed from: v */
    protected final Set<Scope> mo902v() {
        return this.f1677e;
    }
}

package com.google.android.gms.common.stats;

import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public abstract class StatsEvent extends AbstractSafeParcelable {
    /* renamed from: a */
    public abstract long mo974a();

    /* renamed from: b */
    public abstract int mo975b();

    /* renamed from: i */
    public abstract long mo976i();

    /* renamed from: l */
    public abstract String mo977l();

    public String toString() {
        long a = mo974a();
        String valueOf = String.valueOf("\t");
        int b = mo975b();
        String valueOf2 = String.valueOf("\t");
        long i = mo976i();
        String valueOf3 = String.valueOf(mo977l());
        return new StringBuilder(((String.valueOf(valueOf).length() + 51) + String.valueOf(valueOf2).length()) + String.valueOf(valueOf3).length()).append(a).append(valueOf).append(b).append(valueOf2).append(i).append(valueOf3).toString();
    }
}

package com.google.android.gms.common.api;

/* renamed from: com.google.android.gms.common.api.h */
public abstract class C0831h<R extends C0809e, S extends C0809e> {
    /* renamed from: a */
    public Status m3329a(Status status) {
        return status;
    }

    /* renamed from: a */
    public abstract C0827c<S> m3330a(R r);
}

package com.google.android.gms.common.internal;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.ag;
import android.util.Log;
import com.google.android.gms.p023d.ap;

public class aa {
    /* renamed from: a */
    private static Object f1646a = new Object();
    /* renamed from: b */
    private static boolean f1647b;
    /* renamed from: c */
    private static String f1648c;
    /* renamed from: d */
    private static int f1649d;

    /* renamed from: a */
    public static int m3421a(Context context) {
        m3422b(context);
        return f1649d;
    }

    /* renamed from: b */
    private static void m3422b(Context context) {
        synchronized (f1646a) {
            if (f1647b) {
                return;
            }
            f1647b = true;
            try {
                Bundle bundle = ap.m3890b(context).m3887a(context.getPackageName(), (int) ag.FLAG_HIGH_PRIORITY).metaData;
                if (bundle == null) {
                    return;
                }
                f1648c = bundle.getString("com.google.app.id");
                f1649d = bundle.getInt("com.google.android.gms.version");
            } catch (Throwable e) {
                Log.wtf("MetadataValueReader", "This should never happen.", e);
            }
        }
    }
}

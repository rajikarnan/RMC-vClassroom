package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Binder;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.C0844l;
import com.google.android.gms.common.internal.C0849u.C0850a;

/* renamed from: com.google.android.gms.common.internal.a */
public class C0851a extends C0850a {
    /* renamed from: a */
    int f1645a;

    /* renamed from: a */
    public static Account m3419a(C0849u c0849u) {
        Account account = null;
        if (c0849u != null) {
            long clearCallingIdentity = Binder.clearCallingIdentity();
            try {
                account = c0849u.mo900a();
            } catch (RemoteException e) {
                Log.w("AccountAccessor", "Remote account accessor probably died");
            } finally {
                Binder.restoreCallingIdentity(clearCallingIdentity);
            }
        }
        return account;
    }

    /* renamed from: a */
    public Account mo900a() {
        int callingUid = Binder.getCallingUid();
        if (callingUid != this.f1645a) {
            if (C0844l.m3377b(null, callingUid)) {
                this.f1645a = callingUid;
            } else {
                throw new SecurityException("Caller is not GooglePlayServices");
            }
        }
        return null;
    }

    public boolean equals(Object obj) {
        Account account = null;
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0851a)) {
            return false;
        }
        C0851a c0851a = (C0851a) obj;
        return account.equals(account);
    }
}

package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.C0849u.C0850a;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class ResolveAccountResponse extends AbstractSafeParcelable {
    public static final Creator<ResolveAccountResponse> CREATOR = new C0856d();
    /* renamed from: a */
    final int f1634a;
    /* renamed from: b */
    IBinder f1635b;
    /* renamed from: c */
    private ConnectionResult f1636c;
    /* renamed from: d */
    private boolean f1637d;
    /* renamed from: e */
    private boolean f1638e;

    ResolveAccountResponse(int i, IBinder iBinder, ConnectionResult connectionResult, boolean z, boolean z2) {
        this.f1634a = i;
        this.f1635b = iBinder;
        this.f1636c = connectionResult;
        this.f1637d = z;
        this.f1638e = z2;
    }

    /* renamed from: a */
    public C0849u m3409a() {
        return C0850a.m3418a(this.f1635b);
    }

    /* renamed from: b */
    public ConnectionResult m3410b() {
        return this.f1636c;
    }

    /* renamed from: c */
    public boolean m3411c() {
        return this.f1637d;
    }

    /* renamed from: d */
    public boolean m3412d() {
        return this.f1638e;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ResolveAccountResponse)) {
            return false;
        }
        ResolveAccountResponse resolveAccountResponse = (ResolveAccountResponse) obj;
        return this.f1636c.equals(resolveAccountResponse.f1636c) && m3409a().equals(resolveAccountResponse.m3409a());
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0856d.m3440a(this, parcel, i);
    }
}

package com.google.android.gms.common;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;

/* renamed from: com.google.android.gms.common.i */
public class C0848i implements Creator<ConnectionResult> {
    /* renamed from: a */
    static void m3397a(ConnectionResult connectionResult, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3646a(parcel, 1, connectionResult.f1532b);
        C0907b.m3646a(parcel, 2, connectionResult.m3228c());
        C0907b.m3650a(parcel, 3, connectionResult.m3229d(), i, false);
        C0907b.m3652a(parcel, 4, connectionResult.m3230e(), false);
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public ConnectionResult m3398a(Parcel parcel) {
        String str = null;
        int i = 0;
        int b = C0906a.m3626b(parcel);
        PendingIntent pendingIntent = null;
        int i2 = 0;
        while (parcel.dataPosition() < b) {
            PendingIntent pendingIntent2;
            int i3;
            String str2;
            int a = C0906a.m3621a(parcel);
            String str3;
            switch (C0906a.m3620a(a)) {
                case 1:
                    str3 = str;
                    pendingIntent2 = pendingIntent;
                    i3 = i;
                    i = C0906a.m3632e(parcel, a);
                    str2 = str3;
                    break;
                case 2:
                    i = i2;
                    PendingIntent pendingIntent3 = pendingIntent;
                    i3 = C0906a.m3632e(parcel, a);
                    str2 = str;
                    pendingIntent2 = pendingIntent3;
                    break;
                case 3:
                    i3 = i;
                    i = i2;
                    str3 = str;
                    pendingIntent2 = (PendingIntent) C0906a.m3623a(parcel, a, PendingIntent.CREATOR);
                    str2 = str3;
                    break;
                case 4:
                    str2 = C0906a.m3637j(parcel, a);
                    pendingIntent2 = pendingIntent;
                    i3 = i;
                    i = i2;
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    str2 = str;
                    pendingIntent2 = pendingIntent;
                    i3 = i;
                    i = i2;
                    break;
            }
            i2 = i;
            i = i3;
            pendingIntent = pendingIntent2;
            str = str2;
        }
        if (parcel.dataPosition() == b) {
            return new ConnectionResult(i2, i, pendingIntent, str);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public ConnectionResult[] m3399a(int i) {
        return new ConnectionResult[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m3398a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m3399a(i);
    }
}

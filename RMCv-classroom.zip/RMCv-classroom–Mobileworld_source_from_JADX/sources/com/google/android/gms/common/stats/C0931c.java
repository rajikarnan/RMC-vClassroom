package com.google.android.gms.common.stats;

import com.google.android.gms.p023d.al;

/* renamed from: com.google.android.gms.common.stats.c */
public final class C0931c {
    /* renamed from: a */
    public static al<Integer> f1812a = al.m3872a("gms:common:stats:max_num_of_events", Integer.valueOf(100));
    /* renamed from: b */
    public static al<Integer> f1813b = al.m3872a("gms:common:stats:max_chunk_size", Integer.valueOf(100));

    /* renamed from: com.google.android.gms.common.stats.c$a */
    public static final class C0930a {
        /* renamed from: a */
        public static al<Integer> f1806a = al.m3872a("gms:common:stats:connections:level", Integer.valueOf(C0932d.f1815b));
        /* renamed from: b */
        public static al<String> f1807b = al.m3874a("gms:common:stats:connections:ignored_calling_processes", "");
        /* renamed from: c */
        public static al<String> f1808c = al.m3874a("gms:common:stats:connections:ignored_calling_services", "");
        /* renamed from: d */
        public static al<String> f1809d = al.m3874a("gms:common:stats:connections:ignored_target_processes", "");
        /* renamed from: e */
        public static al<String> f1810e = al.m3874a("gms:common:stats:connections:ignored_target_services", "com.google.android.gms.auth.GetToken");
        /* renamed from: f */
        public static al<Long> f1811f = al.m3873a("gms:common:stats:connections:time_out_duration", Long.valueOf(600000));
    }
}

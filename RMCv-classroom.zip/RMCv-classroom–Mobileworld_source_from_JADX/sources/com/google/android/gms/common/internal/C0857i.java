package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.C0839j;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0825b;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.C0870x.C0871a;
import com.google.android.gms.common.internal.C0914y.C0916a;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

/* renamed from: com.google.android.gms.common.internal.i */
public abstract class C0857i<T extends IInterface> {
    /* renamed from: c */
    public static final String[] f1652c = new String[]{"service_esmobile", "service_googleme"};
    /* renamed from: a */
    final Handler f1653a;
    /* renamed from: b */
    protected AtomicInteger f1654b = new AtomicInteger(0);
    /* renamed from: d */
    private int f1655d;
    /* renamed from: e */
    private long f1656e;
    /* renamed from: f */
    private long f1657f;
    /* renamed from: g */
    private int f1658g;
    /* renamed from: h */
    private long f1659h;
    /* renamed from: i */
    private final Context f1660i;
    /* renamed from: j */
    private final Looper f1661j;
    /* renamed from: k */
    private final C0900r f1662k;
    /* renamed from: l */
    private final C0839j f1663l;
    /* renamed from: m */
    private final Object f1664m = new Object();
    /* renamed from: n */
    private final Object f1665n = new Object();
    /* renamed from: o */
    private C0914y f1666o;
    /* renamed from: p */
    private C0869f f1667p;
    /* renamed from: q */
    private T f1668q;
    /* renamed from: r */
    private final ArrayList<C0864e<?>> f1669r = new ArrayList();
    /* renamed from: s */
    private C0873h f1670s;
    /* renamed from: t */
    private int f1671t = 1;
    /* renamed from: u */
    private final C0866b f1672u;
    /* renamed from: v */
    private final C0867c f1673v;
    /* renamed from: w */
    private final int f1674w;
    /* renamed from: x */
    private final String f1675x;

    /* renamed from: com.google.android.gms.common.internal.i$e */
    protected abstract class C0864e<TListener> {
        /* renamed from: a */
        private TListener f1682a;
        /* renamed from: b */
        private boolean f1683b = false;
        /* renamed from: d */
        final /* synthetic */ C0857i f1684d;

        public C0864e(C0857i c0857i, TListener tListener) {
            this.f1684d = c0857i;
            this.f1682a = tListener;
        }

        /* renamed from: a */
        protected abstract void mo908a(TListener tListener);

        /* renamed from: b */
        protected abstract void mo909b();

        /* renamed from: c */
        public void m3508c() {
            synchronized (this) {
                Object obj = this.f1682a;
                if (this.f1683b) {
                    String valueOf = String.valueOf(this);
                    Log.w("GmsClient", new StringBuilder(String.valueOf(valueOf).length() + 47).append("Callback proxy ").append(valueOf).append(" being reused. This is not safe.").toString());
                }
            }
            if (obj != null) {
                try {
                    mo908a(obj);
                } catch (RuntimeException e) {
                    mo909b();
                    throw e;
                }
            }
            mo909b();
            synchronized (this) {
                this.f1683b = true;
            }
            m3509d();
        }

        /* renamed from: d */
        public void m3509d() {
            m3510e();
            synchronized (this.f1684d.f1669r) {
                this.f1684d.f1669r.remove(this);
            }
        }

        /* renamed from: e */
        public void m3510e() {
            synchronized (this) {
                this.f1682a = null;
            }
        }
    }

    /* renamed from: com.google.android.gms.common.internal.i$a */
    private abstract class C0865a extends C0864e<Boolean> {
        /* renamed from: a */
        public final int f1685a;
        /* renamed from: b */
        public final Bundle f1686b;
        /* renamed from: c */
        final /* synthetic */ C0857i f1687c;

        protected C0865a(C0857i c0857i, int i, Bundle bundle) {
            this.f1687c = c0857i;
            super(c0857i, Boolean.valueOf(true));
            this.f1685a = i;
            this.f1686b = bundle;
        }

        /* renamed from: a */
        protected abstract void mo913a(ConnectionResult connectionResult);

        /* renamed from: a */
        protected void m3512a(Boolean bool) {
            PendingIntent pendingIntent = null;
            if (bool == null) {
                this.f1687c.m3449b(1, null);
                return;
            }
            switch (this.f1685a) {
                case 0:
                    if (!mo914a()) {
                        this.f1687c.m3449b(1, null);
                        mo913a(new ConnectionResult(8, null));
                        return;
                    }
                    return;
                case 10:
                    this.f1687c.m3449b(1, null);
                    throw new IllegalStateException("A fatal developer error has occurred. Check the logs for further information.");
                default:
                    this.f1687c.m3449b(1, null);
                    if (this.f1686b != null) {
                        pendingIntent = (PendingIntent) this.f1686b.getParcelable("pendingIntent");
                    }
                    mo913a(new ConnectionResult(this.f1685a, pendingIntent));
                    return;
            }
        }

        /* renamed from: a */
        protected /* synthetic */ void mo908a(Object obj) {
            m3512a((Boolean) obj);
        }

        /* renamed from: a */
        protected abstract boolean mo914a();

        /* renamed from: b */
        protected void mo909b() {
        }
    }

    /* renamed from: com.google.android.gms.common.internal.i$b */
    public interface C0866b {
        /* renamed from: a */
        void mo919a(int i);

        /* renamed from: a */
        void mo920a(Bundle bundle);
    }

    /* renamed from: com.google.android.gms.common.internal.i$c */
    public interface C0867c {
        /* renamed from: a */
        void mo921a(ConnectionResult connectionResult);
    }

    /* renamed from: com.google.android.gms.common.internal.i$d */
    final class C0868d extends Handler {
        /* renamed from: a */
        final /* synthetic */ C0857i f1688a;

        public C0868d(C0857i c0857i, Looper looper) {
            this.f1688a = c0857i;
            super(looper);
        }

        /* renamed from: a */
        private void m3519a(Message message) {
            C0864e c0864e = (C0864e) message.obj;
            c0864e.mo909b();
            c0864e.m3509d();
        }

        /* renamed from: b */
        private boolean m3520b(Message message) {
            return message.what == 2 || message.what == 1 || message.what == 5;
        }

        public void handleMessage(Message message) {
            PendingIntent pendingIntent = null;
            if (this.f1688a.f1654b.get() != message.arg1) {
                if (m3520b(message)) {
                    m3519a(message);
                }
            } else if ((message.what == 1 || message.what == 5) && !this.f1688a.m3468c()) {
                m3519a(message);
            } else if (message.what == 3) {
                if (message.obj instanceof PendingIntent) {
                    pendingIntent = (PendingIntent) message.obj;
                }
                ConnectionResult connectionResult = new ConnectionResult(message.arg2, pendingIntent);
                this.f1688a.f1667p.mo912a(connectionResult);
                this.f1688a.m3462a(connectionResult);
            } else if (message.what == 4) {
                this.f1688a.m3449b(4, null);
                if (this.f1688a.f1672u != null) {
                    this.f1688a.f1672u.mo919a(message.arg2);
                }
                this.f1688a.m3457a(message.arg2);
                this.f1688a.m3446a(4, 1, null);
            } else if (message.what == 2 && !this.f1688a.m3467b()) {
                m3519a(message);
            } else if (m3520b(message)) {
                ((C0864e) message.obj).m3508c();
            } else {
                Log.wtf("GmsClient", "Don't know how to handle message: " + message.what, new Exception());
            }
        }
    }

    /* renamed from: com.google.android.gms.common.internal.i$f */
    public interface C0869f {
        /* renamed from: a */
        void mo912a(ConnectionResult connectionResult);
    }

    /* renamed from: com.google.android.gms.common.internal.i$g */
    public static final class C0872g extends C0871a {
        /* renamed from: a */
        private C0857i f1689a;
        /* renamed from: b */
        private final int f1690b;

        public C0872g(C0857i c0857i, int i) {
            this.f1689a = c0857i;
            this.f1690b = i;
        }

        /* renamed from: a */
        private void m3525a() {
            this.f1689a = null;
        }

        /* renamed from: a */
        public void mo910a(int i, Bundle bundle) {
            Log.wtf("GmsClient", "received deprecated onAccountValidationComplete callback, ignoring", new Exception());
        }

        /* renamed from: a */
        public void mo911a(int i, IBinder iBinder, Bundle bundle) {
            C0854b.m3428a(this.f1689a, (Object) "onPostInitComplete can be called only once per call to getRemoteService");
            this.f1689a.m3459a(i, iBinder, bundle, this.f1690b);
            m3525a();
        }
    }

    /* renamed from: com.google.android.gms.common.internal.i$h */
    public final class C0873h implements ServiceConnection {
        /* renamed from: a */
        final /* synthetic */ C0857i f1691a;
        /* renamed from: b */
        private final int f1692b;

        public C0873h(C0857i c0857i, int i) {
            this.f1691a = c0857i;
            this.f1692b = i;
        }

        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            C0854b.m3428a((Object) iBinder, (Object) "Expecting a valid IBinder");
            synchronized (this.f1691a.f1665n) {
                this.f1691a.f1666o = C0916a.m3763a(iBinder);
            }
            this.f1691a.m3458a(0, null, this.f1692b);
        }

        public void onServiceDisconnected(ComponentName componentName) {
            synchronized (this.f1691a.f1665n) {
                this.f1691a.f1666o = null;
            }
            this.f1691a.f1653a.sendMessage(this.f1691a.f1653a.obtainMessage(4, this.f1692b, 1));
        }
    }

    /* renamed from: com.google.android.gms.common.internal.i$i */
    protected class C0874i implements C0869f {
        /* renamed from: a */
        final /* synthetic */ C0857i f1693a;

        public C0874i(C0857i c0857i) {
            this.f1693a = c0857i;
        }

        /* renamed from: a */
        public void mo912a(ConnectionResult connectionResult) {
            if (connectionResult.m3227b()) {
                this.f1693a.m3464a(null, this.f1693a.mo902v());
            } else if (this.f1693a.f1673v != null) {
                this.f1693a.f1673v.mo921a(connectionResult);
            }
        }
    }

    /* renamed from: com.google.android.gms.common.internal.i$j */
    protected final class C0875j extends C0865a {
        /* renamed from: e */
        public final IBinder f1694e;
        /* renamed from: f */
        final /* synthetic */ C0857i f1695f;

        public C0875j(C0857i c0857i, int i, IBinder iBinder, Bundle bundle) {
            this.f1695f = c0857i;
            super(c0857i, i, bundle);
            this.f1694e = iBinder;
        }

        /* renamed from: a */
        protected void mo913a(ConnectionResult connectionResult) {
            if (this.f1695f.f1673v != null) {
                this.f1695f.f1673v.mo921a(connectionResult);
            }
            this.f1695f.m3462a(connectionResult);
        }

        /* renamed from: a */
        protected boolean mo914a() {
            try {
                String interfaceDescriptor = this.f1694e.getInterfaceDescriptor();
                if (this.f1695f.mo906j().equals(interfaceDescriptor)) {
                    IInterface a = this.f1695f.mo903a(this.f1694e);
                    if (a == null || !this.f1695f.m3446a(2, 3, a)) {
                        return false;
                    }
                    Bundle s = this.f1695f.m3482s();
                    if (this.f1695f.f1672u != null) {
                        this.f1695f.f1672u.mo920a(s);
                    }
                    return true;
                }
                String valueOf = String.valueOf(this.f1695f.mo906j());
                Log.e("GmsClient", new StringBuilder((String.valueOf(valueOf).length() + 34) + String.valueOf(interfaceDescriptor).length()).append("service descriptor mismatch: ").append(valueOf).append(" vs. ").append(interfaceDescriptor).toString());
                return false;
            } catch (RemoteException e) {
                Log.w("GmsClient", "service probably died");
                return false;
            }
        }
    }

    /* renamed from: com.google.android.gms.common.internal.i$k */
    protected final class C0876k extends C0865a {
        /* renamed from: e */
        final /* synthetic */ C0857i f1696e;

        public C0876k(C0857i c0857i, int i, Bundle bundle) {
            this.f1696e = c0857i;
            super(c0857i, i, bundle);
        }

        /* renamed from: a */
        protected void mo913a(ConnectionResult connectionResult) {
            this.f1696e.f1667p.mo912a(connectionResult);
            this.f1696e.m3462a(connectionResult);
        }

        /* renamed from: a */
        protected boolean mo914a() {
            this.f1696e.f1667p.mo912a(ConnectionResult.f1531a);
            return true;
        }
    }

    protected C0857i(Context context, Looper looper, C0900r c0900r, C0839j c0839j, int i, C0866b c0866b, C0867c c0867c, String str) {
        this.f1660i = (Context) C0854b.m3428a((Object) context, (Object) "Context must not be null");
        this.f1661j = (Looper) C0854b.m3428a((Object) looper, (Object) "Looper must not be null");
        this.f1662k = (C0900r) C0854b.m3428a((Object) c0900r, (Object) "Supervisor must not be null");
        this.f1663l = (C0839j) C0854b.m3428a((Object) c0839j, (Object) "API availability must not be null");
        this.f1653a = new C0868d(this, looper);
        this.f1674w = i;
        this.f1672u = c0866b;
        this.f1673v = c0867c;
        this.f1675x = str;
    }

    /* renamed from: a */
    private boolean m3446a(int i, int i2, T t) {
        boolean z;
        synchronized (this.f1664m) {
            if (this.f1671t != i) {
                z = false;
            } else {
                m3449b(i2, t);
                z = true;
            }
        }
        return z;
    }

    /* renamed from: b */
    private void m3449b(int i, T t) {
        boolean z = true;
        if ((i == 3) != (t != null)) {
            z = false;
        }
        C0854b.m3435b(z);
        synchronized (this.f1664m) {
            this.f1671t = i;
            this.f1668q = t;
            mo904a(i, (IInterface) t);
            switch (i) {
                case 1:
                    m3454w();
                    break;
                case 2:
                    mo907k();
                    break;
                case 3:
                    m3461a((IInterface) t);
                    break;
            }
        }
    }

    /* renamed from: k */
    private void mo907k() {
        if (this.f1670s != null) {
            String valueOf = String.valueOf(mo905i());
            String valueOf2 = String.valueOf(c_());
            Log.e("GmsClient", new StringBuilder((String.valueOf(valueOf).length() + 70) + String.valueOf(valueOf2).length()).append("Calling connect() while still connected, missing disconnect() for ").append(valueOf).append(" on ").append(valueOf2).toString());
            this.f1662k.mo923b(mo905i(), c_(), this.f1670s, m3476m());
            this.f1654b.incrementAndGet();
        }
        this.f1670s = new C0873h(this, this.f1654b.get());
        if (!this.f1662k.mo922a(mo905i(), c_(), this.f1670s, m3476m())) {
            valueOf = String.valueOf(mo905i());
            valueOf2 = String.valueOf(c_());
            Log.e("GmsClient", new StringBuilder((String.valueOf(valueOf).length() + 34) + String.valueOf(valueOf2).length()).append("unable to connect to service: ").append(valueOf).append(" on ").append(valueOf2).toString());
            m3458a(16, null, this.f1654b.get());
        }
    }

    /* renamed from: w */
    private void m3454w() {
        if (this.f1670s != null) {
            this.f1662k.mo923b(mo905i(), c_(), this.f1670s, m3476m());
            this.f1670s = null;
        }
    }

    /* renamed from: a */
    protected abstract T mo903a(IBinder iBinder);

    /* renamed from: a */
    public void mo1093a() {
        this.f1654b.incrementAndGet();
        synchronized (this.f1669r) {
            int size = this.f1669r.size();
            for (int i = 0; i < size; i++) {
                ((C0864e) this.f1669r.get(i)).m3510e();
            }
            this.f1669r.clear();
        }
        synchronized (this.f1665n) {
            this.f1666o = null;
        }
        m3449b(1, null);
    }

    /* renamed from: a */
    protected void m3457a(int i) {
        this.f1655d = i;
        this.f1656e = System.currentTimeMillis();
    }

    /* renamed from: a */
    protected void m3458a(int i, Bundle bundle, int i2) {
        this.f1653a.sendMessage(this.f1653a.obtainMessage(5, i2, -1, new C0876k(this, i, bundle)));
    }

    /* renamed from: a */
    protected void m3459a(int i, IBinder iBinder, Bundle bundle, int i2) {
        this.f1653a.sendMessage(this.f1653a.obtainMessage(1, i2, -1, new C0875j(this, i, iBinder, bundle)));
    }

    /* renamed from: a */
    void mo904a(int i, T t) {
    }

    /* renamed from: a */
    protected void m3461a(T t) {
        this.f1657f = System.currentTimeMillis();
    }

    /* renamed from: a */
    protected void m3462a(ConnectionResult connectionResult) {
        this.f1658g = connectionResult.m3228c();
        this.f1659h = System.currentTimeMillis();
    }

    /* renamed from: a */
    public void m3463a(C0869f c0869f) {
        this.f1667p = (C0869f) C0854b.m3428a((Object) c0869f, (Object) "Connection progress callbacks cannot be null.");
        m3449b(2, null);
    }

    /* renamed from: a */
    public void m3464a(C0849u c0849u, Set<Scope> set) {
        try {
            GetServiceRequest a = new GetServiceRequest(this.f1674w).m3404a(this.f1660i.getPackageName()).m3402a(mo1052q());
            if (set != null) {
                a.m3405a((Collection) set);
            }
            if (mo1106d()) {
                a.m3401a(m3479p()).m3403a(c0849u);
            } else if (m3484u()) {
                a.m3401a(mo901o());
            }
            synchronized (this.f1665n) {
                if (this.f1666o != null) {
                    this.f1666o.mo936a(new C0872g(this, this.f1654b.get()), a);
                } else {
                    Log.w("GmsClient", "mServiceBroker is null, client disconnected");
                }
            }
        } catch (DeadObjectException e) {
            Log.w("GmsClient", "service died");
            m3466b(1);
        } catch (Throwable e2) {
            Log.w("GmsClient", "Remote exception occurred", e2);
        }
    }

    /* renamed from: a */
    public void m3465a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        synchronized (this.f1664m) {
            int i = this.f1671t;
            IInterface iInterface = this.f1668q;
        }
        printWriter.append(str).append("mConnectState=");
        switch (i) {
            case 1:
                printWriter.print("DISCONNECTED");
                break;
            case 2:
                printWriter.print("CONNECTING");
                break;
            case 3:
                printWriter.print("CONNECTED");
                break;
            case 4:
                printWriter.print("DISCONNECTING");
                break;
            default:
                printWriter.print("UNKNOWN");
                break;
        }
        printWriter.append(" mService=");
        if (iInterface == null) {
            printWriter.println("null");
        } else {
            printWriter.append(mo906j()).append("@").println(Integer.toHexString(System.identityHashCode(iInterface.asBinder())));
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US);
        if (this.f1657f > 0) {
            PrintWriter append = printWriter.append(str).append("lastConnectedTime=");
            long j = this.f1657f;
            String valueOf = String.valueOf(simpleDateFormat.format(new Date(this.f1657f)));
            append.println(new StringBuilder(String.valueOf(valueOf).length() + 21).append(j).append(" ").append(valueOf).toString());
        }
        if (this.f1656e > 0) {
            printWriter.append(str).append("lastSuspendedCause=");
            switch (this.f1655d) {
                case 1:
                    printWriter.append("CAUSE_SERVICE_DISCONNECTED");
                    break;
                case 2:
                    printWriter.append("CAUSE_NETWORK_LOST");
                    break;
                default:
                    printWriter.append(String.valueOf(this.f1655d));
                    break;
            }
            append = printWriter.append(" lastSuspendedTime=");
            j = this.f1656e;
            valueOf = String.valueOf(simpleDateFormat.format(new Date(this.f1656e)));
            append.println(new StringBuilder(String.valueOf(valueOf).length() + 21).append(j).append(" ").append(valueOf).toString());
        }
        if (this.f1659h > 0) {
            printWriter.append(str).append("lastFailedStatus=").append(C0825b.m3321a(this.f1658g));
            append = printWriter.append(" lastFailedTime=");
            j = this.f1659h;
            String valueOf2 = String.valueOf(simpleDateFormat.format(new Date(this.f1659h)));
            append.println(new StringBuilder(String.valueOf(valueOf2).length() + 21).append(j).append(" ").append(valueOf2).toString());
        }
    }

    /* renamed from: b */
    public void m3466b(int i) {
        this.f1653a.sendMessage(this.f1653a.obtainMessage(4, this.f1654b.get(), i));
    }

    /* renamed from: b */
    public boolean m3467b() {
        boolean z;
        synchronized (this.f1664m) {
            z = this.f1671t == 3;
        }
        return z;
    }

    /* renamed from: c */
    public boolean m3468c() {
        boolean z;
        synchronized (this.f1664m) {
            z = this.f1671t == 2;
        }
        return z;
    }

    protected String c_() {
        return "com.google.android.gms";
    }

    /* renamed from: d */
    public boolean mo1106d() {
        return false;
    }

    /* renamed from: e */
    public boolean m3470e() {
        return true;
    }

    /* renamed from: f */
    public boolean m3471f() {
        return false;
    }

    /* renamed from: g */
    public Intent m3472g() {
        throw new UnsupportedOperationException("Not a sign in API");
    }

    /* renamed from: h */
    public IBinder m3473h() {
        IBinder iBinder;
        synchronized (this.f1665n) {
            if (this.f1666o == null) {
                iBinder = null;
            } else {
                iBinder = this.f1666o.asBinder();
            }
        }
        return iBinder;
    }

    /* renamed from: i */
    protected abstract String mo905i();

    /* renamed from: j */
    protected abstract String mo906j();

    /* renamed from: m */
    protected final String m3476m() {
        return this.f1675x == null ? this.f1660i.getClass().getName() : this.f1675x;
    }

    /* renamed from: n */
    public final Context m3477n() {
        return this.f1660i;
    }

    /* renamed from: o */
    public Account mo901o() {
        return null;
    }

    /* renamed from: p */
    public final Account m3479p() {
        return mo901o() != null ? mo901o() : new Account("<<default account>>", "com.google");
    }

    /* renamed from: q */
    protected Bundle mo1052q() {
        return new Bundle();
    }

    /* renamed from: r */
    protected final void m3481r() {
        if (!m3467b()) {
            throw new IllegalStateException("Not connected. Call connect() and wait for onConnected() to be called.");
        }
    }

    /* renamed from: s */
    public Bundle m3482s() {
        return null;
    }

    /* renamed from: t */
    public final T m3483t() throws DeadObjectException {
        T t;
        synchronized (this.f1664m) {
            if (this.f1671t == 4) {
                throw new DeadObjectException();
            }
            m3481r();
            C0854b.m3432a(this.f1668q != null, (Object) "Client is connected but service is null");
            t = this.f1668q;
        }
        return t;
    }

    /* renamed from: u */
    public boolean m3484u() {
        return false;
    }

    /* renamed from: v */
    protected Set<Scope> mo902v() {
        return Collections.EMPTY_SET;
    }
}

package com.google.android.gms.common.stats;

import android.content.ComponentName;

/* renamed from: com.google.android.gms.common.stats.d */
public final class C0932d {
    /* renamed from: a */
    public static final ComponentName f1814a = new ComponentName("com.google.android.gms", "com.google.android.gms.common.stats.GmsCoreStatsService");
    /* renamed from: b */
    public static int f1815b = 0;
    /* renamed from: c */
    public static int f1816c = 1;
    /* renamed from: d */
    public static int f1817d = 2;
    /* renamed from: e */
    public static int f1818e = 4;
    /* renamed from: f */
    public static int f1819f = 8;
    /* renamed from: g */
    public static int f1820g = 16;
    /* renamed from: h */
    public static int f1821h = 32;
    /* renamed from: i */
    public static int f1822i = 1;
}

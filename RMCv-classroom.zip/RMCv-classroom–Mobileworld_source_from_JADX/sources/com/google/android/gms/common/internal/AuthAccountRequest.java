package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class AuthAccountRequest extends AbstractSafeParcelable {
    public static final Creator<AuthAccountRequest> CREATOR = new C0863h();
    /* renamed from: a */
    final int f1616a;
    /* renamed from: b */
    final IBinder f1617b;
    /* renamed from: c */
    final Scope[] f1618c;
    /* renamed from: d */
    Integer f1619d;
    /* renamed from: e */
    Integer f1620e;

    AuthAccountRequest(int i, IBinder iBinder, Scope[] scopeArr, Integer num, Integer num2) {
        this.f1616a = i;
        this.f1617b = iBinder;
        this.f1618c = scopeArr;
        this.f1619d = num;
        this.f1620e = num2;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0863h.m3503a(this, parcel, i);
    }
}

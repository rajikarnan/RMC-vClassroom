package com.google.android.gms.common.p022a;

import java.util.regex.Pattern;

/* renamed from: com.google.android.gms.common.a.f */
public final class C0799f {
    /* renamed from: a */
    private static Pattern f1541a = null;

    /* renamed from: a */
    public static int m3240a(int i) {
        return i / 1000;
    }
}

package com.google.android.gms.common.p022a;

import android.os.Build.VERSION;

/* renamed from: com.google.android.gms.common.a.g */
public final class C0800g {
    /* renamed from: a */
    public static boolean m3241a() {
        return C0800g.m3242a(11);
    }

    /* renamed from: a */
    private static boolean m3242a(int i) {
        return VERSION.SDK_INT >= i;
    }

    /* renamed from: b */
    public static boolean m3243b() {
        return C0800g.m3242a(13);
    }

    /* renamed from: c */
    public static boolean m3244c() {
        return C0800g.m3242a(14);
    }

    /* renamed from: d */
    public static boolean m3245d() {
        return C0800g.m3242a(16);
    }

    /* renamed from: e */
    public static boolean m3246e() {
        return C0800g.m3242a(18);
    }

    /* renamed from: f */
    public static boolean m3247f() {
        return C0800g.m3242a(19);
    }

    /* renamed from: g */
    public static boolean m3248g() {
        return C0800g.m3242a(20);
    }

    /* renamed from: h */
    public static boolean m3249h() {
        return C0800g.m3242a(21);
    }
}

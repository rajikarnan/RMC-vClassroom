package com.google.android.gms.common.p022a;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;
import android.util.Log;
import com.google.android.gms.common.C0927m;
import com.google.android.gms.p023d.ap;

/* renamed from: com.google.android.gms.common.a.k */
public final class C0804k {
    /* renamed from: a */
    public static boolean m3255a(Context context, int i) {
        boolean z = false;
        if (!C0804k.m3256a(context, i, "com.google.android.gms")) {
            return z;
        }
        try {
            return C0927m.m3777a(context).m3780a(context.getPackageManager(), context.getPackageManager().getPackageInfo("com.google.android.gms", 64));
        } catch (NameNotFoundException e) {
            if (!Log.isLoggable("UidVerifier", 3)) {
                return z;
            }
            Log.d("UidVerifier", "Package manager can't find google play services package, defaulting to false");
            return z;
        }
    }

    @TargetApi(19)
    /* renamed from: a */
    public static boolean m3256a(Context context, int i, String str) {
        return ap.m3890b(context).m3888a(i, str);
    }
}

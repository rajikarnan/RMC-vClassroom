package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.C0839j;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.C0849u.C0850a;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Collection;

public class GetServiceRequest extends AbstractSafeParcelable {
    public static final Creator<GetServiceRequest> CREATOR = new C0896o();
    /* renamed from: a */
    final int f1621a;
    /* renamed from: b */
    final int f1622b;
    /* renamed from: c */
    int f1623c;
    /* renamed from: d */
    String f1624d;
    /* renamed from: e */
    IBinder f1625e;
    /* renamed from: f */
    Scope[] f1626f;
    /* renamed from: g */
    Bundle f1627g;
    /* renamed from: h */
    Account f1628h;
    /* renamed from: i */
    long f1629i;

    public GetServiceRequest(int i) {
        this.f1621a = 3;
        this.f1623c = C0839j.f1598b;
        this.f1622b = i;
    }

    GetServiceRequest(int i, int i2, int i3, String str, IBinder iBinder, Scope[] scopeArr, Bundle bundle, Account account, long j) {
        this.f1621a = i;
        this.f1622b = i2;
        this.f1623c = i3;
        this.f1624d = str;
        if (i < 2) {
            this.f1628h = m3400a(iBinder);
        } else {
            this.f1625e = iBinder;
            this.f1628h = account;
        }
        this.f1626f = scopeArr;
        this.f1627g = bundle;
        this.f1629i = j;
    }

    /* renamed from: a */
    private Account m3400a(IBinder iBinder) {
        return iBinder != null ? C0851a.m3419a(C0850a.m3418a(iBinder)) : null;
    }

    /* renamed from: a */
    public GetServiceRequest m3401a(Account account) {
        this.f1628h = account;
        return this;
    }

    /* renamed from: a */
    public GetServiceRequest m3402a(Bundle bundle) {
        this.f1627g = bundle;
        return this;
    }

    /* renamed from: a */
    public GetServiceRequest m3403a(C0849u c0849u) {
        if (c0849u != null) {
            this.f1625e = c0849u.asBinder();
        }
        return this;
    }

    /* renamed from: a */
    public GetServiceRequest m3404a(String str) {
        this.f1624d = str;
        return this;
    }

    /* renamed from: a */
    public GetServiceRequest m3405a(Collection<Scope> collection) {
        this.f1626f = (Scope[]) collection.toArray(new Scope[collection.size()]);
        return this;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0896o.m3580a(this, parcel, i);
    }
}

package com.google.android.gms.common.p022a;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;

/* renamed from: com.google.android.gms.common.a.e */
public final class C0798e {
    /* renamed from: a */
    private static Boolean f1538a;
    /* renamed from: b */
    private static Boolean f1539b;
    /* renamed from: c */
    private static Boolean f1540c;

    @TargetApi(20)
    /* renamed from: a */
    public static boolean m3237a(Context context) {
        if (f1540c == null) {
            boolean z = C0800g.m3248g() && context.getPackageManager().hasSystemFeature("android.hardware.type.watch");
            f1540c = Boolean.valueOf(z);
        }
        return f1540c.booleanValue();
    }

    /* renamed from: a */
    public static boolean m3238a(Resources resources) {
        boolean z = false;
        if (resources == null) {
            return false;
        }
        if (f1538a == null) {
            boolean z2 = (resources.getConfiguration().screenLayout & 15) > 3;
            if ((C0800g.m3241a() && z2) || C0798e.m3239b(resources)) {
                z = true;
            }
            f1538a = Boolean.valueOf(z);
        }
        return f1538a.booleanValue();
    }

    @TargetApi(13)
    /* renamed from: b */
    private static boolean m3239b(Resources resources) {
        if (f1539b == null) {
            Configuration configuration = resources.getConfiguration();
            boolean z = C0800g.m3243b() && (configuration.screenLayout & 15) <= 3 && configuration.smallestScreenWidthDp >= 600;
            f1539b = Boolean.valueOf(z);
        }
        return f1539b.booleanValue();
    }
}

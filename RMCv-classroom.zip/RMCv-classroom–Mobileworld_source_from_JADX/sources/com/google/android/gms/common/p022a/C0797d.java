package com.google.android.gms.common.p022a;

/* renamed from: com.google.android.gms.common.a.d */
public final class C0797d implements C0796c {
    /* renamed from: a */
    private static C0797d f1537a;

    /* renamed from: b */
    public static synchronized C0796c m3235b() {
        C0796c c0796c;
        synchronized (C0797d.class) {
            if (f1537a == null) {
                f1537a = new C0797d();
            }
            c0796c = f1537a;
        }
        return c0796c;
    }

    /* renamed from: a */
    public long mo889a() {
        return System.currentTimeMillis();
    }
}

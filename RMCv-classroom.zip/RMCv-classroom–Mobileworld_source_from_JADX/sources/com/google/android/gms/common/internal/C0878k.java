package com.google.android.gms.common.internal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/* renamed from: com.google.android.gms.common.internal.k */
public abstract class C0878k {
    /* renamed from: a */
    public static final C0878k f1698a = C0878k.m3535a((CharSequence) "\t\n\u000b\f\r     　 ᠎ ").mo916a(C0878k.m3534a(' ', ' '));
    /* renamed from: b */
    public static final C0878k f1699b = C0878k.m3535a((CharSequence) "\t\n\u000b\f\r     　").mo916a(C0878k.m3534a(' ', ' ')).mo916a(C0878k.m3534a(' ', ' '));
    /* renamed from: c */
    public static final C0878k f1700c = C0878k.m3534a('\u0000', '');
    /* renamed from: d */
    public static final C0878k f1701d;
    /* renamed from: e */
    public static final C0878k f1702e = C0878k.m3534a('\t', '\r').mo916a(C0878k.m3534a('\u001c', ' ')).mo916a(C0878k.m3533a(' ')).mo916a(C0878k.m3533a('᠎')).mo916a(C0878k.m3534a(' ', ' ')).mo916a(C0878k.m3534a(' ', '​')).mo916a(C0878k.m3534a(' ', ' ')).mo916a(C0878k.m3533a(' ')).mo916a(C0878k.m3533a('　'));
    /* renamed from: f */
    public static final C0878k f1703f = new C08791();
    /* renamed from: g */
    public static final C0878k f1704g = new C08857();
    /* renamed from: h */
    public static final C0878k f1705h = new C08868();
    /* renamed from: i */
    public static final C0878k f1706i = new C08879();
    /* renamed from: j */
    public static final C0878k f1707j = new C0878k() {
        /* renamed from: b */
        public boolean mo915b(char c) {
            return Character.isLowerCase(c);
        }
    };
    /* renamed from: k */
    public static final C0878k f1708k = C0878k.m3534a('\u0000', '\u001f').mo916a(C0878k.m3534a('', ''));
    /* renamed from: l */
    public static final C0878k f1709l = C0878k.m3534a('\u0000', ' ').mo916a(C0878k.m3534a('', ' ')).mo916a(C0878k.m3533a('­')).mo916a(C0878k.m3534a('؀', '؃')).mo916a(C0878k.m3535a((CharSequence) "۝܏ ឴឵᠎")).mo916a(C0878k.m3534a(' ', '‏')).mo916a(C0878k.m3534a(' ', ' ')).mo916a(C0878k.m3534a(' ', '⁤')).mo916a(C0878k.m3534a('⁪', '⁯')).mo916a(C0878k.m3533a('　')).mo916a(C0878k.m3534a('?', '')).mo916a(C0878k.m3535a((CharSequence) "﻿￹￺￻"));
    /* renamed from: m */
    public static final C0878k f1710m = C0878k.m3534a('\u0000', 'ӹ').mo916a(C0878k.m3533a('־')).mo916a(C0878k.m3534a('א', 'ת')).mo916a(C0878k.m3533a('׳')).mo916a(C0878k.m3533a('״')).mo916a(C0878k.m3534a('؀', 'ۿ')).mo916a(C0878k.m3534a('ݐ', 'ݿ')).mo916a(C0878k.m3534a('฀', '๿')).mo916a(C0878k.m3534a('Ḁ', '₯')).mo916a(C0878k.m3534a('℀', '℺')).mo916a(C0878k.m3534a('ﭐ', '﷿')).mo916a(C0878k.m3534a('ﹰ', '﻿')).mo916a(C0878k.m3534a('｡', 'ￜ'));
    /* renamed from: n */
    public static final C0878k f1711n = new C0878k() {
        /* renamed from: a */
        public C0878k mo916a(C0878k c0878k) {
            C0854b.m3427a((Object) c0878k);
            return this;
        }

        /* renamed from: b */
        public boolean mo915b(char c) {
            return true;
        }

        /* renamed from: b */
        public boolean mo917b(CharSequence charSequence) {
            C0854b.m3427a((Object) charSequence);
            return true;
        }
    };
    /* renamed from: o */
    public static final C0878k f1712o = new C08802();

    /* renamed from: com.google.android.gms.common.internal.k$1 */
    class C08791 extends C0878k {
        C08791() {
        }

        /* renamed from: b */
        public boolean mo915b(char c) {
            return Character.isDigit(c);
        }
    }

    /* renamed from: com.google.android.gms.common.internal.k$2 */
    class C08802 extends C0878k {
        C08802() {
        }

        /* renamed from: a */
        public C0878k mo916a(C0878k c0878k) {
            return (C0878k) C0854b.m3427a((Object) c0878k);
        }

        /* renamed from: b */
        public boolean mo915b(char c) {
            return false;
        }

        /* renamed from: b */
        public boolean mo917b(CharSequence charSequence) {
            return charSequence.length() == 0;
        }
    }

    /* renamed from: com.google.android.gms.common.internal.k$3 */
    class C08813 extends C0878k {
        /* renamed from: p */
        final /* synthetic */ char f1713p;

        C08813(char c) {
            this.f1713p = c;
        }

        /* renamed from: a */
        public C0878k mo916a(C0878k c0878k) {
            return c0878k.mo915b(this.f1713p) ? c0878k : super.mo916a(c0878k);
        }

        /* renamed from: b */
        public boolean mo915b(char c) {
            return c == this.f1713p;
        }
    }

    /* renamed from: com.google.android.gms.common.internal.k$4 */
    class C08824 extends C0878k {
        /* renamed from: p */
        final /* synthetic */ char f1714p;
        /* renamed from: q */
        final /* synthetic */ char f1715q;

        C08824(char c, char c2) {
            this.f1714p = c;
            this.f1715q = c2;
        }

        /* renamed from: b */
        public boolean mo915b(char c) {
            return c == this.f1714p || c == this.f1715q;
        }
    }

    /* renamed from: com.google.android.gms.common.internal.k$5 */
    class C08835 extends C0878k {
        /* renamed from: p */
        final /* synthetic */ char[] f1716p;

        C08835(char[] cArr) {
            this.f1716p = cArr;
        }

        /* renamed from: b */
        public boolean mo915b(char c) {
            return Arrays.binarySearch(this.f1716p, c) >= 0;
        }
    }

    /* renamed from: com.google.android.gms.common.internal.k$6 */
    class C08846 extends C0878k {
        /* renamed from: p */
        final /* synthetic */ char f1717p;
        /* renamed from: q */
        final /* synthetic */ char f1718q;

        C08846(char c, char c2) {
            this.f1717p = c;
            this.f1718q = c2;
        }

        /* renamed from: b */
        public boolean mo915b(char c) {
            return this.f1717p <= c && c <= this.f1718q;
        }
    }

    /* renamed from: com.google.android.gms.common.internal.k$7 */
    class C08857 extends C0878k {
        C08857() {
        }

        /* renamed from: b */
        public boolean mo915b(char c) {
            return Character.isLetter(c);
        }
    }

    /* renamed from: com.google.android.gms.common.internal.k$8 */
    class C08868 extends C0878k {
        C08868() {
        }

        /* renamed from: b */
        public boolean mo915b(char c) {
            return Character.isLetterOrDigit(c);
        }
    }

    /* renamed from: com.google.android.gms.common.internal.k$9 */
    class C08879 extends C0878k {
        C08879() {
        }

        /* renamed from: b */
        public boolean mo915b(char c) {
            return Character.isUpperCase(c);
        }
    }

    /* renamed from: com.google.android.gms.common.internal.k$a */
    private static class C0888a extends C0878k {
        /* renamed from: p */
        List<C0878k> f1719p;

        C0888a(List<C0878k> list) {
            this.f1719p = list;
        }

        /* renamed from: a */
        public C0878k mo916a(C0878k c0878k) {
            List arrayList = new ArrayList(this.f1719p);
            arrayList.add((C0878k) C0854b.m3427a((Object) c0878k));
            return new C0888a(arrayList);
        }

        /* renamed from: b */
        public boolean mo915b(char c) {
            for (C0878k b : this.f1719p) {
                if (b.mo915b(c)) {
                    return true;
                }
            }
            return false;
        }
    }

    static {
        C0878k a = C0878k.m3534a('0', '9');
        C0878k c0878k = a;
        for (char c : "٠۰߀०০੦૦୦௦౦೦൦๐໐༠၀႐០᠐᥆᧐᭐᮰᱀᱐꘠꣐꤀꩐０".toCharArray()) {
            c0878k = c0878k.mo916a(C0878k.m3534a(c, (char) (c + 9)));
        }
        f1701d = c0878k;
    }

    /* renamed from: a */
    public static C0878k m3533a(char c) {
        return new C08813(c);
    }

    /* renamed from: a */
    public static C0878k m3534a(char c, char c2) {
        C0854b.m3435b(c2 >= c);
        return new C08846(c, c2);
    }

    /* renamed from: a */
    public static C0878k m3535a(CharSequence charSequence) {
        switch (charSequence.length()) {
            case 0:
                return f1712o;
            case 1:
                return C0878k.m3533a(charSequence.charAt(0));
            case 2:
                return new C08824(charSequence.charAt(0), charSequence.charAt(1));
            default:
                char[] toCharArray = charSequence.toString().toCharArray();
                Arrays.sort(toCharArray);
                return new C08835(toCharArray);
        }
    }

    /* renamed from: a */
    public C0878k mo916a(C0878k c0878k) {
        return new C0888a(Arrays.asList(new C0878k[]{this, (C0878k) C0854b.m3427a((Object) c0878k)}));
    }

    /* renamed from: b */
    public abstract boolean mo915b(char c);

    /* renamed from: b */
    public boolean mo917b(CharSequence charSequence) {
        for (int length = charSequence.length() - 1; length >= 0; length--) {
            if (!mo915b(charSequence.charAt(length))) {
                return false;
            }
        }
        return true;
    }
}

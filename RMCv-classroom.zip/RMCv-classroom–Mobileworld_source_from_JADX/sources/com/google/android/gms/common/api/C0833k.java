package com.google.android.gms.common.api;

import android.support.v4.p011e.C0222a;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.p023d.C0957e;

/* renamed from: com.google.android.gms.common.api.k */
public class C0833k implements C0809e {
    /* renamed from: a */
    private final Status f1583a;
    /* renamed from: b */
    private final C0222a<C0957e<?>, ConnectionResult> f1584b;

    public C0833k(Status status, C0222a<C0957e<?>, ConnectionResult> c0222a) {
        this.f1583a = status;
        this.f1584b = c0222a;
    }

    /* renamed from: a */
    public Status mo890a() {
        return this.f1583a;
    }
}

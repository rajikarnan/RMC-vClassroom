package com.google.android.gms.common.stats;

import android.os.SystemClock;
import android.support.v4.p011e.C0221i;
import android.util.Log;

/* renamed from: com.google.android.gms.common.stats.e */
public class C0933e {
    /* renamed from: a */
    private final long f1823a;
    /* renamed from: b */
    private final int f1824b;
    /* renamed from: c */
    private final C0221i<String, Long> f1825c;

    public C0933e() {
        this.f1823a = 60000;
        this.f1824b = 10;
        this.f1825c = new C0221i(10);
    }

    public C0933e(int i, long j) {
        this.f1823a = j;
        this.f1824b = i;
        this.f1825c = new C0221i();
    }

    /* renamed from: a */
    private void m3816a(long j, long j2) {
        for (int size = this.f1825c.size() - 1; size >= 0; size--) {
            if (j2 - ((Long) this.f1825c.m821c(size)).longValue() > j) {
                this.f1825c.m822d(size);
            }
        }
    }

    /* renamed from: a */
    public Long m3817a(String str) {
        Long l;
        long elapsedRealtime = SystemClock.elapsedRealtime();
        long j = this.f1823a;
        synchronized (this) {
            while (this.f1825c.size() >= this.f1824b) {
                m3816a(j, elapsedRealtime);
                j /= 2;
                Log.w("ConnectionTracker", "The max capacity " + this.f1824b + " is not enough. Current durationThreshold is: " + j);
            }
            l = (Long) this.f1825c.put(str, Long.valueOf(elapsedRealtime));
        }
        return l;
    }

    /* renamed from: b */
    public boolean m3818b(String str) {
        boolean z;
        synchronized (this) {
            z = this.f1825c.remove(str) != null;
        }
        return z;
    }
}

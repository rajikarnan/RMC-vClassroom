package com.google.android.gms.common.api;

import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import com.google.android.gms.common.api.GoogleApiClient.C0807b;
import com.google.android.gms.common.api.GoogleApiClient.C0808c;
import com.google.android.gms.common.internal.C0849u;
import com.google.android.gms.common.internal.C0854b;
import com.google.android.gms.common.internal.C0857i.C0869f;
import com.google.android.gms.common.internal.C0890l;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/* renamed from: com.google.android.gms.common.api.a */
public final class C0824a<O extends C0810a> {
    /* renamed from: a */
    private final C0816b<?, O> f1578a;
    /* renamed from: b */
    private final C0822i<?, O> f1579b = null;
    /* renamed from: c */
    private final C0820g<?> f1580c;
    /* renamed from: d */
    private final C0823j<?> f1581d;
    /* renamed from: e */
    private final String f1582e;

    /* renamed from: com.google.android.gms.common.api.a$a */
    public interface C0810a {

        /* renamed from: com.google.android.gms.common.api.a$a$a */
        public interface C0811a extends C0810a {
        }

        /* renamed from: com.google.android.gms.common.api.a$a$c */
        public interface C0812c extends C0810a {
        }

        /* renamed from: com.google.android.gms.common.api.a$a$b */
        public static final class C0813b implements C0812c {
            private C0813b() {
            }
        }

        /* renamed from: com.google.android.gms.common.api.a$a$d */
        public interface C0814d extends C0811a, C0812c {
        }
    }

    /* renamed from: com.google.android.gms.common.api.a$e */
    public static abstract class C0815e<T extends C0817c, O> {
        /* renamed from: a */
        public int m3295a() {
            return ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED;
        }

        /* renamed from: a */
        public List<Scope> m3296a(O o) {
            return Collections.emptyList();
        }
    }

    /* renamed from: com.google.android.gms.common.api.a$b */
    public static abstract class C0816b<T extends C0819f, O> extends C0815e<T, O> {
        /* renamed from: a */
        public abstract T mo987a(Context context, Looper looper, C0890l c0890l, O o, C0807b c0807b, C0808c c0808c);
    }

    /* renamed from: com.google.android.gms.common.api.a$c */
    public interface C0817c {
    }

    /* renamed from: com.google.android.gms.common.api.a$d */
    public static class C0818d<C extends C0817c> {
    }

    /* renamed from: com.google.android.gms.common.api.a$f */
    public interface C0819f extends C0817c {
        /* renamed from: a */
        void mo1093a();

        /* renamed from: a */
        void m3299a(C0869f c0869f);

        /* renamed from: a */
        void m3300a(C0849u c0849u, Set<Scope> set);

        /* renamed from: a */
        void m3301a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

        /* renamed from: b */
        boolean m3302b();

        /* renamed from: c */
        boolean m3303c();

        /* renamed from: d */
        boolean mo1106d();

        /* renamed from: e */
        boolean m3305e();

        /* renamed from: f */
        boolean m3306f();

        /* renamed from: g */
        Intent m3307g();

        /* renamed from: h */
        IBinder m3308h();
    }

    /* renamed from: com.google.android.gms.common.api.a$g */
    public static final class C0820g<C extends C0819f> extends C0818d<C> {
    }

    /* renamed from: com.google.android.gms.common.api.a$h */
    public interface C0821h<T extends IInterface> extends C0817c {
        /* renamed from: a */
        T m3309a(IBinder iBinder);

        /* renamed from: a */
        String m3310a();

        /* renamed from: a */
        void m3311a(int i, T t);

        /* renamed from: b */
        String m3312b();
    }

    /* renamed from: com.google.android.gms.common.api.a$i */
    public static abstract class C0822i<T extends C0821h, O> extends C0815e<T, O> {
        /* renamed from: b */
        public abstract int m3313b();

        /* renamed from: b */
        public abstract T m3314b(O o);
    }

    /* renamed from: com.google.android.gms.common.api.a$j */
    public static final class C0823j<C extends C0821h> extends C0818d<C> {
    }

    public <C extends C0819f> C0824a(String str, C0816b<C, O> c0816b, C0820g<C> c0820g) {
        C0854b.m3428a((Object) c0816b, (Object) "Cannot construct an Api with a null ClientBuilder");
        C0854b.m3428a((Object) c0820g, (Object) "Cannot construct an Api with a null ClientKey");
        this.f1582e = str;
        this.f1578a = c0816b;
        this.f1580c = c0820g;
        this.f1581d = null;
    }

    /* renamed from: a */
    public C0815e<?, O> m3315a() {
        return m3319e() ? null : this.f1578a;
    }

    /* renamed from: b */
    public C0816b<?, O> m3316b() {
        C0854b.m3432a(this.f1578a != null, (Object) "This API was constructed with a SimpleClientBuilder. Use getSimpleClientBuilder");
        return this.f1578a;
    }

    /* renamed from: c */
    public C0822i<?, O> m3317c() {
        C0854b.m3432a(false, (Object) "This API was constructed with a ClientBuilder. Use getClientBuilder");
        return null;
    }

    /* renamed from: d */
    public C0818d<?> m3318d() {
        if (this.f1580c != null) {
            return this.f1580c;
        }
        throw new IllegalStateException("This API was constructed with null client keys. This should not be possible.");
    }

    /* renamed from: e */
    public boolean m3319e() {
        return false;
    }

    /* renamed from: f */
    public String m3320f() {
        return this.f1582e;
    }
}

package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;

/* renamed from: com.google.android.gms.common.internal.h */
public class C0863h implements Creator<AuthAccountRequest> {
    /* renamed from: a */
    static void m3503a(AuthAccountRequest authAccountRequest, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3646a(parcel, 1, authAccountRequest.f1616a);
        C0907b.m3649a(parcel, 2, authAccountRequest.f1617b, false);
        C0907b.m3657a(parcel, 3, authAccountRequest.f1618c, i, false);
        C0907b.m3651a(parcel, 4, authAccountRequest.f1619d, false);
        C0907b.m3651a(parcel, 5, authAccountRequest.f1620e, false);
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public AuthAccountRequest m3504a(Parcel parcel) {
        Integer num = null;
        int b = C0906a.m3626b(parcel);
        int i = 0;
        Integer num2 = null;
        Scope[] scopeArr = null;
        IBinder iBinder = null;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    i = C0906a.m3632e(parcel, a);
                    break;
                case 2:
                    iBinder = C0906a.m3638k(parcel, a);
                    break;
                case 3:
                    scopeArr = (Scope[]) C0906a.m3628b(parcel, a, Scope.CREATOR);
                    break;
                case 4:
                    num2 = C0906a.m3633f(parcel, a);
                    break;
                case 5:
                    num = C0906a.m3633f(parcel, a);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new AuthAccountRequest(i, iBinder, scopeArr, num2, num);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public AuthAccountRequest[] m3505a(int i) {
        return new AuthAccountRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m3504a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m3505a(i);
    }
}

package com.google.android.gms.common.internal.safeparcel;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import java.util.ArrayList;

/* renamed from: com.google.android.gms.common.internal.safeparcel.a */
public class C0906a {

    /* renamed from: com.google.android.gms.common.internal.safeparcel.a$a */
    public static class C0905a extends RuntimeException {
        public C0905a(String str, Parcel parcel) {
            int dataPosition = parcel.dataPosition();
            super(new StringBuilder(String.valueOf(str).length() + 41).append(str).append(" Parcel: pos=").append(dataPosition).append(" size=").append(parcel.dataSize()).toString());
        }
    }

    /* renamed from: a */
    public static int m3620a(int i) {
        return 65535 & i;
    }

    /* renamed from: a */
    public static int m3621a(Parcel parcel) {
        return parcel.readInt();
    }

    /* renamed from: a */
    public static int m3622a(Parcel parcel, int i) {
        return (i & -65536) != -65536 ? (i >> 16) & 65535 : parcel.readInt();
    }

    /* renamed from: a */
    public static <T extends Parcelable> T m3623a(Parcel parcel, int i, Creator<T> creator) {
        int a = C0906a.m3622a(parcel, i);
        int dataPosition = parcel.dataPosition();
        if (a == 0) {
            return null;
        }
        Parcelable parcelable = (Parcelable) creator.createFromParcel(parcel);
        parcel.setDataPosition(a + dataPosition);
        return parcelable;
    }

    /* renamed from: a */
    private static void m3624a(Parcel parcel, int i, int i2) {
        int a = C0906a.m3622a(parcel, i);
        if (a != i2) {
            String valueOf = String.valueOf(Integer.toHexString(a));
            throw new C0905a(new StringBuilder(String.valueOf(valueOf).length() + 46).append("Expected size ").append(i2).append(" got ").append(a).append(" (0x").append(valueOf).append(")").toString(), parcel);
        }
    }

    /* renamed from: a */
    private static void m3625a(Parcel parcel, int i, int i2, int i3) {
        if (i2 != i3) {
            String valueOf = String.valueOf(Integer.toHexString(i2));
            throw new C0905a(new StringBuilder(String.valueOf(valueOf).length() + 46).append("Expected size ").append(i3).append(" got ").append(i2).append(" (0x").append(valueOf).append(")").toString(), parcel);
        }
    }

    /* renamed from: b */
    public static int m3626b(Parcel parcel) {
        int a = C0906a.m3621a(parcel);
        int a2 = C0906a.m3622a(parcel, a);
        int dataPosition = parcel.dataPosition();
        if (C0906a.m3620a(a) != 20293) {
            String str = "Expected object header. Got 0x";
            String valueOf = String.valueOf(Integer.toHexString(a));
            throw new C0905a(valueOf.length() != 0 ? str.concat(valueOf) : new String(str), parcel);
        }
        a = dataPosition + a2;
        if (a >= dataPosition && a <= parcel.dataSize()) {
            return a;
        }
        throw new C0905a("Size read is invalid start=" + dataPosition + " end=" + a, parcel);
    }

    /* renamed from: b */
    public static void m3627b(Parcel parcel, int i) {
        parcel.setDataPosition(C0906a.m3622a(parcel, i) + parcel.dataPosition());
    }

    /* renamed from: b */
    public static <T> T[] m3628b(Parcel parcel, int i, Creator<T> creator) {
        int a = C0906a.m3622a(parcel, i);
        int dataPosition = parcel.dataPosition();
        if (a == 0) {
            return null;
        }
        T[] createTypedArray = parcel.createTypedArray(creator);
        parcel.setDataPosition(a + dataPosition);
        return createTypedArray;
    }

    /* renamed from: c */
    public static <T> ArrayList<T> m3629c(Parcel parcel, int i, Creator<T> creator) {
        int a = C0906a.m3622a(parcel, i);
        int dataPosition = parcel.dataPosition();
        if (a == 0) {
            return null;
        }
        ArrayList<T> createTypedArrayList = parcel.createTypedArrayList(creator);
        parcel.setDataPosition(a + dataPosition);
        return createTypedArrayList;
    }

    /* renamed from: c */
    public static boolean m3630c(Parcel parcel, int i) {
        C0906a.m3624a(parcel, i, 4);
        return parcel.readInt() != 0;
    }

    /* renamed from: d */
    public static short m3631d(Parcel parcel, int i) {
        C0906a.m3624a(parcel, i, 4);
        return (short) parcel.readInt();
    }

    /* renamed from: e */
    public static int m3632e(Parcel parcel, int i) {
        C0906a.m3624a(parcel, i, 4);
        return parcel.readInt();
    }

    /* renamed from: f */
    public static Integer m3633f(Parcel parcel, int i) {
        int a = C0906a.m3622a(parcel, i);
        if (a == 0) {
            return null;
        }
        C0906a.m3625a(parcel, i, a, 4);
        return Integer.valueOf(parcel.readInt());
    }

    /* renamed from: g */
    public static long m3634g(Parcel parcel, int i) {
        C0906a.m3624a(parcel, i, 8);
        return parcel.readLong();
    }

    /* renamed from: h */
    public static float m3635h(Parcel parcel, int i) {
        C0906a.m3624a(parcel, i, 4);
        return parcel.readFloat();
    }

    /* renamed from: i */
    public static double m3636i(Parcel parcel, int i) {
        C0906a.m3624a(parcel, i, 8);
        return parcel.readDouble();
    }

    /* renamed from: j */
    public static String m3637j(Parcel parcel, int i) {
        int a = C0906a.m3622a(parcel, i);
        int dataPosition = parcel.dataPosition();
        if (a == 0) {
            return null;
        }
        String readString = parcel.readString();
        parcel.setDataPosition(a + dataPosition);
        return readString;
    }

    /* renamed from: k */
    public static IBinder m3638k(Parcel parcel, int i) {
        int a = C0906a.m3622a(parcel, i);
        int dataPosition = parcel.dataPosition();
        if (a == 0) {
            return null;
        }
        IBinder readStrongBinder = parcel.readStrongBinder();
        parcel.setDataPosition(a + dataPosition);
        return readStrongBinder;
    }

    /* renamed from: l */
    public static Bundle m3639l(Parcel parcel, int i) {
        int a = C0906a.m3622a(parcel, i);
        int dataPosition = parcel.dataPosition();
        if (a == 0) {
            return null;
        }
        Bundle readBundle = parcel.readBundle();
        parcel.setDataPosition(a + dataPosition);
        return readBundle;
    }

    /* renamed from: m */
    public static int[] m3640m(Parcel parcel, int i) {
        int a = C0906a.m3622a(parcel, i);
        int dataPosition = parcel.dataPosition();
        if (a == 0) {
            return null;
        }
        int[] createIntArray = parcel.createIntArray();
        parcel.setDataPosition(a + dataPosition);
        return createIntArray;
    }

    /* renamed from: n */
    public static ArrayList<Integer> m3641n(Parcel parcel, int i) {
        int a = C0906a.m3622a(parcel, i);
        int dataPosition = parcel.dataPosition();
        if (a == 0) {
            return null;
        }
        ArrayList<Integer> arrayList = new ArrayList();
        int readInt = parcel.readInt();
        for (int i2 = 0; i2 < readInt; i2++) {
            arrayList.add(Integer.valueOf(parcel.readInt()));
        }
        parcel.setDataPosition(dataPosition + a);
        return arrayList;
    }
}

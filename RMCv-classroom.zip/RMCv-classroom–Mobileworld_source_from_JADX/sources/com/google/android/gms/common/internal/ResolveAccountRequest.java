package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class ResolveAccountRequest extends AbstractSafeParcelable {
    public static final Creator<ResolveAccountRequest> CREATOR = new C0855c();
    /* renamed from: a */
    final int f1630a;
    /* renamed from: b */
    private final Account f1631b;
    /* renamed from: c */
    private final int f1632c;
    /* renamed from: d */
    private final GoogleSignInAccount f1633d;

    ResolveAccountRequest(int i, Account account, int i2, GoogleSignInAccount googleSignInAccount) {
        this.f1630a = i;
        this.f1631b = account;
        this.f1632c = i2;
        this.f1633d = googleSignInAccount;
    }

    public ResolveAccountRequest(Account account, int i, GoogleSignInAccount googleSignInAccount) {
        this(2, account, i, googleSignInAccount);
    }

    /* renamed from: a */
    public Account m3406a() {
        return this.f1631b;
    }

    /* renamed from: b */
    public int m3407b() {
        return this.f1632c;
    }

    /* renamed from: c */
    public GoogleSignInAccount m3408c() {
        return this.f1633d;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0855c.m3437a(this, parcel, i);
    }
}

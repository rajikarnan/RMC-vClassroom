package com.google.android.gms.common;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.Notification;
import android.app.Notification.BigTextStyle;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Build.VERSION;
import android.support.v4.app.C0154q;
import android.support.v4.app.Fragment;
import android.support.v4.app.ag.C0084d;
import android.util.TypedValue;
import com.google.android.gms.C0785a.C0780a;
import com.google.android.gms.C0785a.C0781b;
import com.google.android.gms.common.internal.C0854b;
import com.google.android.gms.common.internal.C0891m;
import com.google.android.gms.common.internal.C0892n;
import com.google.android.gms.common.p022a.C0798e;
import com.google.android.gms.common.p022a.C0800g;

/* renamed from: com.google.android.gms.common.e */
public final class C0845e extends C0844l {
    @Deprecated
    /* renamed from: a */
    public static final int f1611a = C0844l.f1603b;

    private C0845e() {
    }

    @Deprecated
    /* renamed from: a */
    public static int m3386a(Context context) {
        return C0844l.m3374b(context);
    }

    @TargetApi(14)
    /* renamed from: a */
    public static Dialog m3387a(int i, Activity activity, C0892n c0892n, OnCancelListener onCancelListener) {
        Builder builder = null;
        if (i == 0) {
            return null;
        }
        if (C0798e.m3237a((Context) activity) && i == 2) {
            i = 42;
        }
        if (C0845e.m3394a(activity, i)) {
            i = 18;
        }
        if (C0800g.m3244c()) {
            TypedValue typedValue = new TypedValue();
            activity.getTheme().resolveAttribute(16843529, typedValue, true);
            if ("Theme.Dialog.Alert".equals(activity.getResources().getResourceEntryName(typedValue.resourceId))) {
                builder = new Builder(activity, 5);
            }
        }
        if (builder == null) {
            builder = new Builder(activity);
        }
        builder.setMessage(C0891m.m3569a(activity, i, C0844l.m3382f(activity)));
        if (onCancelListener != null) {
            builder.setOnCancelListener(onCancelListener);
        }
        CharSequence c = C0891m.m3572c(activity, i);
        if (c != null) {
            builder.setPositiveButton(c, c0892n);
        }
        c = C0891m.m3568a(activity, i);
        if (c != null) {
            builder.setTitle(c);
        }
        return builder.create();
    }

    @Deprecated
    /* renamed from: a */
    public static PendingIntent m3388a(int i, Context context, int i2) {
        return C0844l.m3375b(i, context, i2);
    }

    /* renamed from: a */
    static void m3389a(int i, Context context, PendingIntent pendingIntent) {
        C0845e.m3390a(i, context, null, pendingIntent);
    }

    @TargetApi(20)
    /* renamed from: a */
    private static void m3390a(int i, Context context, String str, PendingIntent pendingIntent) {
        Notification build;
        int i2;
        Resources resources = context.getResources();
        String f = C0844l.m3382f(context);
        CharSequence b = C0891m.m3570b(context, i);
        if (b == null) {
            b = resources.getString(C0781b.common_google_play_services_notification_ticker);
        }
        CharSequence b2 = C0891m.m3571b(context, i, f);
        if (C0798e.m3237a(context)) {
            C0854b.m3431a(C0800g.m3245d());
            build = new Notification.Builder(context).setSmallIcon(C0780a.common_ic_googleplayservices).setPriority(2).setAutoCancel(true).setStyle(new BigTextStyle().bigText(new StringBuilder((String.valueOf(b).length() + 1) + String.valueOf(b2).length()).append(b).append(" ").append(b2).toString())).addAction(C0780a.common_full_open_on_phone, resources.getString(C0781b.common_open_on_phone), pendingIntent).build();
        } else {
            CharSequence string = resources.getString(C0781b.common_google_play_services_notification_ticker);
            if (C0800g.m3241a()) {
                Notification build2;
                Notification.Builder autoCancel = new Notification.Builder(context).setSmallIcon(17301642).setContentTitle(b).setContentText(b2).setContentIntent(pendingIntent).setTicker(string).setAutoCancel(true);
                if (C0800g.m3248g()) {
                    autoCancel.setLocalOnly(true);
                }
                if (C0800g.m3245d()) {
                    autoCancel.setStyle(new BigTextStyle().bigText(b2));
                    build2 = autoCancel.build();
                } else {
                    build2 = autoCancel.getNotification();
                }
                if (VERSION.SDK_INT == 19) {
                    build2.extras.putBoolean("android.support.localOnly", true);
                }
                build = build2;
            } else {
                build = new C0084d(context).setSmallIcon(17301642).setTicker(string).setWhen(System.currentTimeMillis()).setAutoCancel(true).setContentIntent(pendingIntent).setContentTitle(b).setContentText(b2).build();
            }
        }
        if (C0844l.m3371a(i)) {
            f.set(false);
            i2 = 10436;
        } else {
            i2 = 39789;
        }
        NotificationManager notificationManager = (NotificationManager) context.getSystemService("notification");
        if (str != null) {
            notificationManager.notify(str, i2, build);
        } else {
            notificationManager.notify(i2, build);
        }
    }

    @TargetApi(11)
    /* renamed from: a */
    public static void m3391a(Activity activity, OnCancelListener onCancelListener, String str, Dialog dialog) {
        boolean z;
        try {
            z = activity instanceof C0154q;
        } catch (NoClassDefFoundError e) {
            z = false;
        }
        if (z) {
            C0846f.m3395a(dialog, onCancelListener).show(((C0154q) activity).getSupportFragmentManager(), str);
        } else if (C0800g.m3241a()) {
            C0805a.m3257a(dialog, onCancelListener).show(activity.getFragmentManager(), str);
        } else {
            throw new RuntimeException("This Activity does not support Fragments.");
        }
    }

    @Deprecated
    /* renamed from: a */
    public static boolean m3392a(int i, Activity activity, int i2, OnCancelListener onCancelListener) {
        return C0845e.m3393a(i, activity, null, i2, onCancelListener);
    }

    /* renamed from: a */
    public static boolean m3393a(int i, Activity activity, Fragment fragment, int i2, OnCancelListener onCancelListener) {
        Intent a = C0840b.m3355a().mo894a((Context) activity, i, "d");
        Dialog a2 = C0845e.m3387a(i, activity, fragment == null ? C0892n.m3573a(activity, a, i2) : C0892n.m3574a(fragment, a, i2), onCancelListener);
        if (a2 == null) {
            return false;
        }
        C0845e.m3391a(activity, onCancelListener, "GooglePlayServicesErrorDialog", a2);
        return true;
    }

    @Deprecated
    /* renamed from: a */
    public static boolean m3394a(Context context, int i) {
        return C0844l.m3379c(context, i);
    }
}

package com.google.android.gms.common.api;

import android.content.Context;
import com.google.android.gms.common.api.C0824a.C0810a;
import com.google.android.gms.p023d.C0957e;
import com.google.android.gms.p023d.C1012u;
import com.google.android.gms.p023d.ae;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/* renamed from: com.google.android.gms.common.api.l */
public abstract class C0835l<O extends C0810a> {
    /* renamed from: a */
    private final Context f1586a;
    /* renamed from: b */
    private final ae f1587b;
    /* renamed from: c */
    private final C0824a<O> f1588c;
    /* renamed from: d */
    private final O f1589d;
    /* renamed from: e */
    private final C0957e<O> f1590e;
    /* renamed from: f */
    private final int f1591f;
    /* renamed from: g */
    private final C1012u f1592g;
    /* renamed from: h */
    private final AtomicBoolean f1593h;
    /* renamed from: i */
    private final AtomicInteger f1594i;

    /* renamed from: a */
    public void m3332a() {
        boolean z = true;
        if (!this.f1593h.getAndSet(true)) {
            this.f1587b.m3832a();
            C1012u c1012u = this.f1592g;
            int i = this.f1591f;
            if (this.f1594i.get() <= 0) {
                z = false;
            }
            c1012u.m4236a(i, z);
        }
    }

    /* renamed from: b */
    public C0824a<O> m3333b() {
        return this.f1588c;
    }

    /* renamed from: c */
    public O m3334c() {
        return this.f1589d;
    }

    /* renamed from: d */
    public C0957e<O> m3335d() {
        return this.f1590e;
    }

    /* renamed from: e */
    public Context m3336e() {
        return this.f1586a;
    }
}

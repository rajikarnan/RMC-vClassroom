package com.google.android.gms.common;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import com.google.android.gms.common.internal.C0854b;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/* renamed from: com.google.android.gms.common.h */
public class C0847h implements ServiceConnection {
    /* renamed from: a */
    boolean f1614a = false;
    /* renamed from: b */
    private final BlockingQueue<IBinder> f1615b = new LinkedBlockingQueue();

    /* renamed from: a */
    public IBinder m3396a(long j, TimeUnit timeUnit) throws InterruptedException, TimeoutException {
        C0854b.m3434b("BlockingServiceConnection.getServiceWithTimeout() called on main thread");
        if (this.f1614a) {
            throw new IllegalStateException("Cannot call get on this connection more than once");
        }
        this.f1614a = true;
        IBinder iBinder = (IBinder) this.f1615b.poll(j, timeUnit);
        if (iBinder != null) {
            return iBinder;
        }
        throw new TimeoutException("Timed out waiting for the service connection");
    }

    public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        this.f1615b.add(iBinder);
    }

    public void onServiceDisconnected(ComponentName componentName) {
    }
}

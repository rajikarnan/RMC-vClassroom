package com.google.android.gms.common.api;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import com.google.android.gms.common.C0840b;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.p023d.C1012u;

public class GoogleApiActivity extends Activity implements OnCancelListener {
    /* renamed from: a */
    protected int f1546a = 0;

    /* renamed from: a */
    public static PendingIntent m3258a(Context context, PendingIntent pendingIntent, int i) {
        return m3259a(context, pendingIntent, i, true);
    }

    /* renamed from: a */
    public static PendingIntent m3259a(Context context, PendingIntent pendingIntent, int i, boolean z) {
        return PendingIntent.getActivity(context, 0, m3262b(context, pendingIntent, i, z), 134217728);
    }

    /* renamed from: a */
    private void m3260a() {
        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            Log.e("GoogleApiActivity", "Activity started without extras");
            finish();
            return;
        }
        PendingIntent pendingIntent = (PendingIntent) extras.get("pending_intent");
        Integer num = (Integer) extras.get("error_code");
        if (pendingIntent == null && num == null) {
            Log.e("GoogleApiActivity", "Activity started without resolution");
            finish();
        } else if (pendingIntent != null) {
            try {
                startIntentSenderForResult(pendingIntent.getIntentSender(), 1, null, 0, 0, 0);
                this.f1546a = 1;
            } catch (Throwable e) {
                Log.e("GoogleApiActivity", "Failed to launch pendingIntent", e);
                finish();
            }
        } else {
            C0840b.m3355a().m3365a((Activity) this, num.intValue(), 2, (OnCancelListener) this);
            this.f1546a = 1;
        }
    }

    /* renamed from: a */
    private void m3261a(int i, C1012u c1012u) {
        switch (i) {
            case -1:
                c1012u.m4240b();
                return;
            case 0:
                c1012u.m4241b(new ConnectionResult(13, null), getIntent().getIntExtra("failing_client_id", -1));
                return;
            default:
                return;
        }
    }

    /* renamed from: b */
    public static Intent m3262b(Context context, PendingIntent pendingIntent, int i, boolean z) {
        Intent intent = new Intent(context, GoogleApiActivity.class);
        intent.putExtra("pending_intent", pendingIntent);
        intent.putExtra("failing_client_id", i);
        intent.putExtra("notify_manager", z);
        return intent;
    }

    /* renamed from: a */
    protected void m3263a(int i) {
        setResult(i);
    }

    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 1) {
            boolean booleanExtra = getIntent().getBooleanExtra("notify_manager", true);
            this.f1546a = 0;
            C1012u a = C1012u.m4220a();
            m3263a(i2);
            if (booleanExtra) {
                m3261a(i2, a);
            }
        } else if (i == 2) {
            this.f1546a = 0;
            m3263a(i2);
        }
        finish();
    }

    public void onCancel(DialogInterface dialogInterface) {
        this.f1546a = 0;
        setResult(0);
        finish();
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (bundle != null) {
            this.f1546a = bundle.getInt("resolution");
        }
        if (this.f1546a != 1) {
            m3260a();
        }
    }

    protected void onSaveInstanceState(Bundle bundle) {
        bundle.putInt("resolution", this.f1546a);
        super.onSaveInstanceState(bundle);
    }
}

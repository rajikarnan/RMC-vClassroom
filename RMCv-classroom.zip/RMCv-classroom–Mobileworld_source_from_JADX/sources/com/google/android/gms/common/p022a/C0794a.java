package com.google.android.gms.common.p022a;

import android.support.v4.p011e.C0222a;
import java.util.AbstractSet;
import java.util.Collection;
import java.util.Iterator;

/* renamed from: com.google.android.gms.common.a.a */
public class C0794a<E> extends AbstractSet<E> {
    /* renamed from: a */
    private final C0222a<E, E> f1536a = new C0222a();

    /* renamed from: a */
    public boolean m3231a(C0794a<? extends E> c0794a) {
        int size = size();
        this.f1536a.m818a(c0794a.f1536a);
        return size() > size;
    }

    public boolean add(E e) {
        if (this.f1536a.containsKey(e)) {
            return false;
        }
        this.f1536a.put(e, e);
        return true;
    }

    public boolean addAll(Collection<? extends E> collection) {
        return collection instanceof C0794a ? m3231a((C0794a) collection) : super.addAll(collection);
    }

    public void clear() {
        this.f1536a.clear();
    }

    public boolean contains(Object obj) {
        return this.f1536a.containsKey(obj);
    }

    public Iterator<E> iterator() {
        return this.f1536a.keySet().iterator();
    }

    public boolean remove(Object obj) {
        if (!this.f1536a.containsKey(obj)) {
            return false;
        }
        this.f1536a.remove(obj);
        return true;
    }

    public int size() {
        return this.f1536a.size();
    }
}

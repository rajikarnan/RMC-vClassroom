package com.google.android.gms.common.api;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.C0854b;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public final class Scope extends AbstractSafeParcelable {
    public static final Creator<Scope> CREATOR = new C0837n();
    /* renamed from: a */
    final int f1566a;
    /* renamed from: b */
    private final String f1567b;

    Scope(int i, String str) {
        C0854b.m3430a(str, (Object) "scopeUri must not be null or empty");
        this.f1566a = i;
        this.f1567b = str;
    }

    public Scope(String str) {
        this(1, str);
    }

    /* renamed from: a */
    public String m3286a() {
        return this.f1567b;
    }

    public boolean equals(Object obj) {
        return this == obj ? true : !(obj instanceof Scope) ? false : this.f1567b.equals(((Scope) obj).f1567b);
    }

    public int hashCode() {
        return this.f1567b.hashCode();
    }

    public String toString() {
        return this.f1567b;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0837n.m3338a(this, parcel, i);
    }
}

package com.google.android.gms.common.internal;

import android.content.Context;
import android.content.res.Resources;
import com.google.android.gms.C0785a.C0781b;

/* renamed from: com.google.android.gms.common.internal.f */
public class C0861f {
    /* renamed from: a */
    private final Resources f1680a;
    /* renamed from: b */
    private final String f1681b = this.f1680a.getResourcePackageName(C0781b.common_google_play_services_unknown_issue);

    public C0861f(Context context) {
        C0854b.m3427a((Object) context);
        this.f1680a = context.getResources();
    }

    /* renamed from: a */
    public String m3499a(String str) {
        int identifier = this.f1680a.getIdentifier(str, "string", this.f1681b);
        return identifier == 0 ? null : this.f1680a.getString(identifier);
    }
}

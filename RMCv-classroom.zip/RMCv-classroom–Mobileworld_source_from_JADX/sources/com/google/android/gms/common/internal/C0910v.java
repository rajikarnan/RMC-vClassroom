package com.google.android.gms.common.internal;

import android.os.IInterface;
import android.os.RemoteException;

/* renamed from: com.google.android.gms.common.internal.v */
public interface C0910v extends IInterface {
    /* renamed from: a */
    void m3668a() throws RemoteException;
}

package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.C0906a;
import com.google.android.gms.common.internal.safeparcel.C0906a.C0905a;
import com.google.android.gms.common.internal.safeparcel.C0907b;

/* renamed from: com.google.android.gms.common.internal.g */
public class C0862g implements Creator<ValidateAccountRequest> {
    /* renamed from: a */
    static void m3500a(ValidateAccountRequest validateAccountRequest, Parcel parcel, int i) {
        int a = C0907b.m3642a(parcel);
        C0907b.m3646a(parcel, 1, validateAccountRequest.f1639a);
        C0907b.m3646a(parcel, 2, validateAccountRequest.m3413a());
        C0907b.m3649a(parcel, 3, validateAccountRequest.f1640b, false);
        C0907b.m3657a(parcel, 4, validateAccountRequest.m3414b(), i, false);
        C0907b.m3648a(parcel, 5, validateAccountRequest.m3416d(), false);
        C0907b.m3652a(parcel, 6, validateAccountRequest.m3415c(), false);
        C0907b.m3643a(parcel, a);
    }

    /* renamed from: a */
    public ValidateAccountRequest m3501a(Parcel parcel) {
        int i = 0;
        String str = null;
        int b = C0906a.m3626b(parcel);
        Bundle bundle = null;
        Scope[] scopeArr = null;
        IBinder iBinder = null;
        int i2 = 0;
        while (parcel.dataPosition() < b) {
            int a = C0906a.m3621a(parcel);
            switch (C0906a.m3620a(a)) {
                case 1:
                    i2 = C0906a.m3632e(parcel, a);
                    break;
                case 2:
                    i = C0906a.m3632e(parcel, a);
                    break;
                case 3:
                    iBinder = C0906a.m3638k(parcel, a);
                    break;
                case 4:
                    scopeArr = (Scope[]) C0906a.m3628b(parcel, a, Scope.CREATOR);
                    break;
                case 5:
                    bundle = C0906a.m3639l(parcel, a);
                    break;
                case 6:
                    str = C0906a.m3637j(parcel, a);
                    break;
                default:
                    C0906a.m3627b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new ValidateAccountRequest(i2, i, iBinder, scopeArr, bundle, str);
        }
        throw new C0905a("Overread allowed size end=" + b, parcel);
    }

    /* renamed from: a */
    public ValidateAccountRequest[] m3502a(int i) {
        return new ValidateAccountRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m3501a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m3502a(i);
    }
}

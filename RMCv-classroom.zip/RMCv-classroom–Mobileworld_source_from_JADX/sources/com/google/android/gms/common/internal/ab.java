package com.google.android.gms.common.internal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class ab {

    /* renamed from: com.google.android.gms.common.internal.ab$a */
    public static final class C0853a {
        /* renamed from: a */
        private final List<String> f1650a;
        /* renamed from: b */
        private final Object f1651b;

        private C0853a(Object obj) {
            this.f1651b = C0854b.m3427a(obj);
            this.f1650a = new ArrayList();
        }

        /* renamed from: a */
        public C0853a m3423a(String str, Object obj) {
            List list = this.f1650a;
            String str2 = (String) C0854b.m3427a((Object) str);
            String valueOf = String.valueOf(String.valueOf(obj));
            list.add(new StringBuilder((String.valueOf(str2).length() + 1) + String.valueOf(valueOf).length()).append(str2).append("=").append(valueOf).toString());
            return this;
        }

        public String toString() {
            StringBuilder append = new StringBuilder(100).append(this.f1651b.getClass().getSimpleName()).append('{');
            int size = this.f1650a.size();
            for (int i = 0; i < size; i++) {
                append.append((String) this.f1650a.get(i));
                if (i < size - 1) {
                    append.append(", ");
                }
            }
            return append.append('}').toString();
        }
    }

    /* renamed from: a */
    public static int m3424a(Object... objArr) {
        return Arrays.hashCode(objArr);
    }

    /* renamed from: a */
    public static C0853a m3425a(Object obj) {
        return new C0853a(obj);
    }

    /* renamed from: a */
    public static boolean m3426a(Object obj, Object obj2) {
        return obj == obj2 || (obj != null && obj.equals(obj2));
    }
}

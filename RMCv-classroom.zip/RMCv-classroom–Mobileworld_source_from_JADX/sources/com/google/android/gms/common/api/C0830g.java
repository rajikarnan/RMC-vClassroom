package com.google.android.gms.common.api;

/* renamed from: com.google.android.gms.common.api.g */
public abstract class C0830g<R extends C0809e> implements C0829f<R> {
    /* renamed from: a */
    public abstract void m3327a(Status status);

    /* renamed from: b */
    public abstract void m3328b(R r);
}

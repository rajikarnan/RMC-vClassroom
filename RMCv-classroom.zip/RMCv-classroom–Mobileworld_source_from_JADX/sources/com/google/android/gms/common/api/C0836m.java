package com.google.android.gms.common.api;

import java.util.Map;
import java.util.WeakHashMap;

/* renamed from: com.google.android.gms.common.api.m */
public abstract class C0836m {
    /* renamed from: a */
    private static final Map<Object, C0836m> f1595a = new WeakHashMap();
    /* renamed from: b */
    private static final Object f1596b = new Object();

    /* renamed from: a */
    public abstract void m3337a(int i);
}

package com.google.android.gms.common.p022a;

import com.google.android.gms.common.internal.C0878k;
import java.util.regex.Pattern;

/* renamed from: com.google.android.gms.common.a.i */
public class C0802i {
    /* renamed from: a */
    private static final Pattern f1543a = Pattern.compile("\\$\\{(.*?)\\}");

    /* renamed from: a */
    public static boolean m3252a(String str) {
        return str == null || C0878k.f1698a.mo917b((CharSequence) str);
    }
}

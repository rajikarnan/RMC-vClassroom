package com.google.android.gms.common.api;

import android.accounts.Account;
import android.content.Context;
import android.os.Bundle;
import android.os.Looper;
import android.support.v4.p011e.C0222a;
import android.view.View;
import com.google.android.gms.common.C0840b;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0824a.C0810a;
import com.google.android.gms.common.api.C0824a.C0810a.C0812c;
import com.google.android.gms.common.api.C0824a.C0816b;
import com.google.android.gms.common.api.C0824a.C0817c;
import com.google.android.gms.common.api.C0824a.C0818d;
import com.google.android.gms.common.api.C0824a.C0819f;
import com.google.android.gms.common.api.C0824a.C0821h;
import com.google.android.gms.common.api.C0824a.C0822i;
import com.google.android.gms.common.internal.C0854b;
import com.google.android.gms.common.internal.C0860e;
import com.google.android.gms.common.internal.C0890l;
import com.google.android.gms.common.internal.C0890l.C0889a;
import com.google.android.gms.p023d.C0961f;
import com.google.android.gms.p023d.C0965h.C0964a;
import com.google.android.gms.p023d.C0973k;
import com.google.android.gms.p023d.C1004q;
import com.google.android.gms.p023d.C1017y;
import com.google.android.gms.p023d.aj;
import com.google.android.gms.p023d.aq;
import com.google.android.gms.p023d.ar;
import com.google.android.gms.p023d.as;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.locks.ReentrantLock;

public abstract class GoogleApiClient {
    /* renamed from: a */
    private static final Set<GoogleApiClient> f1565a = Collections.newSetFromMap(new WeakHashMap());

    /* renamed from: com.google.android.gms.common.api.GoogleApiClient$a */
    public static final class C0806a {
        /* renamed from: a */
        private Account f1547a;
        /* renamed from: b */
        private final Set<Scope> f1548b = new HashSet();
        /* renamed from: c */
        private final Set<Scope> f1549c = new HashSet();
        /* renamed from: d */
        private int f1550d;
        /* renamed from: e */
        private View f1551e;
        /* renamed from: f */
        private String f1552f;
        /* renamed from: g */
        private String f1553g;
        /* renamed from: h */
        private final Map<C0824a<?>, C0889a> f1554h = new C0222a();
        /* renamed from: i */
        private final Context f1555i;
        /* renamed from: j */
        private final Map<C0824a<?>, C0810a> f1556j = new C0222a();
        /* renamed from: k */
        private C1017y f1557k;
        /* renamed from: l */
        private int f1558l = -1;
        /* renamed from: m */
        private C0808c f1559m;
        /* renamed from: n */
        private Looper f1560n;
        /* renamed from: o */
        private C0840b f1561o = C0840b.m3355a();
        /* renamed from: p */
        private C0816b<? extends ar, as> f1562p = aq.f1885c;
        /* renamed from: q */
        private final ArrayList<C0807b> f1563q = new ArrayList();
        /* renamed from: r */
        private final ArrayList<C0808c> f1564r = new ArrayList();

        public C0806a(Context context) {
            this.f1555i = context;
            this.f1560n = context.getMainLooper();
            this.f1552f = context.getPackageName();
            this.f1553g = context.getClass().getName();
        }

        /* renamed from: a */
        private static <C extends C0819f, O> C m3264a(C0816b<C, O> c0816b, Object obj, Context context, Looper looper, C0890l c0890l, C0807b c0807b, C0808c c0808c) {
            return c0816b.mo987a(context, looper, c0890l, obj, c0807b, c0808c);
        }

        /* renamed from: a */
        private static <C extends C0821h, O> C0860e m3265a(C0822i<C, O> c0822i, Object obj, Context context, Looper looper, C0890l c0890l, C0807b c0807b, C0808c c0808c) {
            return new C0860e(context, looper, c0822i.m3313b(), c0807b, c0808c, c0890l, c0822i.m3314b(obj));
        }

        /* renamed from: a */
        private void m3266a(GoogleApiClient googleApiClient) {
            C0961f.m3951a(this.f1557k).m3954a(this.f1558l, googleApiClient, this.f1559m);
        }

        /* renamed from: c */
        private GoogleApiClient m3267c() {
            C0890l a = m3271a();
            C0824a c0824a = null;
            Map e = a.m3563e();
            Map c0222a = new C0222a();
            Map c0222a2 = new C0222a();
            ArrayList arrayList = new ArrayList();
            C0824a c0824a2 = null;
            for (C0824a c0824a3 : this.f1556j.keySet()) {
                C0824a c0824a32;
                C0819f a2;
                C0824a c0824a4;
                Object obj = this.f1556j.get(c0824a32);
                int i = 0;
                if (e.get(c0824a32) != null) {
                    i = ((C0889a) e.get(c0824a32)).f1721b ? 1 : 2;
                }
                c0222a.put(c0824a32, Integer.valueOf(i));
                C0807b c0973k = new C0973k(c0824a32, i);
                arrayList.add(c0973k);
                C0824a c0824a5;
                if (c0824a32.m3319e()) {
                    C0822i c = c0824a32.m3317c();
                    c0824a5 = c.m3295a() == 1 ? c0824a32 : c0824a2;
                    a2 = C0806a.m3265a(c, obj, this.f1555i, this.f1560n, a, c0973k, (C0808c) c0973k);
                    c0824a4 = c0824a5;
                } else {
                    C0816b b = c0824a32.m3316b();
                    c0824a5 = b.m3295a() == 1 ? c0824a32 : c0824a2;
                    a2 = C0806a.m3264a(b, obj, this.f1555i, this.f1560n, a, c0973k, (C0808c) c0973k);
                    c0824a4 = c0824a5;
                }
                c0222a2.put(c0824a32.m3318d(), a2);
                if (!a2.m3306f()) {
                    c0824a32 = c0824a;
                } else if (c0824a != null) {
                    String valueOf = String.valueOf(c0824a32.m3320f());
                    String valueOf2 = String.valueOf(c0824a.m3320f());
                    throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 21) + String.valueOf(valueOf2).length()).append(valueOf).append(" cannot be used with ").append(valueOf2).toString());
                }
                c0824a2 = c0824a4;
                c0824a = c0824a32;
            }
            if (c0824a != null) {
                if (c0824a2 != null) {
                    valueOf = String.valueOf(c0824a.m3320f());
                    valueOf2 = String.valueOf(c0824a2.m3320f());
                    throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 21) + String.valueOf(valueOf2).length()).append(valueOf).append(" cannot be used with ").append(valueOf2).toString());
                }
                C0854b.m3433a(this.f1547a == null, "Must not set an account in GoogleApiClient.Builder when using %s. Set account in GoogleSignInOptions.Builder instead", c0824a.m3320f());
                C0854b.m3433a(this.f1548b.equals(this.f1549c), "Must not set scopes in GoogleApiClient.Builder when using %s. Set account in GoogleSignInOptions.Builder instead.", c0824a.m3320f());
            }
            return new C1004q(this.f1555i, new ReentrantLock(), this.f1560n, a, this.f1561o, this.f1562p, c0222a, this.f1563q, this.f1564r, c0222a2, this.f1558l, C1004q.m4142a(c0222a2.values(), true), arrayList);
        }

        /* renamed from: a */
        public C0806a m3268a(C0807b c0807b) {
            C0854b.m3428a((Object) c0807b, (Object) "Listener must not be null");
            this.f1563q.add(c0807b);
            return this;
        }

        /* renamed from: a */
        public C0806a m3269a(C0808c c0808c) {
            C0854b.m3428a((Object) c0808c, (Object) "Listener must not be null");
            this.f1564r.add(c0808c);
            return this;
        }

        /* renamed from: a */
        public C0806a m3270a(C0824a<? extends C0812c> c0824a) {
            C0854b.m3428a((Object) c0824a, (Object) "Api must not be null");
            this.f1556j.put(c0824a, null);
            Collection a = c0824a.m3315a().m3296a(null);
            this.f1549c.addAll(a);
            this.f1548b.addAll(a);
            return this;
        }

        /* renamed from: a */
        public C0890l m3271a() {
            as asVar = as.f1891a;
            if (this.f1556j.containsKey(aq.f1889g)) {
                asVar = (as) this.f1556j.get(aq.f1889g);
            }
            return new C0890l(this.f1547a, this.f1548b, this.f1554h, this.f1550d, this.f1551e, this.f1552f, this.f1553g, asVar);
        }

        /* renamed from: b */
        public GoogleApiClient m3272b() {
            C0854b.m3436b(!this.f1556j.isEmpty(), "must call addApi() to add at least one API");
            GoogleApiClient c = m3267c();
            synchronized (GoogleApiClient.f1565a) {
                GoogleApiClient.f1565a.add(c);
            }
            if (this.f1558l >= 0) {
                m3266a(c);
            }
            return c;
        }
    }

    /* renamed from: com.google.android.gms.common.api.GoogleApiClient$b */
    public interface C0807b {
        /* renamed from: a */
        void mo1010a(int i);

        /* renamed from: a */
        void mo1011a(Bundle bundle);
    }

    /* renamed from: com.google.android.gms.common.api.GoogleApiClient$c */
    public interface C0808c {
        /* renamed from: a */
        void mo996a(ConnectionResult connectionResult);
    }

    /* renamed from: a */
    public Looper mo1037a() {
        throw new UnsupportedOperationException();
    }

    /* renamed from: a */
    public <C extends C0819f> C mo1038a(C0818d<C> c0818d) {
        throw new UnsupportedOperationException();
    }

    /* renamed from: a */
    public <A extends C0817c, T extends C0964a<? extends C0809e, A>> T mo1039a(T t) {
        throw new UnsupportedOperationException();
    }

    /* renamed from: a */
    public void mo1040a(int i) {
        throw new UnsupportedOperationException();
    }

    /* renamed from: a */
    public abstract void mo1041a(C0808c c0808c);

    /* renamed from: a */
    public void mo1042a(aj ajVar) {
        throw new UnsupportedOperationException();
    }

    /* renamed from: a */
    public abstract void mo1043a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    /* renamed from: b */
    public abstract void mo1044b(C0808c c0808c);

    /* renamed from: b */
    public void mo1045b(aj ajVar) {
        throw new UnsupportedOperationException();
    }

    public abstract void connect();

    public abstract void disconnect();
}

package com.google.android.gms.common.api;

/* renamed from: com.google.android.gms.common.api.i */
public abstract class C0832i<R extends C0809e> {
}

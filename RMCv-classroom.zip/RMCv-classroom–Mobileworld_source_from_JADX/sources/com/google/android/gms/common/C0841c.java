package com.google.android.gms.common;

/* renamed from: com.google.android.gms.common.c */
public final class C0841c extends Exception {
    /* renamed from: a */
    public final int f1601a;

    public C0841c(int i) {
        this.f1601a = i;
    }
}

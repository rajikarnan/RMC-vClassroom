package com.onesignal.shortcutbadger;

/* compiled from: ShortcutBadgeException */
/* renamed from: com.onesignal.shortcutbadger.b */
public class C1150b extends Exception {
    public C1150b(String message) {
        super(message);
    }

    public C1150b(String message, Exception e) {
        super(message, e);
    }
}

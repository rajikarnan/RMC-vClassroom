package com.onesignal.shortcutbadger;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.util.Log;
import com.onesignal.shortcutbadger.impl.AdwHomeBadger;
import com.onesignal.shortcutbadger.impl.ApexHomeBadger;
import com.onesignal.shortcutbadger.impl.AsusHomeLauncher;
import com.onesignal.shortcutbadger.impl.DefaultBadger;
import com.onesignal.shortcutbadger.impl.HuaweiHomeBadger;
import com.onesignal.shortcutbadger.impl.NewHtcHomeBadger;
import com.onesignal.shortcutbadger.impl.NovaHomeBadger;
import com.onesignal.shortcutbadger.impl.OPPOHomeBader;
import com.onesignal.shortcutbadger.impl.SamsungHomeBadger;
import com.onesignal.shortcutbadger.impl.SonyHomeBadger;
import com.onesignal.shortcutbadger.impl.XiaomiHomeBadger;
import com.onesignal.shortcutbadger.impl.ZukHomeBadger;
import java.util.LinkedList;
import java.util.List;

/* compiled from: ShortcutBadger */
/* renamed from: com.onesignal.shortcutbadger.c */
public final class C1151c {
    /* renamed from: a */
    private static final List<Class<? extends C1149a>> f2389a = new LinkedList();
    /* renamed from: b */
    private static C1149a f2390b;
    /* renamed from: c */
    private static ComponentName f2391c;

    static {
        f2389a.add(AdwHomeBadger.class);
        f2389a.add(ApexHomeBadger.class);
        f2389a.add(NewHtcHomeBadger.class);
        f2389a.add(NovaHomeBadger.class);
        f2389a.add(SonyHomeBadger.class);
        f2389a.add(XiaomiHomeBadger.class);
        f2389a.add(AsusHomeLauncher.class);
        f2389a.add(HuaweiHomeBadger.class);
        f2389a.add(OPPOHomeBader.class);
        f2389a.add(SamsungHomeBadger.class);
        f2389a.add(ZukHomeBadger.class);
    }

    /* renamed from: a */
    public static void m4763a(Context context, int badgeCount) throws C1150b {
        if (f2390b != null || C1151c.m4764a(context)) {
            try {
                f2390b.mo1120a(context, f2391c, badgeCount);
                return;
            } catch (Exception e) {
                throw new C1150b("Unable to execute badge", e);
            }
        }
        throw new C1150b("No default launcher available");
    }

    /* renamed from: a */
    private static boolean m4764a(Context context) {
        Intent launchIntent = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        if (launchIntent == null) {
            Log.e("ShortcutBadger", "Unable to find launch intent for package " + context.getPackageName());
            return false;
        }
        f2391c = launchIntent.getComponent();
        Intent intent = new Intent("android.intent.action.MAIN");
        intent.addCategory("android.intent.category.HOME");
        ResolveInfo resolveInfo = context.getPackageManager().resolveActivity(intent, 65536);
        if (resolveInfo == null || resolveInfo.activityInfo.name.toLowerCase().contains("resolver")) {
            return false;
        }
        String currentHomePackage = resolveInfo.activityInfo.packageName;
        for (Class<? extends C1149a> badger : f2389a) {
            C1149a shortcutBadger = null;
            try {
                shortcutBadger = (C1149a) badger.newInstance();
            } catch (Exception e) {
            }
            if (shortcutBadger != null && shortcutBadger.mo1119a().contains(currentHomePackage)) {
                f2390b = shortcutBadger;
                break;
            }
        }
        if (f2390b == null) {
            if (Build.MANUFACTURER.equalsIgnoreCase("Xiaomi")) {
                f2390b = new XiaomiHomeBadger();
            } else if (Build.MANUFACTURER.equalsIgnoreCase("ZUK")) {
                f2390b = new ZukHomeBadger();
            } else if (Build.MANUFACTURER.equalsIgnoreCase("OPPO")) {
                f2390b = new OPPOHomeBader();
            } else {
                f2390b = new DefaultBadger();
            }
        }
        return true;
    }
}

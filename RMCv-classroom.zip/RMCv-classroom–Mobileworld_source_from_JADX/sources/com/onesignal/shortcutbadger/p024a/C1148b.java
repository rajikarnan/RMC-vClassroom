package com.onesignal.shortcutbadger.p024a;

import android.database.Cursor;
import java.io.Closeable;
import java.io.IOException;

/* compiled from: CloseHelper */
/* renamed from: com.onesignal.shortcutbadger.a.b */
public class C1148b {
    /* renamed from: a */
    public static void m4759a(Cursor cursor) {
        if (cursor != null && !cursor.isClosed()) {
            cursor.close();
        }
    }

    /* renamed from: a */
    public static void m4760a(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException e) {
            }
        }
    }
}

package com.onesignal.shortcutbadger.p024a;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import java.util.List;

/* compiled from: BroadcastHelper */
/* renamed from: com.onesignal.shortcutbadger.a.a */
public class C1147a {
    /* renamed from: a */
    public static boolean m4758a(Context context, Intent intent) {
        List<ResolveInfo> receivers = context.getPackageManager().queryBroadcastReceivers(intent, 0);
        if (receivers == null || receivers.size() <= 0) {
            return false;
        }
        return true;
    }
}

package com.onesignal.shortcutbadger.impl;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import com.onesignal.shortcutbadger.C1149a;
import com.onesignal.shortcutbadger.C1150b;
import com.onesignal.shortcutbadger.p024a.C1147a;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;

public class XiaomiHomeBadger implements C1149a {
    /* renamed from: a */
    public void mo1120a(Context context, ComponentName componentName, int badgeCount) throws C1150b {
        try {
            Object obj;
            Object miuiNotification = Class.forName("android.app.MiuiNotification").newInstance();
            Field field = miuiNotification.getClass().getDeclaredField("messageCount");
            field.setAccessible(true);
            if (badgeCount == 0) {
                obj = "";
            } else {
                obj = Integer.valueOf(badgeCount);
            }
            field.set(miuiNotification, String.valueOf(obj));
        } catch (Exception e) {
            Intent localIntent = new Intent("android.intent.action.APPLICATION_MESSAGE_UPDATE");
            localIntent.putExtra("android.intent.extra.update_application_component_name", componentName.getPackageName() + "/" + componentName.getClassName());
            localIntent.putExtra("android.intent.extra.update_application_message_text", String.valueOf(badgeCount == 0 ? "" : Integer.valueOf(badgeCount)));
            if (C1147a.m4758a(context, localIntent)) {
                context.sendBroadcast(localIntent);
                return;
            }
            throw new C1150b("unable to resolve intent: " + localIntent.toString());
        }
    }

    /* renamed from: a */
    public List<String> mo1119a() {
        return Arrays.asList(new String[]{"com.miui.miuilite", "com.miui.home", "com.miui.miuihome", "com.miui.miuihome2", "com.miui.mihome", "com.miui.mihome2"});
    }
}

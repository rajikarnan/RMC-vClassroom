package com.onesignal.shortcutbadger.impl;

import android.content.AsyncQueryHandler;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import com.onesignal.shortcutbadger.C1149a;
import com.onesignal.shortcutbadger.C1150b;
import java.util.Arrays;
import java.util.List;

public class SonyHomeBadger implements C1149a {
    /* renamed from: a */
    private final Uri f2395a = Uri.parse("content://com.sonymobile.home.resourceprovider/badge");
    /* renamed from: b */
    private AsyncQueryHandler f2396b;

    /* renamed from: a */
    public void mo1120a(Context context, ComponentName componentName, int badgeCount) throws C1150b {
        if (m4793a(context)) {
            m4795c(context, componentName, badgeCount);
        } else {
            m4794b(context, componentName, badgeCount);
        }
    }

    /* renamed from: a */
    public List<String> mo1119a() {
        return Arrays.asList(new String[]{"com.sonyericsson.home"});
    }

    /* renamed from: b */
    private static void m4794b(Context context, ComponentName componentName, int badgeCount) {
        Intent intent = new Intent("com.sonyericsson.home.action.UPDATE_BADGE");
        intent.putExtra("com.sonyericsson.home.intent.extra.badge.PACKAGE_NAME", componentName.getPackageName());
        intent.putExtra("com.sonyericsson.home.intent.extra.badge.ACTIVITY_NAME", componentName.getClassName());
        intent.putExtra("com.sonyericsson.home.intent.extra.badge.MESSAGE", String.valueOf(badgeCount));
        intent.putExtra("com.sonyericsson.home.intent.extra.badge.SHOW_MESSAGE", badgeCount > 0);
        context.sendBroadcast(intent);
    }

    /* renamed from: c */
    private void m4795c(Context context, ComponentName componentName, int badgeCount) {
        if (badgeCount >= 0) {
            if (this.f2396b == null) {
                this.f2396b = new AsyncQueryHandler(this, context.getApplicationContext().getContentResolver()) {
                    /* renamed from: a */
                    final /* synthetic */ SonyHomeBadger f2394a;
                };
            }
            m4792a(badgeCount, componentName.getPackageName(), componentName.getClassName());
        }
    }

    /* renamed from: a */
    private void m4792a(int badgeCount, String packageName, String activityName) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("badge_count", Integer.valueOf(badgeCount));
        contentValues.put("package_name", packageName);
        contentValues.put("activity_name", activityName);
        this.f2396b.startInsert(0, null, this.f2395a, contentValues);
    }

    /* renamed from: a */
    private static boolean m4793a(Context context) {
        if (context.getPackageManager().resolveContentProvider("com.sonymobile.home.resourceprovider", 0) != null) {
            return true;
        }
        return false;
    }
}

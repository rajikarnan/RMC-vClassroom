package com.onesignal.shortcutbadger.impl;

import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import com.onesignal.shortcutbadger.C1149a;
import com.onesignal.shortcutbadger.C1150b;
import com.onesignal.shortcutbadger.p024a.C1148b;
import java.util.Arrays;
import java.util.List;

@Deprecated
public class SamsungHomeBadger implements C1149a {
    /* renamed from: a */
    private static final String[] f2393a = new String[]{"_id", "class"};

    /* renamed from: a */
    public void mo1120a(Context context, ComponentName componentName, int badgeCount) throws C1150b {
        Uri mUri = Uri.parse("content://com.sec.badge/apps?notify=true");
        ContentResolver contentResolver = context.getContentResolver();
        try {
            Cursor cursor = contentResolver.query(mUri, f2393a, "package=?", new String[]{componentName.getPackageName()}, null);
            if (cursor != null) {
                String entryActivityName = componentName.getClassName();
                boolean entryActivityExist = false;
                while (cursor.moveToNext()) {
                    int id = cursor.getInt(0);
                    contentResolver.update(mUri, m4789a(componentName, badgeCount, false), "_id=?", new String[]{String.valueOf(id)});
                    if (entryActivityName.equals(cursor.getString(cursor.getColumnIndex("class")))) {
                        entryActivityExist = true;
                    }
                }
                if (!entryActivityExist) {
                    contentResolver.insert(mUri, m4789a(componentName, badgeCount, true));
                }
            }
            C1148b.m4759a(cursor);
        } catch (Throwable th) {
            C1148b.m4759a(null);
        }
    }

    /* renamed from: a */
    private ContentValues m4789a(ComponentName componentName, int badgeCount, boolean isInsert) {
        ContentValues contentValues = new ContentValues();
        if (isInsert) {
            contentValues.put("package", componentName.getPackageName());
            contentValues.put("class", componentName.getClassName());
        }
        contentValues.put("badgecount", Integer.valueOf(badgeCount));
        return contentValues;
    }

    /* renamed from: a */
    public List<String> mo1119a() {
        return Arrays.asList(new String[]{"com.sec.android.app.launcher", "com.sec.android.app.twlauncher"});
    }
}

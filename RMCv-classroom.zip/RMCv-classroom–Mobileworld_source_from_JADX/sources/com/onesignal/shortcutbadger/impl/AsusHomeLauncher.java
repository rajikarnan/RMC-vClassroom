package com.onesignal.shortcutbadger.impl;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import com.onesignal.shortcutbadger.C1149a;
import com.onesignal.shortcutbadger.C1150b;
import com.onesignal.shortcutbadger.p024a.C1147a;
import java.util.Arrays;
import java.util.List;

public class AsusHomeLauncher implements C1149a {
    /* renamed from: a */
    public void mo1120a(Context context, ComponentName componentName, int badgeCount) throws C1150b {
        Intent intent = new Intent("android.intent.action.BADGE_COUNT_UPDATE");
        intent.putExtra("badge_count", badgeCount);
        intent.putExtra("badge_count_package_name", componentName.getPackageName());
        intent.putExtra("badge_count_class_name", componentName.getClassName());
        intent.putExtra("badge_vip_count", 0);
        if (C1147a.m4758a(context, intent)) {
            context.sendBroadcast(intent);
            return;
        }
        throw new C1150b("unable to resolve intent: " + intent.toString());
    }

    /* renamed from: a */
    public List<String> mo1119a() {
        return Arrays.asList(new String[]{"com.asus.launcher"});
    }
}

package com.onesignal.shortcutbadger.impl;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import com.onesignal.shortcutbadger.C1149a;
import com.onesignal.shortcutbadger.C1150b;
import com.onesignal.shortcutbadger.p024a.C1147a;
import java.util.Arrays;
import java.util.List;

public class NewHtcHomeBadger implements C1149a {
    /* renamed from: a */
    public void mo1120a(Context context, ComponentName componentName, int badgeCount) throws C1150b {
        Intent intent1 = new Intent("com.htc.launcher.action.SET_NOTIFICATION");
        intent1.putExtra("com.htc.launcher.extra.COMPONENT", componentName.flattenToShortString());
        intent1.putExtra("com.htc.launcher.extra.COUNT", badgeCount);
        Intent intent = new Intent("com.htc.launcher.action.UPDATE_SHORTCUT");
        intent.putExtra("packagename", componentName.getPackageName());
        intent.putExtra("count", badgeCount);
        if (C1147a.m4758a(context, intent1) || C1147a.m4758a(context, intent)) {
            context.sendBroadcast(intent1);
            context.sendBroadcast(intent);
            return;
        }
        throw new C1150b("unable to resolve intent: " + intent.toString());
    }

    /* renamed from: a */
    public List<String> mo1119a() {
        return Arrays.asList(new String[]{"com.htc.launcher"});
    }
}

package com.onesignal.shortcutbadger.impl;

import android.annotation.TargetApi;
import android.content.ComponentName;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import com.onesignal.shortcutbadger.C1149a;
import com.onesignal.shortcutbadger.C1150b;
import java.util.Collections;
import java.util.List;

public class ZukHomeBadger implements C1149a {
    /* renamed from: a */
    private final Uri f2397a = Uri.parse("content://com.android.badge/badge");

    @TargetApi(11)
    /* renamed from: a */
    public void mo1120a(Context context, ComponentName componentName, int badgeCount) throws C1150b {
        Bundle extra = new Bundle();
        extra.putInt("app_badge_count", badgeCount);
        context.getContentResolver().call(this.f2397a, "setAppBadgeCount", null, extra);
    }

    /* renamed from: a */
    public List<String> mo1119a() {
        return Collections.singletonList("com.zui.launcher");
    }
}

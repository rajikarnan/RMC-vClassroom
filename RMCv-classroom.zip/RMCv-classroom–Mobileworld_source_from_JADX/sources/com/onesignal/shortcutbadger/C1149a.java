package com.onesignal.shortcutbadger;

import android.content.ComponentName;
import android.content.Context;
import java.util.List;

/* compiled from: Badger */
/* renamed from: com.onesignal.shortcutbadger.a */
public interface C1149a {
    /* renamed from: a */
    List<String> mo1119a();

    /* renamed from: a */
    void mo1120a(Context context, ComponentName componentName, int i) throws C1150b;
}

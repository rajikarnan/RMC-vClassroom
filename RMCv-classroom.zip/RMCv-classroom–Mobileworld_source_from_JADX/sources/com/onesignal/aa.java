package com.onesignal;

/* compiled from: R */
public final class aa {

    /* compiled from: R */
    /* renamed from: com.onesignal.aa$a */
    public static final class C1102a {
        public static final int adjust_height = 2131558428;
        public static final int adjust_width = 2131558429;
        public static final int auto = 2131558443;
        public static final int dark = 2131558444;
        public static final int icon_only = 2131558440;
        public static final int light = 2131558445;
        public static final int none = 2131558414;
        public static final int os_bgimage_notif_bgimage = 2131558554;
        public static final int os_bgimage_notif_bgimage_align_layout = 2131558553;
        public static final int os_bgimage_notif_bgimage_right_aligned = 2131558555;
        public static final int os_bgimage_notif_body = 2131558557;
        public static final int os_bgimage_notif_title = 2131558556;
        public static final int standard = 2131558441;
        public static final int wide = 2131558442;
    }

    /* compiled from: R */
    /* renamed from: com.onesignal.aa$b */
    public static final class C1103b {
        public static final int onesignal_bgimage_notif_layout = 2130903095;
    }
}

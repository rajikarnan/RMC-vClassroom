package com.onesignal;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Application.ActivityLifecycleCallbacks;
import android.os.Bundle;

@TargetApi(14)
/* compiled from: ActivityLifecycleListener */
/* renamed from: com.onesignal.b */
class C1112b implements ActivityLifecycleCallbacks {
    C1112b() {
    }

    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
        C1101a.m4630a(activity);
    }

    public void onActivityStarted(Activity activity) {
        C1101a.m4633b(activity);
    }

    public void onActivityResumed(Activity activity) {
        C1101a.m4636c(activity);
    }

    public void onActivityPaused(Activity activity) {
        C1101a.m4637d(activity);
    }

    public void onActivityStopped(Activity activity) {
        C1101a.m4638e(activity);
    }

    public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
    }

    public void onActivityDestroyed(Activity activity) {
        C1101a.m4639f(activity);
    }
}

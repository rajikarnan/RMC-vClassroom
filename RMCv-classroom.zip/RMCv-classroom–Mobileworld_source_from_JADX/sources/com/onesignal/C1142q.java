package com.onesignal;

/* compiled from: OSNotificationOpenResult */
/* renamed from: com.onesignal.q */
public class C1142q {
    /* renamed from: a */
    public C1139o f2361a;
    /* renamed from: b */
    public C1141p f2362b;
}

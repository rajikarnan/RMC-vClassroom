package com.onesignal;

import android.app.IntentService;
import android.content.Intent;
import android.support.v4.content.C0206j;

public class GcmIntentService extends IntentService {
    public GcmIntentService() {
        super("GcmIntentService");
        setIntentRedelivery(true);
    }

    protected void onHandleIntent(Intent intent) {
        C1131j.m4731a(this, intent.getExtras(), null);
        C0206j.m767a(intent);
    }
}

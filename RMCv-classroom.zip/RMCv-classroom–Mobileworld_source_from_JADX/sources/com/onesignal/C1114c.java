package com.onesignal;

import android.content.Context;
import com.google.android.gms.p017a.p018a.C0784a;
import com.google.android.gms.p017a.p018a.C0784a.C0782a;
import com.onesignal.C1170t.C1166d;

/* compiled from: AdvertisingIdProviderGPS */
/* renamed from: com.onesignal.c */
class C1114c implements C1113d {
    C1114c() {
    }

    /* renamed from: a */
    public String mo1118a(Context appContext) {
        try {
            C0782a adInfo = C0784a.m3181b(appContext);
            String id = adInfo.m3174a();
            if (adInfo.m3175b()) {
                return "OptedOut";
            }
            return id;
        } catch (Throwable t) {
            C1170t.m4844a(C1166d.INFO, "Error getting Google Ad id: ", t);
            return null;
        }
    }
}

package com.onesignal;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/* compiled from: OneSignalDbHelper */
/* renamed from: com.onesignal.u */
public class C1171u extends SQLiteOpenHelper {
    /* renamed from: a */
    private static C1171u f2457a;

    private C1171u(Context context) {
        super(context, "OneSignal.db", null, 1);
    }

    /* renamed from: a */
    public static synchronized C1171u m4908a(Context context) {
        C1171u c1171u;
        synchronized (C1171u.class) {
            if (f2457a == null) {
                f2457a = new C1171u(context.getApplicationContext());
            }
            c1171u = f2457a;
        }
        return c1171u;
    }

    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE notification (_id INTEGER PRIMARY KEY,notification_id TEXT,android_notification_id INTEGER,group_id TEXT,is_summary INTEGER DEFAULT 0,opened INTEGER DEFAULT 0,dismissed INTEGER DEFAULT 0,title TEXT,message TEXT,full_data TEXT,created_time TIMESTAMP DEFAULT (strftime('%s', 'now')));");
        db.execSQL("CREATE INDEX notification_notification_id_idx ON notification(notification_id); CREATE INDEX notification_android_notification_id_idx ON notification(android_notification_id); CREATE INDEX notification_group_id_idx ON notification(group_id); CREATE INDEX notification_created_time_idx ON notification(created_time); ");
    }

    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
    }
}

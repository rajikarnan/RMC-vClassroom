package com.onesignal;

import org.json.JSONObject;

/* compiled from: OneSignalRestClient */
/* renamed from: com.onesignal.v */
class C1175v {

    /* compiled from: OneSignalRestClient */
    /* renamed from: com.onesignal.v$a */
    static class C1108a {
        C1108a() {
        }

        /* renamed from: a */
        void mo1116a(String response) {
        }

        /* renamed from: a */
        void mo1122a(int statusCode, String response, Throwable throwable) {
        }
    }

    /* renamed from: b */
    private static void m4913b(java.lang.String r13, java.lang.String r14, org.json.JSONObject r15, com.onesignal.C1175v.C1108a r16) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find block by offset: 0x00e2 in list [B:18:0x00df]
	at jadx.core.utils.BlockUtils.getBlockByOffset(BlockUtils.java:43)
	at jadx.core.dex.instructions.IfNode.initBlocks(IfNode.java:60)
	at jadx.core.dex.visitors.blocksmaker.BlockFinish.initBlocksInIfNodes(BlockFinish.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockFinish.visit(BlockFinish.java:33)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1782580546.run(Unknown Source)
*/
        /*
        r1 = 0;
        r2 = -1;
        r4 = 0;
        r10 = com.onesignal.C1170t.C1166d.DEBUG;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = new java.lang.StringBuilder;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11.<init>();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r12 = "https://onesignal.com/api/v1/";	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.append(r12);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.append(r13);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.toString();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        com.onesignal.C1170t.m4843a(r10, r11);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r10 = new java.net.URL;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = new java.lang.StringBuilder;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11.<init>();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r12 = "https://onesignal.com/api/v1/";	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.append(r12);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.append(r13);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.toString();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r10.<init>(r11);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r10 = r10.openConnection();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r0 = r10;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r0 = (java.net.HttpURLConnection) r0;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r1 = r0;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r10 = 0;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r1.setUseCaches(r10);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r10 = 120000; // 0x1d4c0 float:1.68156E-40 double:5.9288E-319;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r1.setConnectTimeout(r10);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r10 = 120000; // 0x1d4c0 float:1.68156E-40 double:5.9288E-319;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r1.setReadTimeout(r10);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        if (r15 == 0) goto L_0x0051;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x004d:
        r10 = 1;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r1.setDoInput(r10);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x0051:
        if (r14 == 0) goto L_0x0061;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x0053:
        r10 = "Content-Type";	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = "application/json; charset=UTF-8";	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r1.setRequestProperty(r10, r11);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r1.setRequestMethod(r14);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r10 = 1;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r1.setDoOutput(r10);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x0061:
        if (r15 == 0) goto L_0x0094;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x0063:
        r8 = r15.toString();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r10 = com.onesignal.C1170t.C1166d.DEBUG;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = new java.lang.StringBuilder;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11.<init>();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.append(r14);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r12 = " SEND JSON: ";	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.append(r12);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.append(r8);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.toString();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        com.onesignal.C1170t.m4843a(r10, r11);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r10 = "UTF-8";	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r7 = r8.getBytes(r10);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r10 = r7.length;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r1.setFixedLengthStreamingMode(r10);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r5 = r1.getOutputStream();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r5.write(r7);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x0094:
        r2 = r1.getResponseCode();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r10 = 200; // 0xc8 float:2.8E-43 double:9.9E-322;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        if (r2 != r10) goto L_0x00e6;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x009c:
        r3 = r1.getInputStream();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r6 = new java.util.Scanner;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r10 = "UTF-8";	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r6.<init>(r3, r10);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r10 = "\\A";	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r10 = r6.useDelimiter(r10);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r10 = r10.hasNext();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        if (r10 == 0) goto L_0x00e3;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x00b3:
        r4 = r6.next();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x00b7:
        r6.close();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r10 = com.onesignal.C1170t.C1166d.DEBUG;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = new java.lang.StringBuilder;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11.<init>();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.append(r14);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r12 = " RECEIVED JSON: ";	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.append(r12);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.append(r4);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.toString();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        com.onesignal.C1170t.m4843a(r10, r11);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        if (r16 == 0) goto L_0x00dd;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x00d8:
        r0 = r16;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r0.mo1116a(r4);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x00dd:
        if (r1 == 0) goto L_0x00e2;
    L_0x00df:
        r1.disconnect();
    L_0x00e2:
        return;
    L_0x00e3:
        r4 = "";	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        goto L_0x00b7;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x00e6:
        r3 = r1.getErrorStream();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        if (r3 != 0) goto L_0x00f0;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x00ec:
        r3 = r1.getInputStream();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x00f0:
        if (r3 == 0) goto L_0x016c;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x00f2:
        r6 = new java.util.Scanner;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r10 = "UTF-8";	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r6.<init>(r3, r10);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r10 = "\\A";	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r10 = r6.useDelimiter(r10);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r10 = r10.hasNext();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        if (r10 == 0) goto L_0x0169;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x0105:
        r4 = r6.next();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x0109:
        r6.close();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r10 = com.onesignal.C1170t.C1166d.WARN;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = new java.lang.StringBuilder;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11.<init>();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.append(r14);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r12 = " RECEIVED JSON: ";	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.append(r12);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.append(r4);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.toString();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        com.onesignal.C1170t.m4843a(r10, r11);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x0128:
        if (r16 == 0) goto L_0x00dd;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x012a:
        r10 = 0;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r0 = r16;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r0.mo1122a(r2, r4, r10);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        goto L_0x00dd;
    L_0x0131:
        r9 = move-exception;
        r10 = r9 instanceof java.net.ConnectException;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        if (r10 != 0) goto L_0x013a;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x0136:
        r10 = r9 instanceof java.net.UnknownHostException;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        if (r10 == 0) goto L_0x0196;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x013a:
        r10 = com.onesignal.C1170t.C1166d.INFO;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = new java.lang.StringBuilder;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11.<init>();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r12 = "Could not send last request, device is offline. Throwable: ";	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.append(r12);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r12 = r9.getClass();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r12 = r12.getName();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.append(r12);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.toString();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        com.onesignal.C1170t.m4843a(r10, r11);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x015a:
        if (r16 == 0) goto L_0x0162;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x015c:
        r10 = 0;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r0 = r16;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r0.mo1122a(r2, r10, r9);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x0162:
        if (r1 == 0) goto L_0x00e2;
    L_0x0164:
        r1.disconnect();
        goto L_0x00e2;
    L_0x0169:
        r4 = "";	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        goto L_0x0109;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
    L_0x016c:
        r10 = com.onesignal.C1170t.C1166d.WARN;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = new java.lang.StringBuilder;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11.<init>();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.append(r14);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r12 = " HTTP Code: ";	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.append(r12);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.append(r2);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r12 = " No response body!";	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.append(r12);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.toString();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        com.onesignal.C1170t.m4843a(r10, r11);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        goto L_0x0128;
    L_0x018f:
        r10 = move-exception;
        if (r1 == 0) goto L_0x0195;
    L_0x0192:
        r1.disconnect();
    L_0x0195:
        throw r10;
    L_0x0196:
        r10 = com.onesignal.C1170t.C1166d.WARN;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = new java.lang.StringBuilder;	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11.<init>();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.append(r14);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r12 = " Error thrown from network stack. ";	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.append(r12);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        r11 = r11.toString();	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        com.onesignal.C1170t.m4844a(r10, r11, r9);	 Catch:{ Throwable -> 0x0131, all -> 0x018f }
        goto L_0x015a;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.v.b(java.lang.String, java.lang.String, org.json.JSONObject, com.onesignal.v$a):void");
    }

    /* renamed from: a */
    static void m4911a(final String url, final JSONObject jsonBody, final C1108a responseHandler) {
        new Thread(new Runnable() {
            public void run() {
                C1175v.m4913b(url, "PUT", jsonBody, responseHandler);
            }
        }).start();
    }

    /* renamed from: b */
    static void m4914b(final String url, final JSONObject jsonBody, final C1108a responseHandler) {
        new Thread(new Runnable() {
            public void run() {
                C1175v.m4913b(url, "POST", jsonBody, responseHandler);
            }
        }).start();
    }

    /* renamed from: a */
    static void m4909a(final String url, final C1108a responseHandler) {
        new Thread(new Runnable() {
            public void run() {
                C1175v.m4913b(url, null, null, responseHandler);
            }
        }).start();
    }

    /* renamed from: b */
    static void m4912b(String url, C1108a responseHandler) {
        C1175v.m4913b(url, null, null, responseHandler);
    }

    /* renamed from: c */
    static void m4915c(String url, JSONObject jsonBody, C1108a responseHandler) {
        C1175v.m4913b(url, "PUT", jsonBody, responseHandler);
    }

    /* renamed from: d */
    static void m4916d(String url, JSONObject jsonBody, C1108a responseHandler) {
        C1175v.m4913b(url, "POST", jsonBody, responseHandler);
    }
}

package com.onesignal;

import android.app.Activity;
import android.content.Intent;
import android.os.Build.VERSION;
import android.os.Bundle;
import com.onesignal.C1101a.C1095a;
import com.onesignal.C1119e.C1115a;

public class PermissionsActivity extends Activity {
    /* renamed from: a */
    static boolean f2280a;
    /* renamed from: b */
    static boolean f2281b;
    /* renamed from: c */
    private static C1095a f2282c;

    /* renamed from: com.onesignal.PermissionsActivity$1 */
    static class C10961 implements C1095a {
        C10961() {
        }

        /* renamed from: a */
        public void mo1115a(Activity activity) {
            if (!activity.getClass().equals(PermissionsActivity.class)) {
                Intent intent = new Intent(activity, PermissionsActivity.class);
                intent.setFlags(131072);
                activity.startActivity(intent);
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState == null || !savedInstanceState.getBoolean("android:hasCurrentPermissionsRequest", false)) {
            m4617b();
        } else {
            f2280a = true;
        }
    }

    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (C1170t.f2434d) {
            m4617b();
        }
    }

    /* renamed from: b */
    private void m4617b() {
        if (VERSION.SDK_INT < 23) {
            finish();
        } else if (!f2280a) {
            f2280a = true;
            C1115a.m4674a(this, new String[]{C1129i.f2334a}, 2);
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        f2281b = true;
        f2280a = false;
        if (requestCode == 2) {
            if (grantResults.length <= 0 || grantResults[0] != 0) {
                C1129i.m4723b();
            } else {
                C1129i.m4720a();
            }
        }
        C1101a.m4634b(f2282c);
        finish();
    }

    /* renamed from: a */
    static void m4616a() {
        if (!f2280a && !f2281b) {
            f2282c = new C10961();
            C1101a.m4631a(f2282c);
        }
    }
}

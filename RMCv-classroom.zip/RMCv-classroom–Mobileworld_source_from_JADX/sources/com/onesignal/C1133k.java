package com.onesignal;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v4.app.ag;
import android.support.v4.app.ag.C0086f;

/* compiled from: NotificationExtenderService */
/* renamed from: com.onesignal.k */
public abstract class C1133k extends IntentService {

    /* compiled from: NotificationExtenderService */
    /* renamed from: com.onesignal.k$a */
    public static class C1132a {
        /* renamed from: a */
        public C0086f f2340a;
        /* renamed from: b */
        public Integer f2341b;
    }

    /* renamed from: a */
    static Intent m4742a(Context context) {
        PackageManager packageManager = context.getPackageManager();
        Intent intent = new Intent().setAction("com.onesignal.NotificationExtender").setPackage(context.getPackageName());
        if (packageManager.queryIntentServices(intent, ag.FLAG_HIGH_PRIORITY).size() < 1) {
            return null;
        }
        return intent;
    }
}

package com.onesignal;

import android.app.Activity;
import android.os.Handler;
import android.os.HandlerThread;
import com.onesignal.C1170t.C1166d;

/* compiled from: ActivityLifecycleHandler */
/* renamed from: com.onesignal.a */
class C1101a {
    /* renamed from: a */
    static boolean f2288a;
    /* renamed from: b */
    static Activity f2289b;
    /* renamed from: c */
    static C1100c f2290c = new C1100c();
    /* renamed from: d */
    private static C1095a f2291d;

    /* compiled from: ActivityLifecycleHandler */
    /* renamed from: com.onesignal.a$a */
    interface C1095a {
        /* renamed from: a */
        void mo1115a(Activity activity);
    }

    /* compiled from: ActivityLifecycleHandler */
    /* renamed from: com.onesignal.a$b */
    private static class C1099b implements Runnable {
        /* renamed from: a */
        private boolean f2284a;
        /* renamed from: b */
        private boolean f2285b;

        private C1099b() {
        }

        public void run() {
            if (C1101a.f2289b == null) {
                this.f2284a = true;
                C1170t.m4852a(false);
                this.f2285b = true;
            }
        }
    }

    /* compiled from: ActivityLifecycleHandler */
    /* renamed from: com.onesignal.a$c */
    static class C1100c extends HandlerThread {
        /* renamed from: a */
        Handler f2286a = null;
        /* renamed from: b */
        private C1099b f2287b;

        C1100c() {
            super("FocusHandlerThread");
            start();
            this.f2286a = new Handler(getLooper());
        }

        /* renamed from: a */
        void m4625a() {
            if (this.f2287b != null) {
                this.f2287b.f2284a = false;
            }
        }

        /* renamed from: b */
        void m4627b() {
            this.f2286a.removeCallbacksAndMessages(null);
        }

        /* renamed from: a */
        void m4626a(C1099b runnable) {
            if (this.f2287b == null || !this.f2287b.f2284a || this.f2287b.f2285b) {
                this.f2287b = runnable;
                this.f2286a.removeCallbacksAndMessages(null);
                this.f2286a.postDelayed(runnable, 2000);
            }
        }

        /* renamed from: c */
        boolean m4628c() {
            return this.f2287b != null && this.f2287b.f2284a;
        }
    }

    /* renamed from: a */
    static void m4631a(C1095a activityAvailableListener) {
        if (f2289b != null) {
            activityAvailableListener.mo1115a(f2289b);
            f2291d = activityAvailableListener;
            return;
        }
        f2291d = activityAvailableListener;
    }

    /* renamed from: b */
    public static void m4634b(C1095a activityAvailableListener) {
        f2291d = null;
    }

    /* renamed from: g */
    private static void m4640g(Activity activity) {
        f2289b = activity;
        if (f2291d != null) {
            f2291d.mo1115a(f2289b);
        }
    }

    /* renamed from: a */
    static void m4630a(Activity activity) {
    }

    /* renamed from: b */
    static void m4633b(Activity activity) {
    }

    /* renamed from: c */
    static void m4636c(Activity activity) {
        C1101a.m4640g(activity);
        C1101a.m4629a();
        C1101a.m4635c();
    }

    /* renamed from: d */
    static void m4637d(Activity activity) {
        if (activity == f2289b) {
            f2289b = null;
            C1101a.m4632b();
        }
        C1101a.m4629a();
    }

    /* renamed from: e */
    static void m4638e(Activity activity) {
        C1170t.m4843a(C1166d.DEBUG, "onActivityStopped: " + activity.getClass().getName());
        if (activity == f2289b) {
            f2289b = null;
            C1101a.m4632b();
        }
        C1101a.m4629a();
    }

    /* renamed from: f */
    static void m4639f(Activity activity) {
        C1170t.m4843a(C1166d.DEBUG, "onActivityDestroyed: " + activity.getClass().getName());
        if (activity == f2289b) {
            f2289b = null;
            C1101a.m4632b();
        }
        C1101a.m4629a();
    }

    /* renamed from: a */
    private static void m4629a() {
        C1170t.m4843a(C1166d.DEBUG, "curActivity is NOW: " + (f2289b != null ? "" + f2289b.getClass().getName() + ":" + f2289b : "null"));
    }

    /* renamed from: b */
    private static void m4632b() {
        f2290c.m4626a(new C1099b());
    }

    /* renamed from: c */
    private static void m4635c() {
        if (f2290c.m4628c() || f2288a) {
            f2288a = false;
            f2290c.m4625a();
            C1170t.m4834a();
            return;
        }
        f2290c.m4627b();
    }
}

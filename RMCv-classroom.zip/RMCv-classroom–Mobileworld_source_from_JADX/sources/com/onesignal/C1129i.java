package com.onesignal;

import android.content.Context;
import android.location.Location;
import android.os.Build.VERSION;
import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient.C0806a;
import com.google.android.gms.common.api.GoogleApiClient.C0807b;
import com.google.android.gms.common.api.GoogleApiClient.C0808c;
import com.google.android.gms.location.C1036g;
import com.onesignal.C1119e.C1117c;
import com.onesignal.C1170t.C1166d;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.List;

/* compiled from: LocationGMS */
/* renamed from: com.onesignal.i */
class C1129i {
    /* renamed from: a */
    static String f2334a;
    /* renamed from: b */
    private static C1125h f2335b;
    /* renamed from: c */
    private static C1128b f2336c;
    /* renamed from: d */
    private static Thread f2337d;
    /* renamed from: e */
    private static boolean f2338e;

    /* compiled from: LocationGMS */
    /* renamed from: com.onesignal.i$1 */
    static class C11261 implements Runnable {
        C11261() {
        }

        public void run() {
            try {
                Thread.sleep(30000);
                C1170t.m4843a(C1166d.WARN, "Location permission exists but GoogleApiClient timed out. Maybe related to mismatch google-play aar versions.");
                C1129i.m4723b();
            } catch (Throwable th) {
            }
        }
    }

    /* compiled from: LocationGMS */
    /* renamed from: com.onesignal.i$a */
    private static class C1127a implements C0807b, C0808c {
        private C1127a() {
        }

        /* renamed from: a */
        public void mo1011a(Bundle bundle) {
            int i = 0;
            PermissionsActivity.f2281b = false;
            Location location = C1036g.f2186b.mo1053a(C1129i.f2335b.m4715c());
            if (location != null) {
                location.getAccuracy();
                Double lat = Double.valueOf(new BigDecimal(location.getLatitude()).setScale(7, RoundingMode.HALF_UP).doubleValue());
                Double log = Double.valueOf(new BigDecimal(location.getLongitude()).setScale(7, RoundingMode.HALF_UP).doubleValue());
                Float valueOf = Float.valueOf(location.getAccuracy());
                if (!C1129i.f2338e) {
                    i = 1;
                }
                C1129i.m4724b(lat, log, valueOf, Integer.valueOf(i));
            } else {
                C1129i.m4724b(null, null, null, null);
            }
            C1129i.f2335b.m4714b();
        }

        /* renamed from: a */
        public void mo1010a(int i) {
            C1129i.m4723b();
        }

        /* renamed from: a */
        public void mo996a(ConnectionResult connectionResult) {
            C1129i.m4723b();
        }
    }

    /* compiled from: LocationGMS */
    /* renamed from: com.onesignal.i$b */
    interface C1128b {
        /* renamed from: a */
        void mo1121a(Double d, Double d2, Float f, Integer num);
    }

    /* renamed from: a */
    static void m4721a(Context context, boolean promptLocation, C1128b handler) {
        f2336c = handler;
        int locationCoarsePermission = -1;
        int locationFinePermission = C1117c.m4677a(context, "android.permission.ACCESS_FINE_LOCATION");
        if (locationFinePermission == -1) {
            locationCoarsePermission = C1117c.m4677a(context, "android.permission.ACCESS_COARSE_LOCATION");
            f2338e = true;
        }
        if (VERSION.SDK_INT < 23) {
            if (locationFinePermission == 0 || locationCoarsePermission == 0) {
                C1129i.m4720a();
            } else {
                handler.mo1121a(null, null, null, null);
            }
        } else if (locationFinePermission != 0) {
            try {
                List<String> permissionList = Arrays.asList(context.getPackageManager().getPackageInfo(context.getPackageName(), 4096).requestedPermissions);
                if (permissionList.contains("android.permission.ACCESS_FINE_LOCATION")) {
                    f2334a = "android.permission.ACCESS_FINE_LOCATION";
                } else if (permissionList.contains("android.permission.ACCESS_COARSE_LOCATION") && locationCoarsePermission != 0) {
                    f2334a = "android.permission.ACCESS_COARSE_LOCATION";
                }
                if (f2334a != null && promptLocation) {
                    PermissionsActivity.m4616a();
                } else if (locationCoarsePermission == 0) {
                    C1129i.m4720a();
                } else {
                    C1129i.m4723b();
                }
            } catch (Throwable t) {
                t.printStackTrace();
            }
        } else {
            C1129i.m4720a();
        }
    }

    /* renamed from: a */
    static void m4720a() {
        if (f2337d == null) {
            try {
                C1129i.m4727e();
                C0808c googleApiClientListener = new C1127a();
                f2335b = new C1125h(new C0806a(C1170t.f2433c).m3270a(C1036g.f2185a).m3268a((C0807b) googleApiClientListener).m3269a(googleApiClientListener).m3272b());
                f2335b.m4713a();
            } catch (Throwable t) {
                C1170t.m4844a(C1166d.WARN, "Location permission exists but there was an error initializing: ", t);
                C1129i.m4723b();
            }
        }
    }

    /* renamed from: e */
    private static void m4727e() {
        f2337d = new Thread(new C11261(), "OS_GMS_LOCATION_FALLBACK");
        f2337d.start();
    }

    /* renamed from: b */
    static void m4723b() {
        PermissionsActivity.f2281b = false;
        C1129i.m4724b(null, null, null, null);
        if (f2335b != null) {
            f2335b.m4714b();
        }
    }

    /* renamed from: b */
    private static void m4724b(Double lat, Double log, Float accuracy, Integer type) {
        f2336c.mo1121a(lat, log, accuracy, type);
        if (!(f2337d == null || Thread.currentThread().equals(f2337d))) {
            f2337d.interrupt();
        }
        f2337d = null;
    }
}

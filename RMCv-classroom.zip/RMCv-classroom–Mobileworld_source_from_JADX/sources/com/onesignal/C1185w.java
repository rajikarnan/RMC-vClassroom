package com.onesignal;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Handler;
import android.os.HandlerThread;
import com.onesignal.C1170t.C1166d;
import com.onesignal.C1175v.C1108a;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: OneSignalStateSynchronizer */
/* renamed from: com.onesignal.w */
class C1185w {
    /* renamed from: a */
    static HashMap<Integer, C1183b> f2481a = new HashMap();
    /* renamed from: b */
    static boolean f2482b;
    /* renamed from: c */
    private static boolean f2483c = false;
    /* renamed from: d */
    private static boolean f2484d = false;
    /* renamed from: e */
    private static C1184c f2485e;
    /* renamed from: f */
    private static C1184c f2486f;
    /* renamed from: g */
    private static final Object f2487g = new C11761();
    /* renamed from: h */
    private static Context f2488h;
    /* renamed from: i */
    private static final String[] f2489i = new String[]{"lat", "long", "loc_acc", "loc_type"};
    /* renamed from: j */
    private static final Set<String> f2490j = new HashSet(Arrays.asList(f2489i));
    /* renamed from: k */
    private static final Object f2491k = new C11772();

    /* compiled from: OneSignalStateSynchronizer */
    /* renamed from: com.onesignal.w$1 */
    static class C11761 {
        C11761() {
        }
    }

    /* compiled from: OneSignalStateSynchronizer */
    /* renamed from: com.onesignal.w$2 */
    static class C11772 {
        C11772() {
        }
    }

    /* compiled from: OneSignalStateSynchronizer */
    /* renamed from: com.onesignal.w$5 */
    static class C11805 extends C1108a {
        C11805() {
        }

        /* renamed from: a */
        void mo1116a(String responseStr) {
            C1185w.f2482b = true;
            try {
                JSONObject lastGetTagsResponse = new JSONObject(responseStr);
                if (lastGetTagsResponse.has("tags")) {
                    JSONObject dependDiff = C1185w.m4959b(C1185w.f2485e.f2477b.optJSONObject("tags"), C1185w.f2486f.f2477b.optJSONObject("tags"), null, null);
                    C1185w.f2485e.f2477b.put("tags", lastGetTagsResponse.optJSONObject("tags"));
                    C1185w.f2485e.m4939d();
                    C1185w.f2486f.m4941a(lastGetTagsResponse, dependDiff);
                    C1185w.f2486f.m4939d();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    /* compiled from: OneSignalStateSynchronizer */
    /* renamed from: com.onesignal.w$a */
    static class C1181a {
        /* renamed from: a */
        public boolean f2470a;
        /* renamed from: b */
        public JSONObject f2471b;

        C1181a(boolean serverSuccess, JSONObject result) {
            this.f2470a = serverSuccess;
            this.f2471b = result;
        }
    }

    /* compiled from: OneSignalStateSynchronizer */
    /* renamed from: com.onesignal.w$b */
    static class C1183b extends HandlerThread {
        /* renamed from: a */
        int f2473a;
        /* renamed from: b */
        Handler f2474b = null;
        /* renamed from: c */
        int f2475c;

        /* compiled from: OneSignalStateSynchronizer */
        /* renamed from: com.onesignal.w$b$1 */
        class C11821 implements Runnable {
            /* renamed from: a */
            final /* synthetic */ C1183b f2472a;

            C11821(C1183b this$0) {
                this.f2472a = this$0;
            }

            public void run() {
                C1185w.m4952a(false);
            }
        }

        C1183b(int type) {
            super("OSH_NetworkHandlerThread");
            this.f2473a = type;
            start();
            this.f2474b = new Handler(getLooper());
        }

        /* renamed from: a */
        public void m4923a() {
            this.f2475c = 0;
            this.f2474b.removeCallbacksAndMessages(null);
            this.f2474b.postDelayed(m4922d(), 5000);
        }

        /* renamed from: d */
        private Runnable m4922d() {
            switch (this.f2473a) {
                case 0:
                    return new C11821(this);
                default:
                    return null;
            }
        }

        /* renamed from: b */
        void m4924b() {
            this.f2474b.removeCallbacksAndMessages(null);
        }

        /* renamed from: c */
        void m4925c() {
            if (this.f2475c < 3 && !this.f2474b.hasMessages(0)) {
                this.f2475c++;
                this.f2474b.postDelayed(m4922d(), (long) (this.f2475c * 15000));
            }
        }
    }

    /* compiled from: OneSignalStateSynchronizer */
    /* renamed from: com.onesignal.w$c */
    class C1184c {
        /* renamed from: a */
        JSONObject f2476a;
        /* renamed from: b */
        JSONObject f2477b;
        /* renamed from: c */
        final /* synthetic */ C1185w f2478c;
        /* renamed from: d */
        private final int f2479d;
        /* renamed from: e */
        private String f2480e;

        private C1184c(C1185w this$0, String inPersistKey, boolean load) {
            this.f2478c = this$0;
            this.f2479d = -2;
            this.f2480e = inPersistKey;
            if (load) {
                m4937c();
                return;
            }
            this.f2476a = new JSONObject();
            this.f2477b = new JSONObject();
        }

        /* renamed from: a */
        private C1184c m4927a(String persistKey) {
            C1184c clonedUserState = new C1184c(this.f2478c, persistKey, false);
            try {
                clonedUserState.f2476a = new JSONObject(this.f2476a.toString());
                clonedUserState.f2477b = new JSONObject(this.f2477b.toString());
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return clonedUserState;
        }

        /* renamed from: a */
        private void m4930a() {
            try {
                this.f2477b.put("notification_types", m4933b());
            } catch (JSONException e) {
            }
        }

        /* renamed from: b */
        private int m4933b() {
            int subscribableStatus = this.f2476a.optInt("subscribableStatus", 1);
            boolean userSubscribePref = this.f2476a.optBoolean("userSubscribePref", true);
            if (subscribableStatus < -2) {
                return subscribableStatus;
            }
            return userSubscribePref ? 1 : -2;
        }

        /* renamed from: b */
        private Set<String> m4935b(JSONObject cur, JSONObject changedTo) {
            try {
                if (cur.getDouble("lat") == changedTo.getDouble("lat") && cur.getDouble("long") == changedTo.getDouble("long") && cur.getDouble("loc_acc") == changedTo.getDouble("loc_acc") && cur.getDouble("loc_type") == changedTo.getDouble("loc_type")) {
                    return null;
                }
                return C1185w.f2490j;
            } catch (Throwable th) {
                return C1185w.f2490j;
            }
        }

        /* renamed from: a */
        private JSONObject m4929a(C1184c newState, boolean isSessionCall) {
            m4930a();
            newState.m4930a();
            JSONObject sendJson = C1185w.m4959b(this.f2477b, newState.f2477b, null, m4935b(this.f2477b, newState.f2477b));
            if (!isSessionCall && sendJson.toString().equals("{}")) {
                return null;
            }
            try {
                if (sendJson.has("app_id")) {
                    return sendJson;
                }
                sendJson.put("app_id", (String) this.f2477b.opt("app_id"));
                return sendJson;
            } catch (JSONException e) {
                e.printStackTrace();
                return sendJson;
            }
        }

        /* renamed from: a */
        void m4940a(String key, Object value) {
            try {
                this.f2477b.put(key, value);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        /* renamed from: b */
        void m4942b(String key, Object value) {
            try {
                this.f2476a.put(key, value);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        /* renamed from: c */
        private void m4937c() {
            SharedPreferences prefs = C1170t.m4876d(C1185w.f2488h);
            String dependValuesStr = prefs.getString("ONESIGNAL_USERSTATE_DEPENDVALYES_" + this.f2480e, null);
            if (dependValuesStr == null) {
                this.f2476a = new JSONObject();
                boolean userSubscribePref = true;
                try {
                    int subscribableStatus;
                    if (this.f2480e.equals("CURRENT_STATE")) {
                        subscribableStatus = prefs.getInt("ONESIGNAL_SUBSCRIPTION", 1);
                    } else {
                        subscribableStatus = prefs.getInt("ONESIGNAL_SYNCED_SUBSCRIPTION", 1);
                    }
                    if (subscribableStatus == -2) {
                        subscribableStatus = 1;
                        userSubscribePref = false;
                    }
                    this.f2476a.put("subscribableStatus", subscribableStatus);
                    this.f2476a.put("userSubscribePref", userSubscribePref);
                } catch (JSONException e) {
                }
            } else {
                try {
                    this.f2476a = new JSONObject(dependValuesStr);
                } catch (JSONException e2) {
                    e2.printStackTrace();
                }
            }
            String syncValuesStr = prefs.getString("ONESIGNAL_USERSTATE_SYNCVALYES_" + this.f2480e, null);
            if (syncValuesStr == null) {
                try {
                    this.f2477b = new JSONObject();
                    this.f2477b.put("identifier", prefs.getString("GT_REGISTRATION_ID", null));
                    return;
                } catch (JSONException e22) {
                    e22.printStackTrace();
                    return;
                }
            }
            this.f2477b = new JSONObject(syncValuesStr);
        }

        /* renamed from: d */
        private void m4939d() {
            synchronized (C1185w.f2491k) {
                m4936b("pkgs");
                Editor editor = C1170t.m4876d(C1185w.f2488h).edit();
                editor.putString("ONESIGNAL_USERSTATE_SYNCVALYES_" + this.f2480e, this.f2477b.toString());
                editor.putString("ONESIGNAL_USERSTATE_DEPENDVALYES_" + this.f2480e, this.f2476a.toString());
                editor.commit();
            }
        }

        /* renamed from: b */
        private void m4936b(String baseKey) {
            if (this.f2477b.has(baseKey + "_d") || !this.f2477b.has(baseKey + "_d")) {
                try {
                    JSONArray orgArray;
                    int i;
                    if (this.f2477b.has(baseKey)) {
                        orgArray = this.f2477b.getJSONArray(baseKey);
                    } else {
                        orgArray = new JSONArray();
                    }
                    JSONArray tempArray = new JSONArray();
                    if (this.f2477b.has(baseKey + "_d")) {
                        String remArrayStr = C1185w.m4957b(this.f2477b.getJSONArray(baseKey + "_d"));
                        for (i = 0; i < orgArray.length(); i++) {
                            if (!remArrayStr.contains(orgArray.getString(i))) {
                                tempArray.put(orgArray.get(i));
                            }
                        }
                    } else {
                        tempArray = orgArray;
                    }
                    if (this.f2477b.has(baseKey + "_a")) {
                        JSONArray newArray = this.f2477b.getJSONArray(baseKey + "_a");
                        for (i = 0; i < newArray.length(); i++) {
                            tempArray.put(newArray.get(i));
                        }
                    }
                    this.f2477b.put(baseKey, tempArray);
                    this.f2477b.remove(baseKey + "_a");
                    this.f2477b.remove(baseKey + "_d");
                } catch (Throwable th) {
                }
            }
        }

        /* renamed from: c */
        private void m4938c(JSONObject inDependValues, JSONObject inSyncValues) {
            if (inDependValues != null) {
                C1185w.m4959b(this.f2476a, inDependValues, this.f2476a, null);
            }
            if (inSyncValues != null) {
                C1185w.m4959b(this.f2477b, inSyncValues, this.f2477b, null);
                m4941a(inSyncValues, null);
            }
            if (inDependValues != null || inSyncValues != null) {
                m4939d();
            }
        }

        /* renamed from: a */
        void m4941a(JSONObject inSyncValues, JSONObject omitKeys) {
            synchronized (C1185w.f2491k) {
                if (inSyncValues.has("tags")) {
                    JSONObject newTags;
                    if (this.f2477b.has("tags")) {
                        try {
                            newTags = new JSONObject(this.f2477b.optString("tags"));
                        } catch (JSONException e) {
                            newTags = new JSONObject();
                        }
                    } else {
                        newTags = new JSONObject();
                    }
                    JSONObject curTags = inSyncValues.optJSONObject("tags");
                    Iterator<String> keys = curTags.keys();
                    while (keys.hasNext()) {
                        String key = (String) keys.next();
                        if ("".equals(curTags.optString(key))) {
                            newTags.remove(key);
                        } else {
                            if (omitKeys != null) {
                                try {
                                    if (omitKeys.has(key)) {
                                    }
                                } catch (Throwable th) {
                                }
                            }
                            newTags.put(key, curTags.optString(key));
                        }
                    }
                    if (newTags.toString().equals("{}")) {
                        this.f2477b.remove("tags");
                    } else {
                        this.f2477b.put("tags", newTags);
                    }
                }
            }
        }
    }

    C1185w() {
    }

    /* renamed from: b */
    private static JSONObject m4959b(JSONObject cur, JSONObject changedTo, JSONObject baseOutput, Set<String> includeFields) {
        JSONObject c;
        synchronized (f2491k) {
            c = C1185w.m4961c(cur, changedTo, baseOutput, includeFields);
        }
        return c;
    }

    /* renamed from: c */
    private static JSONObject m4961c(JSONObject cur, JSONObject changedTo, JSONObject baseOutput, Set<String> includeFields) {
        if (cur == null) {
            return null;
        }
        if (changedTo == null) {
            return baseOutput;
        }
        JSONObject output;
        Iterator<String> keys = changedTo.keys();
        if (baseOutput != null) {
            output = baseOutput;
        } else {
            output = new JSONObject();
        }
        while (keys.hasNext()) {
            try {
                String key = (String) keys.next();
                Object value = changedTo.get(key);
                if (cur.has(key)) {
                    if (value instanceof JSONObject) {
                        JSONObject curValue = cur.getJSONObject(key);
                        JSONObject outValue = null;
                        if (baseOutput != null && baseOutput.has(key)) {
                            outValue = baseOutput.getJSONObject(key);
                        }
                        String returnedJsonStr = C1185w.m4961c(curValue, (JSONObject) value, outValue, includeFields).toString();
                        if (!returnedJsonStr.equals("{}")) {
                            output.put(key, new JSONObject(returnedJsonStr));
                        }
                    } else if (value instanceof JSONArray) {
                        C1185w.m4950a(key, (JSONArray) value, cur.getJSONArray(key), output);
                    } else if (includeFields == null || !includeFields.contains(key)) {
                        Object curValue2 = cur.get(key);
                        if (!value.equals(curValue2)) {
                            if (!(curValue2 instanceof Integer) || "".equals(value)) {
                                output.put(key, value);
                            } else if (((Number) curValue2).doubleValue() != ((Number) value).doubleValue()) {
                                output.put(key, value);
                            }
                        }
                    } else {
                        output.put(key, value);
                    }
                } else if (value instanceof JSONObject) {
                    output.put(key, new JSONObject(value.toString()));
                } else if (value instanceof JSONArray) {
                    C1185w.m4950a(key, (JSONArray) value, null, output);
                } else {
                    output.put(key, value);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return output;
    }

    /* renamed from: a */
    private static void m4950a(String key, JSONArray newArray, JSONArray curArray, JSONObject output) throws JSONException {
        if (key.endsWith("_a") || key.endsWith("_d")) {
            output.put(key, newArray);
            return;
        }
        int i;
        String arrayStr = C1185w.m4957b(newArray);
        JSONArray newOutArray = new JSONArray();
        JSONArray remOutArray = new JSONArray();
        String curArrayStr = curArray == null ? null : C1185w.m4957b(curArray);
        for (i = 0; i < newArray.length(); i++) {
            String arrayValue = (String) newArray.get(i);
            if (curArray == null || !curArrayStr.contains(arrayValue)) {
                newOutArray.put(arrayValue);
            }
        }
        if (curArray != null) {
            for (i = 0; i < curArray.length(); i++) {
                arrayValue = curArray.getString(i);
                if (!arrayStr.contains(arrayValue)) {
                    remOutArray.put(arrayValue);
                }
            }
        }
        if (!newOutArray.toString().equals("[]")) {
            output.put(key + "_a", newOutArray);
        }
        if (!remOutArray.toString().equals("[]")) {
            output.put(key + "_d", remOutArray);
        }
    }

    /* renamed from: b */
    private static String m4957b(JSONArray jsonArray) {
        String strArray = "[";
        int i = 0;
        while (i < jsonArray.length()) {
            try {
                strArray = strArray + "\"" + jsonArray.getString(i) + "\"";
                i++;
            } catch (Throwable th) {
            }
        }
        return strArray + "]";
    }

    /* renamed from: b */
    private static JSONObject m4958b(JSONObject jsonObject) {
        if (!jsonObject.has("tags")) {
            return null;
        }
        JSONObject toReturn = new JSONObject();
        synchronized (f2491k) {
            JSONObject keyValues = jsonObject.optJSONObject("tags");
            Iterator<String> keys = keyValues.keys();
            while (keys.hasNext()) {
                String key = (String) keys.next();
                try {
                    Object value = keyValues.get(key);
                    if (!"".equals(value)) {
                        toReturn.put(key, value);
                    }
                } catch (Throwable th) {
                }
            }
        }
        return toReturn;
    }

    /* renamed from: a */
    public static void m4946a() {
        for (Entry<Integer, C1183b> handlerThread : f2481a.entrySet()) {
            ((C1183b) handlerThread.getValue()).m4924b();
        }
        if (f2486f != null) {
            f2486f.m4939d();
        }
    }

    /* renamed from: a */
    static void m4947a(Context context) {
        f2488h = context;
        synchronized (f2491k) {
            if (f2485e == null) {
                C1185w c1185w = new C1185w();
                c1185w.getClass();
                f2485e = new C1184c("CURRENT_STATE", true);
            }
            if (f2486f == null) {
                c1185w = new C1185w();
                c1185w.getClass();
                f2486f = new C1184c("TOSYNC_STATE", true);
            }
        }
    }

    /* renamed from: b */
    static C1184c m4956b() {
        C1185w c1185w = new C1185w();
        c1185w.getClass();
        return new C1184c("nonPersist", false);
    }

    /* renamed from: a */
    static void m4952a(boolean fromSyncService) {
        String userId = C1170t.m4881e();
        boolean isSessionCall = userId == null || (f2483c && !f2484d);
        final JSONObject jsonBody = f2485e.m4929a(f2486f, isSessionCall);
        final JSONObject dependDiff = C1185w.m4959b(f2485e.f2476a, f2486f.f2476a, null, null);
        if (jsonBody == null) {
            f2485e.m4938c(dependDiff, null);
            return;
        }
        f2486f.m4939d();
        if (userId == null && !f2483c) {
            return;
        }
        if (!isSessionCall || fromSyncService) {
            C1175v.m4915c("players/" + userId, jsonBody, new C1108a() {
                /* renamed from: a */
                void mo1122a(int statusCode, String response, Throwable throwable) {
                    C1170t.m4843a(C1166d.WARN, "Failed last request. statusCode: " + statusCode + "\nresponse: " + response);
                    if (C1185w.m4960b(statusCode, response, "No user with this id found")) {
                        C1185w.m4967f();
                    } else {
                        C1185w.m4955b(Integer.valueOf(0)).m4925c();
                    }
                }

                /* renamed from: a */
                void mo1116a(String response) {
                    C1185w.f2485e.m4938c(dependDiff, jsonBody);
                }
            });
            return;
        }
        String urlStr;
        if (userId == null) {
            urlStr = "players";
        } else {
            urlStr = "players/" + userId + "/on_session";
        }
        f2484d = true;
        C1175v.m4916d(urlStr, jsonBody, new C1108a() {
            /* renamed from: a */
            void mo1122a(int statusCode, String response, Throwable throwable) {
                C1185w.f2484d = false;
                C1170t.m4843a(C1166d.WARN, "Failed last request. statusCode: " + statusCode + "\nresponse: " + response);
                if (C1185w.m4960b(statusCode, response, "not a valid device_type")) {
                    C1185w.m4967f();
                } else {
                    C1185w.m4955b(Integer.valueOf(0)).m4925c();
                }
            }

            /* renamed from: a */
            void mo1116a(String response) {
                C1185w.f2483c = C1185w.f2484d = false;
                C1185w.f2485e.m4938c(dependDiff, jsonBody);
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    if (jsonResponse.has("id")) {
                        String userId = jsonResponse.optString("id");
                        C1170t.m4863b(userId);
                        C1170t.m4843a(C1166d.INFO, "Device registered, UserId = " + userId);
                    } else {
                        C1170t.m4843a(C1166d.INFO, "session sent, UserId = " + C1170t.m4881e());
                    }
                    C1170t.m4893l();
                } catch (Throwable t) {
                    C1170t.m4844a(C1166d.ERROR, "ERROR parsing on_session or create JSON Response.", t);
                }
            }
        });
    }

    /* renamed from: b */
    private static boolean m4960b(int statusCode, String response, String contains) {
        if (statusCode != 400 || response == null) {
            return false;
        }
        try {
            JSONObject responseJson = new JSONObject(response);
            if (responseJson.has("errors") && responseJson.optString("errors").contains(contains)) {
                return true;
            }
            return false;
        } catch (Throwable t) {
            t.printStackTrace();
            return false;
        }
    }

    /* renamed from: b */
    private static C1183b m4955b(Integer type) {
        C1183b c1183b;
        synchronized (f2487g) {
            if (!f2481a.containsKey(type)) {
                f2481a.put(type, new C1183b(type.intValue()));
            }
            c1183b = (C1183b) f2481a.get(type);
        }
        return c1183b;
    }

    /* renamed from: l */
    private static C1184c m4973l() {
        if (f2486f == null) {
            f2486f = f2485e.m4927a("TOSYNC_STATE");
        }
        C1185w.m4974m();
        return f2486f;
    }

    /* renamed from: m */
    private static void m4974m() {
        C1185w.m4955b(Integer.valueOf(0)).m4923a();
    }

    /* renamed from: a */
    static void m4948a(C1184c postSession, boolean isSession) {
        JSONObject toSync = C1185w.m4973l().f2477b;
        C1185w.m4959b(toSync, postSession.f2477b, toSync, null);
        JSONObject dependValues = C1185w.m4973l().f2476a;
        C1185w.m4959b(dependValues, postSession.f2476a, dependValues, null);
        boolean z = f2483c || isSession || C1170t.m4881e() == null;
        f2483c = z;
    }

    /* renamed from: a */
    static void m4951a(JSONObject newTags) {
        JSONObject userStateTags = C1185w.m4973l().f2477b;
        try {
            C1185w.m4959b(userStateTags, new JSONObject().put("tags", newTags), userStateTags, null);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    /* renamed from: a */
    static void m4949a(Double lat, Double log, Float accuracy, Integer type) {
        C1184c userState = C1185w.m4973l();
        try {
            userState.f2477b.put("lat", lat);
            userState.f2477b.put("long", log);
            userState.f2477b.put("loc_acc", accuracy);
            userState.f2477b.put("loc_type", type);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    /* renamed from: c */
    static boolean m4962c() {
        return f2486f.m4933b() > 0;
    }

    /* renamed from: d */
    static String m4964d() {
        return f2486f.f2477b.optString("identifier", null);
    }

    /* renamed from: b */
    static C1181a m4954b(boolean fromServer) {
        if (fromServer) {
            C1175v.m4912b("players/" + C1170t.m4881e(), new C11805());
        }
        return new C1181a(f2482b, C1185w.m4958b(f2486f.f2477b));
    }

    /* renamed from: e */
    static void m4966e() {
        C1170t.m4847a(null);
        f2485e.f2477b = new JSONObject();
        f2485e.m4939d();
        C1170t.m4835a(-3660);
    }

    /* renamed from: f */
    static void m4967f() {
        C1185w.m4966e();
        f2483c = true;
        C1185w.m4974m();
    }
}

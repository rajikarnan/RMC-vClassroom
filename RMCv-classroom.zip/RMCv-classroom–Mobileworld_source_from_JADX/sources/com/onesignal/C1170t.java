package com.onesignal;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Application;
import android.app.NotificationManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Base64;
import android.util.Log;
import com.onesignal.C1129i.C1128b;
import com.onesignal.C1139o.C1138a;
import com.onesignal.C1141p.C1140a;
import com.onesignal.C1175v.C1108a;
import com.onesignal.C1185w.C1181a;
import com.onesignal.C1185w.C1184c;
import com.onesignal.C1186x.C1157a;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;
import org.json.JSONArray;
import org.json.JSONObject;

/* compiled from: OneSignal */
/* renamed from: com.onesignal.t */
public class C1170t {
    /* renamed from: A */
    private static Double f2420A;
    /* renamed from: B */
    private static Double f2421B;
    /* renamed from: C */
    private static Float f2422C;
    /* renamed from: D */
    private static Integer f2423D;
    /* renamed from: E */
    private static boolean f2424E = true;
    /* renamed from: F */
    private static C1165b f2425F;
    /* renamed from: G */
    private static boolean f2426G;
    /* renamed from: H */
    private static boolean f2427H;
    /* renamed from: I */
    private static boolean f2428I;
    /* renamed from: J */
    private static JSONObject f2429J;
    /* renamed from: K */
    private static int f2430K = 0;
    /* renamed from: a */
    static String f2431a;
    /* renamed from: b */
    static String f2432b;
    /* renamed from: c */
    static Context f2433c;
    /* renamed from: d */
    static boolean f2434d;
    /* renamed from: e */
    public static String f2435e = "native";
    /* renamed from: f */
    static C1164a f2436f;
    /* renamed from: g */
    static Collection<JSONArray> f2437g = new ArrayList();
    /* renamed from: h */
    static boolean f2438h;
    /* renamed from: i */
    private static C1166d f2439i = C1166d.NONE;
    /* renamed from: j */
    private static C1166d f2440j = C1166d.WARN;
    /* renamed from: k */
    private static String f2441k = null;
    /* renamed from: l */
    private static int f2442l;
    /* renamed from: m */
    private static boolean f2443m;
    /* renamed from: n */
    private static C1110c f2444n;
    /* renamed from: o */
    private static long f2445o = 1;
    /* renamed from: p */
    private static long f2446p = -1;
    /* renamed from: q */
    private static ad f2447q;
    /* renamed from: r */
    private static ac f2448r;
    /* renamed from: s */
    private static C1113d f2449s = new C1114c();
    /* renamed from: t */
    private static int f2450t;
    /* renamed from: u */
    private static C1146s f2451u;
    /* renamed from: v */
    private static String f2452v;
    /* renamed from: w */
    private static boolean f2453w;
    /* renamed from: x */
    private static boolean f2454x;
    /* renamed from: y */
    private static boolean f2455y;
    /* renamed from: z */
    private static boolean f2456z;

    /* compiled from: OneSignal */
    /* renamed from: com.onesignal.t$c */
    public interface C1110c {
        /* renamed from: a */
        void mo1117a(String str, String str2);
    }

    /* compiled from: OneSignal */
    /* renamed from: com.onesignal.t$1 */
    static class C11531 implements C1128b {
        C11531() {
        }

        /* renamed from: a */
        public void mo1121a(Double lat, Double log, Float accuracy, Integer type) {
            C1170t.f2420A = lat;
            C1170t.f2421B = log;
            C1170t.f2422C = accuracy;
            C1170t.f2423D = type;
            C1170t.f2454x = true;
            C1170t.m4825L();
        }
    }

    /* compiled from: OneSignal */
    /* renamed from: com.onesignal.t$3 */
    static class C11553 extends C1108a {
        C11553() {
        }

        /* renamed from: a */
        void mo1122a(int statusCode, String response, Throwable throwable) {
            C1170t.m4864b("sending Notification Opened Failed", statusCode, throwable, response);
        }
    }

    /* compiled from: OneSignal */
    /* renamed from: com.onesignal.t$4 */
    static class C11564 implements C1128b {
        C11564() {
        }

        /* renamed from: a */
        public void mo1121a(Double lat, Double log, Float accuracy, Integer type) {
            if (lat != null && log != null) {
                C1185w.m4949a(lat, log, accuracy, type);
            }
        }
    }

    /* compiled from: OneSignal */
    /* renamed from: com.onesignal.t$5 */
    static class C11585 implements C1157a {
        C11585() {
        }

        /* renamed from: a */
        public void mo1123a(String id, int status) {
            if (status < 1) {
                if (C1185w.m4964d() == null && (C1170t.f2442l == 1 || C1170t.f2442l < -6)) {
                    C1170t.f2442l = status;
                }
            } else if (C1170t.f2442l < -6) {
                C1170t.f2442l = status;
            }
            C1170t.f2452v = id;
            C1170t.f2453w = true;
            C1170t.m4825L();
        }
    }

    /* compiled from: OneSignal */
    /* renamed from: com.onesignal.t$6 */
    static class C11606 extends C1108a {

        /* compiled from: OneSignal */
        /* renamed from: com.onesignal.t$6$1 */
        class C11591 implements Runnable {
            /* renamed from: a */
            final /* synthetic */ C11606 f2400a;

            C11591(C11606 this$0) {
                this.f2400a = this$0;
            }

            public void run() {
                try {
                    Thread.sleep((long) ((C1170t.f2430K * 10000) + 30000));
                } catch (Throwable th) {
                }
                C1170t.m4897p();
                C1170t.m4822I();
            }
        }

        C11606() {
        }

        /* renamed from: a */
        void mo1122a(int statusCode, String response, Throwable throwable) {
            Thread thread = new Thread(new C11591(this), "OS_PARAMS_REQUEST");
        }

        /* renamed from: a */
        void mo1116a(String response) {
            try {
                JSONObject responseJson = new JSONObject(response);
                if (responseJson.has("android_sender_id")) {
                    C1170t.f2432b = responseJson.getString("android_sender_id");
                }
                C1170t.f2429J = responseJson.getJSONObject("awl_list");
            } catch (Throwable t) {
                t.printStackTrace();
            }
            C1170t.f2455y = true;
            C1170t.m4821H();
        }
    }

    /* compiled from: OneSignal */
    /* renamed from: com.onesignal.t$8 */
    static class C11628 extends C1108a {
        C11628() {
        }

        /* renamed from: a */
        void mo1122a(int statusCode, String response, Throwable throwable) {
            C1170t.m4864b("sending on_focus Failed", statusCode, throwable, response);
        }

        /* renamed from: a */
        void mo1116a(String response) {
            C1170t.m4874c(0);
        }
    }

    /* compiled from: OneSignal */
    /* renamed from: com.onesignal.t$9 */
    static class C11639 implements Runnable {
        C11639() {
        }

        public void run() {
            C1184c userState = C1185w.m4956b();
            Object packageName = C1170t.f2433c.getPackageName();
            PackageManager packageManager = C1170t.f2433c.getPackageManager();
            userState.m4940a("app_id", C1170t.f2431a);
            userState.m4940a("identifier", C1170t.f2452v);
            Object adId = C1170t.f2449s.mo1118a(C1170t.f2433c);
            if (adId != null) {
                userState.m4940a("ad_id", adId);
            }
            userState.m4940a("device_os", VERSION.RELEASE);
            userState.m4940a("timezone", Integer.valueOf(C1170t.m4824K()));
            userState.m4940a("language", C1146s.m4753d());
            userState.m4940a("sdk", (Object) "030403");
            userState.m4940a("sdk_type", C1170t.f2435e);
            userState.m4940a("android_package", packageName);
            userState.m4940a("device_model", Build.MODEL);
            userState.m4940a("device_type", Integer.valueOf(C1170t.f2450t));
            userState.m4942b("subscribableStatus", Integer.valueOf(C1170t.f2442l));
            try {
                userState.m4940a("game_version", Integer.valueOf(packageManager.getPackageInfo(packageName, 0).versionCode));
            } catch (NameNotFoundException e) {
            }
            try {
                List<PackageInfo> packList = packageManager.getInstalledPackages(0);
                Object pkgs = new JSONArray();
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                for (int i = 0; i < packList.size(); i++) {
                    md.update(((PackageInfo) packList.get(i)).packageName.getBytes());
                    String pck = Base64.encodeToString(md.digest(), 2);
                    if (C1170t.f2429J.has(pck)) {
                        pkgs.put(pck);
                    }
                }
                userState.m4940a("pkgs", pkgs);
            } catch (Throwable th) {
            }
            userState.m4940a("net_type", C1170t.f2451u.m4756b());
            userState.m4940a("carrier", C1170t.f2451u.m4757c());
            userState.m4940a("rooted", Boolean.valueOf(ab.m4641a()));
            userState.m4940a("lat", C1170t.f2420A);
            userState.m4940a("long", C1170t.f2421B);
            userState.m4940a("loc_acc", C1170t.f2422C);
            userState.m4940a("loc_type", C1170t.f2423D);
            C1185w.m4948a(userState, C1170t.f2428I);
            C1170t.f2427H = false;
        }
    }

    /* compiled from: OneSignal */
    /* renamed from: com.onesignal.t$a */
    public static class C1164a {
        /* renamed from: a */
        C1167e f2403a;
        /* renamed from: b */
        C1168f f2404b;
        /* renamed from: c */
        boolean f2405c;
        /* renamed from: d */
        boolean f2406d;
        /* renamed from: e */
        C1169g f2407e;

        private C1164a() {
            this.f2407e = C1169g.InAppAlert;
        }
    }

    /* compiled from: OneSignal */
    /* renamed from: com.onesignal.t$b */
    public interface C1165b {
        /* renamed from: a */
        void mo1153a(JSONObject jSONObject);
    }

    /* compiled from: OneSignal */
    /* renamed from: com.onesignal.t$d */
    public enum C1166d {
        NONE,
        FATAL,
        ERROR,
        WARN,
        INFO,
        DEBUG,
        VERBOSE
    }

    /* compiled from: OneSignal */
    /* renamed from: com.onesignal.t$e */
    public interface C1167e {
        /* renamed from: a */
        void mo1146a(C1142q c1142q);
    }

    /* compiled from: OneSignal */
    /* renamed from: com.onesignal.t$f */
    public interface C1168f {
        /* renamed from: a */
        void m4813a(C1139o c1139o);
    }

    /* compiled from: OneSignal */
    /* renamed from: com.onesignal.t$g */
    public enum C1169g {
        None,
        InAppAlert,
        Notification
    }

    /* renamed from: p */
    static /* synthetic */ int m4897p() {
        int i = f2430K;
        f2430K = i + 1;
        return i;
    }

    /* renamed from: a */
    public static void m4837a(Context context, String googleProjectNumber, String oneSignalAppId, C1167e notificationOpenedHandler) {
        C1170t.m4838a(context, googleProjectNumber, oneSignalAppId, notificationOpenedHandler, null);
    }

    /* renamed from: a */
    public static void m4838a(Context context, String googleProjectNumber, String oneSignalAppId, C1167e notificationOpenedHandler, C1168f notificationReceivedHandler) {
        if (f2436f == null) {
            f2436f = new C1164a();
        }
        f2436f.f2403a = notificationOpenedHandler;
        f2436f.f2404b = notificationReceivedHandler;
        f2432b = googleProjectNumber;
        f2451u = new C1146s();
        f2450t = f2451u.m4754a();
        f2442l = f2451u.m4755a(f2450t, oneSignalAppId);
        if (f2442l != -999) {
            if (f2434d) {
                if (context != null) {
                    f2433c = context.getApplicationContext();
                }
                if (f2436f.f2403a != null) {
                    C1170t.m4823J();
                    return;
                }
                return;
            }
            boolean contextIsActivity = context instanceof Activity;
            f2443m = contextIsActivity;
            f2431a = oneSignalAppId;
            f2433c = context.getApplicationContext();
            if (contextIsActivity) {
                C1101a.f2289b = (Activity) context;
                C1137n.m4749a(f2433c);
                C1170t.m4828O();
            } else {
                C1101a.f2288a = true;
            }
            f2445o = SystemClock.elapsedRealtime();
            C1185w.m4947a(f2433c);
            if (VERSION.SDK_INT > 13) {
                ((Application) f2433c).registerActivityLifecycleCallbacks(new C1112b());
            } else {
                ActivityLifecycleListenerCompat.startListener();
            }
            try {
                Class.forName("com.amazon.device.iap.PurchasingListener");
                f2448r = new ac(f2433c);
            } catch (ClassNotFoundException e) {
            }
            String oldAppId = C1170t.m4877d();
            if (oldAppId == null) {
                C1120f.m4679a(0, f2433c);
                C1170t.m4878d(f2431a);
            } else if (!oldAppId.equals(f2431a)) {
                C1170t.m4843a(C1166d.DEBUG, "APP ID changed, clearing user id as it is no longer valid.");
                C1170t.m4878d(f2431a);
                C1185w.m4966e();
            }
            if (f2443m || C1170t.m4881e() == null) {
                f2428I = C1170t.m4827N();
                C1170t.m4835a(System.currentTimeMillis());
                C1170t.m4819F();
            }
            if (f2436f.f2403a != null) {
                C1170t.m4823J();
            }
            if (ad.m4656a(f2433c)) {
                f2447q = new ad(f2433c);
            }
            f2434d = true;
        }
    }

    /* renamed from: F */
    private static void m4819F() {
        boolean z = false;
        if (!f2427H) {
            f2427H = true;
            f2453w = false;
            if (f2428I) {
                f2454x = false;
            }
            C1170t.m4820G();
            C1170t.m4822I();
            if (f2456z || f2436f.f2405c) {
                z = true;
            }
            f2456z = z;
        }
    }

    /* renamed from: G */
    private static void m4820G() {
        boolean z = true;
        if (f2424E) {
            Context context = f2433c;
            if (!f2436f.f2405c || f2456z) {
                z = false;
            }
            C1129i.m4721a(context, z, new C11531());
            return;
        }
        f2454x = true;
        C1170t.m4825L();
    }

    /* renamed from: H */
    private static void m4821H() {
        C1186x pushRegistrator;
        if (f2450t == 2) {
            pushRegistrator = new C1188y();
        } else {
            pushRegistrator = new C1193z();
        }
        pushRegistrator.mo1124a(f2433c, f2432b, new C11585());
    }

    /* renamed from: I */
    private static void m4822I() {
        if (f2455y) {
            C1170t.m4821H();
            return;
        }
        C1108a responseHandler = new C11606();
        String awl_url = "apps/" + f2431a + "/android_params.js";
        String userId = C1170t.m4881e();
        if (userId != null) {
            awl_url = awl_url + "?player_id=" + userId;
        }
        C1175v.m4909a(awl_url, responseHandler);
    }

    /* renamed from: J */
    private static void m4823J() {
        for (JSONArray dataArray : f2437g) {
            C1170t.m4865b(dataArray, true, false);
        }
        f2437g.clear();
    }

    /* renamed from: a */
    private static boolean m4856a(C1166d level) {
        return level.compareTo(f2439i) < 1 || level.compareTo(f2440j) < 1;
    }

    /* renamed from: a */
    static void m4843a(C1166d level, String message) {
        C1170t.m4844a(level, message, null);
    }

    /* renamed from: a */
    static void m4844a(final C1166d level, String message, Throwable throwable) {
        if (level.compareTo(f2440j) < 1) {
            if (level == C1166d.VERBOSE) {
                Log.v("OneSignal", message, throwable);
            } else if (level == C1166d.DEBUG) {
                Log.d("OneSignal", message, throwable);
            } else if (level == C1166d.INFO) {
                Log.i("OneSignal", message, throwable);
            } else if (level == C1166d.WARN) {
                Log.w("OneSignal", message, throwable);
            } else if (level == C1166d.ERROR || level == C1166d.FATAL) {
                Log.e("OneSignal", message, throwable);
            }
        }
        if (level.compareTo(f2439i) < 1 && C1101a.f2289b != null) {
            try {
                String fullMessage = message + "\n";
                if (throwable != null) {
                    fullMessage = fullMessage + throwable.getMessage();
                    StringWriter sw = new StringWriter();
                    throwable.printStackTrace(new PrintWriter(sw));
                    fullMessage = fullMessage + sw.toString();
                }
                final String finalFullMessage = fullMessage;
                C1170t.m4846a(new Runnable() {
                    public void run() {
                        if (C1101a.f2289b != null) {
                            new Builder(C1101a.f2289b).setTitle(level.toString()).setMessage(finalFullMessage).show();
                        }
                    }
                });
            } catch (Throwable t) {
                Log.e("OneSignal", "Error showing logging message.", t);
            }
        }
    }

    /* renamed from: b */
    private static void m4864b(String errorString, int statusCode, Throwable throwable, String errorResponse) {
        String jsonError = "";
        if (errorResponse != null && C1170t.m4856a(C1166d.INFO)) {
            jsonError = "\n" + errorResponse + "\n";
        }
        C1170t.m4844a(C1166d.WARN, "HTTP code: " + statusCode + " " + errorString + jsonError, throwable);
    }

    /* renamed from: a */
    static void m4852a(boolean onlySave) {
        f2443m = false;
        if (f2434d) {
            if (f2448r != null) {
                f2448r.m4643a();
            }
            if (f2445o != -1) {
                long time_elapsed = (long) ((((double) (SystemClock.elapsedRealtime() - f2445o)) / 1000.0d) + 0.5d);
                f2445o = SystemClock.elapsedRealtime();
                if (time_elapsed >= 0 && time_elapsed <= 86400) {
                    if (f2433c == null) {
                        C1170t.m4843a(C1166d.ERROR, "Android Context not found, please call OneSignal.init when your app starts.");
                        return;
                    }
                    C1170t.m4835a(System.currentTimeMillis());
                    long totalTimeActive = C1170t.m4891j() + time_elapsed;
                    if (onlySave || totalTimeActive < 60 || C1170t.m4881e() == null) {
                        C1170t.m4874c(totalTimeActive);
                    } else {
                        C1170t.m4836a(totalTimeActive, true);
                    }
                }
            }
        }
    }

    /* renamed from: a */
    static void m4836a(long totalTimeActive, boolean synchronous) {
        JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("app_id", f2431a);
            jsonBody.put("type", 1);
            jsonBody.put("state", "ping");
            jsonBody.put("active_time", totalTimeActive);
            C1170t.m4879d(jsonBody);
            String url = "players/" + C1170t.m4881e() + "/on_focus";
            C1108a responseHandler = new C11628();
            if (synchronous) {
                C1175v.m4916d(url, jsonBody, responseHandler);
            } else {
                C1175v.m4914b(url, jsonBody, responseHandler);
            }
        } catch (Throwable t) {
            C1170t.m4844a(C1166d.ERROR, "Generating on_focus:JSON Failed.", t);
        }
    }

    /* renamed from: a */
    static void m4834a() {
        C1170t.m4828O();
        f2443m = true;
        f2445o = SystemClock.elapsedRealtime();
        f2428I = C1170t.m4827N();
        C1170t.m4835a(System.currentTimeMillis());
        C1170t.m4819F();
        if (f2447q != null) {
            f2447q.m4671a();
        }
        C1137n.m4749a(f2433c);
    }

    /* renamed from: b */
    static boolean m4866b() {
        return f2443m;
    }

    /* renamed from: d */
    private static void m4879d(JSONObject jsonObj) {
        try {
            jsonObj.put("net_type", f2451u.m4756b());
        } catch (Throwable th) {
        }
    }

    /* renamed from: K */
    private static int m4824K() {
        TimeZone timezone = Calendar.getInstance().getTimeZone();
        int offset = timezone.getRawOffset();
        if (timezone.inDaylightTime(new Date())) {
            offset += timezone.getDSTSavings();
        }
        return offset / 1000;
    }

    /* renamed from: L */
    private static void m4825L() {
        C1170t.m4843a(C1166d.DEBUG, "registerUser: registerForPushFired:" + f2453w + ", locationFired: " + f2454x + ", awlFired: " + f2455y);
        if (f2453w && f2454x && f2455y) {
            new Thread(new C11639(), "OS_REG_USER").start();
        }
    }

    /* renamed from: a */
    public static void m4851a(JSONObject keyValues) {
        if (f2433c == null) {
            C1170t.m4843a(C1166d.ERROR, "You must initialize OneSignal before modifying tags! Omitting this tag operation.");
        } else if (keyValues != null) {
            JSONObject existingKeys = C1185w.m4954b(false).f2471b;
            JSONObject toSend = new JSONObject();
            Iterator<String> keys = keyValues.keys();
            while (keys.hasNext()) {
                String key = (String) keys.next();
                try {
                    Object value = keyValues.get(key);
                    if ((value instanceof JSONArray) || (value instanceof JSONObject)) {
                        C1170t.m4843a(C1166d.ERROR, "Omitting key '" + key + "'! sendTags DO NOT supported nested values!");
                    } else if (!keyValues.isNull(key) && !"".equals(value)) {
                        toSend.put(key, value.toString());
                    } else if (existingKeys.has(key)) {
                        toSend.put(key, "");
                    }
                } catch (Throwable th) {
                }
            }
            if (!toSend.toString().equals("{}")) {
                C1185w.m4951a(toSend);
            }
        }
    }

    /* renamed from: a */
    public static void m4841a(C1165b getTagsHandler) {
        if (f2433c == null) {
            C1170t.m4843a(C1166d.ERROR, "You must initialize OneSignal before getting tags! Omitting this tag operation.");
        } else if (getTagsHandler == null) {
            C1170t.m4843a(C1166d.ERROR, "getTagsHandler is null!");
        } else if (C1170t.m4881e() == null) {
            f2425F = getTagsHandler;
        } else {
            C1170t.m4862b(getTagsHandler);
        }
    }

    /* renamed from: b */
    private static void m4862b(final C1165b getTagsHandler) {
        if (getTagsHandler != null) {
            new Thread(new Runnable() {
                public void run() {
                    C1181a tags = C1185w.m4954b(!C1170t.f2426G);
                    if (tags.f2470a) {
                        C1170t.f2426G = true;
                    }
                    if (tags.f2471b == null || tags.toString().equals("{}")) {
                        getTagsHandler.mo1153a(null);
                    } else {
                        getTagsHandler.mo1153a(tags.f2471b);
                    }
                }
            }, "OS_GETTAGS_CALLBACK").start();
        }
    }

    /* renamed from: a */
    public static void m4842a(C1110c inIdsAvailableHandler) {
        f2444n = inIdsAvailableHandler;
        if (C1170t.m4881e() != null) {
            C1170t.m4826M();
        }
    }

    /* renamed from: c */
    static void m4873c() {
        if (f2444n != null) {
            C1170t.m4846a(new Runnable() {
                public void run() {
                    C1170t.m4826M();
                }
            });
        }
    }

    /* renamed from: M */
    private static void m4826M() {
        if (f2444n != null) {
            String regId = C1185w.m4964d();
            if (!C1185w.m4962c()) {
                regId = null;
            }
            String userId = C1170t.m4881e();
            if (userId != null) {
                f2444n.mo1117a(userId, regId);
                if (regId != null) {
                    f2444n = null;
                }
            }
        }
    }

    /* renamed from: a */
    static void m4849a(JSONArray purchases, boolean newAsExisting, C1108a responseHandler) {
        if (C1170t.m4881e() != null) {
            try {
                JSONObject jsonBody = new JSONObject();
                jsonBody.put("app_id", f2431a);
                if (newAsExisting) {
                    jsonBody.put("existing", true);
                }
                jsonBody.put("purchases", purchases);
                C1175v.m4914b("players/" + C1170t.m4881e() + "/on_purchase", jsonBody, responseHandler);
            } catch (Throwable t) {
                C1170t.m4844a(C1166d.ERROR, "Failed to generate JSON for sendPurchases.", t);
            }
        }
    }

    /* renamed from: a */
    private static boolean m4854a(Context context, JSONArray dataArray) {
        int jsonArraySize = dataArray.length();
        boolean urlOpened = false;
        for (int i = 0; i < jsonArraySize; i++) {
            try {
                JSONObject data = dataArray.getJSONObject(i);
                if (data.has("custom")) {
                    JSONObject customJSON = new JSONObject(data.optString("custom"));
                    if (customJSON.has("u")) {
                        String url = customJSON.optString("u", null);
                        if (!url.contains("://")) {
                            url = "http://" + url;
                        }
                        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
                        intent.addFlags(1476919296);
                        context.startActivity(intent);
                        urlOpened = true;
                    }
                }
            } catch (Throwable t) {
                C1170t.m4844a(C1166d.ERROR, "Error parsing JSON item " + i + "/" + jsonArraySize + " for launching a web URL.", t);
            }
        }
        return urlOpened;
    }

    /* renamed from: b */
    private static void m4865b(JSONArray dataArray, boolean shown, boolean fromAlert) {
        if (f2436f == null || f2436f.f2403a == null) {
            f2437g.add(dataArray);
        } else {
            C1170t.m4840a(C1170t.m4870c(dataArray, shown, fromAlert));
        }
    }

    /* renamed from: c */
    private static C1142q m4870c(JSONArray dataArray, boolean shown, boolean fromAlert) {
        int jsonArraySize = dataArray.length();
        boolean firstMessage = true;
        C1142q openResult = new C1142q();
        C1139o notification = new C1139o();
        notification.f2350a = C1170t.m4892k();
        notification.f2351b = shown;
        notification.f2352c = dataArray.optJSONObject(0).optInt("notificationId");
        String actionSelected = null;
        for (int i = 0; i < jsonArraySize; i++) {
            try {
                JSONObject data = dataArray.getJSONObject(i);
                if (data.has("custom")) {
                    notification.f2353d = C1131j.m4729a(data);
                    if (actionSelected == null && data.has("actionSelected")) {
                        actionSelected = data.optString("actionSelected", null);
                    }
                }
                if (firstMessage) {
                    firstMessage = false;
                } else {
                    if (notification.f2355f == null) {
                        notification.f2355f = new ArrayList();
                    }
                    notification.f2355f.add(notification.f2353d);
                }
            } catch (Throwable t) {
                C1170t.m4844a(C1166d.ERROR, "Error parsing JSON item " + i + "/" + jsonArraySize + " for callback.", t);
            }
        }
        openResult.f2361a = notification;
        openResult.f2362b = new C1141p();
        openResult.f2362b.f2360b = actionSelected;
        openResult.f2362b.f2359a = actionSelected != null ? C1140a.ActionTaken : C1140a.Opened;
        if (fromAlert) {
            openResult.f2361a.f2354e = C1138a.InAppAlert;
        } else {
            openResult.f2361a.f2354e = C1138a.Notification;
        }
        return openResult;
    }

    /* renamed from: a */
    private static void m4840a(final C1142q openedResult) {
        if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
            f2436f.f2403a.mo1146a(openedResult);
        } else {
            C1170t.m4846a(new Runnable() {
                public void run() {
                    C1170t.f2436f.f2403a.mo1146a(openedResult);
                }
            });
        }
    }

    /* renamed from: a */
    static void m4850a(JSONArray data, boolean displayed, boolean fromAlert) {
        if (f2436f != null && f2436f.f2404b != null) {
            f2436f.f2404b.m4813a(C1170t.m4870c(data, displayed, fromAlert).f2361a);
        }
    }

    /* renamed from: a */
    public static void m4839a(Context inContext, JSONArray data, boolean fromAlert) {
        C1170t.m4861b(inContext, data);
        boolean urlOpened = false;
        boolean defaultOpenActionDisabled = "DISABLE".equals(C1146s.m4751a(inContext, "com.onesignal.NotificationOpened.DEFAULT"));
        if (!defaultOpenActionDisabled) {
            urlOpened = C1170t.m4854a(inContext, data);
        }
        C1170t.m4865b(data, true, fromAlert);
        if (!fromAlert && !urlOpened && !defaultOpenActionDisabled) {
            C1170t.m4882e(inContext);
        }
    }

    /* renamed from: e */
    private static void m4882e(Context inContext) {
        Intent launchIntent = inContext.getPackageManager().getLaunchIntentForPackage(inContext.getPackageName());
        if (launchIntent != null) {
            launchIntent.setFlags(268566528);
            inContext.startActivity(launchIntent);
        }
    }

    /* renamed from: b */
    private static void m4861b(Context inContext, JSONArray dataArray) {
        for (int i = 0; i < dataArray.length(); i++) {
            try {
                JSONObject data = dataArray.getJSONObject(i);
                if (data.has("custom")) {
                    JSONObject customJson = new JSONObject(data.optString("custom", null));
                    if (customJson.has("i")) {
                        String notificationId = customJson.optString("i", null);
                        JSONObject jsonBody = new JSONObject();
                        jsonBody.put("app_id", C1170t.m4884f(inContext));
                        jsonBody.put("player_id", C1170t.m4887g(inContext));
                        jsonBody.put("opened", true);
                        C1175v.m4911a("notifications/" + notificationId, jsonBody, new C11553());
                    }
                }
            } catch (Throwable t) {
                C1170t.m4844a(C1166d.ERROR, "Failed to generate JSON to send notification opened.", t);
            }
        }
    }

    /* renamed from: d */
    private static void m4878d(String appId) {
        if (f2433c != null) {
            Editor editor = C1170t.m4876d(f2433c).edit();
            editor.putString("GT_APP_ID", appId);
            editor.commit();
        }
    }

    /* renamed from: d */
    static String m4877d() {
        return C1170t.m4884f(f2433c);
    }

    /* renamed from: f */
    private static String m4884f(Context inContext) {
        if (inContext == null) {
            return "";
        }
        return C1170t.m4876d(inContext).getString("GT_APP_ID", null);
    }

    /* renamed from: g */
    private static String m4887g(Context inContext) {
        if (inContext == null) {
            return "";
        }
        return C1170t.m4876d(inContext).getString("GT_PLAYER_ID", null);
    }

    /* renamed from: e */
    static String m4881e() {
        if (f2441k == null && f2433c != null) {
            f2441k = C1170t.m4876d(f2433c).getString("GT_PLAYER_ID", null);
        }
        return f2441k;
    }

    /* renamed from: a */
    static void m4847a(String inUserId) {
        f2441k = inUserId;
        if (f2433c != null) {
            Editor editor = C1170t.m4876d(f2433c).edit();
            editor.putString("GT_PLAYER_ID", f2441k);
            editor.commit();
        }
    }

    /* renamed from: b */
    static void m4863b(String userId) {
        C1170t.m4847a(userId);
        C1170t.m4873c();
        C1170t.m4862b(f2425F);
    }

    /* renamed from: a */
    static boolean m4853a(Context context) {
        return C1170t.m4876d(context).getBoolean("GT_VIBRATE_ENABLED", true);
    }

    /* renamed from: b */
    static boolean m4867b(Context context) {
        return C1170t.m4876d(context).getBoolean("GT_SOUND_ENABLED", true);
    }

    /* renamed from: a */
    static void m4835a(long time) {
        Editor editor = C1170t.m4876d(f2433c).edit();
        editor.putLong("OS_LAST_SESSION_TIME", time);
        editor.apply();
    }

    /* renamed from: c */
    static long m4869c(Context context) {
        return C1170t.m4876d(context).getLong("OS_LAST_SESSION_TIME", -31000);
    }

    /* renamed from: a */
    public static void m4845a(C1169g displayOption) {
        f2436f.f2407e = displayOption;
    }

    /* renamed from: f */
    static boolean m4885f() {
        if (f2436f == null || f2436f.f2407e == C1169g.Notification) {
            return true;
        }
        return false;
    }

    /* renamed from: g */
    static boolean m4888g() {
        if (f2436f != null && f2436f.f2407e == C1169g.InAppAlert) {
            return true;
        }
        return false;
    }

    /* renamed from: h */
    public static void m4889h() {
        if (!f2424E) {
            return;
        }
        if (f2433c == null) {
            C1170t.m4843a(C1166d.ERROR, "OneSignal.init has not been called. Could not prompt for location.");
            return;
        }
        C1129i.m4721a(f2433c, true, new C11564());
        f2456z = true;
    }

    /* renamed from: i */
    public static void m4890i() {
        if (f2433c == null) {
            C1170t.m4843a(C1166d.ERROR, "OneSignal.init has not been called. Could not clear notifications.");
            return;
        }
        NotificationManager notificationManager = (NotificationManager) f2433c.getSystemService("notification");
        C1171u dbHelper = C1171u.m4908a(f2433c);
        Cursor cursor = dbHelper.getReadableDatabase().query("notification", new String[]{"android_notification_id"}, "dismissed = 0 AND opened = 0", null, null, null, null);
        if (cursor.moveToFirst()) {
            while (true) {
                notificationManager.cancel(cursor.getInt(cursor.getColumnIndex("android_notification_id")));
                if (!cursor.moveToNext()) {
                    break;
                }
            }
        }
        cursor.close();
        SQLiteDatabase writableDb = dbHelper.getWritableDatabase();
        writableDb.beginTransaction();
        try {
            ContentValues values = new ContentValues();
            values.put("dismissed", Integer.valueOf(1));
            writableDb.update("notification", values, "opened = 0", null);
            writableDb.setTransactionSuccessful();
        } catch (Throwable e) {
            C1170t.m4844a(C1166d.ERROR, "Error marking all notifications as dismissed! ", e);
        } finally {
            writableDb.endTransaction();
        }
        C1120f.m4679a(0, f2433c);
    }

    /* renamed from: j */
    static long m4891j() {
        if (f2446p == -1 && f2433c != null) {
            f2446p = C1170t.m4876d(f2433c).getLong("GT_UNSENT_ACTIVE_TIME", 0);
        }
        C1170t.m4843a(C1166d.INFO, "GetUnsentActiveTime: " + f2446p);
        return f2446p;
    }

    /* renamed from: c */
    private static void m4874c(long time) {
        f2446p = time;
        if (f2433c != null) {
            C1170t.m4843a(C1166d.INFO, "SaveUnsentActiveTime: " + f2446p);
            Editor editor = C1170t.m4876d(f2433c).edit();
            editor.putLong("GT_UNSENT_ACTIVE_TIME", time);
            editor.commit();
        }
    }

    /* renamed from: d */
    static SharedPreferences m4876d(Context context) {
        return context.getSharedPreferences(C1170t.class.getSimpleName(), 0);
    }

    /* renamed from: a */
    static boolean m4857a(String id, Context context) {
        if (id == null || "".equals(id)) {
            return false;
        }
        Cursor cursor = C1171u.m4908a(context).getReadableDatabase().query("notification", new String[]{"notification_id"}, "notification_id = ?", new String[]{id}, null, null, null);
        boolean exists = cursor.moveToFirst();
        cursor.close();
        if (!exists) {
            return false;
        }
        C1170t.m4843a(C1166d.DEBUG, "Duplicate GCM message received, skip processing of " + id);
        return true;
    }

    /* renamed from: a */
    static void m4846a(Runnable action) {
        new Handler(Looper.getMainLooper()).post(action);
    }

    /* renamed from: a */
    static boolean m4855a(Context context, JSONObject jsonPayload) {
        String id = C1170t.m4859b(jsonPayload);
        return id == null || C1170t.m4857a(id, context);
    }

    /* renamed from: a */
    static String m4833a(Bundle bundle) {
        if (bundle.isEmpty()) {
            return null;
        }
        try {
            if (bundle.containsKey("custom")) {
                JSONObject customJSON = new JSONObject(bundle.getString("custom"));
                if (customJSON.has("i")) {
                    return customJSON.optString("i", null);
                }
                C1170t.m4843a(C1166d.DEBUG, "Not a OneSignal formatted GCM message. No 'i' field in custom.");
                return null;
            }
            C1170t.m4843a(C1166d.DEBUG, "Not a OneSignal formatted GCM message. No 'custom' field in the bundle.");
            return null;
        } catch (Throwable t) {
            C1170t.m4844a(C1166d.DEBUG, "Could not parse bundle, probably not a OneSignal notification.", t);
            return null;
        }
    }

    /* renamed from: b */
    static String m4859b(JSONObject jsonPayload) {
        String str = null;
        try {
            str = new JSONObject(jsonPayload.optString("custom")).optString("i", null);
        } catch (Throwable th) {
        }
        return str;
    }

    /* renamed from: k */
    static boolean m4892k() {
        return f2434d && C1170t.m4866b();
    }

    /* renamed from: l */
    static void m4893l() {
        f2428I = false;
        C1170t.m4835a(System.currentTimeMillis());
    }

    /* renamed from: N */
    private static boolean m4827N() {
        return (System.currentTimeMillis() - C1170t.m4869c(f2433c)) / 1000 >= 30;
    }

    /* renamed from: O */
    private static void m4828O() {
        if (!f2438h) {
            f2438h = true;
            f2433c.startService(new Intent(f2433c, SyncService.class));
        }
    }
}

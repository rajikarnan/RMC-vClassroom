package com.onesignal;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.PendingIntent.CanceledException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import com.google.android.gms.common.C0845e;
import com.google.android.gms.p021c.C0793a;
import com.onesignal.C1170t.C1166d;
import com.onesignal.C1186x.C1157a;

/* compiled from: PushRegistratorGPS */
/* renamed from: com.onesignal.z */
public class C1193z implements C1186x {
    /* renamed from: c */
    private static int f2504c = 5;
    /* renamed from: a */
    private Context f2505a;
    /* renamed from: b */
    private C1157a f2506b;

    /* compiled from: PushRegistratorGPS */
    /* renamed from: com.onesignal.z$1 */
    class C11911 implements Runnable {
        /* renamed from: a */
        final /* synthetic */ C1193z f2501a;

        C11911(C1193z this$0) {
            this.f2501a = this$0;
        }

        public void run() {
            final Activity activity = C1101a.f2289b;
            if (activity != null && !C1170t.f2436f.f2406d) {
                String alertBodyText = C1146s.m4752a(activity, "onesignal_gms_missing_alert_text", "To receive push notifications please press 'Update' to enable 'Google Play services'.");
                String alertButtonUpdate = C1146s.m4752a(activity, "onesignal_gms_missing_alert_button_update", "Update");
                String alertButtonSkip = C1146s.m4752a(activity, "onesignal_gms_missing_alert_button_skip", "Skip");
                new Builder(activity).setMessage(alertBodyText).setPositiveButton(alertButtonUpdate, new OnClickListener(this) {
                    /* renamed from: b */
                    final /* synthetic */ C11911 f2500b;

                    public void onClick(DialogInterface dialog, int which) {
                        try {
                            C0845e.m3388a(C0845e.m3386a(this.f2500b.f2501a.f2505a), activity, 0).send();
                        } catch (CanceledException e) {
                        } catch (Throwable e2) {
                            e2.printStackTrace();
                        }
                    }
                }).setNegativeButton(alertButtonSkip, new OnClickListener(this) {
                    /* renamed from: b */
                    final /* synthetic */ C11911 f2498b;

                    public void onClick(DialogInterface dialog, int which) {
                        Editor editor = C1170t.m4876d(activity).edit();
                        editor.putBoolean("GT_DO_NOT_SHOW_MISSING_GPS", true);
                        editor.commit();
                    }
                }).setNeutralButton(C1146s.m4752a(activity, "onesignal_gms_missing_alert_button_close", "Close"), null).create().show();
            }
        }
    }

    /* renamed from: a */
    public void mo1124a(Context context, String googleProjectNumber, C1157a callback) {
        this.f2505a = context;
        this.f2506b = callback;
        try {
            if (m4984c()) {
                m4981a(googleProjectNumber);
                return;
            }
            C1170t.m4843a(C1166d.ERROR, "'Google Play services' app not installed or disabled on the device.");
            this.f2506b.mo1123a(null, -7);
        } catch (Throwable t) {
            C1170t.m4844a(C1166d.ERROR, "Could not register with GCM due to an error with the AndroidManifest.xml file or with 'Google Play services'.", t);
            this.f2506b.mo1123a(null, -8);
        }
    }

    /* renamed from: b */
    private boolean m4983b() {
        try {
            PackageManager pm = this.f2505a.getPackageManager();
            String label = (String) pm.getPackageInfo("com.android.vending", 1).applicationInfo.loadLabel(pm);
            if (label == null || label.equals("Market")) {
                return false;
            }
            return true;
        } catch (Throwable th) {
            return false;
        }
    }

    /* renamed from: c */
    private boolean m4984c() {
        boolean z = false;
        try {
            PackageInfo info = this.f2505a.getPackageManager().getPackageInfo("com.google.android.gms", 1);
            if (!info.applicationInfo.enabled && m4983b()) {
                if (!C1170t.m4876d(this.f2505a).getBoolean("GT_DO_NOT_SHOW_MISSING_GPS", false)) {
                    try {
                        m4985d();
                    } catch (Throwable th) {
                    }
                }
                return z;
            }
            z = info.applicationInfo.enabled;
        } catch (NameNotFoundException e) {
        }
        return z;
    }

    /* renamed from: d */
    private void m4985d() {
        C1170t.m4846a(new C11911(this));
    }

    /* renamed from: a */
    private void m4981a(final String googleProjectNumber) {
        new Thread(new Runnable(this) {
            /* renamed from: b */
            final /* synthetic */ C1193z f2503b;

            public void run() {
                boolean firedComplete = false;
                int currentRetry = 0;
                while (currentRetry < C1193z.f2504c) {
                    try {
                        String registrationId = C0793a.m3212a(this.f2503b.f2505a).m3222a(googleProjectNumber);
                        C1170t.m4843a(C1166d.INFO, "Device registered, Google Registration ID = " + registrationId);
                        this.f2503b.f2506b.mo1123a(registrationId, 1);
                        return;
                    } catch (Throwable e) {
                        if (!"SERVICE_NOT_AVAILABLE".equals(e.getMessage())) {
                            C1170t.m4844a(C1166d.ERROR, "Error Getting Google Registration ID", e);
                            if (!firedComplete) {
                                this.f2503b.f2506b.mo1123a(null, -11);
                                return;
                            }
                            return;
                        } else if (currentRetry >= C1193z.f2504c - 1) {
                            C1170t.m4844a(C1166d.ERROR, "GCM_RETRY_COUNT of " + C1193z.f2504c + " exceed! Could not get a Google Registration Id", e);
                        } else {
                            C1170t.m4844a(C1166d.INFO, "Google Play services returned SERVICE_NOT_AVAILABLE error. Current retry count: " + currentRetry, e);
                            if (currentRetry == 2) {
                                this.f2503b.f2506b.mo1123a(null, -9);
                                firedComplete = true;
                            }
                            Thread.sleep((long) ((currentRetry + 1) * 10000));
                        }
                    } catch (Throwable th) {
                    }
                }
                return;
                currentRetry++;
            }
        }).start();
    }
}

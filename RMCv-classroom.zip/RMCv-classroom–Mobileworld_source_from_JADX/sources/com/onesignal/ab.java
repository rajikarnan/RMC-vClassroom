package com.onesignal;

import java.io.File;

/* compiled from: RootToolsInternalMethods */
class ab {
    /* renamed from: a */
    static boolean m4641a() {
        for (String where : new String[]{"/sbin/", "/system/bin/", "/system/xbin/", "/data/local/xbin/", "/data/local/bin/", "/system/sd/xbin/", "/system/bin/failsafe/", "/data/local/"}) {
            if (new File(where + "su").exists()) {
                return true;
            }
        }
        return false;
    }
}

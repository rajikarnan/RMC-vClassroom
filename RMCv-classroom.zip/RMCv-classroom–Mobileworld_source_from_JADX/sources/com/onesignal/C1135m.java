package com.onesignal;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.app.ap;
import com.onesignal.C1170t.C1166d;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: NotificationOpenedProcessor */
/* renamed from: com.onesignal.m */
public class C1135m {
    /* renamed from: a */
    private static Context f2342a;
    /* renamed from: b */
    private static Intent f2343b;

    /* renamed from: a */
    public static void m4744a(Context inContext, Intent inIntent) {
        if (inIntent.getBooleanExtra("action_button", false)) {
            ap.m418a(inContext).m422a(inIntent.getIntExtra("notificationId", 0));
            inContext.sendBroadcast(new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS"));
        }
        C1135m.m4747b(inContext, inIntent);
    }

    /* renamed from: b */
    static void m4747b(Context incContext, Intent inIntent) {
        f2342a = incContext;
        f2343b = inIntent;
        String summaryGroup = f2343b.getStringExtra("summary");
        boolean dismissed = f2343b.getBooleanExtra("dismissed", false);
        JSONArray dataArray = null;
        if (!dismissed) {
            try {
                JSONObject jsonData = new JSONObject(f2343b.getStringExtra("onesignal_data"));
                jsonData.put("notificationId", inIntent.getIntExtra("notificationId", 0));
                f2343b.putExtra("onesignal_data", jsonData.toString());
                dataArray = C1131j.m4739b(new JSONObject(f2343b.getStringExtra("onesignal_data")));
            } catch (Throwable t) {
                t.printStackTrace();
            }
        }
        SQLiteDatabase writableDb = C1171u.m4908a(f2342a).getWritableDatabase();
        writableDb.beginTransaction();
        if (!(dismissed || summaryGroup == null)) {
            try {
                C1135m.m4746a(dataArray, summaryGroup, writableDb);
            } catch (Throwable e) {
                C1170t.m4844a(C1166d.ERROR, "Error processing notification open or dismiss record! ", e);
            } finally {
                writableDb.endTransaction();
            }
        }
        C1135m.m4745a(writableDb);
        if (summaryGroup == null && f2343b.getStringExtra("grp") != null) {
            C1135m.m4748b(writableDb);
        }
        writableDb.setTransactionSuccessful();
        writableDb.endTransaction();
        if (!dismissed) {
            C1170t.m4839a(f2342a, dataArray, inIntent.getBooleanExtra("from_alert", false));
        }
    }

    /* renamed from: a */
    private static void m4746a(JSONArray dataArray, String summaryGroup, SQLiteDatabase writableDb) {
        SQLiteDatabase sQLiteDatabase = writableDb;
        Cursor cursor = sQLiteDatabase.query("notification", new String[]{"full_data"}, "group_id = ? AND dismissed = 0 AND opened = 0 AND is_summary = 0", new String[]{summaryGroup}, null, null, null);
        if (cursor.getCount() > 1) {
            cursor.moveToFirst();
            do {
                try {
                    dataArray.put(new JSONObject(cursor.getString(cursor.getColumnIndex("full_data"))));
                } catch (Throwable th) {
                    C1170t.m4843a(C1166d.ERROR, "Could not parse JSON of sub notification in group: " + summaryGroup);
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    /* renamed from: a */
    private static void m4745a(SQLiteDatabase writableDb) {
        String whereStr;
        String[] whereArgs = null;
        if (f2343b.getStringExtra("summary") != null) {
            whereStr = "group_id = ?";
            whereArgs = new String[]{f2343b.getStringExtra("summary")};
        } else {
            whereStr = "android_notification_id = " + f2343b.getIntExtra("notificationId", 0);
        }
        writableDb.update("notification", C1135m.m4743a(), whereStr, whereArgs);
        C1120f.m4680a(writableDb, f2342a);
    }

    /* renamed from: b */
    private static void m4748b(SQLiteDatabase writableDb) {
        SQLiteDatabase sQLiteDatabase = writableDb;
        Cursor cursor = sQLiteDatabase.query("notification", new String[]{"android_notification_id"}, "group_id = ? AND dismissed = 0 AND opened = 0 AND is_summary = 0", new String[]{f2343b.getStringExtra("grp")}, null, null, null);
        if (cursor.getCount() == 0) {
            writableDb.update("notification", C1135m.m4743a(), "group_id = ?", new String[]{grpId});
        } else {
            try {
                C1124g.m4690a(f2342a, true, new JSONObject("{\"grp\": \"" + grpId + "\"}"));
            } catch (JSONException e) {
            }
        }
        cursor.close();
    }

    /* renamed from: a */
    private static ContentValues m4743a() {
        ContentValues values = new ContentValues();
        if (f2343b.getBooleanExtra("dismissed", false)) {
            values.put("dismissed", Integer.valueOf(1));
        } else {
            values.put("opened", Integer.valueOf(1));
        }
        return values;
    }
}

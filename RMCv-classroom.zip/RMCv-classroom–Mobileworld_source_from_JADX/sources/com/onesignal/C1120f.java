package com.onesignal;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.app.ag;
import com.onesignal.C1170t.C1166d;
import com.onesignal.shortcutbadger.C1151c;

/* compiled from: BadgeCountUpdater */
/* renamed from: com.onesignal.f */
class C1120f {
    /* renamed from: a */
    private static int f2318a = -1;

    /* renamed from: a */
    private static boolean m4681a(Context context) {
        if (f2318a == -1) {
            try {
                int i;
                if ("DISABLE".equals(context.getPackageManager().getApplicationInfo(context.getPackageName(), ag.FLAG_HIGH_PRIORITY).metaData.getString("com.onesignal.BadgeCount"))) {
                    i = 0;
                } else {
                    i = 1;
                }
                f2318a = i;
            } catch (Throwable t) {
                f2318a = 1;
                C1170t.m4844a(C1166d.ERROR, "", t);
            }
            if (f2318a != 1) {
                return false;
            }
            return true;
        } else if (f2318a == 1) {
            return true;
        } else {
            return false;
        }
    }

    /* renamed from: a */
    static void m4680a(SQLiteDatabase readableDb, Context context) {
        if (C1120f.m4681a(context)) {
            Cursor cursor = readableDb.query("notification", null, "dismissed = 0 AND opened = 0 AND is_summary = 0 ", null, null, null, null);
            C1120f.m4679a(cursor.getCount(), context);
            cursor.close();
        }
    }

    /* renamed from: a */
    static void m4679a(int count, Context context) {
        if (C1120f.m4681a(context)) {
            try {
                C1151c.m4763a(context, count);
            } catch (Throwable th) {
            }
        }
    }
}

package com.onesignal;

import android.content.Context;
import com.amazon.device.iap.PurchasingListener;
import com.amazon.device.iap.PurchasingService;
import com.amazon.device.iap.model.ProductDataResponse.RequestStatus;
import java.lang.reflect.Field;

/* compiled from: TrackAmazonPurchase */
class ac {
    /* renamed from: a */
    private Context f2295a;
    /* renamed from: b */
    private boolean f2296b = false;
    /* renamed from: c */
    private C1105a f2297c;
    /* renamed from: d */
    private Class<?> f2298d;
    /* renamed from: e */
    private Object f2299e;
    /* renamed from: f */
    private Field f2300f;

    /* compiled from: TrackAmazonPurchase */
    /* renamed from: com.onesignal.ac$1 */
    static /* synthetic */ class C11041 {
        /* renamed from: a */
        static final /* synthetic */ int[] f2292a = new int[RequestStatus.values().length];

        static {
            try {
                f2292a[RequestStatus.SUCCESSFUL.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
        }
    }

    /* compiled from: TrackAmazonPurchase */
    /* renamed from: com.onesignal.ac$a */
    private class C1105a implements PurchasingListener {
        /* renamed from: a */
        public PurchasingListener f2293a;
        /* renamed from: b */
        final /* synthetic */ ac f2294b;

        private C1105a(ac acVar) {
            this.f2294b = acVar;
        }
    }

    ac(Context context) {
        this.f2295a = context;
        try {
            this.f2298d = Class.forName("com.amazon.device.iap.internal.d");
            this.f2299e = this.f2298d.getMethod("d", new Class[0]).invoke(null, new Object[0]);
            this.f2300f = this.f2298d.getDeclaredField("f");
            this.f2300f.setAccessible(true);
            this.f2297c = new C1105a();
            this.f2297c.f2293a = (PurchasingListener) this.f2300f.get(this.f2299e);
            this.f2296b = true;
            m4642b();
        } catch (Throwable th) {
        }
    }

    /* renamed from: b */
    private void m4642b() {
        PurchasingService.registerListener(this.f2295a, this.f2297c);
    }

    /* renamed from: a */
    public void m4643a() {
        if (this.f2296b) {
            try {
                PurchasingListener curPurchasingListener = (PurchasingListener) this.f2300f.get(this.f2299e);
                if (curPurchasingListener != this.f2297c) {
                    this.f2297c.f2293a = curPurchasingListener;
                    m4642b();
                }
            } catch (Throwable th) {
            }
        }
    }
}

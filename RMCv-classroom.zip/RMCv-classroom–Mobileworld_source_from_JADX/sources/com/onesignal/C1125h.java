package com.onesignal;

import com.google.android.gms.common.api.GoogleApiClient;

/* compiled from: GoogleApiClientCompatProxy */
/* renamed from: com.onesignal.h */
public class C1125h {
    /* renamed from: a */
    private final GoogleApiClient f2332a;
    /* renamed from: b */
    private final Class f2333b;

    public C1125h(GoogleApiClient googleApiClient) {
        this.f2332a = googleApiClient;
        this.f2333b = googleApiClient.getClass();
    }

    /* renamed from: a */
    public void m4713a() {
        try {
            this.f2333b.getMethod("connect", new Class[0]).invoke(this.f2332a, new Object[0]);
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    /* renamed from: b */
    public void m4714b() {
        try {
            this.f2333b.getMethod("disconnect", new Class[0]).invoke(this.f2332a, new Object[0]);
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    /* renamed from: c */
    public GoogleApiClient m4715c() {
        return this.f2332a;
    }
}

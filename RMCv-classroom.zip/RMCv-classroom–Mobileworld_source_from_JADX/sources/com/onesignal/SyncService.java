package com.onesignal;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.v4.app.ag;
import com.onesignal.C1170t.C1166d;

public class SyncService extends Service {

    /* renamed from: com.onesignal.SyncService$1 */
    class C10971 implements Runnable {
        /* renamed from: a */
        final /* synthetic */ SyncService f2283a;

        C10971(SyncService this$0) {
            this.f2283a = this$0;
        }

        public void run() {
            if (C1170t.m4881e() == null) {
                this.f2283a.stopSelf();
                return;
            }
            C1170t.f2431a = C1170t.m4877d();
            C1185w.m4947a(C1170t.f2433c);
            C1185w.m4952a(true);
            this.f2283a.m4620c();
            this.f2283a.stopSelf();
        }
    }

    /* renamed from: c */
    private void m4620c() {
        long unsentTime = C1170t.m4891j();
        if (unsentTime >= 60) {
            C1170t.m4836a(unsentTime, true);
        }
    }

    public void onCreate() {
        if (!C1170t.f2438h) {
            C1170t.f2433c = getApplicationContext();
            new Thread(new C10971(this), "OS_SYNCSRV_ONCREATE").start();
        }
    }

    public int onStartCommand(Intent intent, int flags, int startId) {
        return C1170t.f2438h ? 1 : 2;
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        m4618a();
        stopSelf();
        m4621b();
    }

    /* renamed from: a */
    static void m4618a() {
        C1170t.m4843a(C1166d.VERBOSE, "Starting SyncService:onTaskRemoved.");
        C1101a.f2290c.m4627b();
        C1185w.m4946a();
        C1170t.m4852a(true);
        C1170t.m4843a(C1166d.VERBOSE, "Completed SyncService:onTaskRemoved.");
    }

    /* renamed from: b */
    void m4621b() {
        ((AlarmManager) getSystemService(ag.CATEGORY_ALARM)).set(0, System.currentTimeMillis() + 10000, PendingIntent.getService(this, 0, new Intent(this, SyncService.class), 0));
    }
}

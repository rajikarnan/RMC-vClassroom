package com.onesignal;

import android.content.Context;

/* compiled from: PushRegistrator */
/* renamed from: com.onesignal.x */
public interface C1186x {

    /* compiled from: PushRegistrator */
    /* renamed from: com.onesignal.x$a */
    public interface C1157a {
        /* renamed from: a */
        void mo1123a(String str, int i);
    }

    /* renamed from: a */
    void mo1124a(Context context, String str, C1157a c1157a);
}

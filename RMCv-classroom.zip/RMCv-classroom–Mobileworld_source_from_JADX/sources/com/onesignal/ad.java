package com.onesignal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.os.IBinder;
import com.onesignal.C1170t.C1110c;
import com.onesignal.C1170t.C1166d;
import com.onesignal.C1175v.C1108a;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: TrackGooglePurchase */
class ad {
    /* renamed from: a */
    private static int f2307a = -99;
    /* renamed from: c */
    private static Class<?> f2308c;
    /* renamed from: b */
    private ServiceConnection f2309b;
    /* renamed from: d */
    private Object f2310d;
    /* renamed from: e */
    private Method f2311e;
    /* renamed from: f */
    private Method f2312f;
    /* renamed from: g */
    private Context f2313g;
    /* renamed from: h */
    private ArrayList<String> f2314h;
    /* renamed from: i */
    private Editor f2315i;
    /* renamed from: j */
    private boolean f2316j = true;
    /* renamed from: k */
    private boolean f2317k = false;

    /* compiled from: TrackGooglePurchase */
    /* renamed from: com.onesignal.ad$1 */
    class C11061 implements ServiceConnection {
        /* renamed from: a */
        final /* synthetic */ ad f2301a;

        C11061(ad this$0) {
            this.f2301a = this$0;
        }

        public void onServiceDisconnected(ComponentName name) {
            ad.f2307a = -99;
            this.f2301a.f2310d = null;
        }

        public void onServiceConnected(ComponentName name, IBinder service) {
            try {
                Method asInterfaceMethod = ad.m4663c(Class.forName("com.android.vending.billing.IInAppBillingService$Stub"));
                asInterfaceMethod.setAccessible(true);
                this.f2301a.f2310d = asInterfaceMethod.invoke(null, new Object[]{service});
                this.f2301a.m4664c();
            } catch (Throwable t) {
                t.printStackTrace();
            }
        }
    }

    /* compiled from: TrackGooglePurchase */
    /* renamed from: com.onesignal.ad$2 */
    class C11072 implements Runnable {
        /* renamed from: a */
        final /* synthetic */ ad f2302a;

        C11072(ad this$0) {
            this.f2302a = this$0;
        }

        public void run() {
            this.f2302a.f2317k = true;
            try {
                if (this.f2302a.f2311e == null) {
                    this.f2302a.f2311e = ad.m4666d(ad.f2308c);
                    this.f2302a.f2311e.setAccessible(true);
                }
                Bundle ownedItems = (Bundle) this.f2302a.f2311e.invoke(this.f2302a.f2310d, new Object[]{Integer.valueOf(3), this.f2302a.f2313g.getPackageName(), "inapp", null});
                if (ownedItems.getInt("RESPONSE_CODE") == 0) {
                    ArrayList<String> skusToAdd = new ArrayList();
                    ArrayList<String> newPurchaseTokens = new ArrayList();
                    ArrayList<String> ownedSkus = ownedItems.getStringArrayList("INAPP_PURCHASE_ITEM_LIST");
                    ArrayList<String> purchaseDataList = ownedItems.getStringArrayList("INAPP_PURCHASE_DATA_LIST");
                    for (int i = 0; i < purchaseDataList.size(); i++) {
                        String sku = (String) ownedSkus.get(i);
                        String purchaseToken = new JSONObject((String) purchaseDataList.get(i)).getString("purchaseToken");
                        if (!(this.f2302a.f2314h.contains(purchaseToken) || newPurchaseTokens.contains(purchaseToken))) {
                            newPurchaseTokens.add(purchaseToken);
                            skusToAdd.add(sku);
                        }
                    }
                    if (skusToAdd.size() > 0) {
                        this.f2302a.m4655a((ArrayList) skusToAdd, (ArrayList) newPurchaseTokens);
                    } else if (purchaseDataList.size() == 0) {
                        this.f2302a.f2316j = false;
                        this.f2302a.f2315i.putBoolean("ExistingPurchases", false);
                        this.f2302a.f2315i.commit();
                    }
                }
            } catch (Throwable e) {
                e.printStackTrace();
            }
            this.f2302a.f2317k = false;
        }
    }

    ad(Context activity) {
        boolean z = true;
        this.f2313g = activity;
        SharedPreferences prefs = this.f2313g.getSharedPreferences("GTPlayerPurchases", 0);
        this.f2315i = prefs.edit();
        this.f2314h = new ArrayList();
        try {
            JSONArray jsonPurchaseTokens = new JSONArray(prefs.getString("purchaseTokens", "[]"));
            for (int i = 0; i < jsonPurchaseTokens.length(); i++) {
                this.f2314h.add(jsonPurchaseTokens.get(i).toString());
            }
            if (jsonPurchaseTokens.length() != 0) {
                z = false;
            }
            this.f2316j = z;
            if (this.f2316j) {
                this.f2316j = prefs.getBoolean("ExistingPurchases", true);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        m4671a();
    }

    /* renamed from: a */
    static boolean m4656a(Context context) {
        if (f2307a == -99) {
            f2307a = context.checkCallingOrSelfPermission("com.android.vending.BILLING");
        }
        try {
            if (f2307a == 0) {
                f2308c = Class.forName("com.android.vending.billing.IInAppBillingService");
            }
            if (f2307a == 0) {
                return true;
            }
            return false;
        } catch (Throwable th) {
            f2307a = 0;
            return false;
        }
    }

    /* renamed from: a */
    void m4671a() {
        if (this.f2309b == null) {
            this.f2309b = new C11061(this);
            Intent serviceIntent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
            serviceIntent.setPackage("com.android.vending");
            this.f2313g.bindService(serviceIntent, this.f2309b, 1);
        } else if (this.f2310d != null) {
            m4664c();
        }
    }

    /* renamed from: c */
    private void m4664c() {
        if (!this.f2317k) {
            new Thread(new C11072(this)).start();
        }
    }

    /* renamed from: a */
    private void m4655a(ArrayList<String> skusToAdd, ArrayList<String> newPurchaseTokens) {
        try {
            if (this.f2312f == null) {
                this.f2312f = m4667e(f2308c);
                this.f2312f.setAccessible(true);
            }
            new Bundle().putStringArrayList("ITEM_ID_LIST", skusToAdd);
            Bundle skuDetails = (Bundle) this.f2312f.invoke(this.f2310d, new Object[]{Integer.valueOf(3), this.f2313g.getPackageName(), "inapp", querySkus});
            if (skuDetails.getInt("RESPONSE_CODE") == 0) {
                String sku;
                ArrayList<String> responseList = skuDetails.getStringArrayList("DETAILS_LIST");
                Map<String, JSONObject> currentSkus = new HashMap();
                Iterator it = responseList.iterator();
                while (it.hasNext()) {
                    JSONObject object = new JSONObject((String) it.next());
                    sku = object.getString("productId");
                    BigDecimal price = new BigDecimal(object.getString("price_amount_micros")).divide(new BigDecimal(1000000));
                    JSONObject jsonItem = new JSONObject();
                    jsonItem.put("sku", sku);
                    jsonItem.put("iso", object.getString("price_currency_code"));
                    jsonItem.put("amount", price.toString());
                    currentSkus.put(sku, jsonItem);
                }
                JSONArray purchasesToReport = new JSONArray();
                it = skusToAdd.iterator();
                while (it.hasNext()) {
                    sku = (String) it.next();
                    if (currentSkus.containsKey(sku)) {
                        purchasesToReport.put(currentSkus.get(sku));
                    }
                }
                if (purchasesToReport.length() > 0) {
                    final JSONArray finalPurchasesToReport = purchasesToReport;
                    final ArrayList<String> arrayList = newPurchaseTokens;
                    C1170t.m4842a(new C1110c(this) {
                        /* renamed from: c */
                        final /* synthetic */ ad f2306c;

                        /* compiled from: TrackGooglePurchase */
                        /* renamed from: com.onesignal.ad$3$1 */
                        class C11091 extends C1108a {
                            /* renamed from: a */
                            final /* synthetic */ C11113 f2303a;

                            C11091(C11113 this$1) {
                                this.f2303a = this$1;
                            }

                            /* renamed from: a */
                            public void mo1116a(String response) {
                                this.f2303a.f2306c.f2314h.addAll(arrayList);
                                this.f2303a.f2306c.f2315i.putString("purchaseTokens", this.f2303a.f2306c.f2314h.toString());
                                this.f2303a.f2306c.f2315i.remove("ExistingPurchases");
                                this.f2303a.f2306c.f2315i.commit();
                                this.f2303a.f2306c.f2316j = false;
                                this.f2303a.f2306c.f2317k = false;
                            }
                        }

                        /* renamed from: a */
                        public void mo1117a(String userId, String registrationId) {
                            C1170t.m4849a(finalPurchasesToReport, this.f2306c.f2316j, new C11091(this));
                        }
                    });
                }
            }
        } catch (Throwable t) {
            C1170t.m4844a(C1166d.WARN, "Failed to track IAP purchases", t);
        }
    }

    /* renamed from: c */
    private static Method m4663c(Class clazz) {
        for (Method method : clazz.getMethods()) {
            Class<?>[] args = method.getParameterTypes();
            if (args.length == 1 && args[0] == IBinder.class) {
                return method;
            }
        }
        return null;
    }

    /* renamed from: d */
    private static Method m4666d(Class clazz) {
        for (Method method : clazz.getMethods()) {
            Class<?>[] args = method.getParameterTypes();
            if (args.length == 4 && args[0] == Integer.TYPE && args[1] == String.class && args[2] == String.class && args[3] == String.class) {
                return method;
            }
        }
        return null;
    }

    /* renamed from: e */
    private static Method m4667e(Class clazz) {
        for (Method method : clazz.getMethods()) {
            Class<?>[] args = method.getParameterTypes();
            Class<?> returnType = method.getReturnType();
            if (args.length == 4 && args[0] == Integer.TYPE && args[1] == String.class && args[2] == String.class && args[3] == Bundle.class && returnType == Bundle.class) {
                return method;
            }
        }
        return null;
    }
}

package com.onesignal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.C0206j;

public class GcmBroadcastReceiver extends C0206j {
    /* renamed from: b */
    private static boolean m4613b(Intent intent) {
        if (!"com.google.android.c2dm.intent.RECEIVE".equals(intent.getAction())) {
            return false;
        }
        String messageType = intent.getStringExtra("message_type");
        if (messageType == null || "gcm".equals(messageType)) {
            return true;
        }
        return false;
    }

    public void onReceive(Context context, Intent intent) {
        Bundle bundle = intent.getExtras();
        if (bundle != null && !"google.com/iid".equals(bundle.getString("from"))) {
            m4612a(context, intent, bundle);
            setResultCode(-1);
        }
    }

    /* renamed from: a */
    private static void m4612a(Context context, Intent intent, Bundle bundle) {
        if (m4613b(intent) && !C1131j.m4737a(context, bundle)) {
            Intent intentForService = new Intent();
            intentForService.putExtra("json_payload", C1131j.m4740b(bundle).toString());
            intentForService.setComponent(new ComponentName(context.getPackageName(), GcmIntentService.class.getName()));
            C0206j.m766a(context, intentForService);
        }
    }
}

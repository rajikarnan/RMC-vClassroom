package com.onesignal;

import java.util.List;
import org.json.JSONObject;

/* compiled from: OSNotificationPayload */
/* renamed from: com.onesignal.r */
public class C1145r {
    /* renamed from: a */
    public String f2369a;
    /* renamed from: b */
    public String f2370b;
    /* renamed from: c */
    public String f2371c;
    /* renamed from: d */
    public JSONObject f2372d;
    /* renamed from: e */
    public String f2373e;
    /* renamed from: f */
    public String f2374f;
    /* renamed from: g */
    public String f2375g;
    /* renamed from: h */
    public String f2376h;
    /* renamed from: i */
    public String f2377i;
    /* renamed from: j */
    public String f2378j;
    /* renamed from: k */
    public String f2379k;
    /* renamed from: l */
    public int f2380l = 1;
    /* renamed from: m */
    public String f2381m;
    /* renamed from: n */
    public String f2382n;
    /* renamed from: o */
    public List<C1143a> f2383o;
    /* renamed from: p */
    public String f2384p;
    /* renamed from: q */
    public C1144b f2385q;
    /* renamed from: r */
    public String f2386r;
    /* renamed from: s */
    public int f2387s;
    /* renamed from: t */
    public String f2388t;

    /* compiled from: OSNotificationPayload */
    /* renamed from: com.onesignal.r$a */
    public static class C1143a {
        /* renamed from: a */
        public String f2363a;
        /* renamed from: b */
        public String f2364b;
        /* renamed from: c */
        public String f2365c;
    }

    /* compiled from: OSNotificationPayload */
    /* renamed from: com.onesignal.r$b */
    public static class C1144b {
        /* renamed from: a */
        public String f2366a;
        /* renamed from: b */
        public String f2367b;
        /* renamed from: c */
        public String f2368c;
    }
}

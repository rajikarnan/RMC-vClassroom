package com.onesignal;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.content.C0206j;
import com.onesignal.C1133k.C1132a;
import com.onesignal.C1145r.C1143a;
import com.onesignal.C1145r.C1144b;
import com.onesignal.C1170t.C1166d;
import java.util.ArrayList;
import java.util.Random;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: NotificationBundleProcessor */
/* renamed from: com.onesignal.j */
class C1131j {
    /* renamed from: a */
    static void m4731a(Context context, Bundle bundle, C1132a overrideSettings) {
        try {
            boolean restoring = bundle.getBoolean("restoring", false);
            String jsonStrPayload = bundle.getString("json_payload");
            if (jsonStrPayload == null) {
                C1170t.m4843a(C1166d.ERROR, "json_payload key is nonexistent from bundle passed to ProcessFromGCMIntentService: " + bundle);
                return;
            }
            JSONObject jsonPayload = new JSONObject(jsonStrPayload);
            if (restoring || !C1170t.m4855a(context, jsonPayload)) {
                if (bundle.containsKey("android_notif_id")) {
                    if (overrideSettings == null) {
                        overrideSettings = new C1132a();
                    }
                    overrideSettings.f2341b = Integer.valueOf(bundle.getInt("android_notif_id"));
                }
                C1131j.m4728a(context, restoring, jsonPayload, overrideSettings);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    /* renamed from: a */
    static int m4728a(Context context, boolean restoring, JSONObject jsonPayload, C1132a overrideSettings) {
        int notificationId;
        boolean showAsAlert = true;
        if (!(C1170t.m4888g() && C1170t.m4892k())) {
            showAsAlert = false;
        }
        if (overrideSettings == null || overrideSettings.f2341b == null) {
            notificationId = new Random().nextInt();
        } else {
            notificationId = overrideSettings.f2341b.intValue();
        }
        C1124g.m4689a(context, restoring, notificationId, jsonPayload, showAsAlert, overrideSettings);
        if (!restoring) {
            C1131j.m4733a(context, jsonPayload, false, notificationId);
            try {
                JSONObject jsonObject = new JSONObject(jsonPayload.toString());
                jsonObject.put("notificationId", notificationId);
                C1170t.m4850a(C1131j.m4739b(jsonObject), true, showAsAlert);
            } catch (Throwable th) {
            }
        }
        return notificationId;
    }

    /* renamed from: a */
    static JSONArray m4730a(Bundle bundle) {
        JSONArray jsonArray = new JSONArray();
        jsonArray.put(C1131j.m4740b(bundle));
        return jsonArray;
    }

    /* renamed from: a */
    static void m4732a(Context context, Bundle bundle, boolean opened, int notificationId) {
        C1131j.m4733a(context, C1131j.m4740b(bundle), opened, notificationId);
    }

    /* renamed from: a */
    static void m4733a(Context context, JSONObject jsonPayload, boolean opened, int notificationId) {
        try {
            JSONObject customJSON = new JSONObject(jsonPayload.optString("custom"));
            SQLiteDatabase writableDb = C1171u.m4908a(context).getWritableDatabase();
            writableDb.beginTransaction();
            try {
                C1131j.m4734a(writableDb);
                ContentValues values = new ContentValues();
                values.put("notification_id", customJSON.optString("i"));
                if (jsonPayload.has("grp")) {
                    values.put("group_id", jsonPayload.optString("grp"));
                }
                values.put("opened", Integer.valueOf(opened ? 1 : 0));
                if (!opened) {
                    values.put("android_notification_id", Integer.valueOf(notificationId));
                }
                if (jsonPayload.has("title")) {
                    values.put("title", jsonPayload.optString("title"));
                }
                values.put("message", jsonPayload.optString("alert"));
                values.put("full_data", jsonPayload.toString());
                writableDb.insertOrThrow("notification", null, values);
                if (!opened) {
                    C1120f.m4680a(writableDb, context);
                }
                writableDb.setTransactionSuccessful();
            } catch (Throwable e) {
                C1170t.m4844a(C1166d.ERROR, "Error saving notification record! ", e);
            } finally {
                writableDb.endTransaction();
            }
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
    }

    /* renamed from: a */
    static void m4734a(SQLiteDatabase writableDb) {
        writableDb.delete("notification", "created_time < " + ((System.currentTimeMillis() / 1000) - 2419200), null);
    }

    /* renamed from: b */
    static JSONObject m4740b(Bundle bundle) {
        JSONObject json = new JSONObject();
        for (String key : bundle.keySet()) {
            try {
                json.put(key, bundle.get(key));
            } catch (Throwable e) {
                C1170t.m4844a(C1166d.ERROR, "bundleAsJSONObject error for key: " + key, e);
            }
        }
        return json;
    }

    /* renamed from: c */
    static void m4741c(Bundle gcmBundle) {
        if (gcmBundle.containsKey("o")) {
            try {
                JSONObject additionalDataJSON;
                JSONObject customJSON = new JSONObject(gcmBundle.getString("custom"));
                if (customJSON.has("a")) {
                    additionalDataJSON = customJSON.getJSONObject("a");
                } else {
                    additionalDataJSON = new JSONObject();
                }
                JSONArray buttons = new JSONArray(gcmBundle.getString("o"));
                gcmBundle.remove("o");
                for (int i = 0; i < buttons.length(); i++) {
                    String buttonId;
                    JSONObject button = buttons.getJSONObject(i);
                    String buttonText = button.getString("n");
                    button.remove("n");
                    if (button.has("i")) {
                        buttonId = button.getString("i");
                        button.remove("i");
                    } else {
                        buttonId = buttonText;
                    }
                    button.put("id", buttonId);
                    button.put("text", buttonText);
                    if (button.has("p")) {
                        button.put("icon", button.getString("p"));
                        button.remove("p");
                    }
                }
                additionalDataJSON.put("actionButtons", buttons);
                additionalDataJSON.put("actionSelected", "__DEFAULT__");
                if (!customJSON.has("a")) {
                    customJSON.put("a", additionalDataJSON);
                }
                gcmBundle.putString("custom", customJSON.toString());
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    /* renamed from: a */
    static C1145r m4729a(JSONObject currentJsonPayload) {
        C1145r notification = new C1145r();
        try {
            JSONObject customJson = new JSONObject(currentJsonPayload.optString("custom"));
            notification.f2369a = customJson.optString("i");
            notification.f2388t = currentJsonPayload.toString();
            notification.f2372d = customJson.optJSONObject("a");
            notification.f2377i = customJson.optString("u", null);
            notification.f2371c = currentJsonPayload.optString("alert", null);
            notification.f2370b = currentJsonPayload.optString("title", null);
            notification.f2373e = currentJsonPayload.optString("sicon", null);
            notification.f2375g = currentJsonPayload.optString("bicon", null);
            notification.f2374f = currentJsonPayload.optString("licon", null);
            notification.f2378j = currentJsonPayload.optString("sound", null);
            notification.f2381m = currentJsonPayload.optString("grp", null);
            notification.f2382n = currentJsonPayload.optString("grp_msg", null);
            notification.f2376h = currentJsonPayload.optString("bgac", null);
            notification.f2379k = currentJsonPayload.optString("ledc", null);
            String visibility = currentJsonPayload.optString("vis", null);
            if (visibility != null) {
                notification.f2380l = Integer.parseInt(visibility);
            }
            notification.f2384p = currentJsonPayload.optString("from", null);
            notification.f2387s = currentJsonPayload.optInt("pri", 0);
            String collapseKey = currentJsonPayload.optString("collapse_key", null);
            if (!"do_not_collapse".equals(collapseKey)) {
                notification.f2386r = collapseKey;
            }
            C1131j.m4735a(notification);
        } catch (Throwable t) {
            C1170t.m4844a(C1166d.ERROR, "Error assigning OSNotificationPayload values!", t);
        }
        try {
            C1131j.m4736a(notification, currentJsonPayload);
        } catch (Throwable t2) {
            C1170t.m4844a(C1166d.ERROR, "Error assigning OSNotificationPayload.backgroundImageLayout values!", t2);
        }
        return notification;
    }

    /* renamed from: a */
    private static void m4735a(C1145r notification) throws Throwable {
        if (notification.f2372d != null && notification.f2372d.has("actionButtons")) {
            JSONArray jsonActionButtons = notification.f2372d.getJSONArray("actionButtons");
            notification.f2383o = new ArrayList();
            for (int i = 0; i < jsonActionButtons.length(); i++) {
                JSONObject jsonActionButton = jsonActionButtons.getJSONObject(i);
                C1143a actionButton = new C1143a();
                actionButton.f2363a = jsonActionButton.optString("id", null);
                actionButton.f2364b = jsonActionButton.optString("text", null);
                actionButton.f2365c = jsonActionButton.optString("icon", null);
                notification.f2383o.add(actionButton);
            }
            notification.f2372d.remove("actionSelected");
            notification.f2372d.remove("actionButtons");
        }
    }

    /* renamed from: a */
    private static void m4736a(C1145r notification, JSONObject currentJsonPayload) throws Throwable {
        String jsonStrBgImage = currentJsonPayload.optString("bg_img", null);
        if (jsonStrBgImage != null) {
            JSONObject jsonBgImage = new JSONObject(jsonStrBgImage);
            notification.f2385q = new C1144b();
            notification.f2385q.f2366a = jsonBgImage.optString("img");
            notification.f2385q.f2367b = jsonBgImage.optString("tc");
            notification.f2385q.f2368c = jsonBgImage.optString("bc");
        }
    }

    /* renamed from: a */
    static boolean m4737a(Context context, final Bundle bundle) {
        if (C1170t.m4833a(bundle) == null) {
            return true;
        }
        C1131j.m4741c(bundle);
        Intent overrideIntent = C1133k.m4742a(context);
        if (overrideIntent != null) {
            overrideIntent.putExtra("json_payload", C1131j.m4740b(bundle).toString());
            C0206j.m766a(context, overrideIntent);
            return true;
        }
        boolean z;
        if (bundle.getString("alert") == null || "".equals(bundle.getString("alert"))) {
            z = false;
        } else {
            z = true;
        }
        boolean display = C1131j.m4738a(z);
        if (!display) {
            if (C1170t.m4855a(context, C1131j.m4740b(bundle))) {
                return true;
            }
            C1131j.m4732a(context, bundle, true, -1);
            new Thread(new Runnable() {
                public void run() {
                    C1170t.m4850a(C1131j.m4730a(bundle), false, false);
                }
            }, "OS_PROC_BUNDLE").start();
        }
        if (display) {
            return false;
        }
        return true;
    }

    /* renamed from: a */
    static boolean m4738a(boolean hasBody) {
        return hasBody && (C1170t.m4885f() || C1170t.m4888g() || !C1170t.m4892k());
    }

    /* renamed from: b */
    static JSONArray m4739b(JSONObject jsonObject) {
        JSONArray jsonArray = new JSONArray();
        jsonArray.put(jsonObject);
        return jsonArray;
    }
}

package com.onesignal;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/* compiled from: NotificationOpenedActivity */
/* renamed from: com.onesignal.l */
public class C1134l extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        C1135m.m4744a(this, getIntent());
        finish();
    }

    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        C1135m.m4744a(this, getIntent());
        finish();
    }
}

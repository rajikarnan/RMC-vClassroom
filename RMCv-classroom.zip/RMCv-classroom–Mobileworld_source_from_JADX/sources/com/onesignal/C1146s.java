package com.onesignal;

import android.content.Context;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v4.app.ag;
import android.telephony.TelephonyManager;
import com.onesignal.C1170t.C1166d;
import java.util.Locale;
import java.util.UUID;

/* compiled from: OSUtils */
/* renamed from: com.onesignal.s */
class C1146s {
    C1146s() {
    }

    /* renamed from: a */
    int m4755a(int deviceType, String oneSignalAppId) {
        int subscribableStatus = 1;
        try {
            UUID.fromString(oneSignalAppId);
            if ("b2f7f966-d8cc-11e4-bed1-df8f05be55ba".equals(oneSignalAppId) || "5eb5a37e-b458-11e3-ac11-000c2940e62c".equals(oneSignalAppId)) {
                C1170t.m4843a(C1166d.WARN, "OneSignal Example AppID detected, please update to your app's id found on OneSignal.com");
            }
            if (deviceType == 1) {
                try {
                    Class.forName("com.google.android.gms.c.a");
                } catch (Throwable e) {
                    C1170t.m4844a(C1166d.FATAL, "The GCM Google Play services client library was not found. Please make sure to include it in your project.", e);
                    subscribableStatus = -4;
                }
                try {
                    Class.forName("com.google.android.gms.common.e");
                } catch (Throwable e2) {
                    C1170t.m4844a(C1166d.FATAL, "The GooglePlayServicesUtil class part of Google Play services client library was not found. Include this in your project.", e2);
                    subscribableStatus = -4;
                }
            }
            try {
                Class.forName("android.support.v4.view.q");
                try {
                    Class.forName("android.support.v4.content.j");
                    Class.forName("android.support.v4.app.ap");
                } catch (Throwable e22) {
                    C1170t.m4844a(C1166d.FATAL, "The included Android Support Library v4 is to old or incomplete. Please update your project's android-support-v4.jar to the latest revision.", e22);
                    subscribableStatus = -5;
                }
            } catch (Throwable e222) {
                C1170t.m4844a(C1166d.FATAL, "Could not find the Android Support Library v4. Please make sure android-support-v4.jar has been correctly added to your project.", e222);
                subscribableStatus = -3;
            }
            return subscribableStatus;
        } catch (Throwable t) {
            C1170t.m4844a(C1166d.FATAL, "OneSignal AppId format is invalid.\nExample: 'b2f7f966-d8cc-11e4-bed1-df8f05be55ba'\n", t);
            return -999;
        }
    }

    /* renamed from: a */
    int m4754a() {
        try {
            Class.forName("com.amazon.device.messaging.ADM");
            return 2;
        } catch (ClassNotFoundException e) {
            return 1;
        }
    }

    /* renamed from: b */
    Integer m4756b() {
        NetworkInfo netInfo = ((ConnectivityManager) C1170t.f2433c.getSystemService("connectivity")).getActiveNetworkInfo();
        if (netInfo == null) {
            return null;
        }
        int networkType = netInfo.getType();
        if (networkType == 1 || networkType == 9) {
            return Integer.valueOf(0);
        }
        return Integer.valueOf(1);
    }

    /* renamed from: c */
    String m4757c() {
        String carrierName = ((TelephonyManager) C1170t.f2433c.getSystemService("phone")).getNetworkOperatorName();
        return "".equals(carrierName) ? null : carrierName;
    }

    /* renamed from: a */
    static String m4751a(Context context, String metaName) {
        try {
            return context.getPackageManager().getApplicationInfo(context.getPackageName(), ag.FLAG_HIGH_PRIORITY).metaData.getString(metaName);
        } catch (Throwable t) {
            C1170t.m4844a(C1166d.ERROR, "", t);
            return null;
        }
    }

    /* renamed from: a */
    static String m4752a(Context context, String key, String defaultStr) {
        Resources resources = context.getResources();
        int bodyResId = resources.getIdentifier(key, "string", context.getPackageName());
        if (bodyResId != 0) {
            return resources.getString(bodyResId);
        }
        return defaultStr;
    }

    /* renamed from: d */
    static String m4753d() {
        String lang = Locale.getDefault().getLanguage();
        if (lang.equals("iw")) {
            return "he";
        }
        if (lang.equals("in")) {
            return "id";
        }
        if (lang.equals("ji")) {
            return "yi";
        }
        if (lang.equals("zh")) {
            return lang + "-" + Locale.getDefault().getCountry();
        }
        return lang;
    }
}

package com.onesignal;

import java.util.List;

/* compiled from: OSNotification */
/* renamed from: com.onesignal.o */
public class C1139o {
    /* renamed from: a */
    public boolean f2350a;
    /* renamed from: b */
    public boolean f2351b;
    /* renamed from: c */
    public int f2352c;
    /* renamed from: d */
    public C1145r f2353d;
    /* renamed from: e */
    public C1138a f2354e;
    /* renamed from: f */
    public List<C1145r> f2355f;

    /* compiled from: OSNotification */
    /* renamed from: com.onesignal.o$a */
    public enum C1138a {
        Notification,
        InAppAlert,
        None
    }
}

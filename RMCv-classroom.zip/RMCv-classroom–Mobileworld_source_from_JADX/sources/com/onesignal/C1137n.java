package com.onesignal;

import android.content.Context;

/* compiled from: NotificationRestorer */
/* renamed from: com.onesignal.n */
class C1137n {
    /* renamed from: a */
    public static boolean f2345a;

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: b */
    public static void m4750b(android.content.Context r18) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find block by offset: 0x0004 in list [B:19:0x00c5]
	at jadx.core.utils.BlockUtils.getBlockByOffset(BlockUtils.java:43)
	at jadx.core.dex.instructions.IfNode.initBlocks(IfNode.java:60)
	at jadx.core.dex.visitors.blocksmaker.BlockFinish.initBlocksInIfNodes(BlockFinish.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockFinish.visit(BlockFinish.java:33)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1782580546.run(Unknown Source)
*/
        /*
        r3 = f2345a;
        if (r3 == 0) goto L_0x0005;
    L_0x0004:
        return;
    L_0x0005:
        r3 = 1;
        f2345a = r3;
        r11 = com.onesignal.C1171u.m4908a(r18);
        r17 = r11.getWritableDatabase();
        r17.beginTransaction();
        com.onesignal.C1131j.m4734a(r17);	 Catch:{ Throwable -> 0x00d0, all -> 0x00dd }
        r17.setTransactionSuccessful();	 Catch:{ Throwable -> 0x00d0, all -> 0x00dd }
        r17.endTransaction();
    L_0x001c:
        r3 = 2;
        r4 = new java.lang.String[r3];
        r3 = 0;
        r5 = "android_notification_id";
        r4[r3] = r5;
        r3 = 1;
        r5 = "full_data";
        r4[r3] = r5;
        r2 = r11.getReadableDatabase();
        r3 = "notification";
        r5 = new java.lang.StringBuilder;
        r5.<init>();
        r6 = "created_time > ";
        r5 = r5.append(r6);
        r6 = java.lang.System.currentTimeMillis();
        r8 = 1000; // 0x3e8 float:1.401E-42 double:4.94E-321;
        r6 = r6 / r8;
        r8 = 604800; // 0x93a80 float:8.47505E-40 double:2.98811E-318;
        r6 = r6 - r8;
        r5 = r5.append(r6);
        r6 = " AND ";
        r5 = r5.append(r6);
        r6 = "dismissed";
        r5 = r5.append(r6);
        r6 = " = 0 AND ";
        r5 = r5.append(r6);
        r6 = "opened";
        r5 = r5.append(r6);
        r6 = " = 0 AND ";
        r5 = r5.append(r6);
        r6 = "is_summary";
        r5 = r5.append(r6);
        r6 = " = 0";
        r5 = r5.append(r6);
        r5 = r5.toString();
        r6 = 0;
        r7 = 0;
        r8 = 0;
        r9 = "_id ASC";
        r10 = r2.query(r3, r4, r5, r6, r7, r8, r9);
        r3 = r10.moveToFirst();	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        if (r3 == 0) goto L_0x00c3;	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
    L_0x0086:
        r3 = com.onesignal.C1133k.m4742a(r18);	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        if (r3 == 0) goto L_0x00e2;	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
    L_0x008c:
        r16 = 1;	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
    L_0x008e:
        r3 = "android_notification_id";	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        r3 = r10.getColumnIndex(r3);	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        r12 = r10.getInt(r3);	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        r3 = "full_data";	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        r3 = r10.getColumnIndex(r3);	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        r13 = r10.getString(r3);	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        if (r16 == 0) goto L_0x00e5;	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
    L_0x00a4:
        r14 = com.onesignal.C1133k.m4742a(r18);	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
    L_0x00a8:
        r3 = "json_payload";	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        r14.putExtra(r3, r13);	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        r3 = "android_notif_id";	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        r14.putExtra(r3, r12);	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        r3 = "restoring";	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        r5 = 1;	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        r14.putExtra(r3, r5);	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        r0 = r18;	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        r0.startService(r14);	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        r3 = r10.moveToNext();	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        if (r3 != 0) goto L_0x008e;
    L_0x00c3:
        if (r10 == 0) goto L_0x0004;
    L_0x00c5:
        r3 = r10.isClosed();
        if (r3 != 0) goto L_0x0004;
    L_0x00cb:
        r10.close();
        goto L_0x0004;
    L_0x00d0:
        r15 = move-exception;
        r3 = com.onesignal.C1170t.C1166d.ERROR;	 Catch:{ Throwable -> 0x00d0, all -> 0x00dd }
        r5 = "Error deleting old notification records! ";	 Catch:{ Throwable -> 0x00d0, all -> 0x00dd }
        com.onesignal.C1170t.m4844a(r3, r5, r15);	 Catch:{ Throwable -> 0x00d0, all -> 0x00dd }
        r17.endTransaction();
        goto L_0x001c;
    L_0x00dd:
        r3 = move-exception;
        r17.endTransaction();
        throw r3;
    L_0x00e2:
        r16 = 0;
        goto L_0x008e;
    L_0x00e5:
        r3 = new android.content.Intent;	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        r3.<init>();	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        r5 = new android.content.ComponentName;	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        r6 = r18.getPackageName();	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        r7 = com.onesignal.GcmIntentService.class;	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        r7 = r7.getName();	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        r5.<init>(r6, r7);	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        r14 = r3.setComponent(r5);	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        goto L_0x00a8;
    L_0x00fe:
        r15 = move-exception;
        r3 = com.onesignal.C1170t.C1166d.ERROR;	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        r5 = "Error restoring notification records! ";	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        com.onesignal.C1170t.m4844a(r3, r5, r15);	 Catch:{ Throwable -> 0x00fe, all -> 0x0113 }
        if (r10 == 0) goto L_0x0004;
    L_0x0108:
        r3 = r10.isClosed();
        if (r3 != 0) goto L_0x0004;
    L_0x010e:
        r10.close();
        goto L_0x0004;
    L_0x0113:
        r3 = move-exception;
        if (r10 == 0) goto L_0x011f;
    L_0x0116:
        r5 = r10.isClosed();
        if (r5 != 0) goto L_0x011f;
    L_0x011c:
        r10.close();
    L_0x011f:
        throw r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.n.b(android.content.Context):void");
    }

    /* renamed from: a */
    static void m4749a(final Context context) {
        new Thread(new Runnable() {
            public void run() {
                C1137n.m4750b(context);
            }
        }, "OS_RESTORE_NOTIFS").start();
    }
}

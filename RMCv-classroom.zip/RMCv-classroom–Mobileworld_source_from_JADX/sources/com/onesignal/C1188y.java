package com.onesignal;

import android.content.Context;
import com.amazon.device.messaging.ADM;
import com.onesignal.C1170t.C1166d;
import com.onesignal.C1186x.C1157a;

/* compiled from: PushRegistratorADM */
/* renamed from: com.onesignal.y */
public class C1188y implements C1186x {
    /* renamed from: a */
    private static C1157a f2495a;
    /* renamed from: b */
    private static boolean f2496b = false;

    /* renamed from: a */
    public void mo1124a(final Context context, String noKeyNeeded, final C1157a callback) {
        f2495a = callback;
        new Thread(new Runnable(this) {
            /* renamed from: c */
            final /* synthetic */ C1188y f2494c;

            public void run() {
                ADM adm = new ADM(context);
                String registrationId = adm.getRegistrationId();
                if (registrationId == null) {
                    adm.startRegister();
                } else {
                    C1170t.m4843a(C1166d.DEBUG, "ADM Already registered with ID:" + registrationId);
                    callback.mo1123a(registrationId, 1);
                }
                try {
                    Thread.sleep(30000);
                } catch (InterruptedException e) {
                }
                if (!C1188y.f2496b) {
                    C1170t.m4843a(C1166d.ERROR, "com.onesignal.ADMMessageHandler timed out, please check that your have the receiver, service, and your package name matches(NOTE: Case Sensitive) per the OneSignal instructions.");
                    C1188y.m4976a(null);
                }
            }
        }).start();
    }

    /* renamed from: a */
    public static void m4976a(String id) {
        if (f2495a != null) {
            f2496b = true;
            f2495a.mo1123a(id, 1);
        }
    }
}

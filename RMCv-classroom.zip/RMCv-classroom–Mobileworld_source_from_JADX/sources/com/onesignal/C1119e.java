package com.onesignal;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.os.Build.VERSION;
import android.os.Process;
import android.util.Log;

/* compiled from: AndroidSupportV4Compat */
/* renamed from: com.onesignal.e */
class C1119e {

    /* compiled from: AndroidSupportV4Compat */
    /* renamed from: com.onesignal.e$a */
    static class C1115a {
        /* renamed from: a */
        static void m4674a(Activity activity, String[] permissions, int requestCode) {
            C1116b.m4675a(activity, permissions, requestCode);
        }
    }

    @TargetApi(23)
    /* compiled from: AndroidSupportV4Compat */
    /* renamed from: com.onesignal.e$b */
    static class C1116b {
        /* renamed from: a */
        static void m4675a(Activity activity, String[] permissions, int requestCode) {
            if (activity instanceof C1118d) {
                ((C1118d) activity).m4678a(requestCode);
            }
            activity.requestPermissions(permissions, requestCode);
        }
    }

    /* compiled from: AndroidSupportV4Compat */
    /* renamed from: com.onesignal.e$c */
    static class C1117c {
        /* renamed from: a */
        static int m4677a(Context context, String permission) {
            try {
                return context.checkPermission(permission, Process.myPid(), Process.myUid());
            } catch (Throwable th) {
                Log.e("OneSignal", "checkSelfPermission failed, returning PERMISSION_DENIED");
                return -1;
            }
        }

        /* renamed from: a */
        static int m4676a(Context context, int id) {
            if (VERSION.SDK_INT > 22) {
                return context.getColor(id);
            }
            return context.getResources().getColor(id);
        }
    }

    /* compiled from: AndroidSupportV4Compat */
    /* renamed from: com.onesignal.e$d */
    interface C1118d {
        /* renamed from: a */
        void m4678a(int i);
    }
}

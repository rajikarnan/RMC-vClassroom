package com.onesignal;

import android.R.drawable;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build.VERSION;
import android.support.v4.app.ag.C0081q;
import android.support.v4.app.ag.C0082b;
import android.support.v4.app.ag.C0083c;
import android.support.v4.app.ag.C0084d;
import android.support.v4.app.ag.C0087g;
import android.support.v4.app.ap;
import android.text.SpannableString;
import android.text.style.StyleSpan;
import android.widget.RemoteViews;
import com.onesignal.C1119e.C1117c;
import com.onesignal.C1133k.C1132a;
import com.onesignal.C1170t.C1166d;
import com.onesignal.aa.C1102a;
import com.onesignal.aa.C1103b;
import java.math.BigInteger;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Random;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: GenerateNotification */
/* renamed from: com.onesignal.g */
class C1124g {
    /* renamed from: a */
    private static Context f2327a = null;
    /* renamed from: b */
    private static String f2328b = null;
    /* renamed from: c */
    private static Resources f2329c = null;
    /* renamed from: d */
    private static Class<?> f2330d;
    /* renamed from: e */
    private static boolean f2331e;

    /* renamed from: a */
    static void m4687a(Context inContext) {
        f2327a = inContext;
        f2328b = f2327a.getPackageName();
        f2329c = f2327a.getResources();
        PackageManager packageManager = f2327a.getPackageManager();
        Intent intent = new Intent(f2327a, NotificationOpenedReceiver.class);
        intent.setPackage(f2327a.getPackageName());
        if (packageManager.queryBroadcastReceivers(intent, 0).size() > 0) {
            f2331e = true;
            f2330d = NotificationOpenedReceiver.class;
            return;
        }
        f2330d = C1134l.class;
    }

    /* renamed from: a */
    static void m4689a(Context inContext, boolean restoring, int notificationId, JSONObject jsonPayload, boolean showAsAlert, C1132a overrideSettings) {
        C1124g.m4687a(inContext);
        if (restoring || !showAsAlert || C1101a.f2289b == null) {
            C1124g.m4686a(notificationId, restoring, jsonPayload, overrideSettings);
        } else {
            C1124g.m4693a(jsonPayload, C1101a.f2289b, notificationId);
        }
    }

    /* renamed from: a */
    private static void m4693a(final JSONObject gcmJson, final Activity activity, final int notificationId) {
        activity.runOnUiThread(new Runnable() {
            public void run() {
                Builder builder = new Builder(activity);
                builder.setTitle(C1124g.m4700b(gcmJson));
                builder.setMessage(gcmJson.optString("alert"));
                List buttonsLabels = new ArrayList();
                List<String> buttonIds = new ArrayList();
                C1124g.m4701b(activity, gcmJson, buttonsLabels, buttonIds);
                final List<String> finalButtonIds = buttonIds;
                Intent buttonIntent = C1124g.m4698b(notificationId);
                buttonIntent.putExtra("action_button", true);
                buttonIntent.putExtra("from_alert", true);
                buttonIntent.putExtra("onesignal_data", gcmJson.toString());
                if (gcmJson.has("grp")) {
                    buttonIntent.putExtra("grp", gcmJson.optString("grp"));
                }
                final Intent finalButtonIntent = buttonIntent;
                OnClickListener buttonListener = new OnClickListener(this) {
                    /* renamed from: c */
                    final /* synthetic */ C11231 f2321c;

                    public void onClick(DialogInterface dialog, int which) {
                        int index = which + 3;
                        if (finalButtonIds.size() > 1) {
                            try {
                                JSONObject newJsonData = new JSONObject(gcmJson.toString());
                                newJsonData.put("actionSelected", finalButtonIds.get(index));
                                finalButtonIntent.putExtra("onesignal_data", newJsonData.toString());
                                C1135m.m4747b(activity, finalButtonIntent);
                                return;
                            } catch (Throwable th) {
                                return;
                            }
                        }
                        C1135m.m4747b(activity, finalButtonIntent);
                    }
                };
                builder.setOnCancelListener(new OnCancelListener(this) {
                    /* renamed from: b */
                    final /* synthetic */ C11231 f2323b;

                    public void onCancel(DialogInterface dialogInterface) {
                        C1135m.m4747b(activity, finalButtonIntent);
                    }
                });
                for (int i = 0; i < buttonsLabels.size(); i++) {
                    if (i == 0) {
                        builder.setNeutralButton((CharSequence) buttonsLabels.get(i), buttonListener);
                    } else if (i == 1) {
                        builder.setNegativeButton((CharSequence) buttonsLabels.get(i), buttonListener);
                    } else if (i == 2) {
                        builder.setPositiveButton((CharSequence) buttonsLabels.get(i), buttonListener);
                    }
                }
                AlertDialog alertDialog = builder.create();
                alertDialog.setCanceledOnTouchOutside(false);
                alertDialog.show();
            }
        });
    }

    /* renamed from: b */
    private static CharSequence m4700b(JSONObject gcmBundle) {
        CharSequence title = gcmBundle.optString("title", null);
        return title != null ? title : f2327a.getPackageManager().getApplicationLabel(f2327a.getApplicationInfo());
    }

    /* renamed from: a */
    private static PendingIntent m4682a(int requestCode, Intent intent) {
        if (f2331e) {
            return PendingIntent.getBroadcast(f2327a, requestCode, intent, 134217728);
        }
        return PendingIntent.getActivity(f2327a, requestCode, intent, 134217728);
    }

    /* renamed from: b */
    private static Intent m4698b(int notificationId) {
        Intent intent = new Intent(f2327a, f2330d).putExtra("notificationId", notificationId);
        return f2331e ? intent : intent.addFlags(603979776);
    }

    /* renamed from: c */
    private static Intent m4702c(int notificationId) {
        Intent intent = new Intent(f2327a, f2330d).putExtra("notificationId", notificationId).putExtra("dismissed", true);
        return f2331e ? intent : intent.addFlags(402718720);
    }

    /* renamed from: c */
    private static C0084d m4704c(JSONObject gcmBundle) {
        int visibility;
        Bitmap largeIcon;
        Bitmap bigPictureIcon;
        Uri soundUri;
        int notificationIcon = C1124g.m4708e(gcmBundle);
        int notificationDefaults = 0;
        if (C1170t.m4853a(f2327a)) {
            notificationDefaults = 2;
        }
        CharSequence message = gcmBundle.optString("alert", null);
        C0084d notifBuilder = new C0084d(f2327a).setAutoCancel(true).setSmallIcon(notificationIcon).setContentTitle(C1124g.m4700b(gcmBundle)).setStyle(new C0083c().m299a(message)).setContentText(message).setTicker(message);
        try {
            BigInteger accentColor = C1124g.m4712h(gcmBundle);
            if (accentColor != null) {
                notifBuilder.setColor(accentColor.intValue());
            }
        } catch (Throwable th) {
        }
        if (gcmBundle.has("ledc")) {
            try {
                BigInteger ledColor = new BigInteger(gcmBundle.optString("ledc"), 16);
                BigInteger bigInteger;
                try {
                    notifBuilder.setLights(ledColor.intValue(), 2000, 5000);
                    bigInteger = ledColor;
                } catch (Throwable th2) {
                    bigInteger = ledColor;
                    notificationDefaults |= 4;
                    visibility = 1;
                    if (gcmBundle.has("vis")) {
                        visibility = Integer.parseInt(gcmBundle.optString("vis"));
                    }
                    notifBuilder.setVisibility(visibility);
                    largeIcon = C1124g.m4706d(gcmBundle);
                    if (largeIcon != null) {
                        notifBuilder.setLargeIcon(largeIcon);
                    }
                    bigPictureIcon = C1124g.m4705d(gcmBundle.optString("bicon", null));
                    if (bigPictureIcon != null) {
                        notifBuilder.setStyle(new C0082b().m297a(bigPictureIcon).m298a(message));
                    }
                    if (C1124g.m4710f(gcmBundle)) {
                        soundUri = C1124g.m4711g(gcmBundle);
                        if (soundUri != null) {
                            notifBuilder.setSound(soundUri);
                        } else {
                            notificationDefaults |= 1;
                        }
                    }
                    notifBuilder.setDefaults(notificationDefaults);
                    if (gcmBundle.optInt("pri", 0) > 9) {
                        notifBuilder.setPriority(2);
                    }
                    return notifBuilder;
                }
            } catch (Throwable th3) {
                notificationDefaults |= 4;
                visibility = 1;
                if (gcmBundle.has("vis")) {
                    visibility = Integer.parseInt(gcmBundle.optString("vis"));
                }
                notifBuilder.setVisibility(visibility);
                largeIcon = C1124g.m4706d(gcmBundle);
                if (largeIcon != null) {
                    notifBuilder.setLargeIcon(largeIcon);
                }
                bigPictureIcon = C1124g.m4705d(gcmBundle.optString("bicon", null));
                if (bigPictureIcon != null) {
                    notifBuilder.setStyle(new C0082b().m297a(bigPictureIcon).m298a(message));
                }
                if (C1124g.m4710f(gcmBundle)) {
                    soundUri = C1124g.m4711g(gcmBundle);
                    if (soundUri != null) {
                        notificationDefaults |= 1;
                    } else {
                        notifBuilder.setSound(soundUri);
                    }
                }
                notifBuilder.setDefaults(notificationDefaults);
                if (gcmBundle.optInt("pri", 0) > 9) {
                    notifBuilder.setPriority(2);
                }
                return notifBuilder;
            }
        }
        notificationDefaults |= 4;
        visibility = 1;
        try {
            if (gcmBundle.has("vis")) {
                visibility = Integer.parseInt(gcmBundle.optString("vis"));
            }
            notifBuilder.setVisibility(visibility);
        } catch (Throwable th4) {
        }
        largeIcon = C1124g.m4706d(gcmBundle);
        if (largeIcon != null) {
            notifBuilder.setLargeIcon(largeIcon);
        }
        bigPictureIcon = C1124g.m4705d(gcmBundle.optString("bicon", null));
        if (bigPictureIcon != null) {
            notifBuilder.setStyle(new C0082b().m297a(bigPictureIcon).m298a(message));
        }
        if (C1124g.m4710f(gcmBundle)) {
            soundUri = C1124g.m4711g(gcmBundle);
            if (soundUri != null) {
                notifBuilder.setSound(soundUri);
            } else {
                notificationDefaults |= 1;
            }
        }
        notifBuilder.setDefaults(notificationDefaults);
        if (gcmBundle.optInt("pri", 0) > 9) {
            notifBuilder.setPriority(2);
        }
        return notifBuilder;
    }

    /* renamed from: a */
    private static void m4691a(C0084d builder) {
        builder.setDefaults(0).setSound(null).setVibrate(null).setTicker(null);
    }

    /* renamed from: a */
    static void m4686a(int notificationId, boolean restoring, JSONObject gcmBundle, C1132a overrideSettings) {
        Random random = new Random();
        String group = gcmBundle.optString("grp", null);
        C0084d notifBuilder = C1124g.m4704c(gcmBundle);
        C1124g.m4695a(gcmBundle, notifBuilder, notificationId, null);
        try {
            C1124g.m4694a(gcmBundle, notifBuilder);
        } catch (Throwable t) {
            C1170t.m4844a(C1166d.ERROR, "Could not set background notification image!", t);
        }
        if (!(overrideSettings == null || overrideSettings.f2340a == null)) {
            notifBuilder.extend(overrideSettings.f2340a);
        }
        if (group != null) {
            notifBuilder.setContentIntent(C1124g.m4682a(random.nextInt(), C1124g.m4698b(notificationId).putExtra("onesignal_data", gcmBundle.toString()).putExtra("grp", group)));
            notifBuilder.setDeleteIntent(C1124g.m4682a(random.nextInt(), C1124g.m4702c(notificationId).putExtra("grp", group)));
            notifBuilder.setGroup(group);
            C1124g.m4696a(restoring, gcmBundle);
        } else {
            notifBuilder.setContentIntent(C1124g.m4682a(random.nextInt(), C1124g.m4698b(notificationId).putExtra("onesignal_data", gcmBundle.toString())));
            notifBuilder.setDeleteIntent(C1124g.m4682a(random.nextInt(), C1124g.m4702c(notificationId)));
        }
        if (restoring) {
            C1124g.m4691a(notifBuilder);
        }
        if (group == null || VERSION.SDK_INT > 17) {
            ap.m418a(f2327a).m423a(notificationId, notifBuilder.build());
        }
    }

    /* renamed from: a */
    private static void m4696a(boolean restoring, JSONObject gcmBundle) {
        C1124g.m4690a(null, restoring, gcmBundle);
    }

    /* renamed from: a */
    static void m4690a(Context inContext, boolean updateSummary, JSONObject gcmBundle) {
        Throwable th;
        if (updateSummary && inContext != null) {
            C1124g.m4687a(inContext);
        }
        String group = gcmBundle.optString("grp", null);
        Random random = new Random();
        PendingIntent summaryDeleteIntent = C1124g.m4682a(random.nextInt(), C1124g.m4702c(0).putExtra("summary", group));
        C1171u dbHelper = C1171u.m4908a(f2327a);
        Cursor cursor = dbHelper.getReadableDatabase().query("notification", new String[]{"android_notification_id", "full_data", "is_summary", "title", "message"}, "group_id = ? AND dismissed = 0 AND opened = 0", new String[]{group}, null, null, "_id DESC");
        int summaryNotificationId = random.nextInt();
        String firstFullData = null;
        Collection<SpannableString> summeryList = null;
        try {
            Notification summaryNotification;
            if (cursor.moveToFirst()) {
                Collection<SpannableString> summeryList2 = new ArrayList();
                while (true) {
                    try {
                        if (cursor.getInt(cursor.getColumnIndex("is_summary")) == 1) {
                            summaryNotificationId = cursor.getInt(cursor.getColumnIndex("android_notification_id"));
                        } else {
                            String title = cursor.getString(cursor.getColumnIndex("title"));
                            if (title == null) {
                                title = "";
                            } else {
                                title = title + " ";
                            }
                            SpannableString spannableString = new SpannableString(title + cursor.getString(cursor.getColumnIndex("message")));
                            if (title.length() > 0) {
                                spannableString.setSpan(new StyleSpan(1), 0, title.length(), 0);
                            }
                            summeryList2.add(spannableString);
                            if (firstFullData == null) {
                                firstFullData = cursor.getString(cursor.getColumnIndex("full_data"));
                            }
                        }
                        if (!cursor.moveToNext()) {
                            break;
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    } catch (Throwable th2) {
                        th = th2;
                        summeryList = summeryList2;
                    }
                }
                if (updateSummary && firstFullData != null) {
                    summeryList = summeryList2;
                    gcmBundle = new JSONObject(firstFullData);
                }
                summeryList = summeryList2;
            }
            if (!(cursor == null || cursor.isClosed())) {
                cursor.close();
            }
            PendingIntent summaryContentIntent;
            if (summeryList == null || (updateSummary && summeryList.size() <= 1)) {
                SQLiteDatabase writableDb = dbHelper.getWritableDatabase();
                writableDb.beginTransaction();
                try {
                    ContentValues values = new ContentValues();
                    values.put("android_notification_id", Integer.valueOf(summaryNotificationId));
                    values.put("group_id", group);
                    values.put("is_summary", Integer.valueOf(1));
                    writableDb.insertOrThrow("notification", null, values);
                    writableDb.setTransactionSuccessful();
                } catch (Throwable e2) {
                    C1170t.m4844a(C1166d.ERROR, "Error adding summary notification record! ", e2);
                } finally {
                    writableDb.endTransaction();
                }
                C0084d notifBuilder = C1124g.m4704c(gcmBundle);
                if (updateSummary) {
                    C1124g.m4691a(notifBuilder);
                }
                summaryContentIntent = C1124g.m4682a(random.nextInt(), C1124g.m4698b(summaryNotificationId).putExtra("onesignal_data", gcmBundle.toString()).putExtra("summary", group));
                C1124g.m4695a(gcmBundle, notifBuilder, summaryNotificationId, group);
                notifBuilder.setContentIntent(summaryContentIntent).setDeleteIntent(summaryDeleteIntent).setOnlyAlertOnce(updateSummary).setGroup(group).setGroupSummary(true);
                summaryNotification = notifBuilder.build();
            } else {
                int notificationCount = summeryList.size() + (updateSummary ? 0 : 1);
                String summaryMessage = gcmBundle.optString("grp_msg", null);
                if (summaryMessage == null) {
                    summaryMessage = notificationCount + " new messages";
                } else {
                    summaryMessage = summaryMessage.replace("$[notif_count]", "" + notificationCount);
                }
                JSONObject summaryDataBundle = new JSONObject();
                try {
                    summaryDataBundle.put("alert", summaryMessage);
                } catch (JSONException e3) {
                    e3.printStackTrace();
                }
                summaryContentIntent = C1124g.m4682a(random.nextInt(), C1124g.m4698b(summaryNotificationId).putExtra("summary", group).putExtra("onesignal_data", summaryDataBundle.toString()));
                C0084d summeryBuilder = C1124g.m4704c(gcmBundle);
                if (updateSummary) {
                    C1124g.m4691a(summeryBuilder);
                }
                summeryBuilder.setContentIntent(summaryContentIntent).setDeleteIntent(summaryDeleteIntent).setContentTitle(f2327a.getPackageManager().getApplicationLabel(f2327a.getApplicationInfo())).setContentText(summaryMessage).setNumber(notificationCount).setOnlyAlertOnce(updateSummary).setGroup(group).setGroupSummary(true);
                if (!updateSummary) {
                    summeryBuilder.setTicker(summaryMessage);
                }
                C0081q inboxStyle = new C0087g();
                if (!updateSummary) {
                    String line1Title = gcmBundle.optString("title", null);
                    if (line1Title == null) {
                        line1Title = "";
                    } else {
                        line1Title = line1Title + " ";
                    }
                    CharSequence spannableString2 = new SpannableString(line1Title + gcmBundle.optString("alert"));
                    if (line1Title.length() > 0) {
                        spannableString2.setSpan(new StyleSpan(1), 0, line1Title.length(), 0);
                    }
                    inboxStyle.m302b(spannableString2);
                }
                for (SpannableString line : summeryList) {
                    inboxStyle.m302b(line);
                }
                inboxStyle.m301a(summaryMessage);
                summeryBuilder.setStyle(inboxStyle);
                summaryNotification = summeryBuilder.build();
            }
            ap.m418a(f2327a).m423a(summaryNotificationId, summaryNotification);
        } catch (Throwable th3) {
            th = th3;
            if (!(cursor == null || cursor.isClosed())) {
                cursor.close();
            }
            throw th;
        }
    }

    /* renamed from: a */
    private static void m4694a(JSONObject gcmBundle, C0084d notifBuilder) throws Throwable {
        if (VERSION.SDK_INT >= 16) {
            Bitmap bg_image = null;
            JSONObject jsonBgImage = null;
            String jsonStrBgImage = gcmBundle.optString("bg_img", null);
            if (jsonStrBgImage != null) {
                jsonBgImage = new JSONObject(jsonStrBgImage);
                bg_image = C1124g.m4705d(jsonBgImage.optString("img", null));
            }
            if (bg_image == null) {
                bg_image = C1124g.m4699b("onesignal_bgimage_default_image");
            }
            if (bg_image != null) {
                RemoteViews customView = new RemoteViews(f2327a.getPackageName(), C1103b.onesignal_bgimage_notif_layout);
                customView.setTextViewText(C1102a.os_bgimage_notif_title, C1124g.m4700b(gcmBundle));
                customView.setTextViewText(C1102a.os_bgimage_notif_body, gcmBundle.optString("alert"));
                C1124g.m4692a(customView, jsonBgImage, C1102a.os_bgimage_notif_title, "tc", "onesignal_bgimage_notif_title_color");
                C1124g.m4692a(customView, jsonBgImage, C1102a.os_bgimage_notif_body, "bc", "onesignal_bgimage_notif_body_color");
                String alignSetting = null;
                if (jsonBgImage == null || !jsonBgImage.has("img_align")) {
                    int iAlignSetting = f2329c.getIdentifier("onesignal_bgimage_notif_image_align", "string", f2328b);
                    if (iAlignSetting != 0) {
                        alignSetting = f2329c.getString(iAlignSetting);
                    }
                } else {
                    alignSetting = jsonBgImage.getString("img_align");
                }
                if ("right".equals(alignSetting)) {
                    customView.setViewPadding(C1102a.os_bgimage_notif_bgimage_align_layout, -5000, 0, 0, 0);
                    customView.setImageViewBitmap(C1102a.os_bgimage_notif_bgimage_right_aligned, bg_image);
                    customView.setViewVisibility(C1102a.os_bgimage_notif_bgimage_right_aligned, 0);
                    customView.setViewVisibility(C1102a.os_bgimage_notif_bgimage, 2);
                } else {
                    customView.setImageViewBitmap(C1102a.os_bgimage_notif_bgimage, bg_image);
                }
                notifBuilder.setContent(customView);
                notifBuilder.setStyle(null);
            }
        }
    }

    /* renamed from: a */
    private static void m4692a(RemoteViews customView, JSONObject gcmBundle, int viewId, String colorPayloadKey, String colorDefaultResource) {
        Integer color = C1124g.m4685a(gcmBundle, colorPayloadKey);
        if (color != null) {
            customView.setTextColor(viewId, color.intValue());
            return;
        }
        int colorId = f2329c.getIdentifier(colorDefaultResource, "color", f2328b);
        if (colorId != 0) {
            customView.setTextColor(viewId, C1117c.m4676a(f2327a, colorId));
        }
    }

    /* renamed from: a */
    private static Integer m4685a(JSONObject gcmBundle, String colorKey) {
        if (gcmBundle != null) {
            try {
                if (gcmBundle.has(colorKey)) {
                    return Integer.valueOf(new BigInteger(gcmBundle.optString(colorKey), 16).intValue());
                }
            } catch (Throwable th) {
            }
        }
        return null;
    }

    /* renamed from: a */
    private static boolean m4697a(String name) {
        return (name == null || name.matches("^[0-9]")) ? false : true;
    }

    /* renamed from: d */
    private static Bitmap m4706d(JSONObject gcmBundle) {
        if (VERSION.SDK_INT < 11) {
            return null;
        }
        Bitmap bitmap = C1124g.m4705d(gcmBundle.optString("licon"));
        if (bitmap == null) {
            bitmap = C1124g.m4699b("ic_onesignal_large_icon_default");
        }
        if (bitmap == null) {
            return null;
        }
        try {
            int systemLargeIconHeight = (int) f2329c.getDimension(17104902);
            int systemLargeIconWidth = (int) f2329c.getDimension(17104901);
            int bitmapHeight = bitmap.getHeight();
            int bitmapWidth = bitmap.getWidth();
            if (bitmapWidth <= systemLargeIconWidth && bitmapHeight <= systemLargeIconHeight) {
                return bitmap;
            }
            int newWidth = systemLargeIconWidth;
            int newHeight = systemLargeIconHeight;
            if (bitmapHeight > bitmapWidth) {
                newWidth = (int) (((float) newHeight) * (((float) bitmapWidth) / ((float) bitmapHeight)));
            } else if (bitmapWidth > bitmapHeight) {
                newHeight = (int) (((float) newWidth) * (((float) bitmapHeight) / ((float) bitmapWidth)));
            }
            return Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true);
        } catch (Throwable th) {
            return bitmap;
        }
    }

    /* renamed from: b */
    private static Bitmap m4699b(String bitmapStr) {
        Bitmap bitmap = null;
        try {
            bitmap = BitmapFactory.decodeStream(f2327a.getAssets().open(bitmapStr));
        } catch (Throwable th) {
        }
        if (bitmap != null) {
            return bitmap;
        }
        try {
            for (String extension : Arrays.asList(new String[]{".png", ".webp", ".jpg", ".gif", ".bmp"})) {
                try {
                    bitmap = BitmapFactory.decodeStream(f2327a.getAssets().open(bitmapStr + extension));
                    continue;
                } catch (Throwable th2) {
                    continue;
                }
                if (bitmap != null) {
                    return bitmap;
                }
            }
            int bitmapId = C1124g.m4707e(bitmapStr);
            if (bitmapId != 0) {
                return BitmapFactory.decodeResource(f2329c, bitmapId);
            }
        } catch (Throwable th3) {
        }
        return null;
    }

    /* renamed from: c */
    private static Bitmap m4703c(String location) {
        try {
            return BitmapFactory.decodeStream(new URL(location).openConnection().getInputStream());
        } catch (Throwable th) {
            return null;
        }
    }

    /* renamed from: d */
    private static Bitmap m4705d(String name) {
        if (name == null) {
            return null;
        }
        if (name.startsWith("http://") || name.startsWith("https://")) {
            return C1124g.m4703c(name);
        }
        return C1124g.m4699b(name);
    }

    /* renamed from: e */
    private static int m4707e(String iconName) {
        if (!C1124g.m4697a(iconName)) {
            return 0;
        }
        int notificationIcon = C1124g.m4709f(iconName);
        if (notificationIcon != 0) {
            return notificationIcon;
        }
        try {
            return drawable.class.getField(iconName).getInt(null);
        } catch (Throwable th) {
            return 0;
        }
    }

    /* renamed from: e */
    private static int m4708e(JSONObject gcmBundle) {
        int notificationIcon = C1124g.m4707e(gcmBundle.optString("sicon", null));
        if (notificationIcon != 0) {
            return notificationIcon;
        }
        notificationIcon = C1124g.m4709f("ic_stat_onesignal_default");
        if (notificationIcon != 0) {
            return notificationIcon;
        }
        notificationIcon = C1124g.m4709f("corona_statusbar_icon_default");
        if (notificationIcon != 0) {
            return notificationIcon;
        }
        notificationIcon = C1124g.m4709f("ic_os_notification_fallback_white_24dp");
        if (notificationIcon != 0) {
            return notificationIcon;
        }
        return 17301598;
    }

    /* renamed from: f */
    private static int m4709f(String name) {
        return f2329c.getIdentifier(name, "drawable", f2328b);
    }

    /* renamed from: f */
    private static boolean m4710f(JSONObject gcmBundle) {
        String sound = gcmBundle.optString("sound", null);
        if ("null".equals(sound) || "nil".equals(sound)) {
            return false;
        }
        return C1170t.m4867b(f2327a);
    }

    /* renamed from: g */
    private static Uri m4711g(JSONObject gcmBundle) {
        int soundId;
        String sound = gcmBundle.optString("sound", null);
        if (C1124g.m4697a(sound)) {
            soundId = f2329c.getIdentifier(sound, "raw", f2328b);
            if (soundId != 0) {
                return Uri.parse("android.resource://" + f2328b + "/" + soundId);
            }
        }
        soundId = f2329c.getIdentifier("onesignal_default_sound", "raw", f2328b);
        if (soundId != 0) {
            return Uri.parse("android.resource://" + f2328b + "/" + soundId);
        }
        return null;
    }

    /* renamed from: h */
    private static BigInteger m4712h(JSONObject gcmBundle) {
        try {
            if (gcmBundle.has("bgac")) {
                return new BigInteger(gcmBundle.optString("bgac", null), 16);
            }
        } catch (Throwable th) {
        }
        try {
            String defaultColor = C1146s.m4751a(f2327a, "com.onesignal.NotificationAccentColor.DEFAULT");
            if (defaultColor != null) {
                return new BigInteger(defaultColor, 16);
            }
        } catch (Throwable th2) {
        }
        return null;
    }

    /* renamed from: a */
    private static void m4695a(JSONObject gcmBundle, C0084d mBuilder, int notificationId, String groupSummary) {
        try {
            JSONObject customJson = new JSONObject(gcmBundle.optString("custom"));
            if (customJson.has("a")) {
                JSONObject additionalDataJSON = customJson.getJSONObject("a");
                if (additionalDataJSON.has("actionButtons")) {
                    JSONArray buttons = additionalDataJSON.getJSONArray("actionButtons");
                    for (int i = 0; i < buttons.length(); i++) {
                        JSONObject button = buttons.optJSONObject(i);
                        JSONObject bundle = new JSONObject(gcmBundle.toString());
                        Intent buttonIntent = C1124g.m4698b(notificationId);
                        buttonIntent.setAction("" + i);
                        buttonIntent.putExtra("action_button", true);
                        bundle.put("actionSelected", button.optString("id"));
                        buttonIntent.putExtra("onesignal_data", bundle.toString());
                        if (groupSummary != null) {
                            buttonIntent.putExtra("summary", groupSummary);
                        } else if (gcmBundle.has("grp")) {
                            buttonIntent.putExtra("grp", gcmBundle.optString("grp"));
                        }
                        PendingIntent buttonPIntent = C1124g.m4682a(notificationId, buttonIntent);
                        int buttonIcon = 0;
                        if (button.has("icon")) {
                            buttonIcon = C1124g.m4707e(button.optString("icon"));
                        }
                        mBuilder.addAction(buttonIcon, button.optString("text"), buttonPIntent);
                    }
                }
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    /* renamed from: b */
    private static void m4701b(Context context, JSONObject gcmBundle, List<String> buttonsLabels, List<String> buttonsIds) {
        try {
            JSONObject customJson = new JSONObject(gcmBundle.optString("custom"));
            if (customJson.has("a")) {
                JSONObject additionalDataJSON = customJson.getJSONObject("a");
                if (additionalDataJSON.has("actionButtons")) {
                    JSONArray buttons = additionalDataJSON.optJSONArray("actionButtons");
                    for (int i = 0; i < buttons.length(); i++) {
                        JSONObject button = buttons.getJSONObject(i);
                        buttonsLabels.add(button.optString("text"));
                        buttonsIds.add(button.optString("id"));
                    }
                }
            }
            if (buttonsLabels.size() < 3) {
                buttonsLabels.add(C1146s.m4752a(context, "onesignal_in_app_alert_ok_button_text", "Ok"));
                buttonsIds.add("__DEFAULT__");
            }
        } catch (Throwable t) {
            C1170t.m4844a(C1166d.ERROR, "Failed to parse buttons for alert dialog.", t);
        }
    }
}

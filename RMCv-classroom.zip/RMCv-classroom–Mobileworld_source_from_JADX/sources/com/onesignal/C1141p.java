package com.onesignal;

/* compiled from: OSNotificationAction */
/* renamed from: com.onesignal.p */
public class C1141p {
    /* renamed from: a */
    public C1140a f2359a;
    /* renamed from: b */
    public String f2360b;

    /* compiled from: OSNotificationAction */
    /* renamed from: com.onesignal.p$a */
    public enum C1140a {
        Opened,
        ActionTaken
    }
}

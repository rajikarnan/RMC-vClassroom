package com.onesignal;

import android.content.Context;

/* compiled from: AdvertisingIdentifierProvider */
/* renamed from: com.onesignal.d */
interface C1113d {
    /* renamed from: a */
    String mo1118a(Context context);
}

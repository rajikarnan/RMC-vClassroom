package com.facebook;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.C0154q;
import android.support.v4.app.C0157u;
import android.support.v4.app.Fragment;
import android.util.Log;
import com.facebook.C0777t.C0773b;
import com.facebook.C0777t.C0774c;
import com.facebook.login.C0741d;
import com.facebook.p014b.C0659g;
import com.facebook.p014b.C0677m;
import com.facebook.share.internal.DeviceShareDialogFragment;
import com.facebook.share.model.ShareContent;

public class FacebookActivity extends C0154q {
    /* renamed from: a */
    public static String f951a = "PassThrough";
    /* renamed from: b */
    private static String f952b = "SingleFragment";
    /* renamed from: c */
    private static final String f953c = FacebookActivity.class.getName();
    /* renamed from: d */
    private Fragment f954d;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        if (!C0707g.m2846a()) {
            Log.d(f953c, "Facebook SDK not initialized. Make sure you call sdkInitialize inside your Application's onCreate method.");
            C0707g.m2843a(getApplicationContext());
        }
        setContentView(C0774c.com_facebook_activity_layout);
        if (f951a.equals(intent.getAction())) {
            m2396b();
            return;
        }
        C0157u manager = getSupportFragmentManager();
        Fragment fragment = manager.mo129a(f952b);
        if (fragment == null) {
            Fragment dialogFragment;
            if ("FacebookDialogFragment".equals(intent.getAction())) {
                dialogFragment = new C0659g();
                dialogFragment.setRetainInstance(true);
                dialogFragment.show(manager, f952b);
                fragment = dialogFragment;
            } else if ("DeviceShareDialogFragment".equals(intent.getAction())) {
                dialogFragment = new DeviceShareDialogFragment();
                dialogFragment.setRetainInstance(true);
                dialogFragment.m3120a((ShareContent) intent.getParcelableExtra("content"));
                dialogFragment.show(manager, f952b);
                fragment = dialogFragment;
            } else {
                fragment = new C0741d();
                fragment.setRetainInstance(true);
                manager.mo130a().mo95a(C0773b.com_facebook_fragment_container, fragment, f952b).mo98b();
            }
        }
        this.f954d = fragment;
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (this.f954d != null) {
            this.f954d.onConfigurationChanged(newConfig);
        }
    }

    /* renamed from: a */
    public Fragment m2397a() {
        return this.f954d;
    }

    /* renamed from: b */
    private void m2396b() {
        setResult(0, C0677m.m2703a(getIntent(), null, C0677m.m2706a(C0677m.m2716c(getIntent()))));
        finish();
    }
}

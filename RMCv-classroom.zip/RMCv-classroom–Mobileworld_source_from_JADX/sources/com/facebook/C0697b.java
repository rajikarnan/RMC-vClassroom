package com.facebook;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.app.ag;
import android.support.v4.content.C0204h;
import android.util.Log;
import com.facebook.AccessToken.C0572a;
import com.facebook.C0712k.C0633a;
import com.facebook.GraphRequest.C0578b;
import com.facebook.p014b.C0689q;
import com.facebook.p014b.C0690r;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONArray;
import org.json.JSONObject;

/* compiled from: AccessTokenManager */
/* renamed from: com.facebook.b */
final class C0697b {
    /* renamed from: a */
    private static volatile C0697b f1257a;
    /* renamed from: b */
    private final C0204h f1258b;
    /* renamed from: c */
    private final C0629a f1259c;
    /* renamed from: d */
    private AccessToken f1260d;
    /* renamed from: e */
    private AtomicBoolean f1261e = new AtomicBoolean(false);
    /* renamed from: f */
    private Date f1262f = new Date(0);

    /* compiled from: AccessTokenManager */
    /* renamed from: com.facebook.b$a */
    private static class C0635a {
        /* renamed from: a */
        public String f1129a;
        /* renamed from: b */
        public int f1130b;

        private C0635a() {
        }
    }

    C0697b(C0204h localBroadcastManager, C0629a accessTokenCache) {
        C0690r.m2805a((Object) localBroadcastManager, "localBroadcastManager");
        C0690r.m2805a((Object) accessTokenCache, "accessTokenCache");
        this.f1258b = localBroadcastManager;
        this.f1259c = accessTokenCache;
    }

    /* renamed from: a */
    static C0697b m2823a() {
        if (f1257a == null) {
            synchronized (C0697b.class) {
                if (f1257a == null) {
                    f1257a = new C0697b(C0204h.m758a(C0707g.m2855f()), new C0629a());
                }
            }
        }
        return f1257a;
    }

    /* renamed from: b */
    AccessToken m2833b() {
        return this.f1260d;
    }

    /* renamed from: c */
    boolean m2834c() {
        AccessToken accessToken = this.f1259c.m2594a();
        if (accessToken == null) {
            return false;
        }
        m2826a(accessToken, false);
        return true;
    }

    /* renamed from: a */
    void m2832a(AccessToken currentAccessToken) {
        m2826a(currentAccessToken, true);
    }

    /* renamed from: a */
    private void m2826a(AccessToken currentAccessToken, boolean saveToCache) {
        AccessToken oldAccessToken = this.f1260d;
        this.f1260d = currentAccessToken;
        this.f1261e.set(false);
        this.f1262f = new Date(0);
        if (saveToCache) {
            if (currentAccessToken != null) {
                this.f1259c.m2595a(currentAccessToken);
            } else {
                this.f1259c.m2596b();
                C0689q.m2789b(C0707g.m2855f());
            }
        }
        if (!C0689q.m2781a((Object) oldAccessToken, (Object) currentAccessToken)) {
            m2825a(oldAccessToken, currentAccessToken);
        }
    }

    /* renamed from: a */
    private void m2825a(AccessToken oldAccessToken, AccessToken currentAccessToken) {
        Intent intent = new Intent("com.facebook.sdk.ACTION_CURRENT_ACCESS_TOKEN_CHANGED");
        intent.putExtra("com.facebook.sdk.EXTRA_OLD_ACCESS_TOKEN", oldAccessToken);
        intent.putExtra("com.facebook.sdk.EXTRA_NEW_ACCESS_TOKEN", currentAccessToken);
        this.f1258b.m763a(intent);
    }

    /* renamed from: d */
    void m2835d() {
        if (m2830e()) {
            m2831a(null);
        }
    }

    /* renamed from: e */
    private boolean m2830e() {
        if (this.f1260d == null) {
            return false;
        }
        Long now = Long.valueOf(new Date().getTime());
        if (!this.f1260d.m2389f().m2836a() || now.longValue() - this.f1262f.getTime() <= 3600000 || now.longValue() - this.f1260d.m2390g().getTime() <= 86400000) {
            return false;
        }
        return true;
    }

    /* renamed from: a */
    private static GraphRequest m2822a(AccessToken accessToken, C0578b callback) {
        return new GraphRequest(accessToken, "me/permissions", new Bundle(), C0745m.GET, callback);
    }

    /* renamed from: b */
    private static GraphRequest m2828b(AccessToken accessToken, C0578b callback) {
        Bundle parameters = new Bundle();
        parameters.putString("grant_type", "fb_extend_sso_token");
        return new GraphRequest(accessToken, "oauth/access_token", parameters, C0745m.GET, callback);
    }

    /* renamed from: a */
    void m2831a(final C0572a callback) {
        if (Looper.getMainLooper().equals(Looper.myLooper())) {
            m2829b(callback);
        } else {
            new Handler(Looper.getMainLooper()).post(new Runnable(this) {
                /* renamed from: b */
                final /* synthetic */ C0697b f1115b;

                public void run() {
                    this.f1115b.m2829b(callback);
                }
            });
        }
    }

    /* renamed from: b */
    private void m2829b(C0572a callback) {
        final AccessToken accessToken = this.f1260d;
        if (accessToken == null) {
            if (callback != null) {
                callback.m2377a(new C0699e("No current access token to refresh"));
            }
        } else if (this.f1261e.compareAndSet(false, true)) {
            this.f1262f = new Date();
            final Set<String> permissions = new HashSet();
            final Set<String> declinedPermissions = new HashSet();
            final AtomicBoolean permissionsCallSucceeded = new AtomicBoolean(false);
            final C0635a refreshResult = new C0635a();
            C0712k batch = new C0712k(C0697b.m2822a(accessToken, new C0578b(this) {
                /* renamed from: d */
                final /* synthetic */ C0697b f1119d;

                /* renamed from: a */
                public void mo848a(C0713l response) {
                    JSONObject result = response.m2891b();
                    if (result != null) {
                        JSONArray permissionsArray = result.optJSONArray("data");
                        if (permissionsArray != null) {
                            permissionsCallSucceeded.set(true);
                            for (int i = 0; i < permissionsArray.length(); i++) {
                                JSONObject permissionEntry = permissionsArray.optJSONObject(i);
                                if (permissionEntry != null) {
                                    String permission = permissionEntry.optString("permission");
                                    String status = permissionEntry.optString(ag.CATEGORY_STATUS);
                                    if (!(C0689q.m2782a(permission) || C0689q.m2782a(status))) {
                                        status = status.toLowerCase(Locale.US);
                                        if (status.equals("granted")) {
                                            permissions.add(permission);
                                        } else if (status.equals("declined")) {
                                            declinedPermissions.add(permission);
                                        } else {
                                            Log.w("AccessTokenManager", "Unexpected status: " + status);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }), C0697b.m2828b(accessToken, new C0578b(this) {
                /* renamed from: b */
                final /* synthetic */ C0697b f1121b;

                /* renamed from: a */
                public void mo848a(C0713l response) {
                    JSONObject data = response.m2891b();
                    if (data != null) {
                        refreshResult.f1129a = data.optString("access_token");
                        refreshResult.f1130b = data.optInt("expires_at");
                    }
                }
            }));
            final C0572a c0572a = callback;
            batch.m2871a(new C0633a(this) {
                /* renamed from: g */
                final /* synthetic */ C0697b f1128g;

                /* renamed from: a */
                public void mo852a(C0712k batch) {
                    Throwable th;
                    AccessToken newAccessToken;
                    try {
                        if (C0697b.m2823a().m2833b() == null || C0697b.m2823a().m2833b().m2392i() != accessToken.m2392i()) {
                            if (c0572a != null) {
                                c0572a.m2377a(new C0699e("No current access token to refresh"));
                            }
                            this.f1128g.f1261e.set(false);
                            if (!(c0572a == null || null == null)) {
                                c0572a.m2376a(null);
                            }
                            newAccessToken = null;
                        } else if (!permissionsCallSucceeded.get() && refreshResult.f1129a == null && refreshResult.f1130b == 0) {
                            if (c0572a != null) {
                                c0572a.m2377a(new C0699e("Failed to refresh access token"));
                            }
                            this.f1128g.f1261e.set(false);
                            if (!(c0572a == null || null == null)) {
                                c0572a.m2376a(null);
                            }
                            newAccessToken = null;
                        } else {
                            String str;
                            Collection collection;
                            Collection collection2;
                            Date date;
                            if (refreshResult.f1129a != null) {
                                str = refreshResult.f1129a;
                            } else {
                                str = accessToken.m2385b();
                            }
                            String h = accessToken.m2391h();
                            String i = accessToken.m2392i();
                            if (permissionsCallSucceeded.get()) {
                                collection = permissions;
                            } else {
                                collection = accessToken.m2387d();
                            }
                            if (permissionsCallSucceeded.get()) {
                                collection2 = declinedPermissions;
                            } else {
                                collection2 = accessToken.m2388e();
                            }
                            C0698c f = accessToken.m2389f();
                            if (refreshResult.f1130b != 0) {
                                date = new Date(((long) refreshResult.f1130b) * 1000);
                            } else {
                                date = accessToken.m2386c();
                            }
                            newAccessToken = new AccessToken(str, h, i, collection, collection2, f, date, new Date());
                            try {
                                C0697b.m2823a().m2832a(newAccessToken);
                                this.f1128g.f1261e.set(false);
                                if (c0572a != null && newAccessToken != null) {
                                    c0572a.m2376a(newAccessToken);
                                }
                            } catch (Throwable th2) {
                                th = th2;
                                this.f1128g.f1261e.set(false);
                                c0572a.m2376a(newAccessToken);
                                throw th;
                            }
                        }
                    } catch (Throwable th3) {
                        th = th3;
                        newAccessToken = null;
                        this.f1128g.f1261e.set(false);
                        if (!(c0572a == null || newAccessToken == null)) {
                            c0572a.m2376a(newAccessToken);
                        }
                        throw th;
                    }
                }
            });
            batch.m2881h();
        } else if (callback != null) {
            callback.m2377a(new C0699e("Refresh already in progress"));
        }
    }
}

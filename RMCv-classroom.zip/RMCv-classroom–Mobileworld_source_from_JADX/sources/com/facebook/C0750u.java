package com.facebook;

/* compiled from: RequestOutputStream */
/* renamed from: com.facebook.u */
interface C0750u {
    /* renamed from: a */
    void mo882a(GraphRequest graphRequest);
}

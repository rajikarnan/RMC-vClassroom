package com.facebook.p015a;

import com.facebook.AccessToken;
import com.facebook.C0707g;
import com.facebook.p014b.C0689q;
import java.io.Serializable;

/* compiled from: AccessTokenAppIdPair */
/* renamed from: com.facebook.a.a */
class C0598a implements Serializable {
    /* renamed from: a */
    private final String f1022a;
    /* renamed from: b */
    private final String f1023b;

    /* compiled from: AccessTokenAppIdPair */
    /* renamed from: com.facebook.a.a$a */
    static class C0594a implements Serializable {
        /* renamed from: a */
        private final String f1014a;
        /* renamed from: b */
        private final String f1015b;

        private C0594a(String accessTokenString, String appId) {
            this.f1014a = accessTokenString;
            this.f1015b = appId;
        }

        private Object readResolve() {
            return new C0598a(this.f1014a, this.f1015b);
        }
    }

    public C0598a(AccessToken accessToken) {
        this(accessToken.m2385b(), C0707g.m2858i());
    }

    public C0598a(String accessTokenString, String applicationId) {
        if (C0689q.m2782a(accessTokenString)) {
            accessTokenString = null;
        }
        this.f1022a = accessTokenString;
        this.f1023b = applicationId;
    }

    /* renamed from: a */
    public String m2505a() {
        return this.f1022a;
    }

    /* renamed from: b */
    public String m2506b() {
        return this.f1023b;
    }

    public int hashCode() {
        int i = 0;
        int hashCode = this.f1022a == null ? 0 : this.f1022a.hashCode();
        if (this.f1023b != null) {
            i = this.f1023b.hashCode();
        }
        return hashCode ^ i;
    }

    public boolean equals(Object o) {
        if (!(o instanceof C0598a)) {
            return false;
        }
        C0598a p = (C0598a) o;
        if (C0689q.m2781a(p.f1022a, this.f1022a) && C0689q.m2781a(p.f1023b, this.f1023b)) {
            return true;
        }
        return false;
    }

    private Object writeReplace() {
        return new C0594a(this.f1022a, this.f1023b);
    }
}

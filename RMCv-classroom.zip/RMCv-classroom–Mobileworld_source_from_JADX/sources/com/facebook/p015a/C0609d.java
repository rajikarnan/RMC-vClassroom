package com.facebook.p015a;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.C0204h;
import android.util.Log;
import com.facebook.C0707g;
import com.facebook.C0713l;
import com.facebook.C0747o;
import com.facebook.FacebookRequestError;
import com.facebook.GraphRequest;
import com.facebook.GraphRequest.C0578b;
import com.facebook.p014b.C0670l;
import com.facebook.p014b.C0689q;
import com.facebook.p014b.C0689q.C0687b;
import com.facebook.p015a.C0618f.C0615a;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import org.json.JSONArray;
import org.json.JSONException;

/* compiled from: AppEventQueue */
/* renamed from: com.facebook.a.d */
class C0609d {
    /* renamed from: a */
    private static final String f1044a = C0609d.class.getName();
    /* renamed from: b */
    private static volatile C0603c f1045b = new C0603c();
    /* renamed from: c */
    private static final ScheduledExecutorService f1046c = Executors.newSingleThreadScheduledExecutor();
    /* renamed from: d */
    private static ScheduledFuture f1047d;
    /* renamed from: e */
    private static final Runnable f1048e = new C06041();

    /* compiled from: AppEventQueue */
    /* renamed from: com.facebook.a.d$1 */
    static class C06041 implements Runnable {
        C06041() {
        }

        public void run() {
            C0609d.f1047d = null;
            if (C0618f.m2546a() != C0615a.EXPLICIT_ONLY) {
                C0609d.m2532b(C0622h.TIMER);
            }
        }
    }

    C0609d() {
    }

    /* renamed from: a */
    public static void m2529a(final C0622h reason) {
        f1046c.execute(new Runnable() {
            public void run() {
                C0609d.m2532b(reason);
            }
        });
    }

    /* renamed from: a */
    public static void m2528a(final C0598a accessTokenAppId, final C0602b appEvent) {
        f1046c.execute(new Runnable() {
            public void run() {
                C0609d.f1045b.m2519a(accessTokenAppId, appEvent);
                if (C0618f.m2546a() != C0615a.EXPLICIT_ONLY && C0609d.f1045b.m2521b() > 100) {
                    C0609d.m2532b(C0622h.EVENT_THRESHOLD);
                } else if (C0609d.f1047d == null) {
                    C0609d.f1047d = C0609d.f1046c.schedule(C0609d.f1048e, 15, TimeUnit.SECONDS);
                }
            }
        });
    }

    /* renamed from: a */
    public static Set<C0598a> m2525a() {
        return f1045b.m2518a();
    }

    /* renamed from: b */
    static void m2532b(C0622h reason) {
        f1045b.m2520a(C0611e.m2536a());
        try {
            C0624j flushResults = C0609d.m2524a(reason, f1045b);
            if (flushResults != null) {
                Intent intent = new Intent("com.facebook.sdk.APP_EVENTS_FLUSHED");
                intent.putExtra("com.facebook.sdk.APP_EVENTS_NUM_EVENTS_FLUSHED", flushResults.f1101a);
                intent.putExtra("com.facebook.sdk.APP_EVENTS_FLUSH_RESULT", flushResults.f1102b);
                C0204h.m758a(C0707g.m2855f()).m763a(intent);
            }
        } catch (Exception e) {
            Log.w(f1044a, "Caught unexpected exception while flushing app events: ", e);
        }
    }

    /* renamed from: a */
    private static C0624j m2524a(C0622h reason, C0603c appEventCollection) {
        C0624j flushResults = new C0624j();
        boolean limitEventUsage = C0707g.m2850b(C0707g.m2855f());
        List<GraphRequest> requestsToExecute = new ArrayList();
        for (C0598a accessTokenAppId : appEventCollection.m2518a()) {
            GraphRequest request = C0609d.m2523a(accessTokenAppId, appEventCollection.m2517a(accessTokenAppId), limitEventUsage, flushResults);
            if (request != null) {
                requestsToExecute.add(request);
            }
        }
        if (requestsToExecute.size() <= 0) {
            return null;
        }
        C0670l.m2671a(C0747o.APP_EVENTS, f1044a, "Flushing %d events due to %s.", Integer.valueOf(flushResults.f1101a), reason.toString());
        for (GraphRequest request2 : requestsToExecute) {
            request2.m2486i();
        }
        return flushResults;
    }

    /* renamed from: a */
    private static GraphRequest m2523a(final C0598a accessTokenAppId, final C0628l appEvents, boolean limitEventUsage, final C0624j flushState) {
        C0687b fetchedAppSettings = C0689q.m2751a(accessTokenAppId.m2506b(), false);
        final GraphRequest postRequest = GraphRequest.m2435a(null, String.format("%s/activities", new Object[]{applicationId}), null, null);
        Bundle requestParameters = postRequest.m2482e();
        if (requestParameters == null) {
            requestParameters = new Bundle();
        }
        requestParameters.putString("access_token", accessTokenAppId.m2505a());
        String pushNotificationsRegistrationId = C0618f.m2560c();
        if (pushNotificationsRegistrationId != null) {
            requestParameters.putString("device_token", pushNotificationsRegistrationId);
        }
        postRequest.m2473a(requestParameters);
        if (fetchedAppSettings == null) {
            return null;
        }
        int numEvents = appEvents.m2585a(postRequest, C0707g.m2855f(), fetchedAppSettings.m2741a(), limitEventUsage);
        if (numEvents == 0) {
            return null;
        }
        flushState.f1101a += numEvents;
        postRequest.m2474a(new C0578b() {
            /* renamed from: a */
            public void mo848a(C0713l response) {
                C0609d.m2531b(accessTokenAppId, postRequest, response, appEvents, flushState);
            }
        });
        return postRequest;
    }

    /* renamed from: b */
    private static void m2531b(final C0598a accessTokenAppId, GraphRequest request, C0713l response, C0628l appEvents, C0624j flushState) {
        FacebookRequestError error = response.m2890a();
        String resultDescription = "Success";
        C0623i flushResult = C0623i.SUCCESS;
        if (error != null) {
            if (error.m2404b() == -1) {
                resultDescription = "Failed: No Connectivity";
                flushResult = C0623i.NO_CONNECTIVITY;
            } else {
                resultDescription = String.format("Failed:\n  Response: %s\n  Error %s", new Object[]{response.toString(), error.toString()});
                flushResult = C0623i.SERVER_ERROR;
            }
        }
        if (C0707g.m2847a(C0747o.APP_EVENTS)) {
            String prettyPrintedEvents;
            try {
                prettyPrintedEvents = new JSONArray((String) request.m2485h()).toString(2);
            } catch (JSONException e) {
                prettyPrintedEvents = "<Can't encode events for debug logging>";
            }
            C0670l.m2671a(C0747o.APP_EVENTS, f1044a, "Flush completed\nParams: %s\n  Result: %s\n  Events JSON: %s", request.m2472a().toString(), resultDescription, prettyPrintedEvents);
        }
        appEvents.m2587a(error != null);
        if (flushResult == C0623i.NO_CONNECTIVITY) {
            final C0628l c0628l = appEvents;
            C0707g.m2853d().execute(new Runnable() {
                public void run() {
                    C0611e.m2537a(accessTokenAppId, c0628l);
                }
            });
        }
        if (flushResult != C0623i.SUCCESS && flushState.f1102b != C0623i.NO_CONNECTIVITY) {
            flushState.f1102b = flushResult;
        }
    }
}

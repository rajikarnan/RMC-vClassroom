package com.facebook.p015a.p016a;

/* compiled from: Constants */
/* renamed from: com.facebook.a.a.b */
public class C0596b {
    /* renamed from: a */
    public static int m2503a() {
        return 60;
    }
}

package com.facebook.p015a.p016a;

import java.util.UUID;

/* compiled from: SessionInfo */
/* renamed from: com.facebook.a.a.c */
class C0597c {
    /* renamed from: a */
    private UUID f1021a;

    /* renamed from: a */
    public UUID m2504a() {
        return this.f1021a;
    }
}

package com.facebook.p015a.p016a;

import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/* compiled from: ActivityLifecycleTracker */
/* renamed from: com.facebook.a.a.a */
public class C0595a {
    /* renamed from: a */
    private static final String f1016a = C0595a.class.getCanonicalName();
    /* renamed from: b */
    private static final ScheduledExecutorService f1017b = Executors.newSingleThreadScheduledExecutor();
    /* renamed from: c */
    private static AtomicInteger f1018c = new AtomicInteger(0);
    /* renamed from: d */
    private static volatile C0597c f1019d;
    /* renamed from: e */
    private static AtomicBoolean f1020e = new AtomicBoolean(false);

    /* renamed from: a */
    public static boolean m2501a() {
        return f1020e.get();
    }

    /* renamed from: b */
    public static UUID m2502b() {
        return f1019d != null ? f1019d.m2504a() : null;
    }
}

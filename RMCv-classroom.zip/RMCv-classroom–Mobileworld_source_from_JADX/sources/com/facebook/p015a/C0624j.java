package com.facebook.p015a;

/* compiled from: FlushStatistics */
/* renamed from: com.facebook.a.j */
class C0624j {
    /* renamed from: a */
    public int f1101a = 0;
    /* renamed from: b */
    public C0623i f1102b = C0623i.SUCCESS;

    C0624j() {
    }
}

package com.facebook.p015a;

import android.content.Context;
import android.os.Bundle;
import com.facebook.GraphRequest;
import com.facebook.p014b.C0638a;
import com.facebook.p014b.C0638a.C0637a;
import com.facebook.p014b.C0642b;
import com.facebook.p014b.C0689q;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: SessionEventsState */
/* renamed from: com.facebook.a.l */
class C0628l {
    /* renamed from: a */
    private List<C0602b> f1105a = new ArrayList();
    /* renamed from: b */
    private List<C0602b> f1106b = new ArrayList();
    /* renamed from: c */
    private int f1107c;
    /* renamed from: d */
    private C0642b f1108d;
    /* renamed from: e */
    private String f1109e;
    /* renamed from: f */
    private final int f1110f = 1000;

    public C0628l(C0642b identifiers, String anonymousGUID) {
        this.f1108d = identifiers;
        this.f1109e = anonymousGUID;
    }

    /* renamed from: a */
    public synchronized void m2586a(C0602b event) {
        if (this.f1105a.size() + this.f1106b.size() >= 1000) {
            this.f1107c++;
        } else {
            this.f1105a.add(event);
        }
    }

    /* renamed from: a */
    public synchronized int m2584a() {
        return this.f1105a.size();
    }

    /* renamed from: a */
    public synchronized void m2587a(boolean moveToAccumulated) {
        if (moveToAccumulated) {
            this.f1105a.addAll(this.f1106b);
        }
        this.f1106b.clear();
        this.f1107c = 0;
    }

    /* renamed from: a */
    public int m2585a(GraphRequest request, Context applicationContext, boolean includeImplicitEvents, boolean limitEventUsage) {
        synchronized (this) {
            int numSkipped = this.f1107c;
            this.f1106b.addAll(this.f1105a);
            this.f1105a.clear();
            JSONArray jsonArray = new JSONArray();
            for (C0602b event : this.f1106b) {
                if (!event.m2515d()) {
                    C0689q.m2775a("Event with invalid checksum: %s", event.toString());
                } else if (includeImplicitEvents || !event.m2513b()) {
                    jsonArray.put(event.m2514c());
                }
            }
            if (jsonArray.length() == 0) {
                return 0;
            }
            m2582a(request, applicationContext, numSkipped, jsonArray, limitEventUsage);
            return jsonArray.length();
        }
    }

    /* renamed from: b */
    public synchronized List<C0602b> m2588b() {
        List<C0602b> result;
        result = this.f1105a;
        this.f1105a = new ArrayList();
        return result;
    }

    /* renamed from: a */
    private void m2582a(GraphRequest request, Context applicationContext, int numSkipped, JSONArray events, boolean limitEventUsage) {
        JSONObject publishParams;
        try {
            publishParams = C0638a.m2601a(C0637a.CUSTOM_APP_EVENTS, this.f1108d, this.f1109e, limitEventUsage, applicationContext);
            if (this.f1107c > 0) {
                publishParams.put("num_skipped_events", numSkipped);
            }
        } catch (JSONException e) {
            publishParams = new JSONObject();
        }
        request.m2477a(publishParams);
        Bundle requestParameters = request.m2482e();
        if (requestParameters == null) {
            requestParameters = new Bundle();
        }
        Object jsonString = events.toString();
        if (jsonString != null) {
            requestParameters.putByteArray("custom_events_file", m2583a((String) jsonString));
            request.m2476a(jsonString);
        }
        request.m2473a(requestParameters);
    }

    /* renamed from: a */
    private byte[] m2583a(String jsonString) {
        byte[] jsonUtf8 = null;
        try {
            jsonUtf8 = jsonString.getBytes("UTF-8");
        } catch (Exception e) {
            C0689q.m2774a("Encoding exception: ", e);
        }
        return jsonUtf8;
    }
}

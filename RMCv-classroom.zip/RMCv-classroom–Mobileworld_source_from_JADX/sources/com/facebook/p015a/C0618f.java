package com.facebook.p015a;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import com.facebook.AccessToken;
import com.facebook.C0699e;
import com.facebook.C0707g;
import com.facebook.C0747o;
import com.facebook.p014b.C0670l;
import com.facebook.p014b.C0689q;
import com.facebook.p014b.C0690r;
import com.facebook.p015a.p016a.C0595a;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.FileNotFoundException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.json.JSONException;
import p000a.C0000a;

/* compiled from: AppEventsLogger */
/* renamed from: com.facebook.a.f */
public class C0618f {
    /* renamed from: a */
    private static final String f1063a = C0618f.class.getCanonicalName();
    /* renamed from: d */
    private static ScheduledThreadPoolExecutor f1064d;
    /* renamed from: e */
    private static C0615a f1065e = C0615a.AUTO;
    /* renamed from: f */
    private static Object f1066f = new Object();
    /* renamed from: g */
    private static String f1067g;
    /* renamed from: h */
    private static String f1068h;
    /* renamed from: i */
    private static boolean f1069i;
    /* renamed from: j */
    private static boolean f1070j;
    /* renamed from: k */
    private static String f1071k;
    /* renamed from: b */
    private final String f1072b;
    /* renamed from: c */
    private final C0598a f1073c;

    /* compiled from: AppEventsLogger */
    /* renamed from: com.facebook.a.f$3 */
    static class C06143 implements Runnable {
        C06143() {
        }

        public void run() {
            Set<String> applicationIds = new HashSet();
            for (C0598a accessTokenAppId : C0609d.m2525a()) {
                applicationIds.add(accessTokenAppId.m2506b());
            }
            for (String applicationId : applicationIds) {
                C0689q.m2751a(applicationId, true);
            }
        }
    }

    /* compiled from: AppEventsLogger */
    /* renamed from: com.facebook.a.f$a */
    public enum C0615a {
        AUTO,
        EXPLICIT_ONLY
    }

    /* compiled from: AppEventsLogger */
    /* renamed from: com.facebook.a.f$b */
    static class C0617b {
        /* renamed from: a */
        private static final Object f1058a = new Object();
        /* renamed from: b */
        private static boolean f1059b = false;
        /* renamed from: c */
        private static boolean f1060c = false;
        /* renamed from: d */
        private static Map<C0598a, C0621g> f1061d;
        /* renamed from: e */
        private static final Runnable f1062e = new C06161();

        /* compiled from: AppEventsLogger */
        /* renamed from: com.facebook.a.f$b$1 */
        static class C06161 implements Runnable {
            C06161() {
            }

            public void run() {
                C0617b.m2542a(C0707g.m2855f());
            }
        }

        /* renamed from: b */
        private static void m2545b(Context context) {
            Throwable th;
            Exception e;
            Closeable ois = null;
            synchronized (f1058a) {
                if (!f1060c) {
                    try {
                        Closeable ois2 = new ObjectInputStream(context.openFileInput("AppEventsLogger.persistedsessioninfo"));
                        try {
                            f1061d = (HashMap) ois2.readObject();
                            C0670l.m2670a(C0747o.APP_EVENTS, "AppEvents", "App session info loaded");
                            try {
                                C0689q.m2772a(ois2);
                                context.deleteFile("AppEventsLogger.persistedsessioninfo");
                                if (f1061d == null) {
                                    f1061d = new HashMap();
                                }
                                f1060c = true;
                                f1059b = false;
                                ois = ois2;
                            } catch (Throwable th2) {
                                th = th2;
                                ois = ois2;
                                throw th;
                            }
                        } catch (FileNotFoundException e2) {
                            ois = ois2;
                            C0689q.m2772a(ois);
                            context.deleteFile("AppEventsLogger.persistedsessioninfo");
                            if (f1061d == null) {
                                f1061d = new HashMap();
                            }
                            f1060c = true;
                            f1059b = false;
                        } catch (Exception e3) {
                            e = e3;
                            ois = ois2;
                            try {
                                Log.w(C0618f.f1063a, "Got unexpected exception restoring app session info: " + e.toString());
                                C0689q.m2772a(ois);
                                context.deleteFile("AppEventsLogger.persistedsessioninfo");
                                if (f1061d == null) {
                                    f1061d = new HashMap();
                                }
                                f1060c = true;
                                f1059b = false;
                            } catch (Throwable th3) {
                                th = th3;
                                C0689q.m2772a(ois);
                                context.deleteFile("AppEventsLogger.persistedsessioninfo");
                                if (f1061d == null) {
                                    f1061d = new HashMap();
                                }
                                f1060c = true;
                                f1059b = false;
                                throw th;
                            }
                        } catch (Throwable th4) {
                            th = th4;
                            ois = ois2;
                            C0689q.m2772a(ois);
                            context.deleteFile("AppEventsLogger.persistedsessioninfo");
                            if (f1061d == null) {
                                f1061d = new HashMap();
                            }
                            f1060c = true;
                            f1059b = false;
                            throw th;
                        }
                    } catch (FileNotFoundException e4) {
                        C0689q.m2772a(ois);
                        context.deleteFile("AppEventsLogger.persistedsessioninfo");
                        if (f1061d == null) {
                            f1061d = new HashMap();
                        }
                        f1060c = true;
                        f1059b = false;
                    } catch (Exception e5) {
                        e = e5;
                        Log.w(C0618f.f1063a, "Got unexpected exception restoring app session info: " + e.toString());
                        C0689q.m2772a(ois);
                        context.deleteFile("AppEventsLogger.persistedsessioninfo");
                        if (f1061d == null) {
                            f1061d = new HashMap();
                        }
                        f1060c = true;
                        f1059b = false;
                    } catch (Throwable th5) {
                        th = th5;
                        throw th;
                    }
                }
            }
        }

        /* renamed from: a */
        static void m2542a(Context context) {
            Throwable th;
            Exception e;
            Closeable oos = null;
            synchronized (f1058a) {
                try {
                    if (f1059b) {
                        try {
                            Closeable oos2 = new ObjectOutputStream(new BufferedOutputStream(context.openFileOutput("AppEventsLogger.persistedsessioninfo", 0)));
                            try {
                                oos2.writeObject(f1061d);
                                f1059b = false;
                                C0670l.m2670a(C0747o.APP_EVENTS, "AppEvents", "App session info saved");
                                try {
                                    C0689q.m2772a(oos2);
                                    oos = oos2;
                                } catch (Throwable th2) {
                                    th = th2;
                                    oos = oos2;
                                    throw th;
                                }
                            } catch (Exception e2) {
                                e = e2;
                                oos = oos2;
                                try {
                                    Log.w(C0618f.f1063a, "Got unexpected exception while writing app session info: " + e.toString());
                                    C0689q.m2772a(oos);
                                } catch (Throwable th3) {
                                    th = th3;
                                    C0689q.m2772a(oos);
                                    throw th;
                                }
                            } catch (Throwable th4) {
                                th = th4;
                                oos = oos2;
                                C0689q.m2772a(oos);
                                throw th;
                            }
                        } catch (Exception e3) {
                            e = e3;
                            Log.w(C0618f.f1063a, "Got unexpected exception while writing app session info: " + e.toString());
                            C0689q.m2772a(oos);
                        }
                    }
                } catch (Throwable th5) {
                    th = th5;
                    throw th;
                }
            }
        }

        /* renamed from: a */
        static void m2544a(Context context, C0598a accessTokenAppId, C0618f logger, long eventTime, String sourceApplicationInfo) {
            synchronized (f1058a) {
                C0617b.m2540a(context, accessTokenAppId).m2577a(logger, eventTime, sourceApplicationInfo);
                C0617b.m2541a();
            }
        }

        /* renamed from: a */
        static void m2543a(Context context, C0598a accessTokenAppId, C0618f logger, long eventTime) {
            synchronized (f1058a) {
                C0617b.m2540a(context, accessTokenAppId).m2576a(logger, eventTime);
                C0617b.m2541a();
            }
        }

        /* renamed from: a */
        private static C0621g m2540a(Context context, C0598a accessTokenAppId) {
            C0617b.m2545b(context);
            C0621g result = (C0621g) f1061d.get(accessTokenAppId);
            if (result != null) {
                return result;
            }
            result = new C0621g();
            f1061d.put(accessTokenAppId, result);
            return result;
        }

        /* renamed from: a */
        private static void m2541a() {
            if (!f1059b) {
                f1059b = true;
                C0618f.f1064d.schedule(f1062e, 30, TimeUnit.SECONDS);
            }
        }
    }

    @Deprecated
    /* renamed from: a */
    public static void m2550a(Context context) {
        if (C0595a.m2501a()) {
            Log.w(f1063a, "activateApp events are being logged automatically. There's no need to call activateApp explicitly, this is safe to remove.");
            return;
        }
        C0707g.m2843a(context);
        C0618f.m2552a(context, C0689q.m2756a(context));
    }

    @Deprecated
    /* renamed from: a */
    public static void m2552a(Context context, String applicationId) {
        if (C0595a.m2501a()) {
            Log.w(f1063a, "activateApp events are being logged automatically. There's no need to call activateApp explicitly, this is safe to remove.");
        } else if (context == null || applicationId == null) {
            throw new IllegalArgumentException("Both context and applicationId must be non-null");
        } else {
            if (context instanceof Activity) {
                C0618f.m2549a((Activity) context);
            } else {
                C0618f.m2563e();
                Log.d(C0618f.class.getName(), "To set source application the context of activateApp must be an instance of Activity");
            }
            C0707g.m2845a(context, applicationId);
            final C0618f logger = new C0618f(context, applicationId, null);
            final long eventTime = System.currentTimeMillis();
            final String sourceApplicationInfo = C0618f.m2561d();
            f1064d.execute(new Runnable() {
                public void run() {
                    logger.m2548a(eventTime, sourceApplicationInfo);
                }
            });
        }
    }

    @Deprecated
    /* renamed from: b */
    public static void m2556b(Context context) {
        if (C0595a.m2501a()) {
            Log.w(f1063a, "deactivateApp events are being logged automatically. There's no need to call deactivateApp, this is safe to remove.");
        } else {
            C0618f.m2557b(context, C0689q.m2756a(context));
        }
    }

    @Deprecated
    /* renamed from: b */
    public static void m2557b(Context context, String applicationId) {
        if (C0595a.m2501a()) {
            Log.w(f1063a, "deactivateApp events are being logged automatically. There's no need to call deactivateApp, this is safe to remove.");
        } else if (context == null || applicationId == null) {
            throw new IllegalArgumentException("Both context and applicationId must be non-null");
        } else {
            C0618f.m2563e();
            final C0618f logger = new C0618f(context, applicationId, null);
            final long eventTime = System.currentTimeMillis();
            f1064d.execute(new Runnable() {
                public void run() {
                    logger.m2547a(eventTime);
                }
            });
        }
    }

    /* renamed from: a */
    private void m2548a(long eventTime, String sourceApplicationInfo) {
        C0617b.m2544a(C0707g.m2855f(), this.f1073c, this, eventTime, sourceApplicationInfo);
    }

    /* renamed from: a */
    private void m2547a(long eventTime) {
        C0617b.m2543a(C0707g.m2855f(), this.f1073c, this, eventTime);
    }

    /* renamed from: c */
    public static C0618f m2558c(Context context) {
        return new C0618f(context, null, null);
    }

    /* renamed from: c */
    public static C0618f m2559c(Context context, String applicationId) {
        return new C0618f(context, applicationId, null);
    }

    /* renamed from: a */
    public static C0615a m2546a() {
        C0615a c0615a;
        synchronized (f1066f) {
            c0615a = f1065e;
        }
        return c0615a;
    }

    /* renamed from: a */
    public void m2568a(String eventName, Bundle parameters) {
        m2555a(eventName, null, parameters, false, C0595a.m2502b());
    }

    /* renamed from: a */
    public void m2567a(String eventName, double valueToSum, Bundle parameters) {
        m2555a(eventName, Double.valueOf(valueToSum), parameters, false, C0595a.m2502b());
    }

    /* renamed from: b */
    public void m2570b() {
        C0609d.m2529a(C0622h.EXPLICIT);
    }

    /* renamed from: c */
    static String m2560c() {
        String str;
        synchronized (f1066f) {
            str = f1071k;
        }
        return str;
    }

    /* renamed from: a */
    public void m2569a(String eventName, Double valueToSum, Bundle parameters) {
        m2555a(eventName, valueToSum, parameters, true, C0595a.m2502b());
    }

    private C0618f(Context context, String applicationId, AccessToken accessToken) {
        this(C0689q.m2792c(context), applicationId, accessToken);
    }

    protected C0618f(String activityName, String applicationId, AccessToken accessToken) {
        C0690r.m2803a();
        this.f1072b = activityName;
        if (accessToken == null) {
            accessToken = AccessToken.m2378a();
        }
        if (accessToken == null || !(applicationId == null || applicationId.equals(accessToken.m2391h()))) {
            if (applicationId == null) {
                applicationId = C0689q.m2756a(C0707g.m2855f());
            }
            this.f1073c = new C0598a(null, applicationId);
        } else {
            this.f1073c = new C0598a(accessToken);
        }
        C0618f.m2566h();
    }

    /* renamed from: h */
    private static void m2566h() {
        synchronized (f1066f) {
            if (f1064d != null) {
                return;
            }
            f1064d = new ScheduledThreadPoolExecutor(1);
            f1064d.scheduleAtFixedRate(new C06143(), 0, 86400, TimeUnit.SECONDS);
        }
    }

    /* renamed from: a */
    private void m2555a(String eventName, Double valueToSum, Bundle parameters, boolean isImplicitlyLogged, UUID currentSessionId) {
        try {
            C0618f.m2551a(C0707g.m2855f(), new C0602b(this.f1072b, eventName, valueToSum, parameters, isImplicitlyLogged, currentSessionId), this.f1073c);
        } catch (JSONException jsonException) {
            C0670l.m2671a(C0747o.APP_EVENTS, "AppEvents", "JSON encoding for app event failed: '%s'", jsonException.toString());
        } catch (C0699e e) {
            C0670l.m2671a(C0747o.APP_EVENTS, "AppEvents", "Invalid app event: %s", e.toString());
        }
    }

    /* renamed from: a */
    private static void m2551a(Context context, C0602b event, C0598a accessTokenAppId) {
        C0609d.m2528a(accessTokenAppId, event);
        if (!event.m2513b() && !f1070j) {
            if (event.m2512a() == "fb_mobile_activate_app") {
                f1070j = true;
            } else {
                C0670l.m2670a(C0747o.APP_EVENTS, "AppEvents", "Warning: Please call AppEventsLogger.activateApp(...)from the long-lived activity's onResume() methodbefore logging other app events.");
            }
        }
    }

    /* renamed from: a */
    private static void m2549a(Activity activity) {
        ComponentName callingApplication = activity.getCallingActivity();
        if (callingApplication != null) {
            String callingApplicationPackage = callingApplication.getPackageName();
            if (callingApplicationPackage.equals(activity.getPackageName())) {
                C0618f.m2563e();
                return;
            }
            f1068h = callingApplicationPackage;
        }
        Intent openIntent = activity.getIntent();
        if (openIntent == null || openIntent.getBooleanExtra("_fbSourceApplicationHasBeenSet", false)) {
            C0618f.m2563e();
            return;
        }
        Bundle applinkData = C0000a.m0a(openIntent);
        if (applinkData == null) {
            C0618f.m2563e();
            return;
        }
        f1069i = true;
        Bundle applinkReferrerData = applinkData.getBundle("referer_app_link");
        if (applinkReferrerData == null) {
            f1068h = null;
            return;
        }
        f1068h = applinkReferrerData.getString("package");
        openIntent.putExtra("_fbSourceApplicationHasBeenSet", true);
    }

    /* renamed from: d */
    static String m2561d() {
        String openType = "Unclassified";
        if (f1069i) {
            openType = "Applink";
        }
        if (f1068h != null) {
            return openType + "(" + f1068h + ")";
        }
        return openType;
    }

    /* renamed from: e */
    static void m2563e() {
        f1068h = null;
        f1069i = false;
    }

    /* renamed from: d */
    public static String m2562d(Context context) {
        if (f1067g == null) {
            synchronized (f1066f) {
                if (f1067g == null) {
                    f1067g = context.getSharedPreferences("com.facebook.sdk.appEventPreferences", 0).getString("anonymousAppDeviceGUID", null);
                    if (f1067g == null) {
                        f1067g = "XZ" + UUID.randomUUID().toString();
                        context.getSharedPreferences("com.facebook.sdk.appEventPreferences", 0).edit().putString("anonymousAppDeviceGUID", f1067g).apply();
                    }
                }
            }
        }
        return f1067g;
    }
}

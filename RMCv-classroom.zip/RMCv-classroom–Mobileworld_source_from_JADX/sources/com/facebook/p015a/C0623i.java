package com.facebook.p015a;

/* compiled from: FlushResult */
/* renamed from: com.facebook.a.i */
public enum C0623i {
    SUCCESS,
    SERVER_ERROR,
    NO_CONNECTIVITY,
    UNKNOWN_ERROR
}

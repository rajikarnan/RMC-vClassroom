package com.facebook.p015a;

/* compiled from: FlushReason */
/* renamed from: com.facebook.a.h */
enum C0622h {
    EXPLICIT,
    TIMER,
    SESSION_CHANGE,
    PERSISTED_EVENTS,
    EVENT_THRESHOLD,
    EAGER_FLUSHING_EVENT
}

package com.facebook.p015a;

import android.os.Bundle;
import com.facebook.C0699e;
import com.facebook.C0747o;
import com.facebook.p014b.C0670l;
import com.facebook.p014b.C0689q;
import java.io.Serializable;
import java.security.MessageDigest;
import java.util.HashSet;
import java.util.Locale;
import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: AppEvent */
/* renamed from: com.facebook.a.b */
class C0602b implements Serializable {
    /* renamed from: a */
    private static final HashSet<String> f1029a = new HashSet();
    /* renamed from: b */
    private final JSONObject f1030b;
    /* renamed from: c */
    private final boolean f1031c;
    /* renamed from: d */
    private final String f1032d;
    /* renamed from: e */
    private final String f1033e;

    /* compiled from: AppEvent */
    /* renamed from: com.facebook.a.b$a */
    static class C0600a implements Serializable {
        /* renamed from: a */
        private final String f1024a;
        /* renamed from: b */
        private final boolean f1025b;

        private Object readResolve() throws JSONException {
            return new C0602b(this.f1024a, this.f1025b, null);
        }
    }

    /* compiled from: AppEvent */
    /* renamed from: com.facebook.a.b$b */
    static class C0601b implements Serializable {
        /* renamed from: a */
        private final String f1026a;
        /* renamed from: b */
        private final boolean f1027b;
        /* renamed from: c */
        private final String f1028c;

        private C0601b(String jsonString, boolean isImplicit, String checksum) {
            this.f1026a = jsonString;
            this.f1027b = isImplicit;
            this.f1028c = checksum;
        }

        private Object readResolve() throws JSONException {
            return new C0602b(this.f1026a, this.f1027b, this.f1028c);
        }
    }

    public C0602b(String contextName, String eventName, Double valueToSum, Bundle parameters, boolean isImplicitlyLogged, UUID currentSessionId) throws JSONException, C0699e {
        this.f1030b = C0602b.m2508a(contextName, eventName, valueToSum, parameters, isImplicitlyLogged, currentSessionId);
        this.f1031c = isImplicitlyLogged;
        this.f1032d = eventName;
        this.f1033e = m2511e();
    }

    /* renamed from: a */
    public String m2512a() {
        return this.f1032d;
    }

    private C0602b(String jsonString, boolean isImplicit, String checksum) throws JSONException {
        this.f1030b = new JSONObject(jsonString);
        this.f1031c = isImplicit;
        this.f1032d = this.f1030b.optString("_eventName");
        this.f1033e = checksum;
    }

    /* renamed from: b */
    public boolean m2513b() {
        return this.f1031c;
    }

    /* renamed from: c */
    public JSONObject m2514c() {
        return this.f1030b;
    }

    /* renamed from: d */
    public boolean m2515d() {
        if (this.f1033e == null) {
            return true;
        }
        return m2511e().equals(this.f1033e);
    }

    /* renamed from: a */
    private static void m2509a(String identifier) throws C0699e {
        String regex = "^[0-9a-zA-Z_]+[0-9a-zA-Z _-]*$";
        if (identifier == null || identifier.length() == 0 || identifier.length() > 40) {
            if (identifier == null) {
                identifier = "<None Provided>";
            }
            throw new C0699e(String.format(Locale.ROOT, "Identifier '%s' must be less than %d characters", new Object[]{identifier, Integer.valueOf(40)}));
        }
        synchronized (f1029a) {
            boolean alreadyValidated = f1029a.contains(identifier);
        }
        if (!alreadyValidated) {
            if (identifier.matches("^[0-9a-zA-Z_]+[0-9a-zA-Z _-]*$")) {
                synchronized (f1029a) {
                    f1029a.add(identifier);
                }
                return;
            }
            throw new C0699e(String.format("Skipping event named '%s' due to illegal name - must be under 40 chars and alphanumeric, _, - or space, and not start with a space or hyphen.", new Object[]{identifier}));
        }
    }

    /* renamed from: a */
    private static JSONObject m2508a(String contextName, String eventName, Double valueToSum, Bundle parameters, boolean isImplicitlyLogged, UUID currentSessionId) throws C0699e, JSONException {
        C0602b.m2509a(eventName);
        JSONObject eventObject = new JSONObject();
        eventObject.put("_eventName", eventName);
        eventObject.put("_logTime", System.currentTimeMillis() / 1000);
        eventObject.put("_ui", contextName);
        if (currentSessionId != null) {
            eventObject.put("_session_id", currentSessionId);
        }
        if (valueToSum != null) {
            eventObject.put("_valueToSum", valueToSum.doubleValue());
        }
        if (isImplicitlyLogged) {
            eventObject.put("_implicitlyLogged", "1");
        }
        if (parameters != null) {
            for (String key : parameters.keySet()) {
                C0602b.m2509a(key);
                Object value = parameters.get(key);
                if ((value instanceof String) || (value instanceof Number)) {
                    eventObject.put(key, value.toString());
                } else {
                    throw new C0699e(String.format("Parameter value '%s' for key '%s' should be a string or a numeric type.", new Object[]{value, key}));
                }
            }
        }
        if (!isImplicitlyLogged) {
            C0670l.m2671a(C0747o.APP_EVENTS, "AppEvents", "Created app event '%s'", eventObject.toString());
        }
        return eventObject;
    }

    private Object writeReplace() {
        return new C0601b(this.f1030b.toString(), this.f1031c, this.f1033e);
    }

    public String toString() {
        return String.format("\"%s\", implicit: %b, json: %s", new Object[]{this.f1030b.optString("_eventName"), Boolean.valueOf(this.f1031c), this.f1030b.toString()});
    }

    /* renamed from: e */
    private String m2511e() {
        return C0602b.m2510b(this.f1030b.toString());
    }

    /* renamed from: b */
    private static String m2510b(String toHash) {
        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            byte[] bytes = toHash.getBytes("UTF-8");
            digest.update(bytes, 0, bytes.length);
            return C0602b.m2507a(digest.digest());
        } catch (Exception e) {
            C0689q.m2774a("Failed to generate checksum: ", e);
            return "0";
        } catch (Exception e2) {
            C0689q.m2774a("Failed to generate checksum: ", e2);
            return "1";
        }
    }

    /* renamed from: a */
    private static String m2507a(byte[] bytes) {
        StringBuffer sb = new StringBuffer();
        int length = bytes.length;
        for (int i = 0; i < length; i++) {
            sb.append(String.format("%02x", new Object[]{Byte.valueOf(bytes[i])}));
        }
        return sb.toString();
    }
}

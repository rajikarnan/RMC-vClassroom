package com.facebook.p015a;

import android.content.Context;
import android.util.Log;
import com.facebook.C0707g;
import com.facebook.p014b.C0689q;
import com.facebook.p015a.C0598a.C0594a;
import com.facebook.p015a.C0602b.C0600a;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamClass;

/* compiled from: AppEventStore */
/* renamed from: com.facebook.a.e */
class C0611e {
    /* renamed from: a */
    private static final String f1049a = C0611e.class.getName();

    /* compiled from: AppEventStore */
    /* renamed from: com.facebook.a.e$a */
    private static class C0610a extends ObjectInputStream {
        public C0610a(InputStream in) throws IOException {
            super(in);
        }

        protected ObjectStreamClass readClassDescriptor() throws IOException, ClassNotFoundException {
            ObjectStreamClass resultClassDescriptor = super.readClassDescriptor();
            if (resultClassDescriptor.getName().equals("com.facebook.appevents.AppEventsLogger$AccessTokenAppIdPair$SerializationProxyV1")) {
                return ObjectStreamClass.lookup(C0594a.class);
            }
            if (resultClassDescriptor.getName().equals("com.facebook.appevents.AppEventsLogger$AppEvent$SerializationProxyV1")) {
                return ObjectStreamClass.lookup(C0600a.class);
            }
            return resultClassDescriptor;
        }
    }

    C0611e() {
    }

    /* renamed from: a */
    public static synchronized void m2537a(C0598a accessTokenAppIdPair, C0628l appEvents) {
        synchronized (C0611e.class) {
            C0611e.m2539b();
            C0627k persistedEvents = C0611e.m2536a();
            if (persistedEvents.m2581b(accessTokenAppIdPair)) {
                persistedEvents.m2578a(accessTokenAppIdPair).addAll(appEvents.m2588b());
            } else {
                persistedEvents.m2580a(accessTokenAppIdPair, appEvents.m2588b());
            }
            C0611e.m2538a(persistedEvents);
        }
    }

    /* renamed from: a */
    public static synchronized C0627k m2536a() {
        C0627k persistedEvents;
        Exception e;
        Throwable th;
        synchronized (C0611e.class) {
            C0611e.m2539b();
            Closeable ois = null;
            persistedEvents = null;
            Context context = C0707g.m2855f();
            try {
                Closeable ois2 = new C0610a(new BufferedInputStream(context.openFileInput("AppEventsLogger.persistedevents")));
                try {
                    persistedEvents = (C0627k) ois2.readObject();
                    C0689q.m2772a(ois2);
                    try {
                        context.getFileStreamPath("AppEventsLogger.persistedevents").delete();
                        ois = ois2;
                    } catch (Exception ex) {
                        Log.w(f1049a, "Got unexpected exception when removing events file: ", ex);
                        ois = ois2;
                    }
                } catch (FileNotFoundException e2) {
                    ois = ois2;
                    C0689q.m2772a(ois);
                    try {
                        context.getFileStreamPath("AppEventsLogger.persistedevents").delete();
                    } catch (Exception ex2) {
                        Log.w(f1049a, "Got unexpected exception when removing events file: ", ex2);
                    }
                    if (persistedEvents == null) {
                        persistedEvents = new C0627k();
                    }
                    return persistedEvents;
                } catch (Exception e3) {
                    e = e3;
                    ois = ois2;
                    try {
                        Log.w(f1049a, "Got unexpected exception while reading events: ", e);
                        C0689q.m2772a(ois);
                        try {
                            context.getFileStreamPath("AppEventsLogger.persistedevents").delete();
                        } catch (Exception ex22) {
                            Log.w(f1049a, "Got unexpected exception when removing events file: ", ex22);
                        }
                        if (persistedEvents == null) {
                            persistedEvents = new C0627k();
                        }
                        return persistedEvents;
                    } catch (Throwable th2) {
                        th = th2;
                        C0689q.m2772a(ois);
                        try {
                            context.getFileStreamPath("AppEventsLogger.persistedevents").delete();
                        } catch (Exception ex222) {
                            Log.w(f1049a, "Got unexpected exception when removing events file: ", ex222);
                        }
                        throw th;
                    }
                } catch (Throwable th3) {
                    th = th3;
                    ois = ois2;
                    C0689q.m2772a(ois);
                    context.getFileStreamPath("AppEventsLogger.persistedevents").delete();
                    throw th;
                }
            } catch (FileNotFoundException e4) {
                C0689q.m2772a(ois);
                context.getFileStreamPath("AppEventsLogger.persistedevents").delete();
                if (persistedEvents == null) {
                    persistedEvents = new C0627k();
                }
                return persistedEvents;
            } catch (Exception e5) {
                e = e5;
                Log.w(f1049a, "Got unexpected exception while reading events: ", e);
                C0689q.m2772a(ois);
                context.getFileStreamPath("AppEventsLogger.persistedevents").delete();
                if (persistedEvents == null) {
                    persistedEvents = new C0627k();
                }
                return persistedEvents;
            }
            if (persistedEvents == null) {
                persistedEvents = new C0627k();
            }
        }
        return persistedEvents;
    }

    /* renamed from: a */
    private static void m2538a(C0627k eventsToPersist) {
        Exception e;
        Throwable th;
        Closeable oos = null;
        Context context = C0707g.m2855f();
        try {
            Closeable oos2 = new ObjectOutputStream(new BufferedOutputStream(context.openFileOutput("AppEventsLogger.persistedevents", 0)));
            try {
                oos2.writeObject(eventsToPersist);
                C0689q.m2772a(oos2);
                oos = oos2;
            } catch (Exception e2) {
                e = e2;
                oos = oos2;
                try {
                    Log.w(f1049a, "Got unexpected exception while persisting events: ", e);
                    try {
                        context.getFileStreamPath("AppEventsLogger.persistedevents").delete();
                    } catch (Exception e3) {
                    }
                    C0689q.m2772a(oos);
                } catch (Throwable th2) {
                    th = th2;
                    C0689q.m2772a(oos);
                    throw th;
                }
            } catch (Throwable th3) {
                th = th3;
                oos = oos2;
                C0689q.m2772a(oos);
                throw th;
            }
        } catch (Exception e4) {
            e = e4;
            Log.w(f1049a, "Got unexpected exception while persisting events: ", e);
            context.getFileStreamPath("AppEventsLogger.persistedevents").delete();
            C0689q.m2772a(oos);
        }
    }

    /* renamed from: b */
    private static void m2539b() {
    }
}

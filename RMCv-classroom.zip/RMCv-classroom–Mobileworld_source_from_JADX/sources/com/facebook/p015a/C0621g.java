package com.facebook.p015a;

import android.os.Bundle;
import com.facebook.C0747o;
import com.facebook.p014b.C0670l;
import java.io.Serializable;
import java.util.Locale;

/* compiled from: FacebookTimeSpentData */
/* renamed from: com.facebook.a.g */
class C0621g implements Serializable {
    /* renamed from: a */
    private static final String f1079a = C0621g.class.getCanonicalName();
    /* renamed from: b */
    private static final long[] f1080b = new long[]{300000, 900000, 1800000, 3600000, 21600000, 43200000, 86400000, 172800000, 259200000, 604800000, 1209600000, 1814400000, 2419200000L, 5184000000L, 7776000000L, 10368000000L, 12960000000L, 15552000000L, 31536000000L};
    /* renamed from: c */
    private boolean f1081c;
    /* renamed from: d */
    private boolean f1082d;
    /* renamed from: e */
    private long f1083e;
    /* renamed from: f */
    private long f1084f;
    /* renamed from: g */
    private long f1085g;
    /* renamed from: h */
    private long f1086h;
    /* renamed from: i */
    private int f1087i;
    /* renamed from: j */
    private String f1088j;

    /* compiled from: FacebookTimeSpentData */
    /* renamed from: com.facebook.a.g$a */
    private static class C0620a implements Serializable {
        /* renamed from: a */
        private final long f1074a;
        /* renamed from: b */
        private final long f1075b;
        /* renamed from: c */
        private final long f1076c;
        /* renamed from: d */
        private final int f1077d;
        /* renamed from: e */
        private final String f1078e;

        C0620a(long lastResumeTime, long lastSuspendTime, long millisecondsSpentInSession, int interruptionCount, String firstOpenSourceApplication) {
            this.f1074a = lastResumeTime;
            this.f1075b = lastSuspendTime;
            this.f1076c = millisecondsSpentInSession;
            this.f1077d = interruptionCount;
            this.f1078e = firstOpenSourceApplication;
        }

        private Object readResolve() {
            return new C0621g(this.f1074a, this.f1075b, this.f1076c, this.f1077d, this.f1078e);
        }
    }

    C0621g() {
        m2572a();
    }

    private C0621g(long lastResumeTime, long lastSuspendTime, long millisecondsSpentInSession, int interruptionCount, String firstOpenSourceApplication) {
        m2572a();
        this.f1084f = lastResumeTime;
        this.f1085g = lastSuspendTime;
        this.f1086h = millisecondsSpentInSession;
        this.f1087i = interruptionCount;
        this.f1088j = firstOpenSourceApplication;
    }

    private Object writeReplace() {
        return new C0620a(this.f1084f, this.f1085g, this.f1086h, this.f1087i, this.f1088j);
    }

    /* renamed from: a */
    void m2576a(C0618f logger, long eventTime) {
        if (this.f1082d) {
            long now = eventTime;
            long delta = now - this.f1084f;
            if (delta < 0) {
                C0670l.m2670a(C0747o.APP_EVENTS, f1079a, "Clock skew detected");
                delta = 0;
            }
            this.f1086h += delta;
            this.f1085g = now;
            this.f1082d = false;
            return;
        }
        C0670l.m2670a(C0747o.APP_EVENTS, f1079a, "Suspend for inactive app");
    }

    /* renamed from: a */
    void m2577a(C0618f logger, long eventTime, String sourceApplicationInfo) {
        long now = eventTime;
        if (m2575c() || now - this.f1083e > 300000) {
            Bundle eventParams = new Bundle();
            eventParams.putString("fb_mobile_launch_source", sourceApplicationInfo);
            logger.m2568a("fb_mobile_activate_app", eventParams);
            this.f1083e = now;
        }
        if (this.f1082d) {
            C0670l.m2670a(C0747o.APP_EVENTS, f1079a, "Resume for active app");
            return;
        }
        long interruptionDurationMillis = m2574b() ? now - this.f1085g : 0;
        if (interruptionDurationMillis < 0) {
            C0670l.m2670a(C0747o.APP_EVENTS, f1079a, "Clock skew detected");
            interruptionDurationMillis = 0;
        }
        if (interruptionDurationMillis > 60000) {
            m2573b(logger, interruptionDurationMillis);
        } else if (interruptionDurationMillis > 1000) {
            this.f1087i++;
        }
        if (this.f1087i == 0) {
            this.f1088j = sourceApplicationInfo;
        }
        this.f1084f = now;
        this.f1082d = true;
    }

    /* renamed from: b */
    private void m2573b(C0618f logger, long interruptionDurationMillis) {
        Bundle eventParams = new Bundle();
        eventParams.putInt("fb_mobile_app_interruptions", this.f1087i);
        eventParams.putString("fb_mobile_time_between_sessions", String.format(Locale.ROOT, "session_quanta_%d", new Object[]{Integer.valueOf(C0621g.m2571a(interruptionDurationMillis))}));
        eventParams.putString("fb_mobile_launch_source", this.f1088j);
        logger.m2567a("fb_mobile_deactivate_app", (double) (this.f1086h / 1000), eventParams);
        m2572a();
    }

    /* renamed from: a */
    private static int m2571a(long timeBetweenSessions) {
        int quantaIndex = 0;
        while (quantaIndex < f1080b.length && f1080b[quantaIndex] < timeBetweenSessions) {
            quantaIndex++;
        }
        return quantaIndex;
    }

    /* renamed from: a */
    private void m2572a() {
        this.f1082d = false;
        this.f1084f = -1;
        this.f1085g = -1;
        this.f1087i = 0;
        this.f1086h = 0;
    }

    /* renamed from: b */
    private boolean m2574b() {
        return this.f1085g != -1;
    }

    /* renamed from: c */
    private boolean m2575c() {
        boolean result = !this.f1081c;
        this.f1081c = true;
        return result;
    }
}

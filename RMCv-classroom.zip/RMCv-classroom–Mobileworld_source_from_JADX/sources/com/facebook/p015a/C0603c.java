package com.facebook.p015a;

import android.content.Context;
import com.facebook.C0707g;
import com.facebook.p014b.C0642b;
import java.util.HashMap;
import java.util.Set;

/* compiled from: AppEventCollection */
/* renamed from: com.facebook.a.c */
class C0603c {
    /* renamed from: a */
    private final HashMap<C0598a, C0628l> f1034a = new HashMap();

    /* renamed from: a */
    public synchronized void m2520a(C0627k persistedEvents) {
        if (persistedEvents != null) {
            for (C0598a accessTokenAppIdPair : persistedEvents.m2579a()) {
                C0628l sessionEventsState = m2516b(accessTokenAppIdPair);
                for (C0602b appEvent : persistedEvents.m2578a(accessTokenAppIdPair)) {
                    sessionEventsState.m2586a(appEvent);
                }
            }
        }
    }

    /* renamed from: a */
    public synchronized void m2519a(C0598a accessTokenAppIdPair, C0602b appEvent) {
        m2516b(accessTokenAppIdPair).m2586a(appEvent);
    }

    /* renamed from: a */
    public synchronized Set<C0598a> m2518a() {
        return this.f1034a.keySet();
    }

    /* renamed from: a */
    public synchronized C0628l m2517a(C0598a accessTokenAppIdPair) {
        return (C0628l) this.f1034a.get(accessTokenAppIdPair);
    }

    /* renamed from: b */
    public synchronized int m2521b() {
        int count;
        count = 0;
        for (C0628l sessionEventsState : this.f1034a.values()) {
            count += sessionEventsState.m2584a();
        }
        return count;
    }

    /* renamed from: b */
    private synchronized C0628l m2516b(C0598a accessTokenAppId) {
        C0628l eventsState;
        eventsState = (C0628l) this.f1034a.get(accessTokenAppId);
        if (eventsState == null) {
            Context context = C0707g.m2855f();
            eventsState = new C0628l(C0642b.m2605a(context), C0618f.m2562d(context));
        }
        this.f1034a.put(accessTokenAppId, eventsState);
        return eventsState;
    }
}

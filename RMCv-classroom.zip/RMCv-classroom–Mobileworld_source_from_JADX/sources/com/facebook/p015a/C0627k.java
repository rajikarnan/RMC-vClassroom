package com.facebook.p015a;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

/* compiled from: PersistedEvents */
/* renamed from: com.facebook.a.k */
class C0627k implements Serializable {
    /* renamed from: a */
    private HashMap<C0598a, List<C0602b>> f1104a = new HashMap();

    /* compiled from: PersistedEvents */
    /* renamed from: com.facebook.a.k$a */
    static class C0626a implements Serializable {
        /* renamed from: a */
        private final HashMap<C0598a, List<C0602b>> f1103a;

        private C0626a(HashMap<C0598a, List<C0602b>> events) {
            this.f1103a = events;
        }

        private Object readResolve() {
            return new C0627k(this.f1103a);
        }
    }

    public C0627k(HashMap<C0598a, List<C0602b>> appEventMap) {
        this.f1104a.putAll(appEventMap);
    }

    /* renamed from: a */
    public Set<C0598a> m2579a() {
        return this.f1104a.keySet();
    }

    /* renamed from: a */
    public List<C0602b> m2578a(C0598a accessTokenAppIdPair) {
        return (List) this.f1104a.get(accessTokenAppIdPair);
    }

    /* renamed from: b */
    public boolean m2581b(C0598a accessTokenAppIdPair) {
        return this.f1104a.containsKey(accessTokenAppIdPair);
    }

    /* renamed from: a */
    public void m2580a(C0598a accessTokenAppIdPair, List<C0602b> appEvents) {
        if (this.f1104a.containsKey(accessTokenAppIdPair)) {
            ((List) this.f1104a.get(accessTokenAppIdPair)).addAll(appEvents);
        } else {
            this.f1104a.put(accessTokenAppIdPair, appEvents);
        }
    }

    private Object writeReplace() {
        return new C0626a(this.f1104a);
    }
}

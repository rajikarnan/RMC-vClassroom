package com.facebook;

import android.os.Handler;
import com.facebook.GraphRequest.C0578b;
import com.facebook.GraphRequest.C0587e;

/* compiled from: RequestProgress */
/* renamed from: com.facebook.v */
class C0779v {
    /* renamed from: a */
    private final GraphRequest f1482a;
    /* renamed from: b */
    private final Handler f1483b;
    /* renamed from: c */
    private final long f1484c = C0707g.m2857h();
    /* renamed from: d */
    private long f1485d;
    /* renamed from: e */
    private long f1486e;
    /* renamed from: f */
    private long f1487f;

    C0779v(Handler callbackHandler, GraphRequest request) {
        this.f1482a = request;
        this.f1483b = callbackHandler;
    }

    /* renamed from: a */
    void m3172a(long size) {
        this.f1485d += size;
        if (this.f1485d >= this.f1486e + this.f1484c || this.f1485d >= this.f1487f) {
            m3171a();
        }
    }

    /* renamed from: b */
    void m3173b(long size) {
        this.f1487f += size;
    }

    /* renamed from: a */
    void m3171a() {
        if (this.f1485d > this.f1486e) {
            C0578b callback = this.f1482a.m2484g();
            if (this.f1487f > 0 && (callback instanceof C0587e)) {
                final long currentCopy = this.f1485d;
                final long maxProgressCopy = this.f1487f;
                final C0587e callbackCopy = (C0587e) callback;
                if (this.f1483b == null) {
                    callbackCopy.m2421a(currentCopy, maxProgressCopy);
                } else {
                    this.f1483b.post(new Runnable(this) {
                        /* renamed from: d */
                        final /* synthetic */ C0779v f1481d;

                        public void run() {
                            callbackCopy.m2421a(currentCopy, maxProgressCopy);
                        }
                    });
                }
                this.f1486e = this.f1485d;
            }
        }
    }
}

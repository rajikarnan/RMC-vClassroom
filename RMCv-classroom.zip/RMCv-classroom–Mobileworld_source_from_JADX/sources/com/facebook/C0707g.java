package com.facebook;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.AsyncTask;
import android.support.v4.app.ag;
import com.facebook.p014b.C0643c;
import com.facebook.p014b.C0669k;
import com.facebook.p014b.C0677m;
import com.facebook.p014b.C0689q;
import com.facebook.p014b.C0690r;
import com.facebook.p015a.C0618f;
import java.io.File;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.FutureTask;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/* compiled from: FacebookSdk */
/* renamed from: com.facebook.g */
public final class C0707g {
    /* renamed from: a */
    private static final String f1281a = C0707g.class.getCanonicalName();
    /* renamed from: b */
    private static final HashSet<C0747o> f1282b = new HashSet(Arrays.asList(new C0747o[]{C0747o.DEVELOPER_ERRORS}));
    /* renamed from: c */
    private static volatile Executor f1283c;
    /* renamed from: d */
    private static volatile String f1284d;
    /* renamed from: e */
    private static volatile String f1285e;
    /* renamed from: f */
    private static volatile String f1286f;
    /* renamed from: g */
    private static volatile int f1287g;
    /* renamed from: h */
    private static volatile String f1288h = "facebook.com";
    /* renamed from: i */
    private static AtomicLong f1289i = new AtomicLong(65536);
    /* renamed from: j */
    private static volatile boolean f1290j = false;
    /* renamed from: k */
    private static boolean f1291k = false;
    /* renamed from: l */
    private static C0669k<File> f1292l;
    /* renamed from: m */
    private static Context f1293m;
    /* renamed from: n */
    private static int f1294n = 64206;
    /* renamed from: o */
    private static final Object f1295o = new Object();
    /* renamed from: p */
    private static final BlockingQueue<Runnable> f1296p = new LinkedBlockingQueue(10);
    /* renamed from: q */
    private static final ThreadFactory f1297q = new C07021();
    /* renamed from: r */
    private static Boolean f1298r = Boolean.valueOf(false);

    /* compiled from: FacebookSdk */
    /* renamed from: com.facebook.g$1 */
    static class C07021 implements ThreadFactory {
        /* renamed from: a */
        private final AtomicInteger f1276a = new AtomicInteger(0);

        C07021() {
        }

        public Thread newThread(Runnable runnable) {
            return new Thread(runnable, "FacebookSdk #" + this.f1276a.incrementAndGet());
        }
    }

    /* compiled from: FacebookSdk */
    /* renamed from: com.facebook.g$2 */
    static class C07032 implements Callable<File> {
        C07032() {
        }

        public /* synthetic */ Object call() throws Exception {
            return m2839a();
        }

        /* renamed from: a */
        public File m2839a() throws Exception {
            return C0707g.f1293m.getCacheDir();
        }
    }

    /* compiled from: FacebookSdk */
    /* renamed from: com.facebook.g$a */
    public interface C0706a {
        /* renamed from: a */
        void m2841a();
    }

    /* renamed from: a */
    public static synchronized void m2843a(Context applicationContext) {
        synchronized (C0707g.class) {
            C0707g.m2844a(applicationContext, null);
        }
    }

    /* renamed from: a */
    public static synchronized void m2844a(final Context applicationContext, final C0706a callback) {
        synchronized (C0707g.class) {
            if (!f1298r.booleanValue()) {
                C0690r.m2805a((Object) applicationContext, "applicationContext");
                C0690r.m2810b(applicationContext, false);
                C0690r.m2804a(applicationContext, false);
                f1293m = applicationContext.getApplicationContext();
                C0707g.m2851c(f1293m);
                f1298r = Boolean.valueOf(true);
                C0689q.m2768a(f1293m, f1284d);
                C0677m.m2714b();
                C0643c.m2615a(f1293m);
                f1292l = new C0669k(new C07032());
                C0707g.m2853d().execute(new FutureTask(new Callable<Void>() {
                    public /* synthetic */ Object call() throws Exception {
                        return m2840a();
                    }

                    /* renamed from: a */
                    public Void m2840a() throws Exception {
                        C0697b.m2823a().m2834c();
                        C0749q.m3086a().m3091c();
                        if (AccessToken.m2378a() != null && Profile.m2496a() == null) {
                            Profile.m2498b();
                        }
                        if (callback != null) {
                            callback.m2841a();
                        }
                        C0618f.m2558c(applicationContext.getApplicationContext()).m2570b();
                        return null;
                    }
                }));
            } else if (callback != null) {
                callback.m2841a();
            }
        }
    }

    /* renamed from: a */
    public static synchronized boolean m2846a() {
        boolean booleanValue;
        synchronized (C0707g.class) {
            booleanValue = f1298r.booleanValue();
        }
        return booleanValue;
    }

    /* renamed from: a */
    public static boolean m2847a(C0747o behavior) {
        boolean z;
        synchronized (f1282b) {
            z = C0707g.m2849b() && f1282b.contains(behavior);
        }
        return z;
    }

    /* renamed from: b */
    public static boolean m2849b() {
        return f1290j;
    }

    /* renamed from: c */
    public static boolean m2852c() {
        return f1291k;
    }

    /* renamed from: d */
    public static Executor m2853d() {
        synchronized (f1295o) {
            if (f1283c == null) {
                f1283c = AsyncTask.THREAD_POOL_EXECUTOR;
            }
        }
        return f1283c;
    }

    /* renamed from: e */
    public static String m2854e() {
        return f1288h;
    }

    /* renamed from: f */
    public static Context m2855f() {
        C0690r.m2803a();
        return f1293m;
    }

    /* renamed from: a */
    public static void m2845a(Context context, final String applicationId) {
        final Context applicationContext = context.getApplicationContext();
        C0707g.m2853d().execute(new Runnable() {
            public void run() {
                C0707g.m2848b(applicationContext, applicationId);
            }
        });
    }

    /* renamed from: b */
    static com.facebook.C0713l m2848b(android.content.Context r24, java.lang.String r25) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Exception block dominator not found, method:com.facebook.g.b(android.content.Context, java.lang.String):com.facebook.l. bs: [B:2:0x0004, B:10:0x0079]
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:86)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1782580546.run(Unknown Source)
*/
        /*
        if (r24 == 0) goto L_0x0004;
    L_0x0002:
        if (r25 != 0) goto L_0x0029;
    L_0x0004:
        r19 = new java.lang.IllegalArgumentException;	 Catch:{ Exception -> 0x000c }
        r20 = "Both context and applicationId must be non-null";	 Catch:{ Exception -> 0x000c }
        r19.<init>(r20);	 Catch:{ Exception -> 0x000c }
        throw r19;	 Catch:{ Exception -> 0x000c }
    L_0x000c:
        r4 = move-exception;
        r19 = "Facebook-publish";
        r0 = r19;
        com.facebook.p014b.C0689q.m2774a(r0, r4);
        r19 = new com.facebook.l;
        r20 = 0;
        r21 = 0;
        r22 = new com.facebook.FacebookRequestError;
        r23 = 0;
        r0 = r22;
        r1 = r23;
        r0.<init>(r1, r4);
        r19.<init>(r20, r21, r22);
    L_0x0028:
        return r19;
    L_0x0029:
        r8 = com.facebook.p014b.C0642b.m2605a(r24);	 Catch:{ Exception -> 0x000c }
        r19 = "com.facebook.sdk.attributionTracking";	 Catch:{ Exception -> 0x000c }
        r20 = 0;	 Catch:{ Exception -> 0x000c }
        r0 = r24;	 Catch:{ Exception -> 0x000c }
        r1 = r19;	 Catch:{ Exception -> 0x000c }
        r2 = r20;	 Catch:{ Exception -> 0x000c }
        r14 = r0.getSharedPreferences(r1, r2);	 Catch:{ Exception -> 0x000c }
        r19 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x000c }
        r19.<init>();	 Catch:{ Exception -> 0x000c }
        r0 = r19;	 Catch:{ Exception -> 0x000c }
        r1 = r25;	 Catch:{ Exception -> 0x000c }
        r19 = r0.append(r1);	 Catch:{ Exception -> 0x000c }
        r20 = "ping";	 Catch:{ Exception -> 0x000c }
        r19 = r19.append(r20);	 Catch:{ Exception -> 0x000c }
        r13 = r19.toString();	 Catch:{ Exception -> 0x000c }
        r19 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x000c }
        r19.<init>();	 Catch:{ Exception -> 0x000c }
        r0 = r19;	 Catch:{ Exception -> 0x000c }
        r1 = r25;	 Catch:{ Exception -> 0x000c }
        r19 = r0.append(r1);	 Catch:{ Exception -> 0x000c }
        r20 = "json";	 Catch:{ Exception -> 0x000c }
        r19 = r19.append(r20);	 Catch:{ Exception -> 0x000c }
        r9 = r19.toString();	 Catch:{ Exception -> 0x000c }
        r20 = 0;	 Catch:{ Exception -> 0x000c }
        r0 = r20;	 Catch:{ Exception -> 0x000c }
        r10 = r14.getLong(r13, r0);	 Catch:{ Exception -> 0x000c }
        r19 = 0;	 Catch:{ Exception -> 0x000c }
        r0 = r19;	 Catch:{ Exception -> 0x000c }
        r12 = r14.getString(r9, r0);	 Catch:{ Exception -> 0x000c }
        r19 = com.facebook.p014b.C0638a.C0637a.MOBILE_INSTALL_EVENT;	 Catch:{ JSONException -> 0x00e3 }
        r20 = com.facebook.p015a.C0618f.m2562d(r24);	 Catch:{ JSONException -> 0x00e3 }
        r21 = com.facebook.C0707g.m2850b(r24);	 Catch:{ JSONException -> 0x00e3 }
        r0 = r19;	 Catch:{ JSONException -> 0x00e3 }
        r1 = r20;	 Catch:{ JSONException -> 0x00e3 }
        r2 = r21;	 Catch:{ JSONException -> 0x00e3 }
        r3 = r24;	 Catch:{ JSONException -> 0x00e3 }
        r15 = com.facebook.p014b.C0638a.m2601a(r0, r8, r1, r2, r3);	 Catch:{ JSONException -> 0x00e3 }
        r19 = "%s/activities";	 Catch:{ Exception -> 0x000c }
        r20 = 1;	 Catch:{ Exception -> 0x000c }
        r0 = r20;	 Catch:{ Exception -> 0x000c }
        r0 = new java.lang.Object[r0];	 Catch:{ Exception -> 0x000c }
        r20 = r0;	 Catch:{ Exception -> 0x000c }
        r21 = 0;	 Catch:{ Exception -> 0x000c }
        r20[r21] = r25;	 Catch:{ Exception -> 0x000c }
        r18 = java.lang.String.format(r19, r20);	 Catch:{ Exception -> 0x000c }
        r19 = 0;	 Catch:{ Exception -> 0x000c }
        r20 = 0;	 Catch:{ Exception -> 0x000c }
        r0 = r19;	 Catch:{ Exception -> 0x000c }
        r1 = r18;	 Catch:{ Exception -> 0x000c }
        r2 = r20;	 Catch:{ Exception -> 0x000c }
        r16 = com.facebook.GraphRequest.m2435a(r0, r1, r15, r2);	 Catch:{ Exception -> 0x000c }
        r20 = 0;
        r19 = (r10 > r20 ? 1 : (r10 == r20 ? 0 : -1));
        if (r19 == 0) goto L_0x0105;
    L_0x00b5:
        r6 = 0;
        if (r12 == 0) goto L_0x00be;
    L_0x00b8:
        r7 = new org.json.JSONObject;	 Catch:{ JSONException -> 0x012e }
        r7.<init>(r12);	 Catch:{ JSONException -> 0x012e }
        r6 = r7;
    L_0x00be:
        if (r6 != 0) goto L_0x00f0;
    L_0x00c0:
        r19 = "true";	 Catch:{ Exception -> 0x000c }
        r20 = 0;	 Catch:{ Exception -> 0x000c }
        r21 = new com.facebook.k;	 Catch:{ Exception -> 0x000c }
        r22 = 1;	 Catch:{ Exception -> 0x000c }
        r0 = r22;	 Catch:{ Exception -> 0x000c }
        r0 = new com.facebook.GraphRequest[r0];	 Catch:{ Exception -> 0x000c }
        r22 = r0;	 Catch:{ Exception -> 0x000c }
        r23 = 0;	 Catch:{ Exception -> 0x000c }
        r22[r23] = r16;	 Catch:{ Exception -> 0x000c }
        r21.<init>(r22);	 Catch:{ Exception -> 0x000c }
        r19 = com.facebook.C0713l.m2886a(r19, r20, r21);	 Catch:{ Exception -> 0x000c }
        r20 = 0;	 Catch:{ Exception -> 0x000c }
        r19 = r19.get(r20);	 Catch:{ Exception -> 0x000c }
        r19 = (com.facebook.C0713l) r19;	 Catch:{ Exception -> 0x000c }
        goto L_0x0028;	 Catch:{ Exception -> 0x000c }
    L_0x00e3:
        r4 = move-exception;	 Catch:{ Exception -> 0x000c }
        r19 = new com.facebook.e;	 Catch:{ Exception -> 0x000c }
        r20 = "An error occurred while publishing install.";	 Catch:{ Exception -> 0x000c }
        r0 = r19;	 Catch:{ Exception -> 0x000c }
        r1 = r20;	 Catch:{ Exception -> 0x000c }
        r0.<init>(r1, r4);	 Catch:{ Exception -> 0x000c }
        throw r19;	 Catch:{ Exception -> 0x000c }
    L_0x00f0:
        r19 = new com.facebook.l;	 Catch:{ Exception -> 0x000c }
        r20 = 0;	 Catch:{ Exception -> 0x000c }
        r21 = 0;	 Catch:{ Exception -> 0x000c }
        r22 = 0;	 Catch:{ Exception -> 0x000c }
        r0 = r19;	 Catch:{ Exception -> 0x000c }
        r1 = r20;	 Catch:{ Exception -> 0x000c }
        r2 = r21;	 Catch:{ Exception -> 0x000c }
        r3 = r22;	 Catch:{ Exception -> 0x000c }
        r0.<init>(r1, r2, r3, r6);	 Catch:{ Exception -> 0x000c }
        goto L_0x0028;	 Catch:{ Exception -> 0x000c }
    L_0x0105:
        r17 = r16.m2486i();	 Catch:{ Exception -> 0x000c }
        r5 = r14.edit();	 Catch:{ Exception -> 0x000c }
        r10 = java.lang.System.currentTimeMillis();	 Catch:{ Exception -> 0x000c }
        r5.putLong(r13, r10);	 Catch:{ Exception -> 0x000c }
        r19 = r17.m2891b();	 Catch:{ Exception -> 0x000c }
        if (r19 == 0) goto L_0x0127;	 Catch:{ Exception -> 0x000c }
    L_0x011a:
        r19 = r17.m2891b();	 Catch:{ Exception -> 0x000c }
        r19 = r19.toString();	 Catch:{ Exception -> 0x000c }
        r0 = r19;	 Catch:{ Exception -> 0x000c }
        r5.putString(r9, r0);	 Catch:{ Exception -> 0x000c }
    L_0x0127:
        r5.apply();	 Catch:{ Exception -> 0x000c }
        r19 = r17;
        goto L_0x0028;
    L_0x012e:
        r19 = move-exception;
        goto L_0x00be;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.g.b(android.content.Context, java.lang.String):com.facebook.l");
    }

    /* renamed from: g */
    public static String m2856g() {
        return "4.15.0";
    }

    /* renamed from: b */
    public static boolean m2850b(Context context) {
        C0690r.m2803a();
        return context.getSharedPreferences("com.facebook.sdk.appEventPreferences", 0).getBoolean("limitEventUsage", false);
    }

    /* renamed from: h */
    public static long m2857h() {
        C0690r.m2803a();
        return f1289i.get();
    }

    /* renamed from: c */
    static void m2851c(Context context) {
        if (context != null) {
            try {
                ApplicationInfo ai = context.getPackageManager().getApplicationInfo(context.getPackageName(), ag.FLAG_HIGH_PRIORITY);
                if (ai != null && ai.metaData != null) {
                    if (f1284d == null) {
                        String appId = ai.metaData.get("com.facebook.sdk.ApplicationId");
                        if (appId instanceof String) {
                            String appIdString = appId;
                            if (appIdString.toLowerCase(Locale.ROOT).startsWith("fb")) {
                                f1284d = appIdString.substring(2);
                            } else {
                                f1284d = appIdString;
                            }
                        } else if (appId instanceof Integer) {
                            throw new C0699e("App Ids cannot be directly placed in the manifest.They must be prefixed by 'fb' or be placed in the string resource file.");
                        }
                    }
                    if (f1285e == null) {
                        f1285e = ai.metaData.getString("com.facebook.sdk.ApplicationName");
                    }
                    if (f1286f == null) {
                        f1286f = ai.metaData.getString("com.facebook.sdk.ClientToken");
                    }
                    if (f1287g == 0) {
                        C0707g.m2842a(ai.metaData.getInt("com.facebook.sdk.WebDialogTheme"));
                    }
                }
            } catch (NameNotFoundException e) {
            }
        }
    }

    /* renamed from: i */
    public static String m2858i() {
        C0690r.m2803a();
        return f1284d;
    }

    /* renamed from: j */
    public static String m2859j() {
        C0690r.m2803a();
        return f1286f;
    }

    /* renamed from: k */
    public static int m2860k() {
        C0690r.m2803a();
        return f1287g;
    }

    /* renamed from: a */
    public static void m2842a(int theme) {
        if (theme == 0) {
            theme = 16973840;
        }
        f1287g = theme;
    }

    /* renamed from: l */
    public static int m2861l() {
        C0690r.m2803a();
        return f1294n;
    }
}

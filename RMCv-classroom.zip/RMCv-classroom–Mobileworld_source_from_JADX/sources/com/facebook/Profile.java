package com.facebook;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.facebook.p014b.C0689q;
import com.facebook.p014b.C0689q.C0589c;
import com.facebook.p014b.C0690r;
import org.json.JSONException;
import org.json.JSONObject;

public final class Profile implements Parcelable {
    public static final Creator<Profile> CREATOR = new C05912();
    /* renamed from: a */
    private final String f1008a;
    /* renamed from: b */
    private final String f1009b;
    /* renamed from: c */
    private final String f1010c;
    /* renamed from: d */
    private final String f1011d;
    /* renamed from: e */
    private final String f1012e;
    /* renamed from: f */
    private final Uri f1013f;

    /* renamed from: com.facebook.Profile$1 */
    static class C05901 implements C0589c {
        C05901() {
        }

        /* renamed from: a */
        public void mo851a(JSONObject userInfo) {
            String id = userInfo.optString("id");
            if (id != null) {
                String link = userInfo.optString("link");
                Profile.m2497a(new Profile(id, userInfo.optString("first_name"), userInfo.optString("middle_name"), userInfo.optString("last_name"), userInfo.optString("name"), link != null ? Uri.parse(link) : null));
            }
        }

        /* renamed from: a */
        public void mo850a(C0699e error) {
        }
    }

    /* renamed from: com.facebook.Profile$2 */
    static class C05912 implements Creator {
        C05912() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m2494a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m2495a(i);
        }

        /* renamed from: a */
        public Profile m2494a(Parcel source) {
            return new Profile(source);
        }

        /* renamed from: a */
        public Profile[] m2495a(int size) {
            return new Profile[size];
        }
    }

    /* renamed from: a */
    public static Profile m2496a() {
        return C0749q.m3086a().m3090b();
    }

    /* renamed from: a */
    public static void m2497a(Profile profile) {
        C0749q.m3086a().m3089a(profile);
    }

    /* renamed from: b */
    public static void m2498b() {
        AccessToken accessToken = AccessToken.m2378a();
        if (accessToken == null) {
            m2497a(null);
        } else {
            C0689q.m2773a(accessToken.m2385b(), new C05901());
        }
    }

    public Profile(String id, String firstName, String middleName, String lastName, String name, Uri linkUri) {
        C0690r.m2806a(id, "id");
        this.f1008a = id;
        this.f1009b = firstName;
        this.f1010c = middleName;
        this.f1011d = lastName;
        this.f1012e = name;
        this.f1013f = linkUri;
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Profile)) {
            return false;
        }
        Profile o = (Profile) other;
        if (this.f1008a.equals(o.f1008a) && this.f1009b == null) {
            if (o.f1009b != null) {
                return false;
            }
            return true;
        } else if (this.f1009b.equals(o.f1009b) && this.f1010c == null) {
            if (o.f1010c != null) {
                return false;
            }
            return true;
        } else if (this.f1010c.equals(o.f1010c) && this.f1011d == null) {
            if (o.f1011d != null) {
                return false;
            }
            return true;
        } else if (this.f1011d.equals(o.f1011d) && this.f1012e == null) {
            if (o.f1012e != null) {
                return false;
            }
            return true;
        } else if (!this.f1012e.equals(o.f1012e) || this.f1013f != null) {
            return this.f1013f.equals(o.f1013f);
        } else {
            if (o.f1013f != null) {
                return false;
            }
            return true;
        }
    }

    public int hashCode() {
        int result = this.f1008a.hashCode() + 527;
        if (this.f1009b != null) {
            result = (result * 31) + this.f1009b.hashCode();
        }
        if (this.f1010c != null) {
            result = (result * 31) + this.f1010c.hashCode();
        }
        if (this.f1011d != null) {
            result = (result * 31) + this.f1011d.hashCode();
        }
        if (this.f1012e != null) {
            result = (result * 31) + this.f1012e.hashCode();
        }
        if (this.f1013f != null) {
            return (result * 31) + this.f1013f.hashCode();
        }
        return result;
    }

    /* renamed from: c */
    JSONObject m2499c() {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("id", this.f1008a);
            jsonObject.put("first_name", this.f1009b);
            jsonObject.put("middle_name", this.f1010c);
            jsonObject.put("last_name", this.f1011d);
            jsonObject.put("name", this.f1012e);
            if (this.f1013f == null) {
                return jsonObject;
            }
            jsonObject.put("link_uri", this.f1013f.toString());
            return jsonObject;
        } catch (JSONException e) {
            return null;
        }
    }

    Profile(JSONObject jsonObject) {
        Uri uri = null;
        this.f1008a = jsonObject.optString("id", null);
        this.f1009b = jsonObject.optString("first_name", null);
        this.f1010c = jsonObject.optString("middle_name", null);
        this.f1011d = jsonObject.optString("last_name", null);
        this.f1012e = jsonObject.optString("name", null);
        String linkUriString = jsonObject.optString("link_uri", null);
        if (linkUriString != null) {
            uri = Uri.parse(linkUriString);
        }
        this.f1013f = uri;
    }

    private Profile(Parcel source) {
        this.f1008a = source.readString();
        this.f1009b = source.readString();
        this.f1010c = source.readString();
        this.f1011d = source.readString();
        this.f1012e = source.readString();
        String linkUriString = source.readString();
        this.f1013f = linkUriString == null ? null : Uri.parse(linkUriString);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.f1008a);
        dest.writeString(this.f1009b);
        dest.writeString(this.f1010c);
        dest.writeString(this.f1011d);
        dest.writeString(this.f1012e);
        dest.writeString(this.f1013f == null ? null : this.f1013f.toString());
    }
}

package com.facebook;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.content.C0204h;
import com.facebook.p014b.C0655f;

public class CustomTabMainActivity extends Activity {
    /* renamed from: a */
    public static final String f945a = (CustomTabMainActivity.class.getSimpleName() + ".extra_params");
    /* renamed from: b */
    public static final String f946b = (CustomTabMainActivity.class.getSimpleName() + ".extra_chromePackage");
    /* renamed from: c */
    public static final String f947c = (CustomTabMainActivity.class.getSimpleName() + ".extra_url");
    /* renamed from: d */
    public static final String f948d = (CustomTabMainActivity.class.getSimpleName() + ".action_refresh");
    /* renamed from: e */
    private boolean f949e = true;
    /* renamed from: f */
    private BroadcastReceiver f950f;

    /* renamed from: com.facebook.CustomTabMainActivity$1 */
    class C05741 extends BroadcastReceiver {
        /* renamed from: a */
        final /* synthetic */ CustomTabMainActivity f944a;

        C05741(CustomTabMainActivity this$0) {
            this.f944a = this$0;
        }

        public void onReceive(Context context, Intent intent) {
            Intent newIntent = new Intent(this.f944a, CustomTabMainActivity.class);
            newIntent.setAction(CustomTabMainActivity.f948d);
            newIntent.putExtra(CustomTabMainActivity.f947c, intent.getStringExtra(CustomTabMainActivity.f947c));
            newIntent.addFlags(603979776);
            this.f944a.startActivity(newIntent);
        }
    }

    /* renamed from: a */
    public static final String m2394a() {
        return "fb" + C0707g.m2858i() + "://authorize";
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (CustomTabActivity.f941a.equals(getIntent().getAction())) {
            setResult(0);
            finish();
        } else if (savedInstanceState == null) {
            Bundle parameters = getIntent().getBundleExtra(f945a);
            new C0655f("oauth", parameters).m2628a(this, getIntent().getStringExtra(f946b));
            this.f949e = false;
            this.f950f = new C05741(this);
            C0204h.m758a((Context) this).m762a(this.f950f, new IntentFilter(CustomTabActivity.f941a));
        }
    }

    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (f948d.equals(intent.getAction())) {
            C0204h.m758a((Context) this).m763a(new Intent(CustomTabActivity.f942b));
            m2395a(-1, intent);
        } else if (CustomTabActivity.f941a.equals(intent.getAction())) {
            m2395a(-1, intent);
        }
    }

    protected void onResume() {
        super.onResume();
        if (this.f949e) {
            m2395a(0, null);
        }
        this.f949e = true;
    }

    /* renamed from: a */
    private void m2395a(int resultCode, Intent resultIntent) {
        C0204h.m758a((Context) this).m761a(this.f950f);
        if (resultIntent != null) {
            setResult(resultCode, resultIntent);
        } else {
            setResult(resultCode);
        }
        finish();
    }
}

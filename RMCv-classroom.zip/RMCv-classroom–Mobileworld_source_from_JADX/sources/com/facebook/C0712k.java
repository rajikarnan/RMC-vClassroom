package com.facebook;

import android.os.Handler;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/* compiled from: GraphRequestBatch */
/* renamed from: com.facebook.k */
public class C0712k extends AbstractList<GraphRequest> {
    /* renamed from: a */
    private static AtomicInteger f1304a = new AtomicInteger();
    /* renamed from: b */
    private Handler f1305b;
    /* renamed from: c */
    private List<GraphRequest> f1306c;
    /* renamed from: d */
    private int f1307d;
    /* renamed from: e */
    private final String f1308e;
    /* renamed from: f */
    private List<C0633a> f1309f;
    /* renamed from: g */
    private String f1310g;

    /* compiled from: GraphRequestBatch */
    /* renamed from: com.facebook.k$a */
    public interface C0633a {
        /* renamed from: a */
        void mo852a(C0712k c0712k);
    }

    /* compiled from: GraphRequestBatch */
    /* renamed from: com.facebook.k$b */
    public interface C0711b extends C0633a {
        /* renamed from: a */
        void m2866a(C0712k c0712k, long j, long j2);
    }

    public /* synthetic */ void add(int i, Object obj) {
        m2869a(i, (GraphRequest) obj);
    }

    public /* synthetic */ boolean add(Object obj) {
        return m2872a((GraphRequest) obj);
    }

    public /* synthetic */ Object get(int i) {
        return m2868a(i);
    }

    public /* synthetic */ Object remove(int i) {
        return m2873b(i);
    }

    public /* synthetic */ Object set(int i, Object obj) {
        return m2874b(i, (GraphRequest) obj);
    }

    public C0712k() {
        this.f1306c = new ArrayList();
        this.f1307d = 0;
        this.f1308e = Integer.valueOf(f1304a.incrementAndGet()).toString();
        this.f1309f = new ArrayList();
        this.f1306c = new ArrayList();
    }

    public C0712k(Collection<GraphRequest> requests) {
        this.f1306c = new ArrayList();
        this.f1307d = 0;
        this.f1308e = Integer.valueOf(f1304a.incrementAndGet()).toString();
        this.f1309f = new ArrayList();
        this.f1306c = new ArrayList(requests);
    }

    public C0712k(GraphRequest... requests) {
        this.f1306c = new ArrayList();
        this.f1307d = 0;
        this.f1308e = Integer.valueOf(f1304a.incrementAndGet()).toString();
        this.f1309f = new ArrayList();
        this.f1306c = Arrays.asList(requests);
    }

    /* renamed from: a */
    public int m2867a() {
        return this.f1307d;
    }

    /* renamed from: a */
    public void m2871a(C0633a callback) {
        if (!this.f1309f.contains(callback)) {
            this.f1309f.add(callback);
        }
    }

    /* renamed from: a */
    public final boolean m2872a(GraphRequest request) {
        return this.f1306c.add(request);
    }

    /* renamed from: a */
    public final void m2869a(int location, GraphRequest request) {
        this.f1306c.add(location, request);
    }

    public final void clear() {
        this.f1306c.clear();
    }

    /* renamed from: a */
    public final GraphRequest m2868a(int i) {
        return (GraphRequest) this.f1306c.get(i);
    }

    /* renamed from: b */
    public final GraphRequest m2873b(int location) {
        return (GraphRequest) this.f1306c.remove(location);
    }

    /* renamed from: b */
    public final GraphRequest m2874b(int location, GraphRequest request) {
        return (GraphRequest) this.f1306c.set(location, request);
    }

    public final int size() {
        return this.f1306c.size();
    }

    /* renamed from: b */
    final String m2875b() {
        return this.f1308e;
    }

    /* renamed from: c */
    final Handler m2876c() {
        return this.f1305b;
    }

    /* renamed from: a */
    final void m2870a(Handler callbackHandler) {
        this.f1305b = callbackHandler;
    }

    /* renamed from: d */
    final List<GraphRequest> m2877d() {
        return this.f1306c;
    }

    /* renamed from: e */
    final List<C0633a> m2878e() {
        return this.f1309f;
    }

    /* renamed from: f */
    public final String m2879f() {
        return this.f1310g;
    }

    /* renamed from: g */
    public final List<C0713l> m2880g() {
        return m2882i();
    }

    /* renamed from: h */
    public final C0710j m2881h() {
        return m2883j();
    }

    /* renamed from: i */
    List<C0713l> m2882i() {
        return GraphRequest.m2455b(this);
    }

    /* renamed from: j */
    C0710j m2883j() {
        return GraphRequest.m2459c(this);
    }
}

package com.facebook;

import android.content.Intent;
import android.support.v4.content.C0204h;
import com.facebook.p014b.C0689q;
import com.facebook.p014b.C0690r;

/* compiled from: ProfileManager */
/* renamed from: com.facebook.q */
final class C0749q {
    /* renamed from: a */
    private static volatile C0749q f1428a;
    /* renamed from: b */
    private final C0204h f1429b;
    /* renamed from: c */
    private final C0748p f1430c;
    /* renamed from: d */
    private Profile f1431d;

    C0749q(C0204h localBroadcastManager, C0748p profileCache) {
        C0690r.m2805a((Object) localBroadcastManager, "localBroadcastManager");
        C0690r.m2805a((Object) profileCache, "profileCache");
        this.f1429b = localBroadcastManager;
        this.f1430c = profileCache;
    }

    /* renamed from: a */
    static C0749q m3086a() {
        if (f1428a == null) {
            synchronized (C0749q.class) {
                if (f1428a == null) {
                    f1428a = new C0749q(C0204h.m758a(C0707g.m2855f()), new C0748p());
                }
            }
        }
        return f1428a;
    }

    /* renamed from: b */
    Profile m3090b() {
        return this.f1431d;
    }

    /* renamed from: c */
    boolean m3091c() {
        Profile profile = this.f1430c.m3083a();
        if (profile == null) {
            return false;
        }
        m3088a(profile, false);
        return true;
    }

    /* renamed from: a */
    void m3089a(Profile currentProfile) {
        m3088a(currentProfile, true);
    }

    /* renamed from: a */
    private void m3088a(Profile currentProfile, boolean writeToCache) {
        Profile oldProfile = this.f1431d;
        this.f1431d = currentProfile;
        if (writeToCache) {
            if (currentProfile != null) {
                this.f1430c.m3084a(currentProfile);
            } else {
                this.f1430c.m3085b();
            }
        }
        if (!C0689q.m2781a((Object) oldProfile, (Object) currentProfile)) {
            m3087a(oldProfile, currentProfile);
        }
    }

    /* renamed from: a */
    private void m3087a(Profile oldProfile, Profile currentProfile) {
        Intent intent = new Intent("com.facebook.sdk.ACTION_CURRENT_PROFILE_CHANGED");
        intent.putExtra("com.facebook.sdk.EXTRA_OLD_PROFILE", oldProfile);
        intent.putExtra("com.facebook.sdk.EXTRA_NEW_PROFILE", currentProfile);
        this.f1429b.m763a(intent);
    }
}

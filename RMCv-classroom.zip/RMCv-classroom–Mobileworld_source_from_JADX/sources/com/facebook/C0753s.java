package com.facebook;

import android.os.Handler;
import com.facebook.C0712k.C0633a;
import com.facebook.C0712k.C0711b;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;

/* compiled from: ProgressOutputStream */
/* renamed from: com.facebook.s */
class C0753s extends FilterOutputStream implements C0750u {
    /* renamed from: a */
    private final Map<GraphRequest, C0779v> f1439a;
    /* renamed from: b */
    private final C0712k f1440b;
    /* renamed from: c */
    private final long f1441c = C0707g.m2857h();
    /* renamed from: d */
    private long f1442d;
    /* renamed from: e */
    private long f1443e;
    /* renamed from: f */
    private long f1444f;
    /* renamed from: g */
    private C0779v f1445g;

    C0753s(OutputStream out, C0712k requests, Map<GraphRequest, C0779v> progressMap, long maxProgress) {
        super(out);
        this.f1440b = requests;
        this.f1439a = progressMap;
        this.f1444f = maxProgress;
    }

    /* renamed from: a */
    private void m3099a(long size) {
        if (this.f1445g != null) {
            this.f1445g.m3172a(size);
        }
        this.f1442d += size;
        if (this.f1442d >= this.f1443e + this.f1441c || this.f1442d >= this.f1444f) {
            m3098a();
        }
    }

    /* renamed from: a */
    private void m3098a() {
        if (this.f1442d > this.f1443e) {
            for (C0633a callback : this.f1440b.m2878e()) {
                if (callback instanceof C0711b) {
                    Handler callbackHandler = this.f1440b.m2876c();
                    final C0711b progressCallback = (C0711b) callback;
                    if (callbackHandler == null) {
                        progressCallback.m2866a(this.f1440b, this.f1442d, this.f1444f);
                    } else {
                        callbackHandler.post(new Runnable(this) {
                            /* renamed from: b */
                            final /* synthetic */ C0753s f1438b;

                            public void run() {
                                progressCallback.m2866a(this.f1438b.f1440b, this.f1438b.f1442d, this.f1438b.f1444f);
                            }
                        });
                    }
                }
            }
            this.f1443e = this.f1442d;
        }
    }

    /* renamed from: a */
    public void mo882a(GraphRequest request) {
        this.f1445g = request != null ? (C0779v) this.f1439a.get(request) : null;
    }

    public void write(byte[] buffer) throws IOException {
        this.out.write(buffer);
        m3099a((long) buffer.length);
    }

    public void write(byte[] buffer, int offset, int length) throws IOException {
        this.out.write(buffer, offset, length);
        m3099a((long) length);
    }

    public void write(int oneByte) throws IOException {
        this.out.write(oneByte);
        m3099a(1);
    }

    public void close() throws IOException {
        super.close();
        for (C0779v p : this.f1439a.values()) {
            p.m3171a();
        }
        m3098a();
    }
}

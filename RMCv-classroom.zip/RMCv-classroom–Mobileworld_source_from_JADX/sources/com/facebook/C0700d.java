package com.facebook;

/* compiled from: FacebookDialogException */
/* renamed from: com.facebook.d */
public class C0700d extends C0699e {
    /* renamed from: a */
    private int f1274a;
    /* renamed from: b */
    private String f1275b;

    public C0700d(String message, int errorCode, String failingUrl) {
        super(message);
        this.f1274a = errorCode;
        this.f1275b = failingUrl;
    }

    /* renamed from: a */
    public int m2837a() {
        return this.f1274a;
    }

    /* renamed from: b */
    public String m2838b() {
        return this.f1275b;
    }

    public final String toString() {
        return "{FacebookDialogException: " + "errorCode: " + m2837a() + ", message: " + getMessage() + ", url: " + m2838b() + "}";
    }
}

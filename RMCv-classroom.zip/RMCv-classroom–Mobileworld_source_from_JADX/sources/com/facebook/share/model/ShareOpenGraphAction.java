package com.facebook.share.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.facebook.share.model.ShareOpenGraphValueContainer.C0767a;

public final class ShareOpenGraphAction extends ShareOpenGraphValueContainer<ShareOpenGraphAction, C0768a> {
    public static final Creator<ShareOpenGraphAction> CREATOR = new C07661();

    /* renamed from: com.facebook.share.model.ShareOpenGraphAction$1 */
    static class C07661 implements Creator<ShareOpenGraphAction> {
        C07661() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m3148a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m3149a(i);
        }

        /* renamed from: a */
        public ShareOpenGraphAction m3148a(Parcel in) {
            return new ShareOpenGraphAction(in);
        }

        /* renamed from: a */
        public ShareOpenGraphAction[] m3149a(int size) {
            return new ShareOpenGraphAction[size];
        }
    }

    /* renamed from: com.facebook.share.model.ShareOpenGraphAction$a */
    public static final class C0768a extends C0767a<ShareOpenGraphAction, C0768a> {
        /* renamed from: a */
        public C0768a m3155a(String actionType) {
            m3152a("og:type", actionType);
            return this;
        }

        /* renamed from: a */
        public ShareOpenGraphAction m3156a() {
            return new ShareOpenGraphAction();
        }

        /* renamed from: a */
        public C0768a m3154a(ShareOpenGraphAction model) {
            return model == null ? this : ((C0768a) super.mo886a((ShareOpenGraphValueContainer) model)).m3155a(model.m3162a());
        }

        /* renamed from: a */
        C0768a m3153a(Parcel parcel) {
            return m3154a((ShareOpenGraphAction) parcel.readParcelable(ShareOpenGraphAction.class.getClassLoader()));
        }
    }

    private ShareOpenGraphAction(C0768a builder) {
        super((C0767a) builder);
    }

    ShareOpenGraphAction(Parcel in) {
        super(in);
    }

    /* renamed from: a */
    public String m3162a() {
        return m3160b("og:type");
    }
}

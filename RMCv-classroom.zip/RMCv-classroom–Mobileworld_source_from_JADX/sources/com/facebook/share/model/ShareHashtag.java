package com.facebook.share.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;

public class ShareHashtag implements ShareModel {
    public static final Creator<ShareHashtag> CREATOR = new C07631();
    /* renamed from: a */
    private final String f1464a;

    /* renamed from: com.facebook.share.model.ShareHashtag$1 */
    static class C07631 implements Creator<ShareHashtag> {
        C07631() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m3137a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m3138a(i);
        }

        /* renamed from: a */
        public ShareHashtag m3137a(Parcel in) {
            return new ShareHashtag(in);
        }

        /* renamed from: a */
        public ShareHashtag[] m3138a(int size) {
            return new ShareHashtag[size];
        }
    }

    /* renamed from: com.facebook.share.model.ShareHashtag$a */
    public static class C0764a {
        /* renamed from: a */
        private String f1463a;

        /* renamed from: a */
        public C0764a m3142a(String hashtag) {
            this.f1463a = hashtag;
            return this;
        }

        /* renamed from: a */
        public C0764a m3141a(ShareHashtag model) {
            return model == null ? this : m3142a(model.m3144a());
        }

        /* renamed from: a */
        C0764a m3140a(Parcel parcel) {
            return m3141a((ShareHashtag) parcel.readParcelable(ShareHashtag.class.getClassLoader()));
        }

        /* renamed from: a */
        public ShareHashtag m3143a() {
            return new ShareHashtag();
        }
    }

    private ShareHashtag(C0764a builder) {
        this.f1464a = builder.f1463a;
    }

    ShareHashtag(Parcel in) {
        this.f1464a = in.readString();
    }

    /* renamed from: a */
    public String m3144a() {
        return this.f1464a;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.f1464a);
    }
}

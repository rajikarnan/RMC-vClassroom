package com.facebook.share.model;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;

public final class ShareLinkContent extends ShareContent<ShareLinkContent, Object> {
    public static final Creator<ShareLinkContent> CREATOR = new C07651();
    /* renamed from: a */
    private final String f1465a;
    /* renamed from: b */
    private final String f1466b;
    /* renamed from: c */
    private final Uri f1467c;
    /* renamed from: d */
    private final String f1468d;

    /* renamed from: com.facebook.share.model.ShareLinkContent$1 */
    static class C07651 implements Creator<ShareLinkContent> {
        C07651() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m3145a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m3146a(i);
        }

        /* renamed from: a */
        public ShareLinkContent m3145a(Parcel in) {
            return new ShareLinkContent(in);
        }

        /* renamed from: a */
        public ShareLinkContent[] m3146a(int size) {
            return new ShareLinkContent[size];
        }
    }

    ShareLinkContent(Parcel in) {
        super(in);
        this.f1465a = in.readString();
        this.f1466b = in.readString();
        this.f1467c = (Uri) in.readParcelable(Uri.class.getClassLoader());
        this.f1468d = in.readString();
    }

    /* renamed from: c */
    public String m3147c() {
        return this.f1468d;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        super.writeToParcel(out, flags);
        out.writeString(this.f1465a);
        out.writeString(this.f1466b);
        out.writeParcelable(this.f1467c, 0);
        out.writeString(this.f1468d);
    }
}

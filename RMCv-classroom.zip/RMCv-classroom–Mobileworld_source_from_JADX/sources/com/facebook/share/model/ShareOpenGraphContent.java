package com.facebook.share.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.facebook.share.model.ShareOpenGraphAction.C0768a;

public final class ShareOpenGraphContent extends ShareContent<ShareOpenGraphContent, Object> {
    public static final Creator<ShareOpenGraphContent> CREATOR = new C07691();
    /* renamed from: a */
    private final ShareOpenGraphAction f1472a;
    /* renamed from: b */
    private final String f1473b;

    /* renamed from: com.facebook.share.model.ShareOpenGraphContent$1 */
    static class C07691 implements Creator<ShareOpenGraphContent> {
        C07691() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m3163a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m3164a(i);
        }

        /* renamed from: a */
        public ShareOpenGraphContent m3163a(Parcel in) {
            return new ShareOpenGraphContent(in);
        }

        /* renamed from: a */
        public ShareOpenGraphContent[] m3164a(int size) {
            return new ShareOpenGraphContent[size];
        }
    }

    ShareOpenGraphContent(Parcel in) {
        super(in);
        this.f1472a = new C0768a().m3153a(in).m3156a();
        this.f1473b = in.readString();
    }

    /* renamed from: c */
    public ShareOpenGraphAction m3165c() {
        return this.f1472a;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        super.writeToParcel(out, flags);
        out.writeParcelable(this.f1472a, 0);
        out.writeString(this.f1473b);
    }
}

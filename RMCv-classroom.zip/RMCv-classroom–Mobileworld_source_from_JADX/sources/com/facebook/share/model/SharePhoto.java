package com.facebook.share.model;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;

public final class SharePhoto extends ShareMedia {
    public static final Creator<SharePhoto> CREATOR = new C07711();
    /* renamed from: a */
    private final Bitmap f1474a;
    /* renamed from: b */
    private final Uri f1475b;
    /* renamed from: c */
    private final boolean f1476c;
    /* renamed from: d */
    private final String f1477d;

    /* renamed from: com.facebook.share.model.SharePhoto$1 */
    static class C07711 implements Creator<SharePhoto> {
        C07711() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m3168a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m3169a(i);
        }

        /* renamed from: a */
        public SharePhoto m3168a(Parcel source) {
            return new SharePhoto(source);
        }

        /* renamed from: a */
        public SharePhoto[] m3169a(int size) {
            return new SharePhoto[size];
        }
    }

    SharePhoto(Parcel in) {
        super(in);
        this.f1474a = (Bitmap) in.readParcelable(Bitmap.class.getClassLoader());
        this.f1475b = (Uri) in.readParcelable(Uri.class.getClassLoader());
        this.f1476c = in.readByte() != (byte) 0;
        this.f1477d = in.readString();
    }

    /* renamed from: a */
    public Uri m3170a() {
        return this.f1475b;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        int i = 0;
        super.writeToParcel(out, flags);
        out.writeParcelable(this.f1474a, 0);
        out.writeParcelable(this.f1475b, 0);
        if (this.f1476c) {
            i = 1;
        }
        out.writeByte((byte) i);
        out.writeString(this.f1477d);
    }
}

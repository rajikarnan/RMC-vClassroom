package com.facebook.share.model;

import android.os.Bundle;
import android.os.Parcel;

public abstract class ShareMedia implements ShareModel {
    /* renamed from: a */
    private final Bundle f1469a;

    ShareMedia(Parcel in) {
        this.f1469a = in.readBundle();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeBundle(this.f1469a);
    }
}

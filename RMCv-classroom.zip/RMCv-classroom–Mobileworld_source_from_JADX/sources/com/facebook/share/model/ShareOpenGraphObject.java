package com.facebook.share.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;

public final class ShareOpenGraphObject extends ShareOpenGraphValueContainer<ShareOpenGraphObject, Object> {
    public static final Creator<ShareOpenGraphObject> CREATOR = new C07701();

    /* renamed from: com.facebook.share.model.ShareOpenGraphObject$1 */
    static class C07701 implements Creator<ShareOpenGraphObject> {
        C07701() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m3166a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m3167a(i);
        }

        /* renamed from: a */
        public ShareOpenGraphObject m3166a(Parcel in) {
            return new ShareOpenGraphObject(in);
        }

        /* renamed from: a */
        public ShareOpenGraphObject[] m3167a(int size) {
            return new ShareOpenGraphObject[size];
        }
    }

    ShareOpenGraphObject(Parcel in) {
        super(in);
    }
}

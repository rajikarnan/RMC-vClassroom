package com.facebook.share.model;

import android.os.Bundle;
import android.os.Parcel;
import java.util.Set;

public abstract class ShareOpenGraphValueContainer<P extends ShareOpenGraphValueContainer, E extends C0767a> implements ShareModel {
    /* renamed from: a */
    private final Bundle f1471a;

    /* renamed from: com.facebook.share.model.ShareOpenGraphValueContainer$a */
    public static abstract class C0767a<P extends ShareOpenGraphValueContainer, E extends C0767a> {
        /* renamed from: a */
        private Bundle f1470a = new Bundle();

        /* renamed from: a */
        public E m3152a(String key, String value) {
            this.f1470a.putString(key, value);
            return this;
        }

        /* renamed from: a */
        public E mo886a(P model) {
            if (model != null) {
                this.f1470a.putAll(model.m3159b());
            }
            return this;
        }
    }

    protected ShareOpenGraphValueContainer(C0767a<P, E> builder) {
        this.f1471a = (Bundle) builder.f1470a.clone();
    }

    ShareOpenGraphValueContainer(Parcel in) {
        this.f1471a = in.readBundle(C0767a.class.getClassLoader());
    }

    /* renamed from: a */
    public Object m3158a(String key) {
        return this.f1471a.get(key);
    }

    /* renamed from: b */
    public String m3160b(String key) {
        return this.f1471a.getString(key);
    }

    /* renamed from: b */
    public Bundle m3159b() {
        return (Bundle) this.f1471a.clone();
    }

    /* renamed from: c */
    public Set<String> m3161c() {
        return this.f1471a.keySet();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        out.writeBundle(this.f1471a);
    }
}

package com.facebook.share.model;

import android.net.Uri;
import android.os.Parcel;
import com.facebook.share.model.ShareHashtag.C0764a;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class ShareContent<P extends ShareContent, E> implements ShareModel {
    /* renamed from: a */
    private final Uri f1458a;
    /* renamed from: b */
    private final List<String> f1459b;
    /* renamed from: c */
    private final String f1460c;
    /* renamed from: d */
    private final String f1461d;
    /* renamed from: e */
    private final ShareHashtag f1462e;

    protected ShareContent(Parcel in) {
        this.f1458a = (Uri) in.readParcelable(Uri.class.getClassLoader());
        this.f1459b = m3134a(in);
        this.f1460c = in.readString();
        this.f1461d = in.readString();
        this.f1462e = new C0764a().m3140a(in).m3143a();
    }

    /* renamed from: a */
    public Uri m3135a() {
        return this.f1458a;
    }

    /* renamed from: b */
    public ShareHashtag m3136b() {
        return this.f1462e;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        out.writeParcelable(this.f1458a, 0);
        out.writeStringList(this.f1459b);
        out.writeString(this.f1460c);
        out.writeString(this.f1461d);
        out.writeParcelable(this.f1462e, 0);
    }

    /* renamed from: a */
    private List<String> m3134a(Parcel in) {
        List<String> list = new ArrayList();
        in.readStringList(list);
        return list.size() == 0 ? null : Collections.unmodifiableList(list);
    }
}

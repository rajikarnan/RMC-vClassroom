package com.facebook.share.internal;

import android.net.Uri;
import android.util.Pair;
import com.facebook.C0699e;
import com.facebook.share.internal.C0759a.C0758a;
import com.facebook.share.model.ShareOpenGraphContent;
import com.facebook.share.model.SharePhoto;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: ShareInternalUtility */
/* renamed from: com.facebook.share.internal.b */
public final class C0761b {

    /* compiled from: ShareInternalUtility */
    /* renamed from: com.facebook.share.internal.b$1 */
    static class C07601 implements C0758a {
        C07601() {
        }

        /* renamed from: a */
        public JSONObject mo883a(SharePhoto photo) {
            Uri photoUri = photo.m3170a();
            JSONObject photoJSONObject = new JSONObject();
            try {
                photoJSONObject.put("url", photoUri.toString());
                return photoJSONObject;
            } catch (JSONException e) {
                throw new C0699e("Unable to attach images", e);
            }
        }
    }

    /* renamed from: a */
    public static JSONObject m3129a(ShareOpenGraphContent shareOpenGraphContent) throws JSONException {
        return C0759a.m3124a(shareOpenGraphContent.m3165c(), new C07601());
    }

    /* renamed from: a */
    public static JSONArray m3128a(JSONArray jsonArray, boolean requireNamespace) throws JSONException {
        JSONArray newArray = new JSONArray();
        for (int i = 0; i < jsonArray.length(); i++) {
            Object value = jsonArray.get(i);
            if (value instanceof JSONArray) {
                value = C0761b.m3128a((JSONArray) value, requireNamespace);
            } else if (value instanceof JSONObject) {
                value = C0761b.m3130a((JSONObject) value, requireNamespace);
            }
            newArray.put(value);
        }
        return newArray;
    }

    /* renamed from: a */
    public static JSONObject m3130a(JSONObject jsonObject, boolean requireNamespace) {
        if (jsonObject == null) {
            return null;
        }
        try {
            JSONObject newJsonObject = new JSONObject();
            JSONObject data = new JSONObject();
            JSONArray names = jsonObject.names();
            for (int i = 0; i < names.length(); i++) {
                String key = names.getString(i);
                Object value = jsonObject.get(key);
                if (value instanceof JSONObject) {
                    value = C0761b.m3130a((JSONObject) value, true);
                } else if (value instanceof JSONArray) {
                    value = C0761b.m3128a((JSONArray) value, true);
                }
                Pair<String, String> fieldNameAndNamespace = C0761b.m3127a(key);
                String namespace = fieldNameAndNamespace.first;
                String fieldName = fieldNameAndNamespace.second;
                if (requireNamespace) {
                    if (namespace != null && namespace.equals("fbsdk")) {
                        newJsonObject.put(key, value);
                    } else if (namespace == null || namespace.equals("og")) {
                        newJsonObject.put(fieldName, value);
                    } else {
                        data.put(fieldName, value);
                    }
                } else if (namespace == null || !namespace.equals("fb")) {
                    newJsonObject.put(fieldName, value);
                } else {
                    newJsonObject.put(key, value);
                }
            }
            if (data.length() <= 0) {
                return newJsonObject;
            }
            newJsonObject.put("data", data);
            return newJsonObject;
        } catch (JSONException e) {
            throw new C0699e("Failed to create json object from share content");
        }
    }

    /* renamed from: a */
    public static Pair<String, String> m3127a(String fullName) {
        String fieldName;
        String namespace = null;
        int index = fullName.indexOf(58);
        if (index == -1 || fullName.length() <= index + 1) {
            fieldName = fullName;
        } else {
            namespace = fullName.substring(0, index);
            fieldName = fullName.substring(index + 1);
        }
        return new Pair(namespace, fieldName);
    }
}

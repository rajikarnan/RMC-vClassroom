package com.facebook.share.internal;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.app.C0149p;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.facebook.C0713l;
import com.facebook.C0745m;
import com.facebook.C0777t.C0773b;
import com.facebook.C0777t.C0774c;
import com.facebook.C0777t.C0775d;
import com.facebook.C0777t.C0776e;
import com.facebook.FacebookRequestError;
import com.facebook.GraphRequest;
import com.facebook.GraphRequest.C0578b;
import com.facebook.p014b.C0690r;
import com.facebook.share.model.ShareContent;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.model.ShareOpenGraphContent;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.json.JSONException;
import org.json.JSONObject;

public class DeviceShareDialogFragment extends C0149p {
    /* renamed from: f */
    private static ScheduledThreadPoolExecutor f1451f;
    /* renamed from: a */
    private ProgressBar f1452a;
    /* renamed from: b */
    private TextView f1453b;
    /* renamed from: c */
    private Dialog f1454c;
    /* renamed from: d */
    private volatile RequestState f1455d;
    /* renamed from: e */
    private volatile ScheduledFuture f1456e;
    /* renamed from: g */
    private ShareContent f1457g;

    /* renamed from: com.facebook.share.internal.DeviceShareDialogFragment$1 */
    class C07541 implements OnClickListener {
        /* renamed from: a */
        final /* synthetic */ DeviceShareDialogFragment f1446a;

        C07541(DeviceShareDialogFragment this$0) {
            this.f1446a = this$0;
        }

        public void onClick(View v) {
            this.f1446a.f1454c.dismiss();
        }
    }

    /* renamed from: com.facebook.share.internal.DeviceShareDialogFragment$2 */
    class C07552 implements C0578b {
        /* renamed from: a */
        final /* synthetic */ DeviceShareDialogFragment f1447a;

        C07552(DeviceShareDialogFragment this$0) {
            this.f1447a = this$0;
        }

        /* renamed from: a */
        public void mo848a(C0713l response) {
            FacebookRequestError error = response.m2890a();
            if (error != null) {
                this.f1447a.m3113a(error);
                return;
            }
            JSONObject jsonObject = response.m2891b();
            RequestState requestState = new RequestState();
            try {
                requestState.m3108a(jsonObject.getString("user_code"));
                requestState.m3107a(jsonObject.getLong("expires_in"));
                this.f1447a.m3114a(requestState);
            } catch (JSONException e) {
                this.f1447a.m3113a(new FacebookRequestError(0, "", "Malformed server response"));
            }
        }
    }

    /* renamed from: com.facebook.share.internal.DeviceShareDialogFragment$3 */
    class C07563 implements Runnable {
        /* renamed from: a */
        final /* synthetic */ DeviceShareDialogFragment f1448a;

        C07563(DeviceShareDialogFragment this$0) {
            this.f1448a = this$0;
        }

        public void run() {
            this.f1448a.f1454c.dismiss();
        }
    }

    private static class RequestState implements Parcelable {
        public static final Creator<RequestState> CREATOR = new C07571();
        /* renamed from: a */
        private String f1449a;
        /* renamed from: b */
        private long f1450b;

        /* renamed from: com.facebook.share.internal.DeviceShareDialogFragment$RequestState$1 */
        static class C07571 implements Creator<RequestState> {
            C07571() {
            }

            public /* synthetic */ Object createFromParcel(Parcel parcel) {
                return m3104a(parcel);
            }

            public /* synthetic */ Object[] newArray(int i) {
                return m3105a(i);
            }

            /* renamed from: a */
            public RequestState m3104a(Parcel in) {
                return new RequestState(in);
            }

            /* renamed from: a */
            public RequestState[] m3105a(int size) {
                return new RequestState[size];
            }
        }

        RequestState() {
        }

        /* renamed from: a */
        public String m3106a() {
            return this.f1449a;
        }

        /* renamed from: a */
        public void m3108a(String userCode) {
            this.f1449a = userCode;
        }

        /* renamed from: b */
        public long m3109b() {
            return this.f1450b;
        }

        /* renamed from: a */
        public void m3107a(long expiresIn) {
            this.f1450b = expiresIn;
        }

        protected RequestState(Parcel in) {
            this.f1449a = in.readString();
            this.f1450b = in.readLong();
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.f1449a);
            dest.writeLong(this.f1450b);
        }
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = super.onCreateView(inflater, container, savedInstanceState);
        if (savedInstanceState != null) {
            RequestState requestState = (RequestState) savedInstanceState.getParcelable("request_state");
            if (requestState != null) {
                m3114a(requestState);
            }
        }
        return view;
    }

    public Dialog onCreateDialog(Bundle savedInstanceState) {
        this.f1454c = new Dialog(getActivity(), C0776e.com_facebook_auth_dialog);
        View view = getActivity().getLayoutInflater().inflate(C0774c.com_facebook_device_auth_dialog_fragment, null);
        this.f1452a = (ProgressBar) view.findViewById(C0773b.progress_bar);
        this.f1453b = (TextView) view.findViewById(C0773b.confirmation_code);
        ((Button) view.findViewById(C0773b.cancel_button)).setOnClickListener(new C07541(this));
        ((TextView) view.findViewById(C0773b.com_facebook_device_auth_instructions)).setText(Html.fromHtml(getString(C0775d.com_facebook_device_auth_instructions)));
        this.f1454c.setContentView(view);
        m3118c();
        return this.f1454c;
    }

    public void onDismiss(DialogInterface dialog) {
        super.onDismiss(dialog);
        if (this.f1456e != null) {
            this.f1456e.cancel(true);
        }
        m3112a(-1, new Intent());
    }

    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (this.f1455d != null) {
            outState.putParcelable("request_state", this.f1455d);
        }
    }

    /* renamed from: a */
    private void m3112a(int resultCode, Intent data) {
        if (isAdded()) {
            Activity activity = getActivity();
            activity.setResult(resultCode, data);
            activity.finish();
        }
    }

    /* renamed from: a */
    private void m3111a() {
        if (isAdded()) {
            getFragmentManager().mo130a().mo96a(this).mo98b();
        }
    }

    /* renamed from: a */
    public void m3120a(ShareContent shareContent) {
        this.f1457g = shareContent;
    }

    /* renamed from: b */
    private Bundle m3117b() {
        ShareContent content = this.f1457g;
        if (content == null) {
            return null;
        }
        if (content instanceof ShareLinkContent) {
            return C0762c.m3132a((ShareLinkContent) content);
        }
        if (content instanceof ShareOpenGraphContent) {
            return C0762c.m3133a((ShareOpenGraphContent) content);
        }
        return null;
    }

    /* renamed from: c */
    private void m3118c() {
        Bundle parameters = m3117b();
        if (parameters == null || parameters.size() == 0) {
            m3113a(new FacebookRequestError(0, "", "Failed to get share content"));
        }
        parameters.putString("access_token", C0690r.m2809b() + "|" + C0690r.m2812c());
        new GraphRequest(null, "device/share", parameters, C0745m.POST, new C07552(this)).m2487j();
    }

    /* renamed from: a */
    private void m3113a(FacebookRequestError error) {
        m3111a();
        Intent intent = new Intent();
        intent.putExtra("error", error);
        m3112a(-1, intent);
    }

    /* renamed from: d */
    private static synchronized ScheduledThreadPoolExecutor m3119d() {
        ScheduledThreadPoolExecutor scheduledThreadPoolExecutor;
        synchronized (DeviceShareDialogFragment.class) {
            if (f1451f == null) {
                f1451f = new ScheduledThreadPoolExecutor(1);
            }
            scheduledThreadPoolExecutor = f1451f;
        }
        return scheduledThreadPoolExecutor;
    }

    /* renamed from: a */
    private void m3114a(RequestState currentRequestState) {
        this.f1455d = currentRequestState;
        this.f1453b.setText(currentRequestState.m3106a());
        this.f1453b.setVisibility(0);
        this.f1452a.setVisibility(8);
        this.f1456e = m3119d().schedule(new C07563(this), currentRequestState.m3109b(), TimeUnit.SECONDS);
    }
}

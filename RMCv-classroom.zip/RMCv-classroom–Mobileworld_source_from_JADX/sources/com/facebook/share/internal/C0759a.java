package com.facebook.share.internal;

import com.facebook.share.model.ShareOpenGraphAction;
import com.facebook.share.model.ShareOpenGraphObject;
import com.facebook.share.model.SharePhoto;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: OpenGraphJSONUtility */
/* renamed from: com.facebook.share.internal.a */
public final class C0759a {

    /* compiled from: OpenGraphJSONUtility */
    /* renamed from: com.facebook.share.internal.a$a */
    public interface C0758a {
        /* renamed from: a */
        JSONObject mo883a(SharePhoto sharePhoto);
    }

    /* renamed from: a */
    public static JSONObject m3124a(ShareOpenGraphAction action, C0758a photoJSONProcessor) throws JSONException {
        JSONObject result = new JSONObject();
        for (String key : action.m3161c()) {
            result.put(key, C0759a.m3122a(action.m3158a(key), photoJSONProcessor));
        }
        return result;
    }

    /* renamed from: a */
    private static JSONObject m3125a(ShareOpenGraphObject object, C0758a photoJSONProcessor) throws JSONException {
        JSONObject result = new JSONObject();
        for (String key : object.m3161c()) {
            result.put(key, C0759a.m3122a(object.m3158a(key), photoJSONProcessor));
        }
        return result;
    }

    /* renamed from: a */
    private static JSONArray m3123a(List list, C0758a photoJSONProcessor) throws JSONException {
        JSONArray result = new JSONArray();
        for (Object item : list) {
            result.put(C0759a.m3122a(item, photoJSONProcessor));
        }
        return result;
    }

    /* renamed from: a */
    public static Object m3122a(Object object, C0758a photoJSONProcessor) throws JSONException {
        if (object == null) {
            return JSONObject.NULL;
        }
        if ((object instanceof String) || (object instanceof Boolean) || (object instanceof Double) || (object instanceof Float) || (object instanceof Integer) || (object instanceof Long)) {
            return object;
        }
        if (object instanceof SharePhoto) {
            if (photoJSONProcessor != null) {
                return photoJSONProcessor.mo883a((SharePhoto) object);
            }
            return null;
        } else if (object instanceof ShareOpenGraphObject) {
            return C0759a.m3125a((ShareOpenGraphObject) object, photoJSONProcessor);
        } else {
            if (object instanceof List) {
                return C0759a.m3123a((List) object, photoJSONProcessor);
            }
            throw new IllegalArgumentException("Invalid object found for JSON serialization: " + object.toString());
        }
    }
}

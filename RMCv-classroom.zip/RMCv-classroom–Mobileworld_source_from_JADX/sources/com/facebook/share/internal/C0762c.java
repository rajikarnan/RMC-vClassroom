package com.facebook.share.internal;

import android.os.Bundle;
import com.facebook.C0699e;
import com.facebook.p014b.C0689q;
import com.facebook.share.model.ShareContent;
import com.facebook.share.model.ShareHashtag;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.model.ShareOpenGraphContent;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: WebDialogParameters */
/* renamed from: com.facebook.share.internal.c */
public class C0762c {
    /* renamed from: a */
    public static Bundle m3132a(ShareLinkContent shareLinkContent) {
        Bundle params = C0762c.m3131a((ShareContent) shareLinkContent);
        C0689q.m2769a(params, "href", shareLinkContent.m3135a());
        C0689q.m2770a(params, "quote", shareLinkContent.m3147c());
        return params;
    }

    /* renamed from: a */
    public static Bundle m3133a(ShareOpenGraphContent shareOpenGraphContent) {
        Bundle params = C0762c.m3131a((ShareContent) shareOpenGraphContent);
        C0689q.m2770a(params, "action_type", shareOpenGraphContent.m3165c().m3162a());
        try {
            JSONObject ogJSON = C0761b.m3130a(C0761b.m3129a(shareOpenGraphContent), false);
            if (ogJSON != null) {
                C0689q.m2770a(params, "action_properties", ogJSON.toString());
            }
            return params;
        } catch (JSONException e) {
            throw new C0699e("Unable to serialize the ShareOpenGraphContent to JSON", e);
        }
    }

    /* renamed from: a */
    public static Bundle m3131a(ShareContent shareContent) {
        Bundle params = new Bundle();
        ShareHashtag shareHashtag = shareContent.m3136b();
        if (shareHashtag != null) {
            C0689q.m2770a(params, "hashtag", shareHashtag.m3144a());
        }
        return params;
    }
}

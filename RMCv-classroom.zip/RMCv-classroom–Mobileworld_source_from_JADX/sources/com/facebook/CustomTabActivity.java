package com.facebook;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.content.C0204h;

public class CustomTabActivity extends Activity {
    /* renamed from: a */
    public static final String f941a = (CustomTabActivity.class.getSimpleName() + ".action_customTabRedirect");
    /* renamed from: b */
    public static final String f942b = (CustomTabActivity.class.getSimpleName() + ".action_destroy");
    /* renamed from: c */
    private BroadcastReceiver f943c;

    /* renamed from: com.facebook.CustomTabActivity$1 */
    class C05731 extends BroadcastReceiver {
        /* renamed from: a */
        final /* synthetic */ CustomTabActivity f940a;

        C05731(CustomTabActivity this$0) {
            this.f940a = this$0;
        }

        public void onReceive(Context context, Intent intent) {
            this.f940a.finish();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = new Intent(this, CustomTabMainActivity.class);
        intent.setAction(f941a);
        intent.putExtra(CustomTabMainActivity.f947c, getIntent().getDataString());
        intent.addFlags(603979776);
        startActivityForResult(intent, 2);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == 0) {
            Intent broadcast = new Intent(f941a);
            broadcast.putExtra(CustomTabMainActivity.f947c, getIntent().getDataString());
            C0204h.m758a((Context) this).m763a(broadcast);
            this.f943c = new C05731(this);
            C0204h.m758a((Context) this).m762a(this.f943c, new IntentFilter(f942b));
        }
    }

    protected void onDestroy() {
        C0204h.m758a((Context) this).m761a(this.f943c);
        super.onDestroy();
    }
}

package com.facebook;

/* compiled from: FacebookSdkNotInitializedException */
/* renamed from: com.facebook.h */
public class C0708h extends C0699e {
    public C0708h(String message) {
        super(message);
    }
}

package com.facebook.login;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.facebook.C0698c;
import com.facebook.C0699e;
import com.facebook.C0701f;
import com.facebook.C0707g;
import com.facebook.C0709i;
import com.facebook.CustomTabMainActivity;
import com.facebook.FacebookRequestError;
import com.facebook.login.LoginClient.Request;
import com.facebook.p014b.C0689q;
import com.facebook.p014b.C0689q.C0687b;
import com.facebook.p014b.C0690r;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

public class CustomTabLoginMethodHandler extends WebLoginMethodHandler {
    public static final Creator<CustomTabLoginMethodHandler> CREATOR = new C07141();
    /* renamed from: c */
    private static final String[] f1320c = new String[]{"com.android.chrome", "com.chrome.beta", "com.chrome.dev"};
    /* renamed from: d */
    private String f1321d;
    /* renamed from: e */
    private String f1322e;

    /* renamed from: com.facebook.login.CustomTabLoginMethodHandler$1 */
    static class C07141 implements Creator {
        C07141() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m2892a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m2893a(i);
        }

        /* renamed from: a */
        public CustomTabLoginMethodHandler m2892a(Parcel source) {
            return new CustomTabLoginMethodHandler(source);
        }

        /* renamed from: a */
        public CustomTabLoginMethodHandler[] m2893a(int size) {
            return new CustomTabLoginMethodHandler[size];
        }
    }

    CustomTabLoginMethodHandler(LoginClient loginClient) {
        super(loginClient);
        this.f1322e = C0689q.m2755a(20);
    }

    /* renamed from: a */
    String mo862a() {
        return "custom_tab";
    }

    C0698c a_() {
        return C0698c.CHROME_CUSTOM_TAB;
    }

    /* renamed from: c */
    protected String mo867c() {
        return "chrome_custom_tab";
    }

    /* renamed from: a */
    boolean mo865a(Request request) {
        if (!m2916e()) {
            return false;
        }
        Bundle parameters = m2910a(m2912b(request), request);
        Intent intent = new Intent(this.b.m3028b(), CustomTabMainActivity.class);
        intent.putExtra(CustomTabMainActivity.f945a, parameters);
        intent.putExtra(CustomTabMainActivity.f946b, m2918g());
        this.b.m3021a().startActivityForResult(intent, 1);
        return true;
    }

    /* renamed from: e */
    private boolean m2916e() {
        return m2917f() && m2918g() != null && C0690r.m2808a(C0707g.m2855f());
    }

    /* renamed from: f */
    private boolean m2917f() {
        C0687b settings = C0689q.m2791c(C0689q.m2756a(this.b.m3028b()));
        return settings != null && settings.m2742b();
    }

    /* renamed from: g */
    private String m2918g() {
        if (this.f1321d != null) {
            return this.f1321d;
        }
        Context context = this.b.m3028b();
        List<ResolveInfo> resolveInfos = context.getPackageManager().queryIntentServices(new Intent("android.support.customtabs.action.CustomTabsService"), 0);
        if (resolveInfos != null) {
            Set<String> chromePackages = new HashSet(Arrays.asList(f1320c));
            for (ResolveInfo resolveInfo : resolveInfos) {
                ServiceInfo serviceInfo = resolveInfo.serviceInfo;
                if (serviceInfo != null && chromePackages.contains(serviceInfo.packageName)) {
                    this.f1321d = serviceInfo.packageName;
                    return this.f1321d;
                }
            }
        }
        return null;
    }

    /* renamed from: a */
    boolean mo864a(int requestCode, int resultCode, Intent data) {
        if (requestCode != 1) {
            return super.mo864a(requestCode, resultCode, data);
        }
        Request request = this.b.m3031c();
        if (resultCode == -1) {
            m2914a(data.getStringExtra(CustomTabMainActivity.f947c), request);
            return true;
        }
        super.m2911a(request, null, new C0701f());
        return false;
    }

    /* renamed from: a */
    private void m2914a(String url, Request request) {
        if (url != null && url.startsWith(CustomTabMainActivity.m2394a())) {
            Uri uri = Uri.parse(url);
            Bundle values = C0689q.m2785b(uri.getQuery());
            values.putAll(C0689q.m2785b(uri.getFragment()));
            if (m2915a(values)) {
                String error = values.getString("error");
                if (error == null) {
                    error = values.getString("error_type");
                }
                String errorMessage = values.getString("error_msg");
                if (errorMessage == null) {
                    errorMessage = values.getString("error_message");
                }
                if (errorMessage == null) {
                    errorMessage = values.getString("error_description");
                }
                String errorCodeString = values.getString("error_code");
                int errorCode = -1;
                if (!C0689q.m2782a(errorCodeString)) {
                    try {
                        errorCode = Integer.parseInt(errorCodeString);
                    } catch (NumberFormatException e) {
                        errorCode = -1;
                    }
                }
                if (C0689q.m2782a(error) && C0689q.m2782a(errorMessage) && errorCode == -1) {
                    super.m2911a(request, values, null);
                    return;
                } else if (error != null && (error.equals("access_denied") || error.equals("OAuthAccessDeniedException"))) {
                    super.m2911a(request, null, new C0701f());
                    return;
                } else if (errorCode == 4201) {
                    super.m2911a(request, null, new C0701f());
                    return;
                } else {
                    super.m2911a(request, null, new C0709i(new FacebookRequestError(errorCode, error, errorMessage), errorMessage));
                    return;
                }
            }
            super.m2911a(request, null, new C0699e("Invalid state parameter"));
        }
    }

    /* renamed from: a */
    protected void mo863a(JSONObject param) throws JSONException {
        param.put("7_challenge", this.f1322e);
    }

    /* renamed from: a */
    private boolean m2915a(Bundle values) {
        boolean z = false;
        try {
            String stateString = values.getString("state");
            if (stateString != null) {
                z = new JSONObject(stateString).getString("7_challenge").equals(this.f1322e);
            }
        } catch (JSONException e) {
        }
        return z;
    }

    public int describeContents() {
        return 0;
    }

    CustomTabLoginMethodHandler(Parcel source) {
        super(source);
        this.f1322e = source.readString();
    }

    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(this.f1322e);
    }
}

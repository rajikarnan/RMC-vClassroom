package com.facebook.login;

import android.app.Activity;
import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.app.C0154q;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import com.facebook.AccessToken;
import com.facebook.C0699e;
import com.facebook.C0777t.C0775d;
import com.facebook.p014b.C0654e.C0653a;
import com.facebook.p014b.C0689q;
import com.facebook.p014b.C0690r;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

class LoginClient implements Parcelable {
    public static final Creator<LoginClient> CREATOR = new C07271();
    /* renamed from: a */
    LoginMethodHandler[] f1367a;
    /* renamed from: b */
    int f1368b = -1;
    /* renamed from: c */
    Fragment f1369c;
    /* renamed from: d */
    C0732b f1370d;
    /* renamed from: e */
    C0731a f1371e;
    /* renamed from: f */
    boolean f1372f;
    /* renamed from: g */
    Request f1373g;
    /* renamed from: h */
    Map<String, String> f1374h;
    /* renamed from: i */
    private C0742e f1375i;

    /* renamed from: com.facebook.login.LoginClient$1 */
    static class C07271 implements Creator {
        C07271() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m2988a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m2989a(i);
        }

        /* renamed from: a */
        public LoginClient m2988a(Parcel source) {
            return new LoginClient(source);
        }

        /* renamed from: a */
        public LoginClient[] m2989a(int size) {
            return new LoginClient[size];
        }
    }

    public static class Request implements Parcelable {
        public static final Creator<Request> CREATOR = new C07281();
        /* renamed from: a */
        private final C0738c f1349a;
        /* renamed from: b */
        private Set<String> f1350b;
        /* renamed from: c */
        private final C0736a f1351c;
        /* renamed from: d */
        private final String f1352d;
        /* renamed from: e */
        private final String f1353e;
        /* renamed from: f */
        private boolean f1354f;
        /* renamed from: g */
        private String f1355g;

        /* renamed from: com.facebook.login.LoginClient$Request$1 */
        static class C07281 implements Creator {
            C07281() {
            }

            public /* synthetic */ Object createFromParcel(Parcel parcel) {
                return m2990a(parcel);
            }

            public /* synthetic */ Object[] newArray(int i) {
                return m2991a(i);
            }

            /* renamed from: a */
            public Request m2990a(Parcel source) {
                return new Request(source);
            }

            /* renamed from: a */
            public Request[] m2991a(int size) {
                return new Request[size];
            }
        }

        /* renamed from: a */
        Set<String> m2992a() {
            return this.f1350b;
        }

        /* renamed from: a */
        void m2993a(Set<String> permissions) {
            C0690r.m2805a((Object) permissions, "permissions");
            this.f1350b = permissions;
        }

        /* renamed from: b */
        C0738c m2994b() {
            return this.f1349a;
        }

        /* renamed from: c */
        C0736a m2995c() {
            return this.f1351c;
        }

        /* renamed from: d */
        String m2996d() {
            return this.f1352d;
        }

        /* renamed from: e */
        String m2997e() {
            return this.f1353e;
        }

        /* renamed from: f */
        boolean m2998f() {
            return this.f1354f;
        }

        /* renamed from: g */
        String m2999g() {
            return this.f1355g;
        }

        /* renamed from: h */
        boolean m3000h() {
            for (String permission : this.f1350b) {
                if (C0744f.m3074a(permission)) {
                    return true;
                }
            }
            return false;
        }

        private Request(Parcel parcel) {
            C0738c valueOf;
            boolean z;
            C0736a c0736a = null;
            this.f1354f = false;
            String enumValue = parcel.readString();
            if (enumValue != null) {
                valueOf = C0738c.valueOf(enumValue);
            } else {
                valueOf = null;
            }
            this.f1349a = valueOf;
            ArrayList<String> permissionsList = new ArrayList();
            parcel.readStringList(permissionsList);
            this.f1350b = new HashSet(permissionsList);
            enumValue = parcel.readString();
            if (enumValue != null) {
                c0736a = C0736a.valueOf(enumValue);
            }
            this.f1351c = c0736a;
            this.f1352d = parcel.readString();
            this.f1353e = parcel.readString();
            if (parcel.readByte() != (byte) 0) {
                z = true;
            } else {
                z = false;
            }
            this.f1354f = z;
            this.f1355g = parcel.readString();
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel dest, int flags) {
            String str = null;
            dest.writeString(this.f1349a != null ? this.f1349a.name() : null);
            dest.writeStringList(new ArrayList(this.f1350b));
            if (this.f1351c != null) {
                str = this.f1351c.name();
            }
            dest.writeString(str);
            dest.writeString(this.f1352d);
            dest.writeString(this.f1353e);
            dest.writeByte((byte) (this.f1354f ? 1 : 0));
            dest.writeString(this.f1355g);
        }
    }

    public static class Result implements Parcelable {
        public static final Creator<Result> CREATOR = new C07291();
        /* renamed from: a */
        final C0730a f1361a;
        /* renamed from: b */
        final AccessToken f1362b;
        /* renamed from: c */
        final String f1363c;
        /* renamed from: d */
        final String f1364d;
        /* renamed from: e */
        final Request f1365e;
        /* renamed from: f */
        public Map<String, String> f1366f;

        /* renamed from: com.facebook.login.LoginClient$Result$1 */
        static class C07291 implements Creator {
            C07291() {
            }

            public /* synthetic */ Object createFromParcel(Parcel parcel) {
                return m3001a(parcel);
            }

            public /* synthetic */ Object[] newArray(int i) {
                return m3002a(i);
            }

            /* renamed from: a */
            public Result m3001a(Parcel source) {
                return new Result(source);
            }

            /* renamed from: a */
            public Result[] m3002a(int size) {
                return new Result[size];
            }
        }

        /* renamed from: com.facebook.login.LoginClient$Result$a */
        enum C0730a {
            SUCCESS("success"),
            CANCEL("cancel"),
            ERROR("error");
            
            /* renamed from: d */
            private final String f1360d;

            private C0730a(String loggingValue) {
                this.f1360d = loggingValue;
            }

            /* renamed from: a */
            String m3003a() {
                return this.f1360d;
            }
        }

        Result(Request request, C0730a code, AccessToken token, String errorMessage, String errorCode) {
            C0690r.m2805a((Object) code, "code");
            this.f1365e = request;
            this.f1362b = token;
            this.f1363c = errorMessage;
            this.f1361a = code;
            this.f1364d = errorCode;
        }

        /* renamed from: a */
        static Result m3004a(Request request, AccessToken token) {
            return new Result(request, C0730a.SUCCESS, token, null, null);
        }

        /* renamed from: a */
        static Result m3005a(Request request, String message) {
            return new Result(request, C0730a.CANCEL, null, message, null);
        }

        /* renamed from: a */
        static Result m3006a(Request request, String errorType, String errorDescription) {
            return m3007a(request, errorType, errorDescription, null);
        }

        /* renamed from: a */
        static Result m3007a(Request request, String errorType, String errorDescription, String errorCode) {
            return new Result(request, C0730a.ERROR, null, TextUtils.join(": ", C0689q.m2787b(errorType, errorDescription)), errorCode);
        }

        private Result(Parcel parcel) {
            this.f1361a = C0730a.valueOf(parcel.readString());
            this.f1362b = (AccessToken) parcel.readParcelable(AccessToken.class.getClassLoader());
            this.f1363c = parcel.readString();
            this.f1364d = parcel.readString();
            this.f1365e = (Request) parcel.readParcelable(Request.class.getClassLoader());
            this.f1366f = C0689q.m2766a(parcel);
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.f1361a.name());
            dest.writeParcelable(this.f1362b, flags);
            dest.writeString(this.f1363c);
            dest.writeString(this.f1364d);
            dest.writeParcelable(this.f1365e, flags);
            C0689q.m2771a(dest, this.f1366f);
        }
    }

    /* renamed from: com.facebook.login.LoginClient$a */
    interface C0731a {
        /* renamed from: a */
        void mo878a();

        /* renamed from: b */
        void mo879b();
    }

    /* renamed from: com.facebook.login.LoginClient$b */
    public interface C0732b {
        /* renamed from: a */
        void mo877a(Result result);
    }

    public LoginClient(Fragment fragment) {
        this.f1369c = fragment;
    }

    /* renamed from: a */
    public Fragment m3021a() {
        return this.f1369c;
    }

    /* renamed from: a */
    void m3022a(Fragment fragment) {
        if (this.f1369c != null) {
            throw new C0699e("Can't set fragment once it is already set.");
        }
        this.f1369c = fragment;
    }

    /* renamed from: b */
    C0154q m3028b() {
        return this.f1369c.getActivity();
    }

    /* renamed from: c */
    public Request m3031c() {
        return this.f1373g;
    }

    /* renamed from: d */
    public static int m3015d() {
        return C0653a.Login.m2627a();
    }

    /* renamed from: a */
    void m3023a(Request request) {
        if (!m3033e()) {
            m3029b(request);
        }
    }

    /* renamed from: b */
    void m3029b(Request request) {
        if (request != null) {
            if (this.f1373g != null) {
                throw new C0699e("Attempted to authorize while a request is pending.");
            } else if (AccessToken.m2378a() == null || m3036h()) {
                this.f1373g = request;
                this.f1367a = m3014c(request);
                m3037i();
            }
        }
    }

    /* renamed from: e */
    boolean m3033e() {
        return this.f1373g != null && this.f1368b >= 0;
    }

    /* renamed from: f */
    void m3034f() {
        if (this.f1368b >= 0) {
            m3035g().mo873b();
        }
    }

    /* renamed from: g */
    LoginMethodHandler m3035g() {
        if (this.f1368b >= 0) {
            return this.f1367a[this.f1368b];
        }
        return null;
    }

    /* renamed from: a */
    public boolean m3027a(int requestCode, int resultCode, Intent data) {
        if (this.f1373g != null) {
            return m3035g().mo864a(requestCode, resultCode, data);
        }
        return false;
    }

    /* renamed from: c */
    private LoginMethodHandler[] m3014c(Request request) {
        ArrayList<LoginMethodHandler> handlers = new ArrayList();
        C0738c behavior = request.m2994b();
        if (behavior.m3054a()) {
            handlers.add(new GetTokenLoginMethodHandler(this));
        }
        if (behavior.m3055b()) {
            handlers.add(new KatanaProxyLoginMethodHandler(this));
        }
        if (behavior.m3059f()) {
            handlers.add(new FacebookLiteLoginMethodHandler(this));
        }
        if (behavior.m3058e()) {
            handlers.add(new CustomTabLoginMethodHandler(this));
        }
        if (behavior.m3056c()) {
            handlers.add(new WebViewLoginMethodHandler(this));
        }
        if (behavior.m3057d()) {
            handlers.add(new DeviceAuthMethodHandler(this));
        }
        LoginMethodHandler[] result = new LoginMethodHandler[handlers.size()];
        handlers.toArray(result);
        return result;
    }

    /* renamed from: h */
    boolean m3036h() {
        if (this.f1372f) {
            return true;
        }
        if (m3020a("android.permission.INTERNET") != 0) {
            Activity activity = m3028b();
            m3030b(Result.m3006a(this.f1373g, activity.getString(C0775d.com_facebook_internet_permission_error_title), activity.getString(C0775d.com_facebook_internet_permission_error_message)));
            return false;
        }
        this.f1372f = true;
        return true;
    }

    /* renamed from: i */
    void m3037i() {
        if (this.f1368b >= 0) {
            m3012a(m3035g().mo862a(), "skipped", null, null, m3035g().f1317a);
        }
        while (this.f1367a != null && this.f1368b < this.f1367a.length - 1) {
            this.f1368b++;
            if (m3038j()) {
                return;
            }
        }
        if (this.f1373g != null) {
            m3018n();
        }
    }

    /* renamed from: n */
    private void m3018n() {
        m3030b(Result.m3006a(this.f1373g, "Login attempt failed.", null));
    }

    /* renamed from: a */
    private void m3013a(String key, String value, boolean accumulate) {
        if (this.f1374h == null) {
            this.f1374h = new HashMap();
        }
        if (this.f1374h.containsKey(key) && accumulate) {
            value = ((String) this.f1374h.get(key)) + "," + value;
        }
        this.f1374h.put(key, value);
    }

    /* renamed from: j */
    boolean m3038j() {
        boolean z = false;
        LoginMethodHandler handler = m3035g();
        if (!handler.mo875d() || m3036h()) {
            z = handler.mo865a(this.f1373g);
            if (z) {
                m3019o().m3069a(this.f1373g.m2997e(), handler.mo862a());
            } else {
                m3019o().m3072b(this.f1373g.m2997e(), handler.mo862a());
                m3013a("not_tried", handler.mo862a(), true);
            }
        } else {
            m3013a("no_internet_permission", "1", false);
        }
        return z;
    }

    /* renamed from: a */
    void m3024a(Result outcome) {
        if (outcome.f1362b == null || AccessToken.m2378a() == null) {
            m3030b(outcome);
        } else {
            m3032c(outcome);
        }
    }

    /* renamed from: b */
    void m3030b(Result outcome) {
        LoginMethodHandler handler = m3035g();
        if (handler != null) {
            m3011a(handler.mo862a(), outcome, handler.f1317a);
        }
        if (this.f1374h != null) {
            outcome.f1366f = this.f1374h;
        }
        this.f1367a = null;
        this.f1368b = -1;
        this.f1373g = null;
        this.f1374h = null;
        m3016d(outcome);
    }

    /* renamed from: a */
    void m3026a(C0732b onCompletedListener) {
        this.f1370d = onCompletedListener;
    }

    /* renamed from: a */
    void m3025a(C0731a backgroundProcessingListener) {
        this.f1371e = backgroundProcessingListener;
    }

    /* renamed from: a */
    int m3020a(String permission) {
        return m3028b().checkCallingOrSelfPermission(permission);
    }

    /* renamed from: c */
    void m3032c(Result pendingResult) {
        if (pendingResult.f1362b == null) {
            throw new C0699e("Can't validate without a token");
        }
        Result result;
        AccessToken previousToken = AccessToken.m2378a();
        AccessToken newToken = pendingResult.f1362b;
        if (!(previousToken == null || newToken == null)) {
            try {
                if (previousToken.m2392i().equals(newToken.m2392i())) {
                    result = Result.m3004a(this.f1373g, pendingResult.f1362b);
                    m3030b(result);
                }
            } catch (Exception ex) {
                m3030b(Result.m3006a(this.f1373g, "Caught exception", ex.getMessage()));
                return;
            }
        }
        result = Result.m3006a(this.f1373g, "User logged in as different Facebook user.", null);
        m3030b(result);
    }

    /* renamed from: o */
    private C0742e m3019o() {
        if (this.f1375i == null || !this.f1375i.m3068a().equals(this.f1373g.m2996d())) {
            this.f1375i = new C0742e(m3028b(), this.f1373g.m2996d());
        }
        return this.f1375i;
    }

    /* renamed from: d */
    private void m3016d(Result outcome) {
        if (this.f1370d != null) {
            this.f1370d.mo877a(outcome);
        }
    }

    /* renamed from: k */
    void m3039k() {
        if (this.f1371e != null) {
            this.f1371e.mo878a();
        }
    }

    /* renamed from: l */
    void m3040l() {
        if (this.f1371e != null) {
            this.f1371e.mo879b();
        }
    }

    /* renamed from: a */
    private void m3011a(String method, Result result, Map<String, String> loggingExtras) {
        m3012a(method, result.f1361a.m3003a(), result.f1363c, result.f1364d, loggingExtras);
    }

    /* renamed from: a */
    private void m3012a(String method, String result, String errorMessage, String errorCode, Map<String, String> loggingExtras) {
        if (this.f1373g == null) {
            m3019o().m3070a("fb_mobile_login_method_complete", "Unexpected call to logCompleteLogin with null pendingAuthorizationRequest.", method);
        } else {
            m3019o().m3071a(this.f1373g.m2997e(), method, result, errorMessage, errorCode, loggingExtras);
        }
    }

    /* renamed from: m */
    static String m3017m() {
        JSONObject e2e = new JSONObject();
        try {
            e2e.put("init", System.currentTimeMillis());
        } catch (JSONException e) {
        }
        return e2e.toString();
    }

    public LoginClient(Parcel source) {
        Object[] o = source.readParcelableArray(LoginMethodHandler.class.getClassLoader());
        this.f1367a = new LoginMethodHandler[o.length];
        for (int i = 0; i < o.length; i++) {
            this.f1367a[i] = (LoginMethodHandler) o[i];
            this.f1367a[i].m2899a(this);
        }
        this.f1368b = source.readInt();
        this.f1373g = (Request) source.readParcelable(Request.class.getClassLoader());
        this.f1374h = C0689q.m2766a(source);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelableArray(this.f1367a, flags);
        dest.writeInt(this.f1368b);
        dest.writeParcelable(this.f1373g, flags);
        C0689q.m2771a(dest, this.f1374h);
    }
}

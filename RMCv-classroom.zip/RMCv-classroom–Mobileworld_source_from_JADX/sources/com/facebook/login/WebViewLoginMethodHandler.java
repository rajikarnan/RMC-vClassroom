package com.facebook.login;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.app.C0154q;
import com.facebook.C0698c;
import com.facebook.C0699e;
import com.facebook.login.LoginClient.Request;
import com.facebook.p014b.C0659g;
import com.facebook.p014b.C0665s;
import com.facebook.p014b.C0665s.C0656c;
import com.facebook.p014b.C0665s.C0695a;

class WebViewLoginMethodHandler extends WebLoginMethodHandler {
    public static final Creator<WebViewLoginMethodHandler> CREATOR = new C07342();
    /* renamed from: c */
    private C0665s f1380c;
    /* renamed from: d */
    private String f1381d;

    /* renamed from: com.facebook.login.WebViewLoginMethodHandler$2 */
    static class C07342 implements Creator {
        C07342() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m3042a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m3043a(i);
        }

        /* renamed from: a */
        public WebViewLoginMethodHandler m3042a(Parcel source) {
            return new WebViewLoginMethodHandler(source);
        }

        /* renamed from: a */
        public WebViewLoginMethodHandler[] m3043a(int size) {
            return new WebViewLoginMethodHandler[size];
        }
    }

    /* renamed from: com.facebook.login.WebViewLoginMethodHandler$a */
    static class C0735a extends C0695a {
        /* renamed from: a */
        private String f1378a;
        /* renamed from: b */
        private boolean f1379b;

        public C0735a(Context context, String applicationId, Bundle parameters) {
            super(context, applicationId, "oauth", parameters);
        }

        /* renamed from: a */
        public C0735a m3045a(String e2e) {
            this.f1378a = e2e;
            return this;
        }

        /* renamed from: a */
        public C0735a m3046a(boolean isRerequest) {
            this.f1379b = isRerequest;
            return this;
        }

        /* renamed from: a */
        public C0665s mo874a() {
            Bundle parameters = m2820e();
            parameters.putString("redirect_uri", "fbconnect://success");
            parameters.putString("client_id", m2817b());
            parameters.putString("e2e", this.f1378a);
            parameters.putString("response_type", "token,signed_request");
            parameters.putString("return_scopes", "true");
            parameters.putString("auth_type", "rerequest");
            return new C0665s(m2818c(), "oauth", parameters, m2819d(), m2821f());
        }
    }

    WebViewLoginMethodHandler(LoginClient loginClient) {
        super(loginClient);
    }

    /* renamed from: a */
    String mo862a() {
        return "web_view";
    }

    C0698c a_() {
        return C0698c.WEB_VIEW;
    }

    /* renamed from: d */
    boolean mo875d() {
        return true;
    }

    /* renamed from: b */
    void mo873b() {
        if (this.f1380c != null) {
            this.f1380c.cancel();
            this.f1380c = null;
        }
    }

    /* renamed from: a */
    boolean mo865a(final Request request) {
        Bundle parameters = m2912b(request);
        C0656c listener = new C0656c(this) {
            /* renamed from: b */
            final /* synthetic */ WebViewLoginMethodHandler f1377b;

            /* renamed from: a */
            public void mo854a(Bundle values, C0699e error) {
                this.f1377b.m3050b(request, values, error);
            }
        };
        this.f1381d = LoginClient.m3017m();
        m2900a("e2e", this.f1381d);
        C0154q fragmentActivity = this.b.m3028b();
        this.f1380c = new C0735a(fragmentActivity, request.m2996d(), parameters).m3045a(this.f1381d).m3046a(request.m2998f()).m2815a(listener).mo874a();
        C0659g dialogFragment = new C0659g();
        dialogFragment.setRetainInstance(true);
        dialogFragment.m2636a(this.f1380c);
        dialogFragment.show(fragmentActivity.getSupportFragmentManager(), "FacebookDialogFragment");
        return true;
    }

    /* renamed from: b */
    void m3050b(Request request, Bundle values, C0699e error) {
        super.m2911a(request, values, error);
    }

    WebViewLoginMethodHandler(Parcel source) {
        super(source);
        this.f1381d = source.readString();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(this.f1381d);
    }
}

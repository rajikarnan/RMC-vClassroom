package com.facebook.login;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Base64;
import android.util.Log;
import com.facebook.AccessToken;
import com.facebook.C0698c;
import com.facebook.C0699e;
import com.facebook.login.LoginClient.Request;
import com.facebook.p014b.C0689q;
import com.facebook.p015a.C0618f;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

abstract class LoginMethodHandler implements Parcelable {
    /* renamed from: a */
    Map<String, String> f1317a;
    /* renamed from: b */
    protected LoginClient f1318b;

    /* renamed from: a */
    abstract String mo862a();

    /* renamed from: a */
    abstract boolean mo865a(Request request);

    LoginMethodHandler(LoginClient loginClient) {
        this.f1318b = loginClient;
    }

    LoginMethodHandler(Parcel source) {
        this.f1317a = C0689q.m2766a(source);
    }

    /* renamed from: a */
    void m2899a(LoginClient loginClient) {
        if (this.f1318b != null) {
            throw new C0699e("Can't set LoginClient if it is already set.");
        }
        this.f1318b = loginClient;
    }

    /* renamed from: a */
    boolean mo864a(int requestCode, int resultCode, Intent data) {
        return false;
    }

    /* renamed from: d */
    boolean mo875d() {
        return false;
    }

    /* renamed from: b */
    void mo873b() {
    }

    /* renamed from: a */
    void mo863a(JSONObject param) throws JSONException {
    }

    /* renamed from: a */
    protected String m2898a(String authId) {
        JSONObject param = new JSONObject();
        try {
            param.put("0_auth_logger_id", authId);
            param.put("3_method", mo862a());
            mo863a(param);
        } catch (JSONException e) {
            Log.w("LoginMethodHandler", "Error creating client state json: " + e.getMessage());
        }
        return param.toString();
    }

    /* renamed from: a */
    protected void m2900a(String key, Object value) {
        if (this.f1317a == null) {
            this.f1317a = new HashMap();
        }
        this.f1317a.put(key, value == null ? null : value.toString());
    }

    /* renamed from: b */
    protected void m2905b(String e2e) {
        String applicationId = this.f1318b.m3031c().m2996d();
        C0618f appEventsLogger = C0618f.m2559c(this.f1318b.m3028b(), applicationId);
        Bundle parameters = new Bundle();
        parameters.putString("fb_web_login_e2e", e2e);
        parameters.putLong("fb_web_login_switchback_time", System.currentTimeMillis());
        parameters.putString("app_id", applicationId);
        appEventsLogger.m2569a("fb_dialogs_web_login_dialog_complete", null, parameters);
    }

    /* renamed from: a */
    static AccessToken m2894a(Bundle bundle, C0698c source, String applicationId) {
        Date expires = C0689q.m2764a(bundle, "com.facebook.platform.extra.EXPIRES_SECONDS_SINCE_EPOCH", new Date(0));
        ArrayList<String> permissions = bundle.getStringArrayList("com.facebook.platform.extra.PERMISSIONS");
        String token = bundle.getString("com.facebook.platform.extra.ACCESS_TOKEN");
        if (C0689q.m2782a(token)) {
            return null;
        }
        return new AccessToken(token, applicationId, bundle.getString("com.facebook.platform.extra.USER_ID"), permissions, null, source, expires, new Date());
    }

    /* renamed from: a */
    public static AccessToken m2895a(Collection<String> requestedPermissions, Bundle bundle, C0698c source, String applicationId) throws C0699e {
        Date expires = C0689q.m2764a(bundle, "expires_in", new Date());
        String token = bundle.getString("access_token");
        String grantedPermissions = bundle.getString("granted_scopes");
        if (!C0689q.m2782a(grantedPermissions)) {
            requestedPermissions = new ArrayList(Arrays.asList(grantedPermissions.split(",")));
        }
        String deniedPermissions = bundle.getString("denied_scopes");
        List<String> declinedPermissions = null;
        if (!C0689q.m2782a(deniedPermissions)) {
            declinedPermissions = new ArrayList(Arrays.asList(deniedPermissions.split(",")));
        }
        if (C0689q.m2782a(token)) {
            return null;
        }
        return new AccessToken(token, applicationId, m2896c(bundle.getString("signed_request")), requestedPermissions, declinedPermissions, source, expires, new Date());
    }

    /* renamed from: c */
    private static String m2896c(String signedRequest) throws C0699e {
        if (signedRequest == null || signedRequest.isEmpty()) {
            throw new C0699e("Authorization response does not contain the signed_request");
        }
        try {
            String[] signatureAndPayload = signedRequest.split("\\.");
            if (signatureAndPayload.length == 2) {
                return new JSONObject(new String(Base64.decode(signatureAndPayload[1], 0), "UTF-8")).getString("user_id");
            }
        } catch (UnsupportedEncodingException e) {
        } catch (JSONException e2) {
        }
        throw new C0699e("Failed to retrieve user_id from signed_request");
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0689q.m2771a(dest, this.f1317a);
    }
}

package com.facebook.login;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import com.facebook.C0698c;
import com.facebook.C0699e;
import com.facebook.login.LoginClient.Request;
import com.facebook.login.LoginClient.Result;
import com.facebook.p014b.C0680n.C0679a;
import com.facebook.p014b.C0689q;
import com.facebook.p014b.C0689q.C0589c;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

class GetTokenLoginMethodHandler extends LoginMethodHandler {
    public static final Creator<GetTokenLoginMethodHandler> CREATOR = new C07253();
    /* renamed from: c */
    private C0737b f1348c;

    /* renamed from: com.facebook.login.GetTokenLoginMethodHandler$3 */
    static class C07253 implements Creator {
        C07253() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m2976a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m2977a(i);
        }

        /* renamed from: a */
        public GetTokenLoginMethodHandler m2976a(Parcel source) {
            return new GetTokenLoginMethodHandler(source);
        }

        /* renamed from: a */
        public GetTokenLoginMethodHandler[] m2977a(int size) {
            return new GetTokenLoginMethodHandler[size];
        }
    }

    GetTokenLoginMethodHandler(LoginClient loginClient) {
        super(loginClient);
    }

    /* renamed from: a */
    String mo862a() {
        return "get_token";
    }

    /* renamed from: b */
    void mo873b() {
        if (this.f1348c != null) {
            this.f1348c.m2728b();
            this.f1348c.m2726a(null);
            this.f1348c = null;
        }
    }

    /* renamed from: a */
    boolean mo865a(final Request request) {
        this.f1348c = new C0737b(this.b.m3028b(), request.m2996d());
        if (!this.f1348c.m2727a()) {
            return false;
        }
        this.b.m3039k();
        this.f1348c.m2726a(new C0679a(this) {
            /* renamed from: b */
            final /* synthetic */ GetTokenLoginMethodHandler f1344b;

            /* renamed from: a */
            public void mo872a(Bundle result) {
                this.f1344b.m2979a(request, result);
            }
        });
        return true;
    }

    /* renamed from: a */
    void m2979a(Request request, Bundle result) {
        if (this.f1348c != null) {
            this.f1348c.m2726a(null);
        }
        this.f1348c = null;
        this.b.m3040l();
        if (result != null) {
            ArrayList<String> currentPermissions = result.getStringArrayList("com.facebook.platform.extra.PERMISSIONS");
            Set<String> permissions = request.m2992a();
            if (currentPermissions == null || !(permissions == null || currentPermissions.containsAll(permissions))) {
                Set<String> newPermissions = new HashSet();
                for (String permission : permissions) {
                    if (!currentPermissions.contains(permission)) {
                        newPermissions.add(permission);
                    }
                }
                if (!newPermissions.isEmpty()) {
                    m2900a("new_permissions", TextUtils.join(",", newPermissions));
                }
                request.m2993a(newPermissions);
            } else {
                m2983c(request, result);
                return;
            }
        }
        this.b.m3037i();
    }

    /* renamed from: b */
    void m2982b(Request request, Bundle result) {
        this.b.m3024a(Result.m3004a(this.b.m3031c(), LoginMethodHandler.m2894a(result, C0698c.FACEBOOK_APPLICATION_SERVICE, request.m2996d())));
    }

    /* renamed from: c */
    void m2983c(final Request request, final Bundle result) {
        String userId = result.getString("com.facebook.platform.extra.USER_ID");
        if (userId == null || userId.isEmpty()) {
            this.b.m3039k();
            C0689q.m2773a(result.getString("com.facebook.platform.extra.ACCESS_TOKEN"), new C0589c(this) {
                /* renamed from: c */
                final /* synthetic */ GetTokenLoginMethodHandler f1347c;

                /* renamed from: a */
                public void mo851a(JSONObject userInfo) {
                    try {
                        result.putString("com.facebook.platform.extra.USER_ID", userInfo.getString("id"));
                        this.f1347c.m2982b(request, result);
                    } catch (JSONException ex) {
                        this.f1347c.b.m3030b(Result.m3006a(this.f1347c.b.m3031c(), "Caught exception", ex.getMessage()));
                    }
                }

                /* renamed from: a */
                public void mo850a(C0699e error) {
                    this.f1347c.b.m3030b(Result.m3006a(this.f1347c.b.m3031c(), "Caught exception", error.getMessage()));
                }
            });
            return;
        }
        m2982b(request, result);
    }

    GetTokenLoginMethodHandler(Parcel source) {
        super(source);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
    }
}

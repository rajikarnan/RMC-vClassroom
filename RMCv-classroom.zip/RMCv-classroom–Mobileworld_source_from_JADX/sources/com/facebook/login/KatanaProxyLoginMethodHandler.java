package com.facebook.login;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.facebook.login.LoginClient.Request;
import com.facebook.p014b.C0677m;

class KatanaProxyLoginMethodHandler extends NativeAppLoginMethodHandler {
    public static final Creator<KatanaProxyLoginMethodHandler> CREATOR = new C07261();

    /* renamed from: com.facebook.login.KatanaProxyLoginMethodHandler$1 */
    static class C07261 implements Creator {
        C07261() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m2984a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m2985a(i);
        }

        /* renamed from: a */
        public KatanaProxyLoginMethodHandler m2984a(Parcel source) {
            return new KatanaProxyLoginMethodHandler(source);
        }

        /* renamed from: a */
        public KatanaProxyLoginMethodHandler[] m2985a(int size) {
            return new KatanaProxyLoginMethodHandler[size];
        }
    }

    KatanaProxyLoginMethodHandler(LoginClient loginClient) {
        super(loginClient);
    }

    /* renamed from: a */
    String mo862a() {
        return "katana_proxy_auth";
    }

    /* renamed from: a */
    boolean mo865a(Request request) {
        String e2e = LoginClient.m3017m();
        Intent intent = C0677m.m2711b(this.b.m3028b(), request.m2996d(), request.m2992a(), e2e, request.m2998f(), request.m3000h(), request.m2995c(), m2898a(request.m2997e()));
        m2900a("e2e", e2e);
        return m2969a(intent, LoginClient.m3015d());
    }

    KatanaProxyLoginMethodHandler(Parcel source) {
        super(source);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
    }
}

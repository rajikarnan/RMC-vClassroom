package com.facebook.login;

/* compiled from: DefaultAudience */
/* renamed from: com.facebook.login.a */
public enum C0736a {
    NONE(null),
    ONLY_ME("only_me"),
    FRIENDS("friends"),
    EVERYONE("everyone");
    
    /* renamed from: e */
    private final String f1387e;

    private C0736a(String protocol) {
        this.f1387e = protocol;
    }

    /* renamed from: a */
    public String m3052a() {
        return this.f1387e;
    }
}

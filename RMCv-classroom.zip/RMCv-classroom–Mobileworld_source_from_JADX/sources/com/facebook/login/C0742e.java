package com.facebook.login;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import com.facebook.login.LoginClient.Result.C0730a;
import com.facebook.p015a.C0618f;
import java.util.Map;
import org.json.JSONObject;

/* compiled from: LoginLogger */
/* renamed from: com.facebook.login.e */
class C0742e {
    /* renamed from: a */
    private final C0618f f1407a;
    /* renamed from: b */
    private String f1408b;
    /* renamed from: c */
    private String f1409c;

    C0742e(Context context, String applicationId) {
        this.f1408b = applicationId;
        this.f1407a = C0618f.m2559c(context, applicationId);
        try {
            PackageManager packageManager = context.getPackageManager();
            if (packageManager != null) {
                PackageInfo facebookInfo = packageManager.getPackageInfo("com.facebook.katana", 0);
                if (facebookInfo != null) {
                    this.f1409c = facebookInfo.versionName;
                }
            }
        } catch (NameNotFoundException e) {
        }
    }

    /* renamed from: a */
    public String m3068a() {
        return this.f1408b;
    }

    /* renamed from: a */
    static Bundle m3067a(String authLoggerId) {
        Bundle bundle = new Bundle();
        bundle.putLong("1_timestamp_ms", System.currentTimeMillis());
        bundle.putString("0_auth_logger_id", authLoggerId);
        bundle.putString("3_method", "");
        bundle.putString("2_result", "");
        bundle.putString("5_error_message", "");
        bundle.putString("4_error_code", "");
        bundle.putString("6_extras", "");
        return bundle;
    }

    /* renamed from: a */
    public void m3069a(String authId, String method) {
        Bundle bundle = C0742e.m3067a(authId);
        bundle.putString("3_method", method);
        this.f1407a.m2569a("fb_mobile_login_method_start", null, bundle);
    }

    /* renamed from: a */
    public void m3071a(String authId, String method, String result, String errorMessage, String errorCode, Map<String, String> loggingExtras) {
        Bundle bundle = C0742e.m3067a(authId);
        if (result != null) {
            bundle.putString("2_result", result);
        }
        if (errorMessage != null) {
            bundle.putString("5_error_message", errorMessage);
        }
        if (errorCode != null) {
            bundle.putString("4_error_code", errorCode);
        }
        if (!(loggingExtras == null || loggingExtras.isEmpty())) {
            bundle.putString("6_extras", new JSONObject(loggingExtras).toString());
        }
        bundle.putString("3_method", method);
        this.f1407a.m2569a("fb_mobile_login_method_complete", null, bundle);
    }

    /* renamed from: b */
    public void m3072b(String authId, String method) {
        Bundle bundle = C0742e.m3067a(authId);
        bundle.putString("3_method", method);
        this.f1407a.m2569a("fb_mobile_login_method_not_tried", null, bundle);
    }

    /* renamed from: a */
    public void m3070a(String eventName, String errorMessage, String method) {
        Bundle bundle = C0742e.m3067a("");
        bundle.putString("2_result", C0730a.ERROR.m3003a());
        bundle.putString("5_error_message", errorMessage);
        bundle.putString("3_method", method);
        this.f1407a.m2569a(eventName, null, bundle);
    }
}

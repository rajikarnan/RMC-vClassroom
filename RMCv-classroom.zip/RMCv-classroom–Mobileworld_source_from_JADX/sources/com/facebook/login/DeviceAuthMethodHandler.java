package com.facebook.login;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.facebook.AccessToken;
import com.facebook.C0698c;
import com.facebook.login.LoginClient.Request;
import com.facebook.login.LoginClient.Result;
import java.util.Collection;
import java.util.Date;
import java.util.concurrent.ScheduledThreadPoolExecutor;

class DeviceAuthMethodHandler extends LoginMethodHandler {
    public static final Creator<DeviceAuthMethodHandler> CREATOR = new C07211();
    /* renamed from: c */
    private static ScheduledThreadPoolExecutor f1342c;

    /* renamed from: com.facebook.login.DeviceAuthMethodHandler$1 */
    static class C07211 implements Creator {
        C07211() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m2954a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m2955a(i);
        }

        /* renamed from: a */
        public DeviceAuthMethodHandler m2954a(Parcel source) {
            return new DeviceAuthMethodHandler(source);
        }

        /* renamed from: a */
        public DeviceAuthMethodHandler[] m2955a(int size) {
            return new DeviceAuthMethodHandler[size];
        }
    }

    DeviceAuthMethodHandler(LoginClient loginClient) {
        super(loginClient);
    }

    /* renamed from: a */
    boolean mo865a(Request request) {
        m2956b(request);
        return true;
    }

    /* renamed from: b */
    private void m2956b(Request request) {
        DeviceAuthDialog dialog = new DeviceAuthDialog();
        dialog.show(this.b.m3028b().getSupportFragmentManager(), "login_with_facebook");
        dialog.m2953a(request);
    }

    public void b_() {
        this.b.m3024a(Result.m3005a(this.b.m3031c(), "User canceled log in."));
    }

    /* renamed from: a */
    public void m2959a(Exception ex) {
        this.b.m3024a(Result.m3006a(this.b.m3031c(), null, ex.getMessage()));
    }

    /* renamed from: a */
    public void m2960a(String accessToken, String applicationId, String userId, Collection<String> permissions, Collection<String> declinedPermissions, C0698c accessTokenSource, Date expirationTime, Date lastRefreshTime) {
        this.b.m3024a(Result.m3004a(this.b.m3031c(), new AccessToken(accessToken, applicationId, userId, permissions, declinedPermissions, accessTokenSource, expirationTime, lastRefreshTime)));
    }

    /* renamed from: c */
    public static synchronized ScheduledThreadPoolExecutor m2957c() {
        ScheduledThreadPoolExecutor scheduledThreadPoolExecutor;
        synchronized (DeviceAuthMethodHandler.class) {
            if (f1342c == null) {
                f1342c = new ScheduledThreadPoolExecutor(1);
            }
            scheduledThreadPoolExecutor = f1342c;
        }
        return scheduledThreadPoolExecutor;
    }

    protected DeviceAuthMethodHandler(Parcel parcel) {
        super(parcel);
    }

    /* renamed from: a */
    String mo862a() {
        return "device_auth";
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
    }
}

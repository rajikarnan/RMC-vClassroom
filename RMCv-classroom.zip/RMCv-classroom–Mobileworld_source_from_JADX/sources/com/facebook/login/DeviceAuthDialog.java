package com.facebook.login;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.app.C0149p;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.facebook.AccessToken;
import com.facebook.C0698c;
import com.facebook.C0699e;
import com.facebook.C0707g;
import com.facebook.C0710j;
import com.facebook.C0713l;
import com.facebook.C0745m;
import com.facebook.C0777t.C0773b;
import com.facebook.C0777t.C0774c;
import com.facebook.C0777t.C0775d;
import com.facebook.C0777t.C0776e;
import com.facebook.FacebookActivity;
import com.facebook.FacebookRequestError;
import com.facebook.GraphRequest;
import com.facebook.GraphRequest.C0578b;
import com.facebook.login.LoginClient.Request;
import com.facebook.p014b.C0689q;
import com.facebook.p014b.C0689q.C0688d;
import com.facebook.p014b.C0690r;
import java.util.Date;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONObject;

public class DeviceAuthDialog extends C0149p {
    /* renamed from: a */
    private ProgressBar f1333a;
    /* renamed from: b */
    private TextView f1334b;
    /* renamed from: c */
    private DeviceAuthMethodHandler f1335c;
    /* renamed from: d */
    private AtomicBoolean f1336d = new AtomicBoolean();
    /* renamed from: e */
    private volatile C0710j f1337e;
    /* renamed from: f */
    private volatile ScheduledFuture f1338f;
    /* renamed from: g */
    private volatile RequestState f1339g;
    /* renamed from: h */
    private Dialog f1340h;
    /* renamed from: i */
    private boolean f1341i = false;

    /* renamed from: com.facebook.login.DeviceAuthDialog$1 */
    class C07151 implements OnClickListener {
        /* renamed from: a */
        final /* synthetic */ DeviceAuthDialog f1323a;

        C07151(DeviceAuthDialog this$0) {
            this.f1323a = this$0;
        }

        public void onClick(View v) {
            this.f1323a.m2949d();
        }
    }

    /* renamed from: com.facebook.login.DeviceAuthDialog$2 */
    class C07162 implements C0578b {
        /* renamed from: a */
        final /* synthetic */ DeviceAuthDialog f1324a;

        C07162(DeviceAuthDialog this$0) {
            this.f1324a = this$0;
        }

        /* renamed from: a */
        public void mo848a(C0713l response) {
            if (response.m2890a() != null) {
                this.f1324a.m2938a(response.m2890a().m2408f());
                return;
            }
            JSONObject jsonObject = response.m2891b();
            RequestState requestState = new RequestState();
            try {
                requestState.m2931a(jsonObject.getString("user_code"));
                requestState.m2934b(jsonObject.getString("code"));
                requestState.m2930a(jsonObject.getLong("interval"));
                this.f1324a.m2939a(requestState);
            } catch (Throwable ex) {
                this.f1324a.m2938a(new C0699e(ex));
            }
        }
    }

    /* renamed from: com.facebook.login.DeviceAuthDialog$3 */
    class C07173 implements Runnable {
        /* renamed from: a */
        final /* synthetic */ DeviceAuthDialog f1325a;

        C07173(DeviceAuthDialog this$0) {
            this.f1325a = this$0;
        }

        public void run() {
            this.f1325a.m2937a();
        }
    }

    /* renamed from: com.facebook.login.DeviceAuthDialog$4 */
    class C07184 implements C0578b {
        /* renamed from: a */
        final /* synthetic */ DeviceAuthDialog f1326a;

        C07184(DeviceAuthDialog this$0) {
            this.f1326a = this$0;
        }

        /* renamed from: a */
        public void mo848a(C0713l response) {
            if (!this.f1326a.f1336d.get()) {
                FacebookRequestError error = response.m2890a();
                if (error != null) {
                    switch (error.m2405c()) {
                        case 1349152:
                        case 1349173:
                            this.f1326a.m2949d();
                            return;
                        case 1349172:
                        case 1349174:
                            this.f1326a.m2945b();
                            return;
                        default:
                            this.f1326a.m2938a(response.m2890a().m2408f());
                            return;
                    }
                }
                try {
                    this.f1326a.m2944a(response.m2891b().getString("access_token"));
                } catch (Throwable ex) {
                    this.f1326a.m2938a(new C0699e(ex));
                }
            }
        }
    }

    private static class RequestState implements Parcelable {
        public static final Creator<RequestState> CREATOR = new C07201();
        /* renamed from: a */
        private String f1329a;
        /* renamed from: b */
        private String f1330b;
        /* renamed from: c */
        private long f1331c;
        /* renamed from: d */
        private long f1332d;

        /* renamed from: com.facebook.login.DeviceAuthDialog$RequestState$1 */
        static class C07201 implements Creator<RequestState> {
            C07201() {
            }

            public /* synthetic */ Object createFromParcel(Parcel parcel) {
                return m2927a(parcel);
            }

            public /* synthetic */ Object[] newArray(int i) {
                return m2928a(i);
            }

            /* renamed from: a */
            public RequestState m2927a(Parcel in) {
                return new RequestState(in);
            }

            /* renamed from: a */
            public RequestState[] m2928a(int size) {
                return new RequestState[size];
            }
        }

        RequestState() {
        }

        /* renamed from: a */
        public String m2929a() {
            return this.f1329a;
        }

        /* renamed from: a */
        public void m2931a(String userCode) {
            this.f1329a = userCode;
        }

        /* renamed from: b */
        public String m2932b() {
            return this.f1330b;
        }

        /* renamed from: b */
        public void m2934b(String requestCode) {
            this.f1330b = requestCode;
        }

        /* renamed from: c */
        public long m2935c() {
            return this.f1331c;
        }

        /* renamed from: a */
        public void m2930a(long interval) {
            this.f1331c = interval;
        }

        /* renamed from: b */
        public void m2933b(long lastPoll) {
            this.f1332d = lastPoll;
        }

        protected RequestState(Parcel in) {
            this.f1329a = in.readString();
            this.f1330b = in.readString();
            this.f1331c = in.readLong();
            this.f1332d = in.readLong();
        }

        /* renamed from: d */
        public boolean m2936d() {
            if (this.f1332d != 0 && (new Date().getTime() - this.f1332d) - (this.f1331c * 1000) < 0) {
                return true;
            }
            return false;
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.f1329a);
            dest.writeString(this.f1330b);
            dest.writeLong(this.f1331c);
            dest.writeLong(this.f1332d);
        }
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = super.onCreateView(inflater, container, savedInstanceState);
        this.f1335c = (DeviceAuthMethodHandler) ((C0741d) ((FacebookActivity) getActivity()).m2397a()).m3066a().m3035g();
        if (savedInstanceState != null) {
            RequestState requestState = (RequestState) savedInstanceState.getParcelable("request_state");
            if (requestState != null) {
                m2939a(requestState);
            }
        }
        return view;
    }

    public Dialog onCreateDialog(Bundle savedInstanceState) {
        this.f1340h = new Dialog(getActivity(), C0776e.com_facebook_auth_dialog);
        View view = getActivity().getLayoutInflater().inflate(C0774c.com_facebook_device_auth_dialog_fragment, null);
        this.f1333a = (ProgressBar) view.findViewById(C0773b.progress_bar);
        this.f1334b = (TextView) view.findViewById(C0773b.confirmation_code);
        ((Button) view.findViewById(C0773b.cancel_button)).setOnClickListener(new C07151(this));
        ((TextView) view.findViewById(C0773b.com_facebook_device_auth_instructions)).setText(Html.fromHtml(getString(C0775d.com_facebook_device_auth_instructions)));
        this.f1340h.setContentView(view);
        return this.f1340h;
    }

    public void onDismiss(DialogInterface dialog) {
        super.onDismiss(dialog);
        if (!this.f1341i) {
            m2949d();
        }
    }

    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (this.f1339g != null) {
            outState.putParcelable("request_state", this.f1339g);
        }
    }

    public void onDestroy() {
        this.f1341i = true;
        this.f1336d.set(true);
        super.onDestroy();
        if (this.f1337e != null) {
            this.f1337e.cancel(true);
        }
        if (this.f1338f != null) {
            this.f1338f.cancel(true);
        }
    }

    /* renamed from: a */
    public void m2953a(Request request) {
        Bundle parameters = new Bundle();
        parameters.putString("scope", TextUtils.join(",", request.m2992a()));
        String redirectUriString = request.m2999g();
        if (redirectUriString != null) {
            parameters.putString("redirect_uri", redirectUriString);
        }
        parameters.putString("access_token", C0690r.m2809b() + "|" + C0690r.m2812c());
        new GraphRequest(null, "device/login", parameters, C0745m.POST, new C07162(this)).m2487j();
    }

    /* renamed from: a */
    private void m2939a(RequestState currentRequestState) {
        this.f1339g = currentRequestState;
        this.f1334b.setText(currentRequestState.m2929a());
        this.f1334b.setVisibility(0);
        this.f1333a.setVisibility(8);
        if (currentRequestState.m2936d()) {
            m2945b();
        } else {
            m2937a();
        }
    }

    /* renamed from: a */
    private void m2937a() {
        this.f1339g.m2933b(new Date().getTime());
        this.f1337e = m2947c().m2487j();
    }

    /* renamed from: b */
    private void m2945b() {
        this.f1338f = DeviceAuthMethodHandler.m2957c().schedule(new C07173(this), this.f1339g.m2935c(), TimeUnit.SECONDS);
    }

    /* renamed from: c */
    private GraphRequest m2947c() {
        Bundle parameters = new Bundle();
        parameters.putString("code", this.f1339g.m2932b());
        return new GraphRequest(null, "device/login_status", parameters, C0745m.POST, new C07184(this));
    }

    /* renamed from: a */
    private void m2944a(final String accessToken) {
        Bundle parameters = new Bundle();
        parameters.putString("fields", "id,permissions");
        new GraphRequest(new AccessToken(accessToken, C0707g.m2858i(), "0", null, null, null, null, null), "me", parameters, C0745m.GET, new C0578b(this) {
            /* renamed from: b */
            final /* synthetic */ DeviceAuthDialog f1328b;

            /* renamed from: a */
            public void mo848a(C0713l response) {
                if (!this.f1328b.f1336d.get()) {
                    if (response.m2890a() != null) {
                        this.f1328b.m2938a(response.m2890a().m2408f());
                        return;
                    }
                    try {
                        JSONObject jsonObject = response.m2891b();
                        String userId = jsonObject.getString("id");
                        C0688d permissions = C0689q.m2752a(jsonObject);
                        this.f1328b.f1335c.m2960a(accessToken, C0707g.m2858i(), userId, permissions.m2744a(), permissions.m2745b(), C0698c.DEVICE_AUTH, null, null);
                        this.f1328b.f1340h.dismiss();
                    } catch (Throwable ex) {
                        this.f1328b.m2938a(new C0699e(ex));
                    }
                }
            }
        }).m2487j();
    }

    /* renamed from: a */
    private void m2938a(C0699e ex) {
        if (this.f1336d.compareAndSet(false, true)) {
            this.f1335c.m2959a((Exception) ex);
            this.f1340h.dismiss();
        }
    }

    /* renamed from: d */
    private void m2949d() {
        if (this.f1336d.compareAndSet(false, true)) {
            if (this.f1335c != null) {
                this.f1335c.b_();
            }
            this.f1340h.dismiss();
        }
    }
}

package com.facebook.login;

import android.content.Context;
import android.os.Bundle;
import com.facebook.p014b.C0680n;

/* compiled from: GetTokenClient */
/* renamed from: com.facebook.login.b */
final class C0737b extends C0680n {
    C0737b(Context context, String applicationId) {
        super(context, 65536, 65537, 20121101, applicationId);
    }

    /* renamed from: a */
    protected void mo876a(Bundle data) {
    }
}

package com.facebook.login;

import android.os.Bundle;
import android.os.Parcel;
import android.text.TextUtils;
import android.webkit.CookieSyncManager;
import com.facebook.AccessToken;
import com.facebook.C0698c;
import com.facebook.C0699e;
import com.facebook.C0701f;
import com.facebook.C0707g;
import com.facebook.C0709i;
import com.facebook.login.LoginClient.Request;
import com.facebook.login.LoginClient.Result;
import com.facebook.p014b.C0689q;
import java.util.Locale;

abstract class WebLoginMethodHandler extends LoginMethodHandler {
    /* renamed from: c */
    private String f1319c;

    abstract C0698c a_();

    /* renamed from: e */
    private static final String m2908e() {
        return "fb" + C0707g.m2858i() + "://authorize";
    }

    WebLoginMethodHandler(LoginClient loginClient) {
        super(loginClient);
    }

    WebLoginMethodHandler(Parcel source) {
        super(source);
    }

    /* renamed from: c */
    protected String mo867c() {
        return null;
    }

    /* renamed from: b */
    protected Bundle m2912b(Request request) {
        Bundle parameters = new Bundle();
        if (!C0689q.m2783a(request.m2992a())) {
            String scope = TextUtils.join(",", request.m2992a());
            parameters.putString("scope", scope);
            m2900a("scope", scope);
        }
        parameters.putString("default_audience", request.m2995c().m3052a());
        parameters.putString("state", m2898a(request.m2997e()));
        AccessToken previousToken = AccessToken.m2378a();
        String previousTokenString = previousToken != null ? previousToken.m2385b() : null;
        if (previousTokenString == null || !previousTokenString.equals(m2909f())) {
            C0689q.m2789b(this.b.m3028b());
            m2900a("access_token", "0");
        } else {
            parameters.putString("access_token", previousTokenString);
            m2900a("access_token", "1");
        }
        return parameters;
    }

    /* renamed from: a */
    protected Bundle m2910a(Bundle parameters, Request request) {
        parameters.putString("redirect_uri", m2908e());
        parameters.putString("client_id", request.m2996d());
        LoginClient loginClient = this.b;
        parameters.putString("e2e", LoginClient.m3017m());
        parameters.putString("response_type", "token,signed_request");
        parameters.putString("return_scopes", "true");
        parameters.putString("auth_type", "rerequest");
        if (mo867c() != null) {
            parameters.putString("sso", mo867c());
        }
        return parameters;
    }

    /* renamed from: a */
    protected void m2911a(Request request, Bundle values, C0699e error) {
        Result outcome;
        this.f1319c = null;
        if (values != null) {
            if (values.containsKey("e2e")) {
                this.f1319c = values.getString("e2e");
            }
            try {
                AccessToken token = LoginMethodHandler.m2895a(request.m2992a(), values, a_(), request.m2996d());
                outcome = Result.m3004a(this.b.m3031c(), token);
                CookieSyncManager.createInstance(this.b.m3028b()).sync();
                m2907c(token.m2385b());
            } catch (C0699e ex) {
                outcome = Result.m3006a(this.b.m3031c(), null, ex.getMessage());
            }
        } else if (error instanceof C0701f) {
            outcome = Result.m3005a(this.b.m3031c(), "User canceled log in.");
        } else {
            this.f1319c = null;
            String errorCode = null;
            String errorMessage = error.getMessage();
            if (error instanceof C0709i) {
                errorCode = String.format(Locale.ROOT, "%d", new Object[]{Integer.valueOf(((C0709i) error).m2863a().m2404b())});
                errorMessage = requestError.toString();
            }
            outcome = Result.m3007a(this.b.m3031c(), null, errorMessage, errorCode);
        }
        if (!C0689q.m2782a(this.f1319c)) {
            m2905b(this.f1319c);
        }
        this.b.m3024a(outcome);
    }

    /* renamed from: f */
    private String m2909f() {
        return this.b.m3028b().getSharedPreferences("com.facebook.login.AuthorizationClient.WebViewAuthHandler.TOKEN_STORE_KEY", 0).getString("TOKEN", "");
    }

    /* renamed from: c */
    private void m2907c(String token) {
        this.b.m3028b().getSharedPreferences("com.facebook.login.AuthorizationClient.WebViewAuthHandler.TOKEN_STORE_KEY", 0).edit().putString("TOKEN", token).apply();
    }
}

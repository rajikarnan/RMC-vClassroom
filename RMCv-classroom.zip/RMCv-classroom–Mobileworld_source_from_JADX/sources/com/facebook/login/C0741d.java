package com.facebook.login;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.facebook.C0777t.C0773b;
import com.facebook.C0777t.C0774c;
import com.facebook.login.LoginClient.C0731a;
import com.facebook.login.LoginClient.C0732b;
import com.facebook.login.LoginClient.Request;
import com.facebook.login.LoginClient.Result;
import com.facebook.login.LoginClient.Result.C0730a;

/* compiled from: LoginFragment */
/* renamed from: com.facebook.login.d */
public class C0741d extends Fragment {
    /* renamed from: a */
    private String f1404a;
    /* renamed from: b */
    private LoginClient f1405b;
    /* renamed from: c */
    private Request f1406c;

    /* compiled from: LoginFragment */
    /* renamed from: com.facebook.login.d$1 */
    class C07391 implements C0732b {
        /* renamed from: a */
        final /* synthetic */ C0741d f1401a;

        C07391(C0741d this$0) {
            this.f1401a = this$0;
        }

        /* renamed from: a */
        public void mo877a(Result outcome) {
            this.f1401a.m3064a(outcome);
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            this.f1405b = (LoginClient) savedInstanceState.getParcelable("loginClient");
            this.f1405b.m3022a((Fragment) this);
        } else {
            this.f1405b = new LoginClient((Fragment) this);
        }
        this.f1405b.m3026a(new C07391(this));
        Activity activity = getActivity();
        if (activity != null) {
            m3063a(activity);
            if (activity.getIntent() != null) {
                this.f1406c = (Request) activity.getIntent().getBundleExtra("com.facebook.LoginFragment:Request").getParcelable("request");
            }
        }
    }

    public void onDestroy() {
        this.f1405b.m3034f();
        super.onDestroy();
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(C0774c.com_facebook_login_fragment, container, false);
        this.f1405b.m3025a(new C0731a(this) {
            /* renamed from: b */
            final /* synthetic */ C0741d f1403b;

            /* renamed from: a */
            public void mo878a() {
                view.findViewById(C0773b.com_facebook_login_activity_progress_bar).setVisibility(0);
            }

            /* renamed from: b */
            public void mo879b() {
                view.findViewById(C0773b.com_facebook_login_activity_progress_bar).setVisibility(8);
            }
        });
        return view;
    }

    /* renamed from: a */
    private void m3064a(Result outcome) {
        this.f1406c = null;
        int resultCode = outcome.f1361a == C0730a.CANCEL ? 0 : -1;
        Bundle bundle = new Bundle();
        bundle.putParcelable("com.facebook.LoginFragment:Result", outcome);
        Intent resultIntent = new Intent();
        resultIntent.putExtras(bundle);
        if (isAdded()) {
            getActivity().setResult(resultCode, resultIntent);
            getActivity().finish();
        }
    }

    public void onResume() {
        super.onResume();
        if (this.f1404a == null) {
            Log.e("LoginFragment", "Cannot call LoginFragment with a null calling package. This can occur if the launchMode of the caller is singleInstance.");
            getActivity().finish();
            return;
        }
        this.f1405b.m3023a(this.f1406c);
    }

    public void onPause() {
        super.onPause();
        getActivity().findViewById(C0773b.com_facebook_login_activity_progress_bar).setVisibility(8);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        this.f1405b.m3027a(requestCode, resultCode, data);
    }

    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelable("loginClient", this.f1405b);
    }

    /* renamed from: a */
    private void m3063a(Activity activity) {
        ComponentName componentName = activity.getCallingActivity();
        if (componentName != null) {
            this.f1404a = componentName.getPackageName();
        }
    }

    /* renamed from: a */
    LoginClient m3066a() {
        return this.f1405b;
    }
}

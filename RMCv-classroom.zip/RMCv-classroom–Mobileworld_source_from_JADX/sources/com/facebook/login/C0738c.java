package com.facebook.login;

/* compiled from: LoginBehavior */
/* renamed from: com.facebook.login.c */
public enum C0738c {
    NATIVE_WITH_FALLBACK(true, true, true, false, true, true),
    NATIVE_ONLY(true, true, false, false, false, true),
    KATANA_ONLY(false, true, false, false, false, false),
    WEB_ONLY(false, false, true, false, true, false),
    WEB_VIEW_ONLY(false, false, true, false, false, false),
    DEVICE_AUTH(false, false, false, true, false, false);
    
    /* renamed from: g */
    private final boolean f1395g;
    /* renamed from: h */
    private final boolean f1396h;
    /* renamed from: i */
    private final boolean f1397i;
    /* renamed from: j */
    private final boolean f1398j;
    /* renamed from: k */
    private final boolean f1399k;
    /* renamed from: l */
    private final boolean f1400l;

    private C0738c(boolean allowsGetTokenAuth, boolean allowsKatanaAuth, boolean allowsWebViewAuth, boolean allowsDeviceAuth, boolean allowsCustomTabAuth, boolean allowsFacebookLiteAuth) {
        this.f1395g = allowsGetTokenAuth;
        this.f1396h = allowsKatanaAuth;
        this.f1397i = allowsWebViewAuth;
        this.f1398j = allowsDeviceAuth;
        this.f1399k = allowsCustomTabAuth;
        this.f1400l = allowsFacebookLiteAuth;
    }

    /* renamed from: a */
    boolean m3054a() {
        return this.f1395g;
    }

    /* renamed from: b */
    boolean m3055b() {
        return this.f1396h;
    }

    /* renamed from: c */
    boolean m3056c() {
        return this.f1397i;
    }

    /* renamed from: d */
    boolean m3057d() {
        return this.f1398j;
    }

    /* renamed from: e */
    boolean m3058e() {
        return this.f1399k;
    }

    /* renamed from: f */
    boolean m3059f() {
        return this.f1400l;
    }
}

package com.facebook.login;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcel;
import com.facebook.C0698c;
import com.facebook.C0699e;
import com.facebook.login.LoginClient.Request;
import com.facebook.login.LoginClient.Result;
import com.facebook.p014b.C0682p;
import com.facebook.p014b.C0689q;

abstract class NativeAppLoginMethodHandler extends LoginMethodHandler {
    /* renamed from: a */
    abstract boolean mo865a(Request request);

    NativeAppLoginMethodHandler(LoginClient loginClient) {
        super(loginClient);
    }

    NativeAppLoginMethodHandler(Parcel source) {
        super(source);
    }

    /* renamed from: a */
    boolean mo864a(int requestCode, int resultCode, Intent data) {
        Result outcome;
        Request request = this.b.m3031c();
        if (data == null) {
            outcome = Result.m3005a(request, "Operation canceled");
        } else if (resultCode == 0) {
            outcome = m2966b(request, data);
        } else if (resultCode != -1) {
            outcome = Result.m3006a(request, "Unexpected resultCode from authorization.", null);
        } else {
            outcome = m2964a(request, data);
        }
        if (outcome != null) {
            this.b.m3024a(outcome);
        } else {
            this.b.m3037i();
        }
        return true;
    }

    /* renamed from: a */
    private Result m2964a(Request request, Intent data) {
        String str = null;
        Bundle extras = data.getExtras();
        String error = m2965a(extras);
        String errorCode = extras.getString("error_code");
        String errorMessage = m2967b(extras);
        String e2e = extras.getString("e2e");
        if (!C0689q.m2782a(e2e)) {
            m2905b(e2e);
        }
        if (error == null && errorCode == null && errorMessage == null) {
            try {
                return Result.m3004a(request, LoginMethodHandler.m2895a(request.m2992a(), extras, C0698c.FACEBOOK_APPLICATION_WEB, request.m2996d()));
            } catch (C0699e ex) {
                return Result.m3006a(request, str, ex.getMessage());
            }
        } else if (C0682p.f1213a.contains(error)) {
            return str;
        } else {
            if (C0682p.f1214b.contains(error)) {
                return Result.m3005a(request, str);
            }
            return Result.m3007a(request, error, errorMessage, errorCode);
        }
    }

    /* renamed from: b */
    private Result m2966b(Request request, Intent data) {
        Bundle extras = data.getExtras();
        String error = m2965a(extras);
        String errorCode = extras.getString("error_code");
        if ("CONNECTION_FAILURE".equals(errorCode)) {
            return Result.m3007a(request, error, m2967b(extras), errorCode);
        }
        return Result.m3005a(request, error);
    }

    /* renamed from: a */
    private String m2965a(Bundle extras) {
        String error = extras.getString("error");
        if (error == null) {
            return extras.getString("error_type");
        }
        return error;
    }

    /* renamed from: b */
    private String m2967b(Bundle extras) {
        String errorMessage = extras.getString("error_message");
        if (errorMessage == null) {
            return extras.getString("error_description");
        }
        return errorMessage;
    }

    /* renamed from: a */
    protected boolean m2969a(Intent intent, int requestCode) {
        if (intent == null) {
            return false;
        }
        try {
            this.b.m3021a().startActivityForResult(intent, requestCode);
            return true;
        } catch (ActivityNotFoundException e) {
            return false;
        }
    }
}

package com.facebook.login;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/* compiled from: LoginManager */
/* renamed from: com.facebook.login.f */
public class C0744f {
    /* renamed from: a */
    private static final Set<String> f1410a = C0744f.m3073a();

    /* compiled from: LoginManager */
    /* renamed from: com.facebook.login.f$1 */
    static class C07431 extends HashSet<String> {
        C07431() {
            add("ads_management");
            add("create_event");
            add("rsvp_event");
        }
    }

    /* renamed from: a */
    static boolean m3074a(String permission) {
        return permission != null && (permission.startsWith("publish") || permission.startsWith("manage") || f1410a.contains(permission));
    }

    /* renamed from: a */
    private static Set<String> m3073a() {
        return Collections.unmodifiableSet(new C07431());
    }
}

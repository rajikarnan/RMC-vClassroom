package com.facebook.p014b;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ResolveInfo;
import android.content.pm.Signature;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import com.facebook.C0699e;
import com.facebook.C0701f;
import com.facebook.C0707g;
import com.facebook.login.C0736a;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

/* compiled from: NativeProtocol */
/* renamed from: com.facebook.b.m */
public final class C0677m {
    /* renamed from: a */
    private static final String f1197a = C0677m.class.getName();
    /* renamed from: b */
    private static List<C0672d> f1198b = C0677m.m2719e();
    /* renamed from: c */
    private static Map<String, List<C0672d>> f1199c = C0677m.m2720f();
    /* renamed from: d */
    private static AtomicBoolean f1200d = new AtomicBoolean(false);
    /* renamed from: e */
    private static final List<Integer> f1201e = Arrays.asList(new Integer[]{Integer.valueOf(20160327), Integer.valueOf(20141218), Integer.valueOf(20141107), Integer.valueOf(20141028), Integer.valueOf(20141001), Integer.valueOf(20140701), Integer.valueOf(20140324), Integer.valueOf(20140204), Integer.valueOf(20131107), Integer.valueOf(20130618), Integer.valueOf(20130502), Integer.valueOf(20121101)});

    /* compiled from: NativeProtocol */
    /* renamed from: com.facebook.b.m$1 */
    static class C06711 implements Runnable {
        C06711() {
        }

        public void run() {
            try {
                for (C0672d appInfo : C0677m.f1198b) {
                    appInfo.m2682a(true);
                }
            } finally {
                C0677m.f1200d.set(false);
            }
        }
    }

    /* compiled from: NativeProtocol */
    /* renamed from: com.facebook.b.m$d */
    private static abstract class C0672d {
        /* renamed from: a */
        private static final HashSet<String> f1195a = C0672d.m2683d();
        /* renamed from: b */
        private TreeSet<Integer> f1196b;

        /* renamed from: a */
        protected abstract String mo859a();

        /* renamed from: b */
        protected abstract String mo860b();

        private C0672d() {
        }

        /* renamed from: d */
        private static HashSet<String> m2683d() {
            HashSet<String> set = new HashSet();
            set.add("8a3c4b262d721acd49a4bf97d5213199c86fa2b9");
            set.add("a4b7452e2ed8f5f191058ca7bbfd26b0d3214bfc");
            set.add("5e8f16062ea3cd2c4a0d547876baa6f38cabf625");
            return set;
        }

        /* renamed from: a */
        public boolean m2685a(Context context, String packageName) {
            String brand = Build.BRAND;
            int applicationFlags = context.getApplicationInfo().flags;
            if (brand.startsWith("generic") && (applicationFlags & 2) != 0) {
                return true;
            }
            try {
                PackageInfo packageInfo = context.getPackageManager().getPackageInfo(packageName, 64);
                if (packageInfo.signatures == null || packageInfo.signatures.length <= 0) {
                    return false;
                }
                for (Signature signature : packageInfo.signatures) {
                    if (!f1195a.contains(C0689q.m2760a(signature.toByteArray()))) {
                        return false;
                    }
                }
                return true;
            } catch (NameNotFoundException e) {
                return false;
            }
        }

        /* renamed from: c */
        public TreeSet<Integer> m2687c() {
            if (this.f1196b == null) {
                m2682a(false);
            }
            return this.f1196b;
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        /* renamed from: a */
        private synchronized void m2682a(boolean r2) {
            /*
            r1 = this;
            monitor-enter(r1);
            if (r2 != 0) goto L_0x0007;
        L_0x0003:
            r0 = r1.f1196b;	 Catch:{ all -> 0x000f }
            if (r0 != 0) goto L_0x000d;
        L_0x0007:
            r0 = com.facebook.p014b.C0677m.m2712b(r1);	 Catch:{ all -> 0x000f }
            r1.f1196b = r0;	 Catch:{ all -> 0x000f }
        L_0x000d:
            monitor-exit(r1);
            return;
        L_0x000f:
            r0 = move-exception;
            monitor-exit(r1);
            throw r0;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facebook.b.m.d.a(boolean):void");
        }
    }

    /* compiled from: NativeProtocol */
    /* renamed from: com.facebook.b.m$a */
    private static class C0673a extends C0672d {
        private C0673a() {
            super();
        }

        /* renamed from: a */
        protected String mo859a() {
            return "com.facebook.lite";
        }

        /* renamed from: b */
        protected String mo860b() {
            return "com.facebook.lite.platform.LoginGDPDialogActivity";
        }
    }

    /* compiled from: NativeProtocol */
    /* renamed from: com.facebook.b.m$b */
    private static class C0674b extends C0672d {
        private C0674b() {
            super();
        }

        /* renamed from: a */
        protected String mo859a() {
            return "com.facebook.katana";
        }

        /* renamed from: b */
        protected String mo860b() {
            return "com.facebook.katana.ProxyAuth";
        }
    }

    /* compiled from: NativeProtocol */
    /* renamed from: com.facebook.b.m$c */
    private static class C0675c extends C0672d {
        private C0675c() {
            super();
        }

        /* renamed from: a */
        protected String mo859a() {
            return "com.facebook.orca";
        }

        /* renamed from: b */
        protected String mo860b() {
            return null;
        }
    }

    /* compiled from: NativeProtocol */
    /* renamed from: com.facebook.b.m$e */
    private static class C0676e extends C0672d {
        private C0676e() {
            super();
        }

        /* renamed from: a */
        protected String mo859a() {
            return "com.facebook.wakizashi";
        }

        /* renamed from: b */
        protected String mo860b() {
            return "com.facebook.katana.ProxyAuth";
        }
    }

    /* renamed from: e */
    private static List<C0672d> m2719e() {
        List<C0672d> list = new ArrayList();
        list.add(new C0674b());
        list.add(new C0676e());
        return list;
    }

    /* renamed from: f */
    private static Map<String, List<C0672d>> m2720f() {
        Map<String, List<C0672d>> map = new HashMap();
        ArrayList<C0672d> messengerAppInfoList = new ArrayList();
        messengerAppInfoList.add(new C0675c());
        map.put("com.facebook.platform.action.request.OGACTIONPUBLISH_DIALOG", f1198b);
        map.put("com.facebook.platform.action.request.FEED_DIALOG", f1198b);
        map.put("com.facebook.platform.action.request.LIKE_DIALOG", f1198b);
        map.put("com.facebook.platform.action.request.APPINVITES_DIALOG", f1198b);
        map.put("com.facebook.platform.action.request.MESSAGE_DIALOG", messengerAppInfoList);
        map.put("com.facebook.platform.action.request.OGMESSAGEPUBLISH_DIALOG", messengerAppInfoList);
        return map;
    }

    /* renamed from: a */
    static Intent m2701a(Context context, Intent intent, C0672d appInfo) {
        if (intent == null) {
            return null;
        }
        ResolveInfo resolveInfo = context.getPackageManager().resolveActivity(intent, 0);
        if (resolveInfo == null) {
            return null;
        }
        if (appInfo.m2685a(context, resolveInfo.activityInfo.packageName)) {
            return intent;
        }
        return null;
    }

    /* renamed from: b */
    static Intent m2710b(Context context, Intent intent, C0672d appInfo) {
        if (intent == null) {
            return null;
        }
        ResolveInfo resolveInfo = context.getPackageManager().resolveService(intent, 0);
        if (resolveInfo == null) {
            return null;
        }
        if (appInfo.m2685a(context, resolveInfo.serviceInfo.packageName)) {
            return intent;
        }
        return null;
    }

    /* renamed from: a */
    public static Intent m2702a(Context context, String applicationId, Collection<String> permissions, String e2e, boolean isRerequest, boolean isForPublish, C0736a defaultAudience, String clientState) {
        C0672d appInfo = new C0673a();
        return C0677m.m2701a(context, C0677m.m2704a(appInfo, applicationId, (Collection) permissions, e2e, isRerequest, isForPublish, defaultAudience, clientState), appInfo);
    }

    /* renamed from: a */
    private static Intent m2704a(C0672d appInfo, String applicationId, Collection<String> permissions, String e2e, boolean isRerequest, boolean isForPublish, C0736a defaultAudience, String clientState) {
        String activityName = appInfo.mo860b();
        if (activityName == null) {
            return null;
        }
        Intent intent = new Intent().setClassName(appInfo.mo859a(), activityName).putExtra("client_id", applicationId);
        if (!C0689q.m2783a((Collection) permissions)) {
            intent.putExtra("scope", TextUtils.join(",", permissions));
        }
        if (!C0689q.m2782a(e2e)) {
            intent.putExtra("e2e", e2e);
        }
        intent.putExtra("state", clientState);
        intent.putExtra("response_type", "token,signed_request");
        intent.putExtra("return_scopes", "true");
        if (isForPublish) {
            intent.putExtra("default_audience", defaultAudience.m3052a());
        }
        intent.putExtra("legacy_override", "v2.7");
        intent.putExtra("auth_type", "rerequest");
        return intent;
    }

    /* renamed from: b */
    public static Intent m2711b(Context context, String applicationId, Collection<String> permissions, String e2e, boolean isRerequest, boolean isForPublish, C0736a defaultAudience, String clientState) {
        for (C0672d appInfo : f1198b) {
            Intent intent = C0677m.m2701a(context, C0677m.m2704a(appInfo, applicationId, (Collection) permissions, e2e, isRerequest, isForPublish, defaultAudience, clientState), appInfo);
            if (intent != null) {
                return intent;
            }
        }
        return null;
    }

    /* renamed from: a */
    public static final int m2696a() {
        return ((Integer) f1201e.get(0)).intValue();
    }

    /* renamed from: a */
    public static boolean m2708a(int version) {
        return f1201e.contains(Integer.valueOf(version)) && version >= 20140701;
    }

    /* renamed from: a */
    public static Intent m2703a(Intent requestIntent, Bundle results, C0699e error) {
        UUID callId = C0677m.m2713b(requestIntent);
        if (callId == null) {
            return null;
        }
        Intent resultIntent = new Intent();
        resultIntent.putExtra("com.facebook.platform.protocol.PROTOCOL_VERSION", C0677m.m2697a(requestIntent));
        Bundle bridgeArguments = new Bundle();
        bridgeArguments.putString("action_id", callId.toString());
        if (error != null) {
            bridgeArguments.putBundle("error", C0677m.m2705a(error));
        }
        resultIntent.putExtra("com.facebook.platform.protocol.BRIDGE_ARGS", bridgeArguments);
        if (results == null) {
            return resultIntent;
        }
        resultIntent.putExtra("com.facebook.platform.protocol.RESULT_ARGS", results);
        return resultIntent;
    }

    /* renamed from: a */
    public static Intent m2700a(Context context) {
        for (C0672d appInfo : f1198b) {
            Intent intent = C0677m.m2710b(context, new Intent("com.facebook.platform.PLATFORM_SERVICE").setPackage(appInfo.mo859a()).addCategory("android.intent.category.DEFAULT"), appInfo);
            if (intent != null) {
                return intent;
            }
        }
        return null;
    }

    /* renamed from: a */
    public static int m2697a(Intent intent) {
        return intent.getIntExtra("com.facebook.platform.protocol.PROTOCOL_VERSION", 0);
    }

    /* renamed from: b */
    public static UUID m2713b(Intent intent) {
        if (intent == null) {
            return null;
        }
        String callIdString = null;
        if (C0677m.m2708a(C0677m.m2697a(intent))) {
            Bundle bridgeArgs = intent.getBundleExtra("com.facebook.platform.protocol.BRIDGE_ARGS");
            if (bridgeArgs != null) {
                callIdString = bridgeArgs.getString("action_id");
            }
        } else {
            callIdString = intent.getStringExtra("com.facebook.platform.protocol.CALL_ID");
        }
        UUID callId = null;
        if (callIdString == null) {
            return callId;
        }
        try {
            return UUID.fromString(callIdString);
        } catch (IllegalArgumentException e) {
            return callId;
        }
    }

    /* renamed from: c */
    public static Bundle m2716c(Intent intent) {
        if (C0677m.m2708a(C0677m.m2697a(intent))) {
            return intent.getBundleExtra("com.facebook.platform.protocol.METHOD_ARGS");
        }
        return intent.getExtras();
    }

    /* renamed from: a */
    public static C0699e m2706a(Bundle errorData) {
        if (errorData == null) {
            return null;
        }
        String type = errorData.getString("error_type");
        if (type == null) {
            type = errorData.getString("com.facebook.platform.status.ERROR_TYPE");
        }
        String description = errorData.getString("error_description");
        if (description == null) {
            description = errorData.getString("com.facebook.platform.status.ERROR_DESCRIPTION");
        }
        if (type == null || !type.equalsIgnoreCase("UserCanceled")) {
            return new C0699e(description);
        }
        return new C0701f(description);
    }

    /* renamed from: a */
    public static Bundle m2705a(C0699e e) {
        if (e == null) {
            return null;
        }
        Bundle errorBundle = new Bundle();
        errorBundle.putString("error_description", e.toString());
        if (!(e instanceof C0701f)) {
            return errorBundle;
        }
        errorBundle.putString("error_type", "UserCanceled");
        return errorBundle;
    }

    /* renamed from: b */
    public static int m2709b(int minimumVersion) {
        return C0677m.m2698a(f1198b, new int[]{minimumVersion});
    }

    /* renamed from: a */
    private static int m2698a(List<C0672d> appInfoList, int[] versionSpec) {
        C0677m.m2714b();
        if (appInfoList == null) {
            return -1;
        }
        for (C0672d appInfo : appInfoList) {
            int protocolVersion = C0677m.m2699a(appInfo.m2687c(), C0677m.m2696a(), versionSpec);
            if (protocolVersion != -1) {
                return protocolVersion;
            }
        }
        return -1;
    }

    /* renamed from: b */
    public static void m2714b() {
        if (f1200d.compareAndSet(false, true)) {
            C0707g.m2853d().execute(new C06711());
        }
    }

    /* renamed from: b */
    private static TreeSet<Integer> m2712b(C0672d appInfo) {
        TreeSet<Integer> allAvailableVersions = new TreeSet();
        ContentResolver contentResolver = C0707g.m2855f().getContentResolver();
        String[] projection = new String[]{"version"};
        Uri uri = C0677m.m2715c(appInfo);
        Cursor c = null;
        if (C0707g.m2855f().getPackageManager().resolveContentProvider(appInfo.mo859a() + ".provider.PlatformProvider", 0) != null) {
            try {
                c = contentResolver.query(uri, projection, null, null, null);
            } catch (NullPointerException e) {
                try {
                    Log.e(f1197a, "Failed to query content resolver.");
                    c = null;
                    if (c != null) {
                        while (c.moveToNext()) {
                            allAvailableVersions.add(Integer.valueOf(c.getInt(c.getColumnIndex("version"))));
                        }
                    }
                    if (c != null) {
                        c.close();
                    }
                    return allAvailableVersions;
                } catch (Throwable th) {
                    if (c != null) {
                        c.close();
                    }
                }
            } catch (SecurityException e2) {
                Log.e(f1197a, "Failed to query content resolver.");
                c = null;
                if (c != null) {
                    while (c.moveToNext()) {
                        allAvailableVersions.add(Integer.valueOf(c.getInt(c.getColumnIndex("version"))));
                    }
                }
                if (c != null) {
                    c.close();
                }
                return allAvailableVersions;
            }
            if (c != null) {
                while (c.moveToNext()) {
                    allAvailableVersions.add(Integer.valueOf(c.getInt(c.getColumnIndex("version"))));
                }
            }
        }
        if (c != null) {
            c.close();
        }
        return allAvailableVersions;
    }

    /* renamed from: a */
    public static int m2699a(TreeSet<Integer> allAvailableFacebookAppVersions, int latestSdkVersion, int[] versionSpec) {
        int versionSpecIndex = versionSpec.length - 1;
        Iterator<Integer> fbAppVersionsIterator = allAvailableFacebookAppVersions.descendingIterator();
        int latestFacebookAppVersion = -1;
        while (fbAppVersionsIterator.hasNext()) {
            int fbAppVersion = ((Integer) fbAppVersionsIterator.next()).intValue();
            latestFacebookAppVersion = Math.max(latestFacebookAppVersion, fbAppVersion);
            while (versionSpecIndex >= 0 && versionSpec[versionSpecIndex] > fbAppVersion) {
                versionSpecIndex--;
            }
            if (versionSpecIndex < 0) {
                return -1;
            }
            if (versionSpec[versionSpecIndex] == fbAppVersion) {
                return versionSpecIndex % 2 == 0 ? Math.min(latestFacebookAppVersion, latestSdkVersion) : -1;
            }
        }
        return -1;
    }

    /* renamed from: c */
    private static Uri m2715c(C0672d appInfo) {
        return Uri.parse("content://" + appInfo.mo859a() + ".provider.PlatformProvider/versions");
    }
}

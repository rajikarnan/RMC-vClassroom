package com.facebook.p014b;

import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONObject;

/* compiled from: ProfileInformationCache */
/* renamed from: com.facebook.b.o */
class C0681o {
    /* renamed from: a */
    private static final ConcurrentHashMap<String, JSONObject> f1212a = new ConcurrentHashMap();

    /* renamed from: a */
    public static JSONObject m2729a(String accessToken) {
        return (JSONObject) f1212a.get(accessToken);
    }

    /* renamed from: a */
    public static void m2730a(String key, JSONObject value) {
        f1212a.put(key, value);
    }
}

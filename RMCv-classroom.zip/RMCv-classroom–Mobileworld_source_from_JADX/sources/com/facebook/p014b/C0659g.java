package com.facebook.p014b;

import android.app.Dialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.C0149p;
import android.support.v4.app.C0154q;
import com.facebook.C0699e;
import com.facebook.C0707g;
import com.facebook.p014b.C0665s.C0656c;
import com.facebook.p014b.C0665s.C0695a;

/* compiled from: FacebookDialogFragment */
/* renamed from: com.facebook.b.g */
public class C0659g extends C0149p {
    /* renamed from: a */
    private Dialog f1163a;

    /* compiled from: FacebookDialogFragment */
    /* renamed from: com.facebook.b.g$1 */
    class C06571 implements C0656c {
        /* renamed from: a */
        final /* synthetic */ C0659g f1161a;

        C06571(C0659g this$0) {
            this.f1161a = this$0;
        }

        /* renamed from: a */
        public void mo854a(Bundle values, C0699e error) {
            this.f1161a.m2633a(values, error);
        }
    }

    /* compiled from: FacebookDialogFragment */
    /* renamed from: com.facebook.b.g$2 */
    class C06582 implements C0656c {
        /* renamed from: a */
        final /* synthetic */ C0659g f1162a;

        C06582(C0659g this$0) {
            this.f1162a = this$0;
        }

        /* renamed from: a */
        public void mo854a(Bundle values, C0699e error) {
            this.f1162a.m2632a(values);
        }
    }

    /* renamed from: a */
    public void m2636a(Dialog dialog) {
        this.f1163a = dialog;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (this.f1163a == null) {
            C0665s webDialog;
            C0154q activity = getActivity();
            Bundle params = C0677m.m2716c(activity.getIntent());
            if (params.getBoolean("is_fallback", false)) {
                String url = params.getString("url");
                if (C0689q.m2782a(url)) {
                    C0689q.m2775a("FacebookDialogFragment", "Cannot start a fallback WebDialog with an empty/missing 'url'");
                    activity.finish();
                    return;
                }
                webDialog = new C0666i(activity, url, String.format("fb%s://bridge/", new Object[]{C0707g.m2858i()}));
                webDialog.m2655a(new C06582(this));
            } else {
                String actionName = params.getString("action");
                Bundle webParams = params.getBundle("params");
                if (C0689q.m2782a(actionName)) {
                    C0689q.m2775a("FacebookDialogFragment", "Cannot start a WebDialog with an empty/missing 'actionName'");
                    activity.finish();
                    return;
                }
                webDialog = new C0695a(activity, actionName, webParams).m2815a(new C06571(this)).mo874a();
            }
            this.f1163a = webDialog;
        }
    }

    public Dialog onCreateDialog(Bundle savedInstanceState) {
        if (this.f1163a == null) {
            m2633a(null, null);
            setShowsDialog(false);
        }
        return this.f1163a;
    }

    public void onResume() {
        super.onResume();
        if (this.f1163a instanceof C0665s) {
            ((C0665s) this.f1163a).m2661d();
        }
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if ((this.f1163a instanceof C0665s) && isResumed()) {
            ((C0665s) this.f1163a).m2661d();
        }
    }

    public void onDestroyView() {
        if (getDialog() != null && getRetainInstance()) {
            getDialog().setDismissMessage(null);
        }
        super.onDestroyView();
    }

    /* renamed from: a */
    private void m2633a(Bundle values, C0699e error) {
        C0154q fragmentActivity = getActivity();
        fragmentActivity.setResult(error == null ? -1 : 0, C0677m.m2703a(fragmentActivity.getIntent(), values, error));
        fragmentActivity.finish();
    }

    /* renamed from: a */
    private void m2632a(Bundle values) {
        C0154q fragmentActivity = getActivity();
        Intent resultIntent = new Intent();
        if (values == null) {
            values = new Bundle();
        }
        resultIntent.putExtras(values);
        fragmentActivity.setResult(-1, resultIntent);
        fragmentActivity.finish();
    }
}

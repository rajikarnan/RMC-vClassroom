package com.facebook.p014b;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.content.C0204h;
import com.facebook.p015a.C0618f;

/* compiled from: BoltsMeasurementEventListener */
/* renamed from: com.facebook.b.c */
public class C0643c extends BroadcastReceiver {
    /* renamed from: a */
    private static C0643c f1145a;
    /* renamed from: b */
    private Context f1146b;

    private C0643c(Context context) {
        this.f1146b = context.getApplicationContext();
    }

    /* renamed from: a */
    private void m2616a() {
        C0204h.m758a(this.f1146b).m762a(this, new IntentFilter("com.parse.bolts.measurement_event"));
    }

    /* renamed from: b */
    private void m2617b() {
        C0204h.m758a(this.f1146b).m761a((BroadcastReceiver) this);
    }

    /* renamed from: a */
    public static C0643c m2615a(Context context) {
        if (f1145a != null) {
            return f1145a;
        }
        f1145a = new C0643c(context);
        f1145a.m2616a();
        return f1145a;
    }

    protected void finalize() throws Throwable {
        try {
            m2617b();
        } finally {
            super.finalize();
        }
    }

    public void onReceive(Context context, Intent intent) {
        C0618f appEventsLogger = C0618f.m2558c(context);
        String eventName = "bf_" + intent.getStringExtra("event_name");
        Bundle eventArgs = intent.getBundleExtra("event_args");
        Bundle logData = new Bundle();
        for (String key : eventArgs.keySet()) {
            logData.putString(key.replaceAll("[^0-9a-zA-Z _-]", "-").replaceAll("^[ -]*", "").replaceAll("[ -]*$", ""), (String) eventArgs.get(key));
        }
        appEventsLogger.m2568a(eventName, logData);
    }
}

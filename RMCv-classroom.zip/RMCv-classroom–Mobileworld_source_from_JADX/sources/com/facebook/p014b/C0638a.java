package com.facebook.p014b;

import android.content.Context;
import android.support.v4.app.ag;
import com.facebook.C0747o;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: AppEventsLoggerUtility */
/* renamed from: com.facebook.b.a */
public class C0638a {
    /* renamed from: a */
    private static final Map<C0637a, String> f1134a = new C06361();

    /* compiled from: AppEventsLoggerUtility */
    /* renamed from: com.facebook.b.a$1 */
    static class C06361 extends HashMap<C0637a, String> {
        C06361() {
            put(C0637a.MOBILE_INSTALL_EVENT, "MOBILE_APP_INSTALL");
            put(C0637a.CUSTOM_APP_EVENTS, "CUSTOM_APP_EVENTS");
        }
    }

    /* compiled from: AppEventsLoggerUtility */
    /* renamed from: com.facebook.b.a$a */
    public enum C0637a {
        MOBILE_INSTALL_EVENT,
        CUSTOM_APP_EVENTS
    }

    /* renamed from: a */
    public static JSONObject m2601a(C0637a activityType, C0642b attributionIdentifiers, String anonymousAppDeviceGUID, boolean limitEventUsage, Context context) throws JSONException {
        JSONObject publishParams = new JSONObject();
        publishParams.put(ag.CATEGORY_EVENT, f1134a.get(activityType));
        C0689q.m2779a(publishParams, attributionIdentifiers, anonymousAppDeviceGUID, limitEventUsage);
        try {
            C0689q.m2778a(publishParams, context);
        } catch (Exception e) {
            C0670l.m2671a(C0747o.APP_EVENTS, "AppEvents", "Fetching extended device info parameters failed: '%s'", e.toString());
        }
        publishParams.put("application_package_name", context.getPackageName());
        return publishParams;
    }
}

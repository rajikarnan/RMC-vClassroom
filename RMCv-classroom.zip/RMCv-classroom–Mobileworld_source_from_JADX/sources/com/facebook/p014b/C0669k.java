package com.facebook.p014b;

import com.facebook.C0707g;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.FutureTask;

/* compiled from: LockOnGetVariable */
/* renamed from: com.facebook.b.k */
public class C0669k<T> {
    /* renamed from: a */
    private T f1188a;
    /* renamed from: b */
    private CountDownLatch f1189b = new CountDownLatch(1);

    public C0669k(final Callable<T> callable) {
        C0707g.m2853d().execute(new FutureTask(new Callable<Void>(this) {
            /* renamed from: b */
            final /* synthetic */ C0669k f1187b;

            public /* synthetic */ Object call() throws Exception {
                return m2665a();
            }

            /* renamed from: a */
            public Void m2665a() throws Exception {
                try {
                    this.f1187b.f1188a = callable.call();
                    return null;
                } finally {
                    this.f1187b.f1189b.countDown();
                }
            }
        }));
    }
}

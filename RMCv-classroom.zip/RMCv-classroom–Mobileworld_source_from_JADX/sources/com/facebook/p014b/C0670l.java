package com.facebook.p014b;

import android.util.Log;
import com.facebook.C0707g;
import com.facebook.C0747o;
import java.util.HashMap;
import java.util.Map.Entry;

/* compiled from: Logger */
/* renamed from: com.facebook.b.l */
public class C0670l {
    /* renamed from: a */
    private static final HashMap<String, String> f1190a = new HashMap();
    /* renamed from: b */
    private final C0747o f1191b;
    /* renamed from: c */
    private final String f1192c;
    /* renamed from: d */
    private StringBuilder f1193d;
    /* renamed from: e */
    private int f1194e = 3;

    /* renamed from: a */
    public static synchronized void m2673a(String original, String replace) {
        synchronized (C0670l.class) {
            f1190a.put(original, replace);
        }
    }

    /* renamed from: a */
    public static synchronized void m2672a(String accessToken) {
        synchronized (C0670l.class) {
            if (!C0707g.m2847a(C0747o.INCLUDE_ACCESS_TOKENS)) {
                C0670l.m2673a(accessToken, "ACCESS_TOKEN_REMOVED");
            }
        }
    }

    /* renamed from: a */
    public static void m2670a(C0747o behavior, String tag, String string) {
        C0670l.m2668a(behavior, 3, tag, string);
    }

    /* renamed from: a */
    public static void m2671a(C0747o behavior, String tag, String format, Object... args) {
        if (C0707g.m2847a(behavior)) {
            C0670l.m2668a(behavior, 3, tag, String.format(format, args));
        }
    }

    /* renamed from: a */
    public static void m2669a(C0747o behavior, int priority, String tag, String format, Object... args) {
        if (C0707g.m2847a(behavior)) {
            C0670l.m2668a(behavior, priority, tag, String.format(format, args));
        }
    }

    /* renamed from: a */
    public static void m2668a(C0747o behavior, int priority, String tag, String string) {
        if (C0707g.m2847a(behavior)) {
            string = C0670l.m2675d(string);
            if (!tag.startsWith("FacebookSDK.")) {
                tag = "FacebookSDK." + tag;
            }
            Log.println(priority, tag, string);
            if (behavior == C0747o.DEVELOPER_ERRORS) {
                new Exception().printStackTrace();
            }
        }
    }

    /* renamed from: d */
    private static synchronized String m2675d(String string) {
        synchronized (C0670l.class) {
            for (Entry<String, String> entry : f1190a.entrySet()) {
                string = string.replace((CharSequence) entry.getKey(), (CharSequence) entry.getValue());
            }
        }
        return string;
    }

    public C0670l(C0747o behavior, String tag) {
        C0690r.m2806a(tag, "tag");
        this.f1191b = behavior;
        this.f1192c = "FacebookSDK." + tag;
        this.f1193d = new StringBuilder();
    }

    /* renamed from: a */
    public void m2676a() {
        m2679b(this.f1193d.toString());
        this.f1193d = new StringBuilder();
    }

    /* renamed from: b */
    public void m2679b(String string) {
        C0670l.m2668a(this.f1191b, this.f1194e, this.f1192c, string);
    }

    /* renamed from: c */
    public void m2680c(String string) {
        if (m2674b()) {
            this.f1193d.append(string);
        }
    }

    /* renamed from: a */
    public void m2678a(String format, Object... args) {
        if (m2674b()) {
            this.f1193d.append(String.format(format, args));
        }
    }

    /* renamed from: a */
    public void m2677a(String key, Object value) {
        m2678a("  %s:\t%s\n", key, value);
    }

    /* renamed from: b */
    private boolean m2674b() {
        return C0707g.m2847a(this.f1191b);
    }
}

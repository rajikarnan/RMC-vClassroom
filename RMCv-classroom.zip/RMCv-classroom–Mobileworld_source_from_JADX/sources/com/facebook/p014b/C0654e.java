package com.facebook.p014b;

import com.facebook.C0707g;
import java.util.HashMap;
import java.util.Map;

/* compiled from: CallbackManagerImpl */
/* renamed from: com.facebook.b.e */
public final class C0654e {
    /* renamed from: a */
    private static Map<Integer, Object> f1159a = new HashMap();

    /* compiled from: CallbackManagerImpl */
    /* renamed from: com.facebook.b.e$a */
    public enum C0653a {
        Login(0),
        Share(1),
        Message(2),
        Like(3),
        GameRequest(4),
        AppGroupCreate(5),
        AppGroupJoin(6),
        AppInvite(7),
        DeviceShare(8);
        
        /* renamed from: j */
        private final int f1158j;

        private C0653a(int offset) {
            this.f1158j = offset;
        }

        /* renamed from: a */
        public int m2627a() {
            return C0707g.m2861l() + this.f1158j;
        }
    }
}

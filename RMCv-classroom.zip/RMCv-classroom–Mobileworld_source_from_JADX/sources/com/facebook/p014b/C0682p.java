package com.facebook.p014b;

import com.facebook.C0707g;
import java.util.Collection;

/* compiled from: ServerProtocol */
/* renamed from: com.facebook.b.p */
public final class C0682p {
    /* renamed from: a */
    public static final Collection<String> f1213a = C0689q.m2763a("service_disabled", "AndroidAuthKillSwitchException");
    /* renamed from: b */
    public static final Collection<String> f1214b = C0689q.m2763a("access_denied", "OAuthAccessDeniedException");
    /* renamed from: c */
    private static final String f1215c = C0682p.class.getName();

    /* renamed from: a */
    public static final String m2731a() {
        return String.format("m.%s", new Object[]{C0707g.m2854e()});
    }

    /* renamed from: b */
    public static final String m2732b() {
        return String.format("https://graph.%s", new Object[]{C0707g.m2854e()});
    }

    /* renamed from: c */
    public static final String m2733c() {
        return String.format("https://graph-video.%s", new Object[]{C0707g.m2854e()});
    }

    /* renamed from: d */
    public static final String m2734d() {
        return "v2.7";
    }
}

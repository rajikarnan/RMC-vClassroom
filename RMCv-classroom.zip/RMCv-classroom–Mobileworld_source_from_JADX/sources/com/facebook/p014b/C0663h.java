package com.facebook.p014b;

import com.facebook.FacebookRequestError.C0576a;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

/* compiled from: FacebookRequestErrorClassification */
/* renamed from: com.facebook.b.h */
public final class C0663h {
    /* renamed from: g */
    private static C0663h f1165g;
    /* renamed from: a */
    private final Map<Integer, Set<Integer>> f1166a;
    /* renamed from: b */
    private final Map<Integer, Set<Integer>> f1167b;
    /* renamed from: c */
    private final Map<Integer, Set<Integer>> f1168c;
    /* renamed from: d */
    private final String f1169d;
    /* renamed from: e */
    private final String f1170e;
    /* renamed from: f */
    private final String f1171f;

    /* compiled from: FacebookRequestErrorClassification */
    /* renamed from: com.facebook.b.h$1 */
    static class C06601 extends HashMap<Integer, Set<Integer>> {
        C06601() {
            put(Integer.valueOf(2), null);
            put(Integer.valueOf(4), null);
            put(Integer.valueOf(9), null);
            put(Integer.valueOf(17), null);
            put(Integer.valueOf(341), null);
        }
    }

    /* compiled from: FacebookRequestErrorClassification */
    /* renamed from: com.facebook.b.h$2 */
    static class C06612 extends HashMap<Integer, Set<Integer>> {
        C06612() {
            put(Integer.valueOf(102), null);
            put(Integer.valueOf(190), null);
        }
    }

    C0663h(Map<Integer, Set<Integer>> otherErrors, Map<Integer, Set<Integer>> transientErrors, Map<Integer, Set<Integer>> loginRecoverableErrors, String otherRecoveryMessage, String transientRecoveryMessage, String loginRecoverableRecoveryMessage) {
        this.f1166a = otherErrors;
        this.f1167b = transientErrors;
        this.f1168c = loginRecoverableErrors;
        this.f1169d = otherRecoveryMessage;
        this.f1170e = transientRecoveryMessage;
        this.f1171f = loginRecoverableRecoveryMessage;
    }

    /* renamed from: a */
    public String m2642a(C0576a category) {
        switch (category) {
            case OTHER:
                return this.f1169d;
            case LOGIN_RECOVERABLE:
                return this.f1171f;
            case TRANSIENT:
                return this.f1170e;
            default:
                return null;
        }
    }

    /* renamed from: a */
    public C0576a m2641a(int errorCode, int errorSubCode, boolean isTransient) {
        if (isTransient) {
            return C0576a.TRANSIENT;
        }
        Set<Integer> subCodes;
        if (this.f1166a != null && this.f1166a.containsKey(Integer.valueOf(errorCode))) {
            subCodes = (Set) this.f1166a.get(Integer.valueOf(errorCode));
            if (subCodes == null || subCodes.contains(Integer.valueOf(errorSubCode))) {
                return C0576a.OTHER;
            }
        }
        if (this.f1168c != null && this.f1168c.containsKey(Integer.valueOf(errorCode))) {
            subCodes = (Set) this.f1168c.get(Integer.valueOf(errorCode));
            if (subCodes == null || subCodes.contains(Integer.valueOf(errorSubCode))) {
                return C0576a.LOGIN_RECOVERABLE;
            }
        }
        if (this.f1167b != null && this.f1167b.containsKey(Integer.valueOf(errorCode))) {
            subCodes = (Set) this.f1167b.get(Integer.valueOf(errorCode));
            if (subCodes == null || subCodes.contains(Integer.valueOf(errorSubCode))) {
                return C0576a.TRANSIENT;
            }
        }
        return C0576a.OTHER;
    }

    /* renamed from: a */
    public static synchronized C0663h m2637a() {
        C0663h c0663h;
        synchronized (C0663h.class) {
            if (f1165g == null) {
                f1165g = C0663h.m2640b();
            }
            c0663h = f1165g;
        }
        return c0663h;
    }

    /* renamed from: b */
    private static C0663h m2640b() {
        return new C0663h(null, new C06601(), new C06612(), null, null, null);
    }

    /* renamed from: a */
    private static Map<Integer, Set<Integer>> m2639a(JSONObject definition) {
        JSONArray itemsArray = definition.optJSONArray("items");
        if (itemsArray.length() == 0) {
            return null;
        }
        Map<Integer, Set<Integer>> items = new HashMap();
        for (int i = 0; i < itemsArray.length(); i++) {
            JSONObject item = itemsArray.optJSONObject(i);
            if (item != null) {
                int code = item.optInt("code");
                if (code != 0) {
                    Set<Integer> subcodes = null;
                    JSONArray subcodesArray = item.optJSONArray("subcodes");
                    if (subcodesArray != null && subcodesArray.length() > 0) {
                        subcodes = new HashSet();
                        for (int j = 0; j < subcodesArray.length(); j++) {
                            int subCode = subcodesArray.optInt(j);
                            if (subCode != 0) {
                                subcodes.add(Integer.valueOf(subCode));
                            }
                        }
                    }
                    items.put(Integer.valueOf(code), subcodes);
                }
            }
        }
        return items;
    }

    /* renamed from: a */
    public static C0663h m2638a(JSONArray jsonArray) {
        if (jsonArray == null) {
            return null;
        }
        Map<Integer, Set<Integer>> otherErrors = null;
        Map<Integer, Set<Integer>> transientErrors = null;
        Map<Integer, Set<Integer>> loginRecoverableErrors = null;
        String otherRecoveryMessage = null;
        String transientRecoveryMessage = null;
        String loginRecoverableRecoveryMessage = null;
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject definition = jsonArray.optJSONObject(i);
            if (definition != null) {
                String name = definition.optString("name");
                if (name != null) {
                    if (name.equalsIgnoreCase("other")) {
                        otherRecoveryMessage = definition.optString("recovery_message", null);
                        otherErrors = C0663h.m2639a(definition);
                    } else if (name.equalsIgnoreCase("transient")) {
                        transientRecoveryMessage = definition.optString("recovery_message", null);
                        transientErrors = C0663h.m2639a(definition);
                    } else if (name.equalsIgnoreCase("login_recoverable")) {
                        loginRecoverableRecoveryMessage = definition.optString("recovery_message", null);
                        loginRecoverableErrors = C0663h.m2639a(definition);
                    }
                }
            }
        }
        return new C0663h(otherErrors, transientErrors, loginRecoverableErrors, otherRecoveryMessage, transientRecoveryMessage, loginRecoverableRecoveryMessage);
    }
}

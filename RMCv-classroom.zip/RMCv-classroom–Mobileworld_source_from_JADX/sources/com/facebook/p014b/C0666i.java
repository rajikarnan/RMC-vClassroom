package com.facebook.p014b;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebView;
import org.json.JSONObject;

/* compiled from: FacebookWebFallbackDialog */
/* renamed from: com.facebook.b.i */
public class C0666i extends C0665s {
    /* renamed from: a */
    private static final String f1183a = C0666i.class.getName();
    /* renamed from: b */
    private boolean f1184b;

    /* compiled from: FacebookWebFallbackDialog */
    /* renamed from: com.facebook.b.i$1 */
    class C06641 implements Runnable {
        /* renamed from: a */
        final /* synthetic */ C0666i f1172a;

        C06641(C0666i this$0) {
            this.f1172a = this$0;
        }

        public void run() {
            super.cancel();
        }
    }

    public C0666i(Context context, String url, String expectedRedirectUrl) {
        super(context, url);
        m2658b(expectedRedirectUrl);
    }

    /* renamed from: a */
    protected Bundle mo857a(String url) {
        Bundle queryParams = C0689q.m2785b(Uri.parse(url).getQuery());
        String bridgeArgsJSONString = queryParams.getString("bridge_args");
        queryParams.remove("bridge_args");
        if (!C0689q.m2782a(bridgeArgsJSONString)) {
            try {
                queryParams.putBundle("com.facebook.platform.protocol.BRIDGE_ARGS", C0652d.m2626a(new JSONObject(bridgeArgsJSONString)));
            } catch (Throwable je) {
                C0689q.m2776a(f1183a, "Unable to parse bridge_args JSON", je);
            }
        }
        String methodResultsJSONString = queryParams.getString("method_results");
        queryParams.remove("method_results");
        if (!C0689q.m2782a(methodResultsJSONString)) {
            if (C0689q.m2782a(methodResultsJSONString)) {
                methodResultsJSONString = "{}";
            }
            try {
                queryParams.putBundle("com.facebook.platform.protocol.RESULT_ARGS", C0652d.m2626a(new JSONObject(methodResultsJSONString)));
            } catch (Throwable je2) {
                C0689q.m2776a(f1183a, "Unable to parse bridge_args JSON", je2);
            }
        }
        queryParams.remove("version");
        queryParams.putInt("com.facebook.platform.protocol.PROTOCOL_VERSION", C0677m.m2696a());
        return queryParams;
    }

    public void cancel() {
        WebView webView = m2660c();
        if (!m2659b() || m2657a() || webView == null || !webView.isShown()) {
            super.cancel();
        } else if (!this.f1184b) {
            this.f1184b = true;
            webView.loadUrl("javascript:" + "(function() {  var event = document.createEvent('Event');  event.initEvent('fbPlatformDialogMustClose',true,true);  document.dispatchEvent(event);})();");
            new Handler(Looper.getMainLooper()).postDelayed(new C06641(this), 1500);
        }
    }
}

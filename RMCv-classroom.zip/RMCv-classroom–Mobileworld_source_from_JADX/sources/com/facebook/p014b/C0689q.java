package com.facebook.p014b;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.Cursor;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.os.Parcel;
import android.os.StatFs;
import android.support.v4.app.ag;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import com.facebook.AccessToken;
import com.facebook.C0699e;
import com.facebook.C0707g;
import com.facebook.C0713l;
import com.facebook.C0745m;
import com.facebook.GraphRequest;
import com.facebook.GraphRequest.C0578b;
import com.facebook.p015a.p016a.C0596b;
import java.io.BufferedInputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

/* compiled from: Utility */
/* renamed from: com.facebook.b.q */
public final class C0689q {
    /* renamed from: a */
    private static final String[] f1234a = new String[]{"supports_implicit_sdk_logging", "gdpv4_nux_content", "gdpv4_nux_enabled", "gdpv4_chrome_custom_tabs_enabled", "android_dialog_configs", "android_sdk_error_categories", "app_events_session_timeout"};
    /* renamed from: b */
    private static Map<String, C0687b> f1235b = new ConcurrentHashMap();
    /* renamed from: c */
    private static AtomicBoolean f1236c = new AtomicBoolean(false);
    /* renamed from: d */
    private static int f1237d = 0;
    /* renamed from: e */
    private static long f1238e = -1;
    /* renamed from: f */
    private static long f1239f = -1;
    /* renamed from: g */
    private static long f1240g = -1;
    /* renamed from: h */
    private static String f1241h = "";
    /* renamed from: i */
    private static String f1242i = "";
    /* renamed from: j */
    private static String f1243j = "NoCarrier";

    /* compiled from: Utility */
    /* renamed from: com.facebook.b.q$c */
    public interface C0589c {
        /* renamed from: a */
        void mo850a(C0699e c0699e);

        /* renamed from: a */
        void mo851a(JSONObject jSONObject);
    }

    /* compiled from: Utility */
    /* renamed from: com.facebook.b.q$3 */
    static class C06853 implements FilenameFilter {
        C06853() {
        }

        public boolean accept(File dir, String fileName) {
            return Pattern.matches("cpu[0-9]+", fileName);
        }
    }

    /* compiled from: Utility */
    /* renamed from: com.facebook.b.q$a */
    public static class C0686a {
        /* renamed from: a */
        private String f1221a;
        /* renamed from: b */
        private String f1222b;
        /* renamed from: c */
        private Uri f1223c;
        /* renamed from: d */
        private int[] f1224d;

        /* renamed from: b */
        private static C0686a m2738b(JSONObject dialogConfigJSON) {
            String dialogNameWithFeature = dialogConfigJSON.optString("name");
            if (C0689q.m2782a(dialogNameWithFeature)) {
                return null;
            }
            String[] components = dialogNameWithFeature.split("\\|");
            if (components.length != 2) {
                return null;
            }
            String dialogName = components[0];
            String featureName = components[1];
            if (C0689q.m2782a(dialogName) || C0689q.m2782a(featureName)) {
                return null;
            }
            String urlString = dialogConfigJSON.optString("url");
            Uri fallbackUri = null;
            if (!C0689q.m2782a(urlString)) {
                fallbackUri = Uri.parse(urlString);
            }
            return new C0686a(dialogName, featureName, fallbackUri, C0686a.m2737a(dialogConfigJSON.optJSONArray("versions")));
        }

        /* renamed from: a */
        private static int[] m2737a(JSONArray versionsJSON) {
            int[] versionSpec = null;
            if (versionsJSON != null) {
                int numVersions = versionsJSON.length();
                versionSpec = new int[numVersions];
                for (int i = 0; i < numVersions; i++) {
                    int version = versionsJSON.optInt(i, -1);
                    if (version == -1) {
                        String versionString = versionsJSON.optString(i);
                        if (!C0689q.m2782a(versionString)) {
                            try {
                                version = Integer.parseInt(versionString);
                            } catch (Exception nfe) {
                                C0689q.m2774a("FacebookSDK", nfe);
                                version = -1;
                            }
                        }
                    }
                    versionSpec[i] = version;
                }
            }
            return versionSpec;
        }

        private C0686a(String dialogName, String featureName, Uri fallbackUrl, int[] featureVersionSpec) {
            this.f1221a = dialogName;
            this.f1222b = featureName;
            this.f1223c = fallbackUrl;
            this.f1224d = featureVersionSpec;
        }

        /* renamed from: a */
        public String m2739a() {
            return this.f1221a;
        }

        /* renamed from: b */
        public String m2740b() {
            return this.f1222b;
        }
    }

    /* compiled from: Utility */
    /* renamed from: com.facebook.b.q$b */
    public static class C0687b {
        /* renamed from: a */
        private boolean f1225a;
        /* renamed from: b */
        private String f1226b;
        /* renamed from: c */
        private boolean f1227c;
        /* renamed from: d */
        private boolean f1228d;
        /* renamed from: e */
        private int f1229e;
        /* renamed from: f */
        private Map<String, Map<String, C0686a>> f1230f;
        /* renamed from: g */
        private C0663h f1231g;

        private C0687b(boolean supportsImplicitLogging, String nuxContent, boolean nuxEnabled, boolean customTabsEnabled, int sessionTimeoutInSeconds, Map<String, Map<String, C0686a>> dialogConfigMap, C0663h errorClassification) {
            this.f1225a = supportsImplicitLogging;
            this.f1226b = nuxContent;
            this.f1227c = nuxEnabled;
            this.f1228d = customTabsEnabled;
            this.f1230f = dialogConfigMap;
            this.f1231g = errorClassification;
            this.f1229e = sessionTimeoutInSeconds;
        }

        /* renamed from: a */
        public boolean m2741a() {
            return this.f1225a;
        }

        /* renamed from: b */
        public boolean m2742b() {
            return this.f1228d;
        }

        /* renamed from: c */
        public C0663h m2743c() {
            return this.f1231g;
        }
    }

    /* compiled from: Utility */
    /* renamed from: com.facebook.b.q$d */
    public static class C0688d {
        /* renamed from: a */
        List<String> f1232a;
        /* renamed from: b */
        List<String> f1233b;

        public C0688d(List<String> grantedPermissions, List<String> declinedPermissions) {
            this.f1232a = grantedPermissions;
            this.f1233b = declinedPermissions;
        }

        /* renamed from: a */
        public List<String> m2744a() {
            return this.f1232a;
        }

        /* renamed from: b */
        public List<String> m2745b() {
            return this.f1233b;
        }
    }

    /* renamed from: a */
    public static <T> boolean m2783a(Collection<T> c) {
        return c == null || c.size() == 0;
    }

    /* renamed from: a */
    public static boolean m2782a(String s) {
        return s == null || s.length() == 0;
    }

    /* renamed from: a */
    public static <T> Collection<T> m2763a(T... ts) {
        return Collections.unmodifiableCollection(Arrays.asList(ts));
    }

    /* renamed from: a */
    public static String m2760a(byte[] bytes) {
        return C0689q.m2758a("SHA-1", bytes);
    }

    /* renamed from: a */
    private static String m2758a(String algorithm, byte[] bytes) {
        try {
            return C0689q.m2759a(MessageDigest.getInstance(algorithm), bytes);
        } catch (NoSuchAlgorithmException e) {
            return null;
        }
    }

    /* renamed from: a */
    private static String m2759a(MessageDigest hash, byte[] bytes) {
        hash.update(bytes);
        byte[] digest = hash.digest();
        StringBuilder builder = new StringBuilder();
        for (int b : digest) {
            builder.append(Integer.toHexString((b >> 4) & 15));
            builder.append(Integer.toHexString((b >> 0) & 15));
        }
        return builder.toString();
    }

    /* renamed from: a */
    public static Uri m2749a(String authority, String path, Bundle parameters) {
        Builder builder = new Builder();
        builder.scheme("https");
        builder.authority(authority);
        builder.path(path);
        if (parameters != null) {
            for (String key : parameters.keySet()) {
                Object parameter = parameters.get(key);
                if (parameter instanceof String) {
                    builder.appendQueryParameter(key, (String) parameter);
                }
            }
        }
        return builder.build();
    }

    /* renamed from: b */
    public static Bundle m2785b(String queryString) {
        Bundle params = new Bundle();
        if (!C0689q.m2782a(queryString)) {
            for (String parameter : queryString.split("&")) {
                String[] keyValuePair = parameter.split("=");
                try {
                    if (keyValuePair.length == 2) {
                        params.putString(URLDecoder.decode(keyValuePair[0], "UTF-8"), URLDecoder.decode(keyValuePair[1], "UTF-8"));
                    } else if (keyValuePair.length == 1) {
                        params.putString(URLDecoder.decode(keyValuePair[0], "UTF-8"), "");
                    }
                } catch (Exception e) {
                    C0689q.m2774a("FacebookSDK", e);
                }
            }
        }
        return params;
    }

    /* renamed from: a */
    public static void m2770a(Bundle b, String key, String value) {
        if (!C0689q.m2782a(value)) {
            b.putString(key, value);
        }
    }

    /* renamed from: a */
    public static void m2769a(Bundle b, String key, Uri uri) {
        if (uri != null) {
            C0689q.m2770a(b, key, uri.toString());
        }
    }

    /* renamed from: a */
    public static void m2772a(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException e) {
            }
        }
    }

    /* renamed from: a */
    public static void m2777a(URLConnection connection) {
        if (connection != null && (connection instanceof HttpURLConnection)) {
            ((HttpURLConnection) connection).disconnect();
        }
    }

    /* renamed from: a */
    public static String m2756a(Context context) {
        C0690r.m2805a((Object) context, "context");
        C0707g.m2843a(context);
        return C0707g.m2858i();
    }

    /* renamed from: a */
    public static Object m2754a(JSONObject jsonObject, String key, String nonJSONPropertyKey) throws JSONException {
        JSONObject value = jsonObject.opt(key);
        if (value != null && (value instanceof String)) {
            value = new JSONTokener((String) value).nextValue();
        }
        if (value == null || (value instanceof JSONObject) || (value instanceof JSONArray)) {
            return value;
        }
        if (nonJSONPropertyKey != null) {
            jsonObject = new JSONObject();
            jsonObject.putOpt(nonJSONPropertyKey, value);
            return jsonObject;
        }
        throw new C0699e("Got an unexpected non-JSON object.");
    }

    /* renamed from: a */
    public static String m2757a(InputStream inputStream) throws IOException {
        Throwable th;
        Closeable bufferedInputStream = null;
        Closeable reader = null;
        try {
            Closeable reader2;
            Closeable bufferedInputStream2 = new BufferedInputStream(inputStream);
            try {
                reader2 = new InputStreamReader(bufferedInputStream2);
            } catch (Throwable th2) {
                th = th2;
                bufferedInputStream = bufferedInputStream2;
                C0689q.m2772a(bufferedInputStream);
                C0689q.m2772a(reader);
                throw th;
            }
            try {
                StringBuilder stringBuilder = new StringBuilder();
                char[] buffer = new char[2048];
                while (true) {
                    int n = reader2.read(buffer);
                    if (n != -1) {
                        stringBuilder.append(buffer, 0, n);
                    } else {
                        String stringBuilder2 = stringBuilder.toString();
                        C0689q.m2772a(bufferedInputStream2);
                        C0689q.m2772a(reader2);
                        return stringBuilder2;
                    }
                }
            } catch (Throwable th3) {
                th = th3;
                reader = reader2;
                bufferedInputStream = bufferedInputStream2;
                C0689q.m2772a(bufferedInputStream);
                C0689q.m2772a(reader);
                throw th;
            }
        } catch (Throwable th4) {
            th = th4;
            C0689q.m2772a(bufferedInputStream);
            C0689q.m2772a(reader);
            throw th;
        }
    }

    /* renamed from: a */
    public static int m2746a(InputStream inputStream, OutputStream outputStream) throws IOException {
        Throwable th;
        BufferedInputStream bufferedInputStream = null;
        int totalBytes = 0;
        try {
            BufferedInputStream bufferedInputStream2 = new BufferedInputStream(inputStream);
            try {
                byte[] buffer = new byte[8192];
                while (true) {
                    int bytesRead = bufferedInputStream2.read(buffer);
                    if (bytesRead == -1) {
                        break;
                    }
                    outputStream.write(buffer, 0, bytesRead);
                    totalBytes += bytesRead;
                }
                if (bufferedInputStream2 != null) {
                    bufferedInputStream2.close();
                }
                if (inputStream != null) {
                    inputStream.close();
                }
                return totalBytes;
            } catch (Throwable th2) {
                th = th2;
                bufferedInputStream = bufferedInputStream2;
                if (bufferedInputStream != null) {
                    bufferedInputStream.close();
                }
                if (inputStream != null) {
                    inputStream.close();
                }
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            if (bufferedInputStream != null) {
                bufferedInputStream.close();
            }
            if (inputStream != null) {
                inputStream.close();
            }
            throw th;
        }
    }

    /* renamed from: b */
    private static void m2790b(Context context, String domain) {
        CookieSyncManager.createInstance(context).sync();
        CookieManager cookieManager = CookieManager.getInstance();
        String cookies = cookieManager.getCookie(domain);
        if (cookies != null) {
            for (String cookie : cookies.split(";")) {
                String[] cookieParts = cookie.split("=");
                if (cookieParts.length > 0) {
                    cookieManager.setCookie(domain, cookieParts[0].trim() + "=;expires=Sat, 1 Jan 2000 00:00:01 UTC;");
                }
            }
            cookieManager.removeExpiredCookie();
        }
    }

    /* renamed from: b */
    public static void m2789b(Context context) {
        C0689q.m2790b(context, "facebook.com");
        C0689q.m2790b(context, ".facebook.com");
        C0689q.m2790b(context, "https://facebook.com");
        C0689q.m2790b(context, "https://.facebook.com");
    }

    /* renamed from: a */
    public static void m2774a(String tag, Exception e) {
        if (C0707g.m2849b() && tag != null && e != null) {
            Log.d(tag, e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    /* renamed from: a */
    public static void m2775a(String tag, String msg) {
        if (C0707g.m2849b() && tag != null && msg != null) {
            Log.d(tag, msg);
        }
    }

    /* renamed from: a */
    public static void m2776a(String tag, String msg, Throwable t) {
        if (C0707g.m2849b() && !C0689q.m2782a(tag)) {
            Log.d(tag, msg, t);
        }
    }

    /* renamed from: a */
    public static <T> boolean m2781a(T a, T b) {
        if (a == null) {
            return b == null;
        } else {
            return a.equals(b);
        }
    }

    /* renamed from: a */
    public static void m2768a(final Context context, final String applicationId) {
        boolean canStartLoading = f1236c.compareAndSet(false, true);
        if (!C0689q.m2782a(applicationId) && !f1235b.containsKey(applicationId) && canStartLoading) {
            final String settingsKey = String.format("com.facebook.internal.APP_SETTINGS.%s", new Object[]{applicationId});
            C0707g.m2853d().execute(new Runnable() {
                public void run() {
                    SharedPreferences sharedPrefs = context.getSharedPreferences("com.facebook.internal.preferences.APP_SETTINGS", 0);
                    String settingsJSONString = sharedPrefs.getString(settingsKey, null);
                    if (!C0689q.m2782a(settingsJSONString)) {
                        JSONObject settingsJSON = null;
                        try {
                            settingsJSON = new JSONObject(settingsJSONString);
                        } catch (Exception je) {
                            C0689q.m2774a("FacebookSDK", je);
                        }
                        if (settingsJSON != null) {
                            C0689q.m2786b(applicationId, settingsJSON);
                        }
                    }
                    JSONObject resultJSON = C0689q.m2800f(applicationId);
                    if (resultJSON != null) {
                        C0689q.m2786b(applicationId, resultJSON);
                        sharedPrefs.edit().putString(settingsKey, resultJSON.toString()).apply();
                    }
                    C0689q.f1236c.set(false);
                }
            });
        }
    }

    /* renamed from: c */
    public static C0687b m2791c(String applicationId) {
        return applicationId != null ? (C0687b) f1235b.get(applicationId) : null;
    }

    /* renamed from: a */
    public static C0687b m2751a(String applicationId, boolean forceRequery) {
        if (!forceRequery && f1235b.containsKey(applicationId)) {
            return (C0687b) f1235b.get(applicationId);
        }
        JSONObject response = C0689q.m2800f(applicationId);
        if (response == null) {
            return null;
        }
        return C0689q.m2786b(applicationId, response);
    }

    /* renamed from: b */
    private static C0687b m2786b(String applicationId, JSONObject settingsJSON) {
        C0663h errorClassification;
        JSONArray errorClassificationJSON = settingsJSON.optJSONArray("android_sdk_error_categories");
        if (errorClassificationJSON == null) {
            errorClassification = C0663h.m2637a();
        } else {
            errorClassification = C0663h.m2638a(errorClassificationJSON);
        }
        C0687b result = new C0687b(settingsJSON.optBoolean("supports_implicit_sdk_logging", false), settingsJSON.optString("gdpv4_nux_content", ""), settingsJSON.optBoolean("gdpv4_nux_enabled", false), settingsJSON.optBoolean("gdpv4_chrome_custom_tabs_enabled", false), settingsJSON.optInt("app_events_session_timeout", C0596b.m2503a()), C0689q.m2788b(settingsJSON.optJSONObject("android_dialog_configs")), errorClassification);
        f1235b.put(applicationId, result);
        return result;
    }

    /* renamed from: f */
    private static JSONObject m2800f(String applicationId) {
        Bundle appSettingsParams = new Bundle();
        appSettingsParams.putString("fields", TextUtils.join(",", f1234a));
        GraphRequest request = GraphRequest.m2434a(null, applicationId, null);
        request.m2478a(true);
        request.m2473a(appSettingsParams);
        return request.m2486i().m2891b();
    }

    /* renamed from: b */
    private static Map<String, Map<String, C0686a>> m2788b(JSONObject dialogConfigResponse) {
        HashMap<String, Map<String, C0686a>> dialogConfigMap = new HashMap();
        if (dialogConfigResponse != null) {
            JSONArray dialogConfigData = dialogConfigResponse.optJSONArray("data");
            if (dialogConfigData != null) {
                for (int i = 0; i < dialogConfigData.length(); i++) {
                    C0686a dialogConfig = C0686a.m2738b(dialogConfigData.optJSONObject(i));
                    if (dialogConfig != null) {
                        String dialogName = dialogConfig.m2739a();
                        Map<String, C0686a> featureMap = (Map) dialogConfigMap.get(dialogName);
                        if (featureMap == null) {
                            featureMap = new HashMap();
                            dialogConfigMap.put(dialogName, featureMap);
                        }
                        featureMap.put(dialogConfig.m2740b(), dialogConfig);
                    }
                }
            }
        }
        return dialogConfigMap;
    }

    /* renamed from: b */
    public static <T> List<T> m2787b(T... array) {
        ArrayList<T> result = new ArrayList();
        for (T t : array) {
            if (t != null) {
                result.add(t);
            }
        }
        return result;
    }

    /* renamed from: a */
    public static List<String> m2765a(JSONArray jsonArray) throws JSONException {
        ArrayList<String> result = new ArrayList();
        for (int i = 0; i < jsonArray.length(); i++) {
            result.add(jsonArray.getString(i));
        }
        return result;
    }

    /* renamed from: a */
    public static void m2779a(JSONObject params, C0642b attributionIdentifiers, String anonymousAppDeviceGUID, boolean limitEventUsage) throws JSONException {
        boolean z = true;
        if (!(attributionIdentifiers == null || attributionIdentifiers.m2611a() == null)) {
            params.put("attribution", attributionIdentifiers.m2611a());
        }
        if (!(attributionIdentifiers == null || attributionIdentifiers.m2612b() == null)) {
            params.put("advertiser_id", attributionIdentifiers.m2612b());
            params.put("advertiser_tracking_enabled", !attributionIdentifiers.m2614d());
        }
        if (!(attributionIdentifiers == null || attributionIdentifiers.m2613c() == null)) {
            params.put("installer_package", attributionIdentifiers.m2613c());
        }
        params.put("anon_id", anonymousAppDeviceGUID);
        String str = "application_tracking_enabled";
        if (limitEventUsage) {
            z = false;
        }
        params.put(str, z);
    }

    /* renamed from: a */
    public static void m2778a(JSONObject params, Context appContext) throws JSONException {
        Locale locale;
        JSONArray extraInfoArray = new JSONArray();
        extraInfoArray.put("a2");
        C0689q.m2795d(appContext);
        String pkgName = appContext.getPackageName();
        int versionCode = -1;
        String versionName = "";
        try {
            PackageInfo pi = appContext.getPackageManager().getPackageInfo(pkgName, 0);
            versionCode = pi.versionCode;
            versionName = pi.versionName;
        } catch (NameNotFoundException e) {
        }
        extraInfoArray.put(pkgName);
        extraInfoArray.put(versionCode);
        extraInfoArray.put(versionName);
        extraInfoArray.put(VERSION.RELEASE);
        extraInfoArray.put(Build.MODEL);
        try {
            locale = appContext.getResources().getConfiguration().locale;
        } catch (Exception e2) {
            locale = Locale.getDefault();
        }
        extraInfoArray.put(locale.getLanguage() + "_" + locale.getCountry());
        extraInfoArray.put(f1241h);
        extraInfoArray.put(f1243j);
        int width = 0;
        int height = 0;
        double density = 0.0d;
        try {
            WindowManager wm = (WindowManager) appContext.getSystemService("window");
            if (wm != null) {
                Display display = wm.getDefaultDisplay();
                DisplayMetrics displayMetrics = new DisplayMetrics();
                display.getMetrics(displayMetrics);
                width = displayMetrics.widthPixels;
                height = displayMetrics.heightPixels;
                density = (double) displayMetrics.density;
            }
        } catch (Exception e3) {
        }
        extraInfoArray.put(width);
        extraInfoArray.put(height);
        extraInfoArray.put(String.format("%.2f", new Object[]{Double.valueOf(density)}));
        extraInfoArray.put(C0689q.m2784b());
        extraInfoArray.put(f1239f);
        extraInfoArray.put(f1240g);
        extraInfoArray.put(f1242i);
        params.put("extinfo", extraInfoArray.toString());
    }

    /* renamed from: a */
    public static Method m2761a(Class<?> clazz, String methodName, Class<?>... parameterTypes) {
        try {
            return clazz.getMethod(methodName, parameterTypes);
        } catch (NoSuchMethodException e) {
            return null;
        }
    }

    /* renamed from: a */
    public static Method m2762a(String className, String methodName, Class<?>... parameterTypes) {
        try {
            return C0689q.m2761a(Class.forName(className), methodName, (Class[]) parameterTypes);
        } catch (ClassNotFoundException e) {
            return null;
        }
    }

    /* renamed from: a */
    public static Object m2753a(Object receiver, Method method, Object... args) {
        Object obj = null;
        try {
            obj = method.invoke(receiver, args);
        } catch (IllegalAccessException e) {
        } catch (InvocationTargetException e2) {
        }
        return obj;
    }

    /* renamed from: c */
    public static String m2792c(Context context) {
        if (context == null) {
            return "null";
        }
        if (context == context.getApplicationContext()) {
            return "unknown";
        }
        return context.getClass().getSimpleName();
    }

    /* renamed from: a */
    public static long m2748a(Uri contentUri) {
        Cursor cursor = null;
        try {
            cursor = C0707g.m2855f().getContentResolver().query(contentUri, null, null, null, null);
            int sizeIndex = cursor.getColumnIndex("_size");
            cursor.moveToFirst();
            long j = cursor.getLong(sizeIndex);
            return j;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    /* renamed from: a */
    public static Date m2764a(Bundle bundle, String key, Date dateBase) {
        if (bundle == null) {
            return null;
        }
        long secondsFromBase;
        Object secondsObject = bundle.get(key);
        if (secondsObject instanceof Long) {
            secondsFromBase = ((Long) secondsObject).longValue();
        } else if (!(secondsObject instanceof String)) {
            return null;
        } else {
            try {
                secondsFromBase = Long.parseLong((String) secondsObject);
            } catch (NumberFormatException e) {
                return null;
            }
        }
        if (secondsFromBase == 0) {
            return new Date(Long.MAX_VALUE);
        }
        return new Date(dateBase.getTime() + (1000 * secondsFromBase));
    }

    /* renamed from: a */
    public static void m2771a(Parcel parcel, Map<String, String> map) {
        if (map == null) {
            parcel.writeInt(-1);
            return;
        }
        parcel.writeInt(map.size());
        for (Entry<String, String> entry : map.entrySet()) {
            parcel.writeString((String) entry.getKey());
            parcel.writeString((String) entry.getValue());
        }
    }

    /* renamed from: a */
    public static Map<String, String> m2766a(Parcel parcel) {
        int size = parcel.readInt();
        if (size < 0) {
            return null;
        }
        Map<String, String> map = new HashMap();
        for (int i = 0; i < size; i++) {
            map.put(parcel.readString(), parcel.readString());
        }
        return map;
    }

    /* renamed from: a */
    public static boolean m2780a(AccessToken token) {
        return token != null ? token.equals(AccessToken.m2378a()) : false;
    }

    /* renamed from: a */
    public static void m2773a(final String accessToken, final C0589c callback) {
        JSONObject cachedValue = C0681o.m2729a(accessToken);
        if (cachedValue != null) {
            callback.mo851a(cachedValue);
            return;
        }
        C0578b graphCallback = new C0578b() {
            /* renamed from: a */
            public void mo848a(C0713l response) {
                if (response.m2890a() != null) {
                    callback.mo850a(response.m2890a().m2408f());
                    return;
                }
                C0681o.m2730a(accessToken, response.m2891b());
                callback.mo851a(response.m2891b());
            }
        };
        GraphRequest graphRequest = C0689q.m2802g(accessToken);
        graphRequest.m2474a(graphCallback);
        graphRequest.m2487j();
    }

    /* renamed from: d */
    public static JSONObject m2794d(String accessToken) {
        JSONObject cachedValue = C0681o.m2729a(accessToken);
        if (cachedValue != null) {
            return cachedValue;
        }
        C0713l response = C0689q.m2802g(accessToken).m2486i();
        if (response.m2890a() != null) {
            return null;
        }
        return response.m2891b();
    }

    /* renamed from: g */
    private static GraphRequest m2802g(String accessToken) {
        Bundle parameters = new Bundle();
        parameters.putString("fields", "id,name,first_name,middle_name,last_name,link");
        parameters.putString("access_token", accessToken);
        return new GraphRequest(null, "me", parameters, C0745m.GET, null);
    }

    /* renamed from: b */
    private static int m2784b() {
        if (f1237d > 0) {
            return f1237d;
        }
        try {
            File[] cpuFiles = new File("/sys/devices/system/cpu/").listFiles(new C06853());
            if (cpuFiles != null) {
                f1237d = cpuFiles.length;
            }
        } catch (Exception e) {
        }
        if (f1237d <= 0) {
            f1237d = Math.max(Runtime.getRuntime().availableProcessors(), 1);
        }
        return f1237d;
    }

    /* renamed from: d */
    private static void m2795d(Context appContext) {
        if (f1238e == -1 || System.currentTimeMillis() - f1238e >= 1800000) {
            f1238e = System.currentTimeMillis();
            C0689q.m2793c();
            C0689q.m2799e(appContext);
            C0689q.m2801f();
            C0689q.m2798e();
        }
    }

    /* renamed from: c */
    private static void m2793c() {
        try {
            TimeZone tz = TimeZone.getDefault();
            f1241h = tz.getDisplayName(tz.inDaylightTime(new Date()), 0);
            f1242i = tz.getID();
        } catch (Exception e) {
        }
    }

    /* renamed from: e */
    private static void m2799e(Context appContext) {
        if (f1243j.equals("NoCarrier")) {
            try {
                f1243j = ((TelephonyManager) appContext.getSystemService("phone")).getNetworkOperatorName();
            } catch (Exception e) {
            }
        }
    }

    /* renamed from: d */
    private static boolean m2796d() {
        return "mounted".equals(Environment.getExternalStorageState());
    }

    /* renamed from: e */
    private static void m2798e() {
        try {
            if (C0689q.m2796d()) {
                StatFs stat = new StatFs(Environment.getExternalStorageDirectory().getPath());
                f1240g = ((long) stat.getAvailableBlocks()) * ((long) stat.getBlockSize());
            }
            f1240g = C0689q.m2747a((double) f1240g);
        } catch (Exception e) {
        }
    }

    /* renamed from: f */
    private static void m2801f() {
        try {
            if (C0689q.m2796d()) {
                StatFs stat = new StatFs(Environment.getExternalStorageDirectory().getPath());
                f1239f = ((long) stat.getBlockCount()) * ((long) stat.getBlockSize());
            }
            f1239f = C0689q.m2747a((double) f1239f);
        } catch (Exception e) {
        }
    }

    /* renamed from: a */
    private static long m2747a(double bytes) {
        return Math.round(bytes / 1.073741824E9d);
    }

    /* renamed from: a */
    public static C0688d m2752a(JSONObject result) throws JSONException {
        JSONArray data = result.getJSONObject("permissions").getJSONArray("data");
        List<String> grantedPermissions = new ArrayList(data.length());
        List<String> declinedPermissions = new ArrayList(data.length());
        for (int i = 0; i < data.length(); i++) {
            JSONObject object = data.optJSONObject(i);
            String permission = object.optString("permission");
            if (!(permission == null || permission.equals("installed"))) {
                String status = object.optString(ag.CATEGORY_STATUS);
                if (status != null) {
                    if (status.equals("granted")) {
                        grantedPermissions.add(permission);
                    } else if (status.equals("declined")) {
                        declinedPermissions.add(permission);
                    }
                }
            }
        }
        return new C0688d(grantedPermissions, declinedPermissions);
    }

    /* renamed from: a */
    public static String m2755a(int length) {
        return new BigInteger(length * 5, new Random()).toString(32);
    }
}

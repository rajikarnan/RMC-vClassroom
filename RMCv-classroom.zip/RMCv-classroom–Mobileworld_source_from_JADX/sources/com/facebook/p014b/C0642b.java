package com.facebook.p014b;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.Parcel;
import android.os.RemoteException;
import com.facebook.C0699e;
import java.lang.reflect.Method;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.atomic.AtomicBoolean;

/* compiled from: AttributionIdentifiers */
/* renamed from: com.facebook.b.b */
public class C0642b {
    /* renamed from: a */
    private static final String f1138a = C0642b.class.getCanonicalName();
    /* renamed from: g */
    private static C0642b f1139g;
    /* renamed from: b */
    private String f1140b;
    /* renamed from: c */
    private String f1141c;
    /* renamed from: d */
    private String f1142d;
    /* renamed from: e */
    private boolean f1143e;
    /* renamed from: f */
    private long f1144f;

    /* compiled from: AttributionIdentifiers */
    /* renamed from: com.facebook.b.b$a */
    private static final class C0640a implements IInterface {
        /* renamed from: a */
        private IBinder f1135a;

        C0640a(IBinder binder) {
            this.f1135a = binder;
        }

        public IBinder asBinder() {
            return this.f1135a;
        }

        /* renamed from: a */
        public String m2602a() throws RemoteException {
            Parcel data = Parcel.obtain();
            Parcel reply = Parcel.obtain();
            try {
                data.writeInterfaceToken("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
                this.f1135a.transact(1, data, reply, 0);
                reply.readException();
                String id = reply.readString();
                return id;
            } finally {
                reply.recycle();
                data.recycle();
            }
        }

        /* renamed from: b */
        public boolean m2603b() throws RemoteException {
            boolean limitAdTracking = true;
            Parcel data = Parcel.obtain();
            Parcel reply = Parcel.obtain();
            try {
                data.writeInterfaceToken("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
                data.writeInt(1);
                this.f1135a.transact(2, data, reply, 0);
                reply.readException();
                if (reply.readInt() == 0) {
                    limitAdTracking = false;
                }
                reply.recycle();
                data.recycle();
                return limitAdTracking;
            } catch (Throwable th) {
                reply.recycle();
                data.recycle();
            }
        }
    }

    /* compiled from: AttributionIdentifiers */
    /* renamed from: com.facebook.b.b$b */
    private static final class C0641b implements ServiceConnection {
        /* renamed from: a */
        private AtomicBoolean f1136a;
        /* renamed from: b */
        private final BlockingQueue<IBinder> f1137b;

        private C0641b() {
            this.f1136a = new AtomicBoolean(false);
            this.f1137b = new LinkedBlockingDeque();
        }

        public void onServiceConnected(ComponentName name, IBinder service) {
            try {
                this.f1137b.put(service);
            } catch (InterruptedException e) {
            }
        }

        public void onServiceDisconnected(ComponentName name) {
        }

        /* renamed from: a */
        public IBinder m2604a() throws InterruptedException {
            if (!this.f1136a.compareAndSet(true, true)) {
                return (IBinder) this.f1137b.take();
            }
            throw new IllegalStateException("Binder already consumed");
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: a */
    public static com.facebook.p014b.C0642b m2605a(android.content.Context r16) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find block by offset: 0x0016 in list [B:17:0x0052]
	at jadx.core.utils.BlockUtils.getBlockByOffset(BlockUtils.java:43)
	at jadx.core.dex.instructions.IfNode.initBlocks(IfNode.java:60)
	at jadx.core.dex.visitors.blocksmaker.BlockFinish.initBlocksInIfNodes(BlockFinish.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockFinish.visit(BlockFinish.java:33)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1782580546.run(Unknown Source)
*/
        /*
        r0 = f1139g;
        if (r0 == 0) goto L_0x0017;
    L_0x0004:
        r4 = java.lang.System.currentTimeMillis();
        r0 = f1139g;
        r14 = r0.f1144f;
        r4 = r4 - r14;
        r14 = 3600000; // 0x36ee80 float:5.044674E-39 double:1.7786363E-317;
        r0 = (r4 > r14 ? 1 : (r4 == r14 ? 0 : -1));
        if (r0 >= 0) goto L_0x0017;
    L_0x0014:
        r0 = f1139g;
    L_0x0016:
        return r0;
    L_0x0017:
        r10 = com.facebook.p014b.C0642b.m2607b(r16);
        r8 = 0;
        r0 = 3;
        r2 = new java.lang.String[r0];	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = 0;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r3 = "aid";	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r2[r0] = r3;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = 1;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r3 = "androidid";	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r2[r0] = r3;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = 2;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r3 = "limit_tracking";	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r2[r0] = r3;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r1 = 0;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = r16.getPackageManager();	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r3 = "com.facebook.katana.provider.AttributionIdProvider";	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r4 = 0;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = r0.resolveContentProvider(r3, r4);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        if (r0 == 0) goto L_0x0056;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x003c:
        r0 = "content://com.facebook.katana.provider.AttributionIdProvider";	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r1 = android.net.Uri.parse(r0);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x0042:
        r11 = com.facebook.p014b.C0642b.m2610e(r16);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        if (r11 == 0) goto L_0x004a;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x0048:
        r10.f1142d = r11;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x004a:
        if (r1 != 0) goto L_0x006a;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x004c:
        r0 = com.facebook.p014b.C0642b.m2606a(r10);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        if (r8 == 0) goto L_0x0016;
    L_0x0052:
        r8.close();
        goto L_0x0016;
    L_0x0056:
        r0 = r16.getPackageManager();	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r3 = "com.facebook.wakizashi.provider.AttributionIdProvider";	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r4 = 0;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = r0.resolveContentProvider(r3, r4);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        if (r0 == 0) goto L_0x0042;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x0063:
        r0 = "content://com.facebook.wakizashi.provider.AttributionIdProvider";	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r1 = android.net.Uri.parse(r0);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        goto L_0x0042;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x006a:
        r0 = r16.getContentResolver();	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r3 = 0;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r4 = 0;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r5 = 0;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r8 = r0.query(r1, r2, r3, r4, r5);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        if (r8 == 0) goto L_0x007d;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x0077:
        r0 = r8.moveToFirst();	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        if (r0 != 0) goto L_0x0087;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x007d:
        r0 = com.facebook.p014b.C0642b.m2606a(r10);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        if (r8 == 0) goto L_0x0016;
    L_0x0083:
        r8.close();
        goto L_0x0016;
    L_0x0087:
        r0 = "aid";	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r7 = r8.getColumnIndex(r0);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = "androidid";	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r6 = r8.getColumnIndex(r0);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = "limit_tracking";	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r12 = r8.getColumnIndex(r0);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = r8.getString(r7);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r10.f1140b = r0;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        if (r6 <= 0) goto L_0x00b9;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x00a1:
        if (r12 <= 0) goto L_0x00b9;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x00a3:
        r0 = r10.m2612b();	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        if (r0 != 0) goto L_0x00b9;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x00a9:
        r0 = r8.getString(r6);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r10.f1141c = r0;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = r8.getString(r12);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = java.lang.Boolean.parseBoolean(r0);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r10.f1143e = r0;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x00b9:
        if (r8 == 0) goto L_0x00be;
    L_0x00bb:
        r8.close();
    L_0x00be:
        r0 = com.facebook.p014b.C0642b.m2606a(r10);
        goto L_0x0016;
    L_0x00c4:
        r9 = move-exception;
        r0 = f1138a;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r3 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r3.<init>();	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r4 = "Caught unexpected exception in getAttributionId(): ";	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r3 = r3.append(r4);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r4 = r9.toString();	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r3 = r3.append(r4);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r3 = r3.toString();	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        android.util.Log.d(r0, r3);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = 0;
        if (r8 == 0) goto L_0x0016;
    L_0x00e4:
        r8.close();
        goto L_0x0016;
    L_0x00e9:
        r0 = move-exception;
        if (r8 == 0) goto L_0x00ef;
    L_0x00ec:
        r8.close();
    L_0x00ef:
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.b.b.a(android.content.Context):com.facebook.b.b");
    }

    /* renamed from: b */
    private static C0642b m2607b(Context context) {
        C0642b identifiers = C0642b.m2608c(context);
        if (identifiers != null) {
            return identifiers;
        }
        identifiers = C0642b.m2609d(context);
        if (identifiers == null) {
            return new C0642b();
        }
        return identifiers;
    }

    /* renamed from: c */
    private static C0642b m2608c(Context context) {
        try {
            if (Looper.myLooper() == Looper.getMainLooper()) {
                throw new C0699e("getAndroidId cannot be called on the main thread.");
            }
            Method isGooglePlayServicesAvailable = C0689q.m2762a("com.google.android.gms.common.GooglePlayServicesUtil", "isGooglePlayServicesAvailable", Context.class);
            if (isGooglePlayServicesAvailable == null) {
                return null;
            }
            Object connectionResult = C0689q.m2753a(null, isGooglePlayServicesAvailable, context);
            if (!(connectionResult instanceof Integer) || ((Integer) connectionResult).intValue() != 0) {
                return null;
            }
            Method getAdvertisingIdInfo = C0689q.m2762a("com.google.android.gms.ads.identifier.AdvertisingIdClient", "getAdvertisingIdInfo", Context.class);
            if (getAdvertisingIdInfo == null) {
                return null;
            }
            Object advertisingInfo = C0689q.m2753a(null, getAdvertisingIdInfo, context);
            if (advertisingInfo == null) {
                return null;
            }
            Method getId = C0689q.m2761a(advertisingInfo.getClass(), "getId", new Class[0]);
            Method isLimitAdTrackingEnabled = C0689q.m2761a(advertisingInfo.getClass(), "isLimitAdTrackingEnabled", new Class[0]);
            if (getId == null || isLimitAdTrackingEnabled == null) {
                return null;
            }
            C0642b identifiers = new C0642b();
            identifiers.f1141c = (String) C0689q.m2753a(advertisingInfo, getId, new Object[0]);
            identifiers.f1143e = ((Boolean) C0689q.m2753a(advertisingInfo, isLimitAdTrackingEnabled, new Object[0])).booleanValue();
            return identifiers;
        } catch (Exception e) {
            C0689q.m2774a("android_id", e);
            return null;
        }
    }

    /* renamed from: d */
    private static C0642b m2609d(Context context) {
        C0641b connection = new C0641b();
        Intent intent = new Intent("com.google.android.gms.ads.identifier.service.START");
        intent.setPackage("com.google.android.gms");
        if (context.bindService(intent, connection, 1)) {
            try {
                C0640a adInfo = new C0640a(connection.m2604a());
                C0642b identifiers = new C0642b();
                identifiers.f1141c = adInfo.m2602a();
                identifiers.f1143e = adInfo.m2603b();
                return identifiers;
            } catch (Exception exception) {
                C0689q.m2774a("android_id", exception);
            } finally {
                context.unbindService(connection);
            }
        }
        return null;
    }

    /* renamed from: a */
    private static C0642b m2606a(C0642b identifiers) {
        identifiers.f1144f = System.currentTimeMillis();
        f1139g = identifiers;
        return identifiers;
    }

    /* renamed from: a */
    public String m2611a() {
        return this.f1140b;
    }

    /* renamed from: b */
    public String m2612b() {
        return this.f1141c;
    }

    /* renamed from: c */
    public String m2613c() {
        return this.f1142d;
    }

    /* renamed from: d */
    public boolean m2614d() {
        return this.f1143e;
    }

    /* renamed from: e */
    private static String m2610e(Context context) {
        PackageManager packageManager = context.getPackageManager();
        if (packageManager != null) {
            return packageManager.getInstallerPackageName(context.getPackageName());
        }
        return null;
    }
}

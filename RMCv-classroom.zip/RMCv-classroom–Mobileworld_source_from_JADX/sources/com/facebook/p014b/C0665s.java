package com.facebook.p014b;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowManager;
import android.webkit.SslErrorHandler;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.facebook.AccessToken;
import com.facebook.C0699e;
import com.facebook.C0700d;
import com.facebook.C0701f;
import com.facebook.C0707g;
import com.facebook.C0709i;
import com.facebook.C0777t.C0772a;
import com.facebook.C0777t.C0775d;
import com.facebook.FacebookRequestError;
import java.util.Locale;

/* compiled from: WebDialog */
/* renamed from: com.facebook.b.s */
public class C0665s extends Dialog {
    /* renamed from: a */
    private String f1173a;
    /* renamed from: b */
    private String f1174b;
    /* renamed from: c */
    private C0656c f1175c;
    /* renamed from: d */
    private WebView f1176d;
    /* renamed from: e */
    private ProgressDialog f1177e;
    /* renamed from: f */
    private ImageView f1178f;
    /* renamed from: g */
    private FrameLayout f1179g;
    /* renamed from: h */
    private boolean f1180h;
    /* renamed from: i */
    private boolean f1181i;
    /* renamed from: j */
    private boolean f1182j;

    /* compiled from: WebDialog */
    /* renamed from: com.facebook.b.s$c */
    public interface C0656c {
        /* renamed from: a */
        void mo854a(Bundle bundle, C0699e c0699e);
    }

    /* compiled from: WebDialog */
    /* renamed from: com.facebook.b.s$1 */
    class C06911 implements OnCancelListener {
        /* renamed from: a */
        final /* synthetic */ C0665s f1245a;

        C06911(C0665s this$0) {
            this.f1245a = this$0;
        }

        public void onCancel(DialogInterface dialogInterface) {
            this.f1245a.cancel();
        }
    }

    /* compiled from: WebDialog */
    /* renamed from: com.facebook.b.s$2 */
    class C06922 implements OnClickListener {
        /* renamed from: a */
        final /* synthetic */ C0665s f1246a;

        C06922(C0665s this$0) {
            this.f1246a = this$0;
        }

        public void onClick(View v) {
            this.f1246a.cancel();
        }
    }

    /* compiled from: WebDialog */
    /* renamed from: com.facebook.b.s$4 */
    class C06944 implements OnTouchListener {
        /* renamed from: a */
        final /* synthetic */ C0665s f1248a;

        C06944(C0665s this$0) {
            this.f1248a = this$0;
        }

        public boolean onTouch(View v, MotionEvent event) {
            if (!v.hasFocus()) {
                v.requestFocus();
            }
            return false;
        }
    }

    /* compiled from: WebDialog */
    /* renamed from: com.facebook.b.s$a */
    public static class C0695a {
        /* renamed from: a */
        private Context f1249a;
        /* renamed from: b */
        private String f1250b;
        /* renamed from: c */
        private String f1251c;
        /* renamed from: d */
        private int f1252d;
        /* renamed from: e */
        private C0656c f1253e;
        /* renamed from: f */
        private Bundle f1254f;
        /* renamed from: g */
        private AccessToken f1255g;

        public C0695a(Context context, String action, Bundle parameters) {
            this.f1255g = AccessToken.m2378a();
            if (this.f1255g == null) {
                String applicationId = C0689q.m2756a(context);
                if (applicationId != null) {
                    this.f1250b = applicationId;
                } else {
                    throw new C0699e("Attempted to create a builder without a valid access token or a valid default Application ID.");
                }
            }
            m2814a(context, action, parameters);
        }

        public C0695a(Context context, String applicationId, String action, Bundle parameters) {
            if (applicationId == null) {
                applicationId = C0689q.m2756a(context);
            }
            C0690r.m2806a(applicationId, "applicationId");
            this.f1250b = applicationId;
            m2814a(context, action, parameters);
        }

        /* renamed from: a */
        public C0695a m2815a(C0656c listener) {
            this.f1253e = listener;
            return this;
        }

        /* renamed from: a */
        public C0665s mo874a() {
            if (this.f1255g != null) {
                this.f1254f.putString("app_id", this.f1255g.m2391h());
                this.f1254f.putString("access_token", this.f1255g.m2385b());
            } else {
                this.f1254f.putString("app_id", this.f1250b);
            }
            return new C0665s(this.f1249a, this.f1251c, this.f1254f, this.f1252d, this.f1253e);
        }

        /* renamed from: b */
        public String m2817b() {
            return this.f1250b;
        }

        /* renamed from: c */
        public Context m2818c() {
            return this.f1249a;
        }

        /* renamed from: d */
        public int m2819d() {
            return this.f1252d;
        }

        /* renamed from: e */
        public Bundle m2820e() {
            return this.f1254f;
        }

        /* renamed from: f */
        public C0656c m2821f() {
            return this.f1253e;
        }

        /* renamed from: a */
        private void m2814a(Context context, String action, Bundle parameters) {
            this.f1249a = context;
            this.f1251c = action;
            if (parameters != null) {
                this.f1254f = parameters;
            } else {
                this.f1254f = new Bundle();
            }
        }
    }

    /* compiled from: WebDialog */
    /* renamed from: com.facebook.b.s$b */
    private class C0696b extends WebViewClient {
        /* renamed from: a */
        final /* synthetic */ C0665s f1256a;

        private C0696b(C0665s c0665s) {
            this.f1256a = c0665s;
        }

        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            C0689q.m2775a("FacebookSDK.WebDialog", "Redirect URL: " + url);
            if (url.startsWith(this.f1256a.f1174b)) {
                Bundle values = this.f1256a.mo857a(url);
                String error = values.getString("error");
                if (error == null) {
                    error = values.getString("error_type");
                }
                String errorMessage = values.getString("error_msg");
                if (errorMessage == null) {
                    errorMessage = values.getString("error_message");
                }
                if (errorMessage == null) {
                    errorMessage = values.getString("error_description");
                }
                String errorCodeString = values.getString("error_code");
                int errorCode = -1;
                if (!C0689q.m2782a(errorCodeString)) {
                    try {
                        errorCode = Integer.parseInt(errorCodeString);
                    } catch (NumberFormatException e) {
                        errorCode = -1;
                    }
                }
                if (C0689q.m2782a(error) && C0689q.m2782a(errorMessage) && errorCode == -1) {
                    this.f1256a.m2654a(values);
                } else if (error != null && (error.equals("access_denied") || error.equals("OAuthAccessDeniedException"))) {
                    this.f1256a.cancel();
                } else if (errorCode == 4201) {
                    this.f1256a.cancel();
                } else {
                    this.f1256a.m2656a(new C0709i(new FacebookRequestError(errorCode, error, errorMessage), errorMessage));
                }
                return true;
            } else if (url.startsWith("fbconnect://cancel")) {
                this.f1256a.cancel();
                return true;
            } else if (url.contains("touch")) {
                return false;
            } else {
                try {
                    this.f1256a.getContext().startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
                    return true;
                } catch (ActivityNotFoundException e2) {
                    return false;
                }
            }
        }

        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            super.onReceivedError(view, errorCode, description, failingUrl);
            this.f1256a.m2656a(new C0700d(description, errorCode, failingUrl));
        }

        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            super.onReceivedSslError(view, handler, error);
            handler.cancel();
            this.f1256a.m2656a(new C0700d(null, -11, null));
        }

        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            C0689q.m2775a("FacebookSDK.WebDialog", "Webview loading URL: " + url);
            super.onPageStarted(view, url, favicon);
            if (!this.f1256a.f1181i) {
                this.f1256a.f1177e.show();
            }
        }

        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            if (!this.f1256a.f1181i) {
                this.f1256a.f1177e.dismiss();
            }
            this.f1256a.f1179g.setBackgroundColor(0);
            this.f1256a.f1176d.setVisibility(0);
            this.f1256a.f1178f.setVisibility(0);
            this.f1256a.f1182j = true;
        }
    }

    public C0665s(Context context, String url) {
        this(context, url, C0707g.m2860k());
    }

    public C0665s(Context context, String url, int theme) {
        if (theme == 0) {
            theme = C0707g.m2860k();
        }
        super(context, theme);
        this.f1174b = "fbconnect://success";
        this.f1180h = false;
        this.f1181i = false;
        this.f1182j = false;
        this.f1173a = url;
    }

    public C0665s(Context context, String action, Bundle parameters, int theme, C0656c listener) {
        if (theme == 0) {
            theme = C0707g.m2860k();
        }
        super(context, theme);
        this.f1174b = "fbconnect://success";
        this.f1180h = false;
        this.f1181i = false;
        this.f1182j = false;
        if (parameters == null) {
            parameters = new Bundle();
        }
        parameters.putString("redirect_uri", "fbconnect://success");
        parameters.putString("display", "touch");
        parameters.putString("sdk", String.format(Locale.ROOT, "android-%s", new Object[]{C0707g.m2856g()}));
        this.f1173a = C0689q.m2749a(C0682p.m2731a(), C0682p.m2734d() + "/" + "dialog/" + action, parameters).toString();
        this.f1175c = listener;
    }

    /* renamed from: a */
    public void m2655a(C0656c listener) {
        this.f1175c = listener;
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            cancel();
        }
        return super.onKeyDown(keyCode, event);
    }

    public void dismiss() {
        if (this.f1176d != null) {
            this.f1176d.stopLoading();
        }
        if (!(this.f1181i || this.f1177e == null || !this.f1177e.isShowing())) {
            this.f1177e.dismiss();
        }
        super.dismiss();
    }

    protected void onStart() {
        super.onStart();
        m2661d();
    }

    public void onDetachedFromWindow() {
        this.f1181i = true;
        super.onDetachedFromWindow();
    }

    public void onAttachedToWindow() {
        this.f1181i = false;
        super.onAttachedToWindow();
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.f1177e = new ProgressDialog(getContext());
        this.f1177e.requestWindowFeature(1);
        this.f1177e.setMessage(getContext().getString(C0775d.com_facebook_loading));
        this.f1177e.setCanceledOnTouchOutside(false);
        this.f1177e.setOnCancelListener(new C06911(this));
        requestWindowFeature(1);
        this.f1179g = new FrameLayout(getContext());
        m2661d();
        getWindow().setGravity(17);
        getWindow().setSoftInputMode(16);
        m2651e();
        m2645a((this.f1178f.getDrawable().getIntrinsicWidth() / 2) + 1);
        this.f1179g.addView(this.f1178f, new LayoutParams(-2, -2));
        setContentView(this.f1179g);
    }

    /* renamed from: b */
    protected void m2658b(String expectedRedirectUrl) {
        this.f1174b = expectedRedirectUrl;
    }

    /* renamed from: a */
    protected Bundle mo857a(String urlString) {
        Uri u = Uri.parse(urlString);
        Bundle b = C0689q.m2785b(u.getQuery());
        b.putAll(C0689q.m2785b(u.getFragment()));
        return b;
    }

    /* renamed from: a */
    protected boolean m2657a() {
        return this.f1180h;
    }

    /* renamed from: b */
    protected boolean m2659b() {
        return this.f1182j;
    }

    /* renamed from: c */
    protected WebView m2660c() {
        return this.f1176d;
    }

    /* renamed from: d */
    public void m2661d() {
        Display display = ((WindowManager) getContext().getSystemService("window")).getDefaultDisplay();
        DisplayMetrics metrics = new DisplayMetrics();
        display.getMetrics(metrics);
        getWindow().setLayout(Math.min(m2643a(metrics.widthPixels < metrics.heightPixels ? metrics.widthPixels : metrics.heightPixels, metrics.density, 480, 800), metrics.widthPixels), Math.min(m2643a(metrics.widthPixels < metrics.heightPixels ? metrics.heightPixels : metrics.widthPixels, metrics.density, 800, 1280), metrics.heightPixels));
    }

    /* renamed from: a */
    private int m2643a(int screenSize, float density, int noPaddingSize, int maxPaddingSize) {
        double scaleFactor;
        int scaledSize = (int) (((float) screenSize) / density);
        if (scaledSize <= noPaddingSize) {
            scaleFactor = 1.0d;
        } else if (scaledSize >= maxPaddingSize) {
            scaleFactor = 0.5d;
        } else {
            scaleFactor = 0.5d + ((((double) (maxPaddingSize - scaledSize)) / ((double) (maxPaddingSize - noPaddingSize))) * 0.5d);
        }
        return (int) (((double) screenSize) * scaleFactor);
    }

    /* renamed from: a */
    protected void m2654a(Bundle values) {
        if (this.f1175c != null && !this.f1180h) {
            this.f1180h = true;
            this.f1175c.mo854a(values, null);
            dismiss();
        }
    }

    /* renamed from: a */
    protected void m2656a(Throwable error) {
        if (this.f1175c != null && !this.f1180h) {
            C0699e facebookException;
            this.f1180h = true;
            if (error instanceof C0699e) {
                facebookException = (C0699e) error;
            } else {
                facebookException = new C0699e(error);
            }
            this.f1175c.mo854a(null, facebookException);
            dismiss();
        }
    }

    public void cancel() {
        if (this.f1175c != null && !this.f1180h) {
            m2656a(new C0701f());
        }
    }

    /* renamed from: e */
    private void m2651e() {
        this.f1178f = new ImageView(getContext());
        this.f1178f.setOnClickListener(new C06922(this));
        this.f1178f.setImageDrawable(getContext().getResources().getDrawable(C0772a.com_facebook_close));
        this.f1178f.setVisibility(4);
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    /* renamed from: a */
    private void m2645a(int margin) {
        LinearLayout webViewContainer = new LinearLayout(getContext());
        this.f1176d = new WebView(this, getContext().getApplicationContext()) {
            /* renamed from: a */
            final /* synthetic */ C0665s f1247a;

            public void onWindowFocusChanged(boolean hasWindowFocus) {
                try {
                    super.onWindowFocusChanged(hasWindowFocus);
                } catch (NullPointerException e) {
                }
            }
        };
        this.f1176d.setVerticalScrollBarEnabled(false);
        this.f1176d.setHorizontalScrollBarEnabled(false);
        this.f1176d.setWebViewClient(new C0696b());
        this.f1176d.getSettings().setJavaScriptEnabled(true);
        this.f1176d.loadUrl(this.f1173a);
        this.f1176d.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        this.f1176d.setVisibility(4);
        this.f1176d.getSettings().setSavePassword(false);
        this.f1176d.getSettings().setSaveFormData(false);
        this.f1176d.setFocusable(true);
        this.f1176d.setFocusableInTouchMode(true);
        this.f1176d.setOnTouchListener(new C06944(this));
        webViewContainer.setPadding(margin, margin, margin, margin);
        webViewContainer.addView(this.f1176d);
        webViewContainer.setBackgroundColor(-872415232);
        this.f1179g.addView(webViewContainer);
    }
}

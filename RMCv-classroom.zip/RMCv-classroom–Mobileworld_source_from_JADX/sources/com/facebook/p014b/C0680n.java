package com.facebook.p014b;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;

/* compiled from: PlatformServiceClient */
/* renamed from: com.facebook.b.n */
public abstract class C0680n implements ServiceConnection {
    /* renamed from: a */
    private final Context f1203a;
    /* renamed from: b */
    private final Handler f1204b;
    /* renamed from: c */
    private C0679a f1205c;
    /* renamed from: d */
    private boolean f1206d;
    /* renamed from: e */
    private Messenger f1207e;
    /* renamed from: f */
    private int f1208f;
    /* renamed from: g */
    private int f1209g;
    /* renamed from: h */
    private final String f1210h;
    /* renamed from: i */
    private final int f1211i;

    /* compiled from: PlatformServiceClient */
    /* renamed from: com.facebook.b.n$1 */
    class C06781 extends Handler {
        /* renamed from: a */
        final /* synthetic */ C0680n f1202a;

        C06781(C0680n this$0) {
            this.f1202a = this$0;
        }

        public void handleMessage(Message message) {
            this.f1202a.m2725a(message);
        }
    }

    /* compiled from: PlatformServiceClient */
    /* renamed from: com.facebook.b.n$a */
    public interface C0679a {
        /* renamed from: a */
        void mo872a(Bundle bundle);
    }

    /* renamed from: a */
    protected abstract void mo876a(Bundle bundle);

    public C0680n(Context context, int requestMessage, int replyMessage, int protocolVersion, String applicationId) {
        Context applicationContext = context.getApplicationContext();
        if (applicationContext == null) {
            applicationContext = context;
        }
        this.f1203a = applicationContext;
        this.f1208f = requestMessage;
        this.f1209g = replyMessage;
        this.f1210h = applicationId;
        this.f1211i = protocolVersion;
        this.f1204b = new C06781(this);
    }

    /* renamed from: a */
    public void m2726a(C0679a listener) {
        this.f1205c = listener;
    }

    /* renamed from: a */
    public boolean m2727a() {
        if (this.f1206d || C0677m.m2709b(this.f1211i) == -1) {
            return false;
        }
        Intent intent = C0677m.m2700a(this.f1203a);
        if (intent == null) {
            return false;
        }
        this.f1206d = true;
        this.f1203a.bindService(intent, this, 1);
        return true;
    }

    /* renamed from: b */
    public void m2728b() {
        this.f1206d = false;
    }

    public void onServiceConnected(ComponentName name, IBinder service) {
        this.f1207e = new Messenger(service);
        m2723c();
    }

    public void onServiceDisconnected(ComponentName name) {
        this.f1207e = null;
        try {
            this.f1203a.unbindService(this);
        } catch (IllegalArgumentException e) {
        }
        m2722b(null);
    }

    /* renamed from: c */
    private void m2723c() {
        Bundle data = new Bundle();
        data.putString("com.facebook.platform.extra.APPLICATION_ID", this.f1210h);
        mo876a(data);
        Message request = Message.obtain(null, this.f1208f);
        request.arg1 = this.f1211i;
        request.setData(data);
        request.replyTo = new Messenger(this.f1204b);
        try {
            this.f1207e.send(request);
        } catch (RemoteException e) {
            m2722b(null);
        }
    }

    /* renamed from: a */
    protected void m2725a(Message message) {
        if (message.what == this.f1209g) {
            Bundle extras = message.getData();
            if (extras.getString("com.facebook.platform.status.ERROR_TYPE") != null) {
                m2722b(null);
            } else {
                m2722b(extras);
            }
            try {
                this.f1203a.unbindService(this);
            } catch (IllegalArgumentException e) {
            }
        }
    }

    /* renamed from: b */
    private void m2722b(Bundle result) {
        if (this.f1206d) {
            this.f1206d = false;
            C0679a callback = this.f1205c;
            if (callback != null) {
                callback.mo872a(result);
            }
        }
    }
}

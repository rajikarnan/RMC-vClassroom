package com.facebook.p014b;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.util.Log;
import com.facebook.C0707g;
import com.facebook.C0708h;
import com.facebook.CustomTabActivity;
import com.facebook.FacebookActivity;
import java.util.Collection;
import java.util.List;

/* compiled from: Validate */
/* renamed from: com.facebook.b.r */
public final class C0690r {
    /* renamed from: a */
    private static final String f1244a = C0690r.class.getName();

    /* renamed from: a */
    public static void m2805a(Object arg, String name) {
        if (arg == null) {
            throw new NullPointerException("Argument '" + name + "' cannot be null");
        }
    }

    /* renamed from: a */
    public static <T> void m2807a(Collection<T> container, String name) {
        if (container.isEmpty()) {
            throw new IllegalArgumentException("Container '" + name + "' cannot be empty");
        }
    }

    /* renamed from: b */
    public static <T> void m2811b(Collection<T> container, String name) {
        C0690r.m2805a((Object) container, name);
        for (T item : container) {
            if (item == null) {
                throw new NullPointerException("Container '" + name + "' cannot contain null values");
            }
        }
    }

    /* renamed from: c */
    public static <T> void m2813c(Collection<T> container, String name) {
        C0690r.m2811b((Collection) container, name);
        C0690r.m2807a((Collection) container, name);
    }

    /* renamed from: a */
    public static void m2806a(String arg, String name) {
        if (C0689q.m2782a(arg)) {
            throw new IllegalArgumentException("Argument '" + name + "' cannot be null or empty");
        }
    }

    /* renamed from: a */
    public static void m2803a() {
        if (!C0707g.m2846a()) {
            throw new C0708h("The SDK has not been initialized, make sure to call FacebookSdk.sdkInitialize() first.");
        }
    }

    /* renamed from: b */
    public static String m2809b() {
        String id = C0707g.m2858i();
        if (id != null) {
            return id;
        }
        throw new IllegalStateException("No App ID found, please set the App ID.");
    }

    /* renamed from: c */
    public static String m2812c() {
        String token = C0707g.m2859j();
        if (token != null) {
            return token;
        }
        throw new IllegalStateException("No Client Token found, please set the Client Token.");
    }

    /* renamed from: a */
    public static void m2804a(Context context, boolean shouldThrow) {
        C0690r.m2805a((Object) context, "context");
        if (context.checkCallingOrSelfPermission("android.permission.INTERNET") != -1) {
            return;
        }
        if (shouldThrow) {
            throw new IllegalStateException("No internet permissions granted for the app, please add <uses-permission android:name=\"android.permission.INTERNET\" /> to your AndroidManifest.xml.");
        }
        Log.w(f1244a, "No internet permissions granted for the app, please add <uses-permission android:name=\"android.permission.INTERNET\" /> to your AndroidManifest.xml.");
    }

    /* renamed from: b */
    public static void m2810b(Context context, boolean shouldThrow) {
        C0690r.m2805a((Object) context, "context");
        PackageManager pm = context.getPackageManager();
        ActivityInfo activityInfo = null;
        if (pm != null) {
            try {
                activityInfo = pm.getActivityInfo(new ComponentName(context, FacebookActivity.class), 1);
            } catch (NameNotFoundException e) {
            }
        }
        if (activityInfo != null) {
            return;
        }
        if (shouldThrow) {
            throw new IllegalStateException("FacebookActivity is not declared in the AndroidManifest.xml, please add com.facebook.FacebookActivity to your AndroidManifest.xml file. See https://developers.facebook.com/docs/android/getting-started for more info.");
        }
        Log.w(f1244a, "FacebookActivity is not declared in the AndroidManifest.xml, please add com.facebook.FacebookActivity to your AndroidManifest.xml file. See https://developers.facebook.com/docs/android/getting-started for more info.");
    }

    /* renamed from: a */
    public static boolean m2808a(Context context) {
        C0690r.m2805a((Object) context, "context");
        PackageManager pm = context.getPackageManager();
        List<ResolveInfo> infos = null;
        if (pm != null) {
            Intent intent = new Intent();
            intent.setAction("android.intent.action.VIEW");
            intent.addCategory("android.intent.category.DEFAULT");
            intent.addCategory("android.intent.category.BROWSABLE");
            intent.setData(Uri.parse("fb" + C0707g.m2858i() + "://authorize"));
            infos = pm.queryIntentActivities(intent, 64);
        }
        boolean hasActivity = false;
        if (infos != null) {
            for (ResolveInfo info : infos) {
                if (!info.activityInfo.name.equals(CustomTabActivity.class.getName())) {
                    return false;
                }
                hasActivity = true;
            }
        }
        return hasActivity;
    }
}

package com.facebook.p014b;

import android.os.Bundle;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: BundleJSONConverter */
/* renamed from: com.facebook.b.d */
public class C0652d {
    /* renamed from: a */
    private static final Map<Class<?>, C0644a> f1147a = new HashMap();

    /* compiled from: BundleJSONConverter */
    /* renamed from: com.facebook.b.d$a */
    public interface C0644a {
        /* renamed from: a */
        void mo853a(Bundle bundle, String str, Object obj) throws JSONException;
    }

    /* compiled from: BundleJSONConverter */
    /* renamed from: com.facebook.b.d$1 */
    static class C06451 implements C0644a {
        C06451() {
        }

        /* renamed from: a */
        public void mo853a(Bundle bundle, String key, Object value) throws JSONException {
            bundle.putBoolean(key, ((Boolean) value).booleanValue());
        }
    }

    /* compiled from: BundleJSONConverter */
    /* renamed from: com.facebook.b.d$2 */
    static class C06462 implements C0644a {
        C06462() {
        }

        /* renamed from: a */
        public void mo853a(Bundle bundle, String key, Object value) throws JSONException {
            bundle.putInt(key, ((Integer) value).intValue());
        }
    }

    /* compiled from: BundleJSONConverter */
    /* renamed from: com.facebook.b.d$3 */
    static class C06473 implements C0644a {
        C06473() {
        }

        /* renamed from: a */
        public void mo853a(Bundle bundle, String key, Object value) throws JSONException {
            bundle.putLong(key, ((Long) value).longValue());
        }
    }

    /* compiled from: BundleJSONConverter */
    /* renamed from: com.facebook.b.d$4 */
    static class C06484 implements C0644a {
        C06484() {
        }

        /* renamed from: a */
        public void mo853a(Bundle bundle, String key, Object value) throws JSONException {
            bundle.putDouble(key, ((Double) value).doubleValue());
        }
    }

    /* compiled from: BundleJSONConverter */
    /* renamed from: com.facebook.b.d$5 */
    static class C06495 implements C0644a {
        C06495() {
        }

        /* renamed from: a */
        public void mo853a(Bundle bundle, String key, Object value) throws JSONException {
            bundle.putString(key, (String) value);
        }
    }

    /* compiled from: BundleJSONConverter */
    /* renamed from: com.facebook.b.d$6 */
    static class C06506 implements C0644a {
        C06506() {
        }

        /* renamed from: a */
        public void mo853a(Bundle bundle, String key, Object value) throws JSONException {
            throw new IllegalArgumentException("Unexpected type from JSON");
        }
    }

    /* compiled from: BundleJSONConverter */
    /* renamed from: com.facebook.b.d$7 */
    static class C06517 implements C0644a {
        C06517() {
        }

        /* renamed from: a */
        public void mo853a(Bundle bundle, String key, Object value) throws JSONException {
            JSONArray jsonArray = (JSONArray) value;
            ArrayList<String> stringArrayList = new ArrayList();
            if (jsonArray.length() == 0) {
                bundle.putStringArrayList(key, stringArrayList);
                return;
            }
            int i = 0;
            while (i < jsonArray.length()) {
                Object current = jsonArray.get(i);
                if (current instanceof String) {
                    stringArrayList.add((String) current);
                    i++;
                } else {
                    throw new IllegalArgumentException("Unexpected type in an array: " + current.getClass());
                }
            }
            bundle.putStringArrayList(key, stringArrayList);
        }
    }

    static {
        f1147a.put(Boolean.class, new C06451());
        f1147a.put(Integer.class, new C06462());
        f1147a.put(Long.class, new C06473());
        f1147a.put(Double.class, new C06484());
        f1147a.put(String.class, new C06495());
        f1147a.put(String[].class, new C06506());
        f1147a.put(JSONArray.class, new C06517());
    }

    /* renamed from: a */
    public static Bundle m2626a(JSONObject jsonObject) throws JSONException {
        Bundle bundle = new Bundle();
        Iterator<String> jsonIterator = jsonObject.keys();
        while (jsonIterator.hasNext()) {
            String key = (String) jsonIterator.next();
            Object value = jsonObject.get(key);
            if (!(value == null || value == JSONObject.NULL)) {
                if (value instanceof JSONObject) {
                    bundle.putBundle(key, C0652d.m2626a((JSONObject) value));
                } else {
                    C0644a setter = (C0644a) f1147a.get(value.getClass());
                    if (setter == null) {
                        throw new IllegalArgumentException("Unsupported type: " + value.getClass());
                    }
                    setter.mo853a(bundle, key, value);
                }
            }
        }
        return bundle;
    }
}

package com.facebook.p014b;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.support.p001a.C0003a;
import android.support.p001a.C0003a.C0002a;

/* compiled from: CustomTab */
/* renamed from: com.facebook.b.f */
public class C0655f {
    /* renamed from: a */
    private Uri f1160a;

    public C0655f(String action, Bundle parameters) {
        if (parameters == null) {
            parameters = new Bundle();
        }
        this.f1160a = C0689q.m2749a(C0682p.m2731a(), C0682p.m2734d() + "/" + "dialog/" + action, parameters);
    }

    /* renamed from: a */
    public void m2628a(Activity activity, String packageName) {
        C0003a customTabsIntent = new C0002a().m1a();
        customTabsIntent.f4a.setPackage(packageName);
        customTabsIntent.f4a.addFlags(1073741824);
        customTabsIntent.m2a(activity, this.f1160a);
    }
}

package com.facebook.p014b;

/* compiled from: InternalSettings */
/* renamed from: com.facebook.b.j */
public class C0667j {
    /* renamed from: a */
    private static volatile String f1185a;

    /* renamed from: a */
    public static String m2664a() {
        return f1185a;
    }
}

package com.facebook;

/* compiled from: FacebookServiceException */
/* renamed from: com.facebook.i */
public class C0709i extends C0699e {
    /* renamed from: a */
    private final FacebookRequestError f1299a;

    public C0709i(FacebookRequestError error, String errorMessage) {
        super(errorMessage);
        this.f1299a = error;
    }

    /* renamed from: a */
    public final FacebookRequestError m2863a() {
        return this.f1299a;
    }

    public final String toString() {
        return "{FacebookServiceException: " + "httpResponseCode: " + this.f1299a.m2403a() + ", facebookErrorCode: " + this.f1299a.m2404b() + ", facebookErrorType: " + this.f1299a.m2406d() + ", message: " + this.f1299a.m2407e() + "}";
    }
}

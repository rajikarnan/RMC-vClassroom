package com.facebook;

import android.os.Handler;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

/* compiled from: ProgressNoopOutputStream */
/* renamed from: com.facebook.r */
class C0751r extends OutputStream implements C0750u {
    /* renamed from: a */
    private final Map<GraphRequest, C0779v> f1432a = new HashMap();
    /* renamed from: b */
    private final Handler f1433b;
    /* renamed from: c */
    private GraphRequest f1434c;
    /* renamed from: d */
    private C0779v f1435d;
    /* renamed from: e */
    private int f1436e;

    C0751r(Handler callbackHandler) {
        this.f1433b = callbackHandler;
    }

    /* renamed from: a */
    public void mo882a(GraphRequest currentRequest) {
        this.f1434c = currentRequest;
        this.f1435d = currentRequest != null ? (C0779v) this.f1432a.get(currentRequest) : null;
    }

    /* renamed from: a */
    int m3093a() {
        return this.f1436e;
    }

    /* renamed from: b */
    Map<GraphRequest, C0779v> m3096b() {
        return this.f1432a;
    }

    /* renamed from: a */
    void m3094a(long size) {
        if (this.f1435d == null) {
            this.f1435d = new C0779v(this.f1433b, this.f1434c);
            this.f1432a.put(this.f1434c, this.f1435d);
        }
        this.f1435d.m3173b(size);
        this.f1436e = (int) (((long) this.f1436e) + size);
    }

    public void write(byte[] buffer) {
        m3094a((long) buffer.length);
    }

    public void write(byte[] buffer, int offset, int length) {
        m3094a((long) length);
    }

    public void write(int oneByte) {
        m3094a(1);
    }
}

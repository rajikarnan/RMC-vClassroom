package com.facebook;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.facebook.p014b.C0663h;
import com.facebook.p014b.C0689q;
import com.facebook.p014b.C0689q.C0687b;
import java.net.HttpURLConnection;
import org.json.JSONException;
import org.json.JSONObject;

public final class FacebookRequestError implements Parcelable {
    public static final Creator<FacebookRequestError> CREATOR = new C05751();
    /* renamed from: a */
    static final C0577b f961a = new C0577b(200, 299);
    /* renamed from: b */
    private final C0576a f962b;
    /* renamed from: c */
    private final int f963c;
    /* renamed from: d */
    private final int f964d;
    /* renamed from: e */
    private final int f965e;
    /* renamed from: f */
    private final String f966f;
    /* renamed from: g */
    private final String f967g;
    /* renamed from: h */
    private final String f968h;
    /* renamed from: i */
    private final String f969i;
    /* renamed from: j */
    private final String f970j;
    /* renamed from: k */
    private final JSONObject f971k;
    /* renamed from: l */
    private final JSONObject f972l;
    /* renamed from: m */
    private final Object f973m;
    /* renamed from: n */
    private final HttpURLConnection f974n;
    /* renamed from: o */
    private final C0699e f975o;

    /* renamed from: com.facebook.FacebookRequestError$1 */
    static class C05751 implements Creator<FacebookRequestError> {
        C05751() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m2398a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m2399a(i);
        }

        /* renamed from: a */
        public FacebookRequestError m2398a(Parcel in) {
            return new FacebookRequestError(in);
        }

        /* renamed from: a */
        public FacebookRequestError[] m2399a(int size) {
            return new FacebookRequestError[size];
        }
    }

    /* renamed from: com.facebook.FacebookRequestError$a */
    public enum C0576a {
        LOGIN_RECOVERABLE,
        OTHER,
        TRANSIENT
    }

    /* renamed from: com.facebook.FacebookRequestError$b */
    private static class C0577b {
        /* renamed from: a */
        private final int f959a;
        /* renamed from: b */
        private final int f960b;

        private C0577b(int start, int end) {
            this.f959a = start;
            this.f960b = end;
        }

        /* renamed from: a */
        boolean m2400a(int value) {
            return this.f959a <= value && value <= this.f960b;
        }
    }

    private FacebookRequestError(int requestStatusCode, int errorCode, int subErrorCode, String errorType, String errorMessage, String errorUserTitle, String errorUserMessage, boolean errorIsTransient, JSONObject requestResultBody, JSONObject requestResult, Object batchRequestResult, HttpURLConnection connection, C0699e exception) {
        C0576a c0576a;
        this.f963c = requestStatusCode;
        this.f964d = errorCode;
        this.f965e = subErrorCode;
        this.f966f = errorType;
        this.f967g = errorMessage;
        this.f972l = requestResultBody;
        this.f971k = requestResult;
        this.f973m = batchRequestResult;
        this.f974n = connection;
        this.f968h = errorUserTitle;
        this.f969i = errorUserMessage;
        boolean isLocalException = false;
        if (exception != null) {
            this.f975o = exception;
            isLocalException = true;
        } else {
            this.f975o = new C0709i(this, errorMessage);
        }
        C0663h errorClassification = m2402g();
        if (isLocalException) {
            c0576a = C0576a.OTHER;
        } else {
            c0576a = errorClassification.m2641a(errorCode, subErrorCode, errorIsTransient);
        }
        this.f962b = c0576a;
        this.f970j = errorClassification.m2642a(this.f962b);
    }

    FacebookRequestError(HttpURLConnection connection, Exception exception) {
        this(-1, -1, -1, null, null, null, null, false, null, null, null, connection, exception instanceof C0699e ? (C0699e) exception : new C0699e((Throwable) exception));
    }

    public FacebookRequestError(int errorCode, String errorType, String errorMessage) {
        this(-1, errorCode, -1, errorType, errorMessage, null, null, false, null, null, null, null, null);
    }

    /* renamed from: a */
    public int m2403a() {
        return this.f963c;
    }

    /* renamed from: b */
    public int m2404b() {
        return this.f964d;
    }

    /* renamed from: c */
    public int m2405c() {
        return this.f965e;
    }

    /* renamed from: d */
    public String m2406d() {
        return this.f966f;
    }

    /* renamed from: e */
    public String m2407e() {
        if (this.f967g != null) {
            return this.f967g;
        }
        return this.f975o.getLocalizedMessage();
    }

    /* renamed from: f */
    public C0699e m2408f() {
        return this.f975o;
    }

    public String toString() {
        return "{HttpStatus: " + this.f963c + ", errorCode: " + this.f964d + ", errorType: " + this.f966f + ", errorMessage: " + m2407e() + "}";
    }

    /* renamed from: a */
    static FacebookRequestError m2401a(JSONObject singleResult, Object batchResult, HttpURLConnection connection) {
        try {
            if (singleResult.has("code")) {
                int responseCode = singleResult.getInt("code");
                Object body = C0689q.m2754a(singleResult, "body", "FACEBOOK_NON_JSON_RESULT");
                if (body != null && (body instanceof JSONObject)) {
                    JSONObject jsonBody = (JSONObject) body;
                    String errorType = null;
                    String errorMessage = null;
                    String errorUserMessage = null;
                    String errorUserTitle = null;
                    boolean errorIsTransient = false;
                    int errorCode = -1;
                    int errorSubCode = -1;
                    boolean hasError = false;
                    if (jsonBody.has("error")) {
                        JSONObject error = (JSONObject) C0689q.m2754a(jsonBody, "error", null);
                        errorType = error.optString("type", null);
                        errorMessage = error.optString("message", null);
                        errorCode = error.optInt("code", -1);
                        errorSubCode = error.optInt("error_subcode", -1);
                        errorUserMessage = error.optString("error_user_msg", null);
                        errorUserTitle = error.optString("error_user_title", null);
                        errorIsTransient = error.optBoolean("is_transient", false);
                        hasError = true;
                    } else if (jsonBody.has("error_code") || jsonBody.has("error_msg") || jsonBody.has("error_reason")) {
                        errorType = jsonBody.optString("error_reason", null);
                        errorMessage = jsonBody.optString("error_msg", null);
                        errorCode = jsonBody.optInt("error_code", -1);
                        errorSubCode = jsonBody.optInt("error_subcode", -1);
                        hasError = true;
                    }
                    if (hasError) {
                        return new FacebookRequestError(responseCode, errorCode, errorSubCode, errorType, errorMessage, errorUserTitle, errorUserMessage, errorIsTransient, jsonBody, singleResult, batchResult, connection, null);
                    }
                }
                if (!f961a.m2400a(responseCode)) {
                    JSONObject jSONObject;
                    if (singleResult.has("body")) {
                        jSONObject = (JSONObject) C0689q.m2754a(singleResult, "body", "FACEBOOK_NON_JSON_RESULT");
                    } else {
                        jSONObject = null;
                    }
                    return new FacebookRequestError(responseCode, -1, -1, null, null, null, null, false, jSONObject, singleResult, batchResult, connection, null);
                }
            }
        } catch (JSONException e) {
        }
        return null;
    }

    /* renamed from: g */
    static synchronized C0663h m2402g() {
        C0663h a;
        synchronized (FacebookRequestError.class) {
            C0687b appSettings = C0689q.m2791c(C0707g.m2858i());
            if (appSettings == null) {
                a = C0663h.m2637a();
            } else {
                a = appSettings.m2743c();
            }
        }
        return a;
    }

    public void writeToParcel(Parcel out, int flags) {
        out.writeInt(this.f963c);
        out.writeInt(this.f964d);
        out.writeInt(this.f965e);
        out.writeString(this.f966f);
        out.writeString(this.f967g);
        out.writeString(this.f968h);
        out.writeString(this.f969i);
    }

    private FacebookRequestError(Parcel in) {
        this(in.readInt(), in.readInt(), in.readInt(), in.readString(), in.readString(), in.readString(), in.readString(), false, null, null, null, null, null);
    }

    public int describeContents() {
        return 0;
    }
}

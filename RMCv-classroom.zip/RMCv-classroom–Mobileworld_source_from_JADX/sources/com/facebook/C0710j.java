package com.facebook;

import android.os.AsyncTask;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.Log;
import java.net.HttpURLConnection;
import java.util.List;

/* compiled from: GraphRequestAsyncTask */
/* renamed from: com.facebook.j */
public class C0710j extends AsyncTask<Void, Void, List<C0713l>> {
    /* renamed from: a */
    private static final String f1300a = C0710j.class.getCanonicalName();
    /* renamed from: b */
    private final HttpURLConnection f1301b;
    /* renamed from: c */
    private final C0712k f1302c;
    /* renamed from: d */
    private Exception f1303d;

    protected /* synthetic */ Object doInBackground(Object[] objArr) {
        return m2864a((Void[]) objArr);
    }

    protected /* synthetic */ void onPostExecute(Object obj) {
        m2865a((List) obj);
    }

    public C0710j(C0712k requests) {
        this(null, requests);
    }

    public C0710j(HttpURLConnection connection, C0712k requests) {
        this.f1302c = requests;
        this.f1301b = connection;
    }

    public String toString() {
        return "{RequestAsyncTask: " + " connection: " + this.f1301b + ", requests: " + this.f1302c + "}";
    }

    protected void onPreExecute() {
        super.onPreExecute();
        if (C0707g.m2849b()) {
            Log.d(f1300a, String.format("execute async task: %s", new Object[]{this}));
        }
        if (this.f1302c.m2876c() == null) {
            Handler handler;
            if (Thread.currentThread() instanceof HandlerThread) {
                handler = new Handler();
            } else {
                handler = new Handler(Looper.getMainLooper());
            }
            this.f1302c.m2870a(handler);
        }
    }

    /* renamed from: a */
    protected void m2865a(List<C0713l> result) {
        super.onPostExecute(result);
        if (this.f1303d != null) {
            Log.d(f1300a, String.format("onPostExecute: exception encountered during request: %s", new Object[]{this.f1303d.getMessage()}));
        }
    }

    /* renamed from: a */
    protected List<C0713l> m2864a(Void... params) {
        try {
            if (this.f1301b == null) {
                return this.f1302c.m2880g();
            }
            return GraphRequest.m2440a(this.f1301b, this.f1302c);
        } catch (Exception e) {
            this.f1303d = e;
            return null;
        }
    }
}

package com.facebook;

import android.content.SharedPreferences;
import android.os.Bundle;
import com.facebook.p014b.C0690r;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: AccessTokenCache */
/* renamed from: com.facebook.a */
class C0629a {
    /* renamed from: a */
    private final SharedPreferences f1111a;
    /* renamed from: b */
    private final C0592a f1112b;
    /* renamed from: c */
    private C0746n f1113c;

    /* compiled from: AccessTokenCache */
    /* renamed from: com.facebook.a$a */
    static class C0592a {
        C0592a() {
        }

        /* renamed from: a */
        public C0746n m2500a() {
            return new C0746n(C0707g.m2855f());
        }
    }

    C0629a(SharedPreferences sharedPreferences, C0592a tokenCachingStrategyFactory) {
        this.f1111a = sharedPreferences;
        this.f1112b = tokenCachingStrategyFactory;
    }

    public C0629a() {
        this(C0707g.m2855f().getSharedPreferences("com.facebook.AccessTokenManager.SharedPreferences", 0), new C0592a());
    }

    /* renamed from: a */
    public AccessToken m2594a() {
        if (m2589c()) {
            return m2590d();
        }
        if (!m2591e()) {
            return null;
        }
        AccessToken accessToken = m2592f();
        if (accessToken == null) {
            return accessToken;
        }
        m2595a(accessToken);
        m2593g().m3082b();
        return accessToken;
    }

    /* renamed from: a */
    public void m2595a(AccessToken accessToken) {
        C0690r.m2805a((Object) accessToken, "accessToken");
        try {
            this.f1111a.edit().putString("com.facebook.AccessTokenManager.CachedAccessToken", accessToken.m2393j().toString()).apply();
        } catch (JSONException e) {
        }
    }

    /* renamed from: b */
    public void m2596b() {
        this.f1111a.edit().remove("com.facebook.AccessTokenManager.CachedAccessToken").apply();
        if (m2591e()) {
            m2593g().m3082b();
        }
    }

    /* renamed from: c */
    private boolean m2589c() {
        return this.f1111a.contains("com.facebook.AccessTokenManager.CachedAccessToken");
    }

    /* renamed from: d */
    private AccessToken m2590d() {
        AccessToken accessToken = null;
        String jsonString = this.f1111a.getString("com.facebook.AccessTokenManager.CachedAccessToken", accessToken);
        if (jsonString != null) {
            try {
                accessToken = AccessToken.m2380a(new JSONObject(jsonString));
            } catch (JSONException e) {
            }
        }
        return accessToken;
    }

    /* renamed from: e */
    private boolean m2591e() {
        return C0707g.m2852c();
    }

    /* renamed from: f */
    private AccessToken m2592f() {
        Bundle bundle = m2593g().m3081a();
        if (bundle == null || !C0746n.m3077a(bundle)) {
            return null;
        }
        return AccessToken.m2379a(bundle);
    }

    /* renamed from: g */
    private C0746n m2593g() {
        if (this.f1113c == null) {
            synchronized (this) {
                if (this.f1113c == null) {
                    this.f1113c = this.f1112b.m2500a();
                }
            }
        }
        return this.f1113c;
    }
}

package com.facebook;

/* compiled from: FacebookOperationCanceledException */
/* renamed from: com.facebook.f */
public class C0701f extends C0699e {
    public C0701f(String message) {
        super(message);
    }
}

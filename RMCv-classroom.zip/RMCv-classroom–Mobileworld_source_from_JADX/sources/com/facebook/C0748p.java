package com.facebook;

import android.content.SharedPreferences;
import com.facebook.p014b.C0690r;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: ProfileCache */
/* renamed from: com.facebook.p */
final class C0748p {
    /* renamed from: a */
    private final SharedPreferences f1427a = C0707g.m2855f().getSharedPreferences("com.facebook.AccessTokenManager.SharedPreferences", 0);

    C0748p() {
    }

    /* renamed from: a */
    Profile m3083a() {
        String jsonString = this.f1427a.getString("com.facebook.ProfileManager.CachedProfile", null);
        if (jsonString != null) {
            try {
                return new Profile(new JSONObject(jsonString));
            } catch (JSONException e) {
            }
        }
        return null;
    }

    /* renamed from: a */
    void m3084a(Profile profile) {
        C0690r.m2805a((Object) profile, "profile");
        JSONObject jsonObject = profile.m2499c();
        if (jsonObject != null) {
            this.f1427a.edit().putString("com.facebook.ProfileManager.CachedProfile", jsonObject.toString()).apply();
        }
    }

    /* renamed from: b */
    void m3085b() {
        this.f1427a.edit().remove("com.facebook.ProfileManager.CachedProfile").apply();
    }
}

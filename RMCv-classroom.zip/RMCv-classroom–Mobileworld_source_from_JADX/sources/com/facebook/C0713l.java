package com.facebook;

import com.facebook.p014b.C0670l;
import com.facebook.p014b.C0689q;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

/* compiled from: GraphResponse */
/* renamed from: com.facebook.l */
public class C0713l {
    /* renamed from: a */
    private final HttpURLConnection f1311a;
    /* renamed from: b */
    private final JSONObject f1312b;
    /* renamed from: c */
    private final JSONArray f1313c;
    /* renamed from: d */
    private final FacebookRequestError f1314d;
    /* renamed from: e */
    private final String f1315e;
    /* renamed from: f */
    private final GraphRequest f1316f;

    C0713l(GraphRequest request, HttpURLConnection connection, String rawResponse, JSONObject graphObject) {
        this(request, connection, rawResponse, graphObject, null, null);
    }

    C0713l(GraphRequest request, HttpURLConnection connection, String rawResponse, JSONArray graphObjects) {
        this(request, connection, rawResponse, null, graphObjects, null);
    }

    C0713l(GraphRequest request, HttpURLConnection connection, FacebookRequestError error) {
        this(request, connection, null, null, null, error);
    }

    C0713l(GraphRequest request, HttpURLConnection connection, String rawResponse, JSONObject graphObject, JSONArray graphObjects, FacebookRequestError error) {
        this.f1316f = request;
        this.f1311a = connection;
        this.f1315e = rawResponse;
        this.f1312b = graphObject;
        this.f1313c = graphObjects;
        this.f1314d = error;
    }

    /* renamed from: a */
    public final FacebookRequestError m2890a() {
        return this.f1314d;
    }

    /* renamed from: b */
    public final JSONObject m2891b() {
        return this.f1312b;
    }

    public String toString() {
        String responseCode;
        try {
            Locale locale = Locale.US;
            String str = "%d";
            Object[] objArr = new Object[1];
            objArr[0] = Integer.valueOf(this.f1311a != null ? this.f1311a.getResponseCode() : 200);
            responseCode = String.format(locale, str, objArr);
        } catch (IOException e) {
            responseCode = "unknown";
        }
        return "{Response: " + " responseCode: " + responseCode + ", graphObject: " + this.f1312b + ", error: " + this.f1314d + "}";
    }

    /* renamed from: a */
    static List<C0713l> m2887a(HttpURLConnection connection, C0712k requests) {
        List<C0713l> a;
        Closeable stream = null;
        try {
            if (connection.getResponseCode() >= 400) {
                stream = connection.getErrorStream();
            } else {
                stream = connection.getInputStream();
            }
            a = C0713l.m2885a((InputStream) stream, connection, requests);
        } catch (C0699e facebookException) {
            C0670l.m2671a(C0747o.REQUESTS, "Response", "Response <Error>: %s", facebookException);
            a = C0713l.m2889a((List) requests, connection, facebookException);
        } catch (Throwable exception) {
            C0670l.m2671a(C0747o.REQUESTS, "Response", "Response <Error>: %s", exception);
            a = C0713l.m2889a((List) requests, connection, new C0699e(exception));
        } finally {
            C0689q.m2772a(stream);
        }
        return a;
    }

    /* renamed from: a */
    static List<C0713l> m2885a(InputStream stream, HttpURLConnection connection, C0712k requests) throws C0699e, JSONException, IOException {
        C0670l.m2671a(C0747o.INCLUDE_RAW_RESPONSES, "Response", "Response (raw)\n  Size: %d\n  Response:\n%s\n", Integer.valueOf(C0689q.m2757a(stream).length()), responseString);
        return C0713l.m2886a(C0689q.m2757a(stream), connection, requests);
    }

    /* renamed from: a */
    static List<C0713l> m2886a(String responseString, HttpURLConnection connection, C0712k requests) throws C0699e, JSONException, IOException {
        C0670l.m2671a(C0747o.REQUESTS, "Response", "Response\n  Id: %s\n  Size: %d\n  Responses:\n%s\n", requests.m2875b(), Integer.valueOf(responseString.length()), C0713l.m2888a(connection, (List) requests, new JSONTokener(responseString).nextValue()));
        return C0713l.m2888a(connection, (List) requests, new JSONTokener(responseString).nextValue());
    }

    /* renamed from: a */
    private static List<C0713l> m2888a(HttpURLConnection connection, List<GraphRequest> requests, Object object) throws C0699e, JSONException {
        GraphRequest request;
        int numRequests = requests.size();
        List<C0713l> responses = new ArrayList(numRequests);
        Object originalResult = object;
        if (numRequests == 1) {
            request = (GraphRequest) requests.get(0);
            try {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("body", object);
                jsonObject.put("code", connection != null ? connection.getResponseCode() : 200);
                JSONArray jsonArray = new JSONArray();
                jsonArray.put(jsonObject);
                object = jsonArray;
            } catch (Exception e) {
                responses.add(new C0713l(request, connection, new FacebookRequestError(connection, e)));
            } catch (Exception e2) {
                responses.add(new C0713l(request, connection, new FacebookRequestError(connection, e2)));
            }
        }
        if ((object instanceof JSONArray) && ((JSONArray) object).length() == numRequests) {
            jsonArray = (JSONArray) object;
            for (int i = 0; i < jsonArray.length(); i++) {
                request = (GraphRequest) requests.get(i);
                try {
                    responses.add(C0713l.m2884a(request, connection, jsonArray.get(i), originalResult));
                } catch (Exception e22) {
                    responses.add(new C0713l(request, connection, new FacebookRequestError(connection, e22)));
                } catch (Exception e222) {
                    responses.add(new C0713l(request, connection, new FacebookRequestError(connection, e222)));
                }
            }
            return responses;
        }
        throw new C0699e("Unexpected number of results");
    }

    /* renamed from: a */
    private static C0713l m2884a(GraphRequest request, HttpURLConnection connection, Object object, Object originalResult) throws JSONException {
        if (object instanceof JSONObject) {
            JSONObject jsonObject = (JSONObject) object;
            FacebookRequestError error = FacebookRequestError.m2401a(jsonObject, originalResult, connection);
            if (error != null) {
                if (error.m2404b() == 190 && C0689q.m2780a(request.m2483f())) {
                    AccessToken.m2382a(null);
                }
                return new C0713l(request, connection, error);
            }
            Object body = C0689q.m2754a(jsonObject, "body", "FACEBOOK_NON_JSON_RESULT");
            if (body instanceof JSONObject) {
                return new C0713l(request, connection, body.toString(), (JSONObject) body);
            }
            if (body instanceof JSONArray) {
                return new C0713l(request, connection, body.toString(), (JSONArray) body);
            }
            object = JSONObject.NULL;
        }
        if (object == JSONObject.NULL) {
            return new C0713l(request, connection, object.toString(), (JSONObject) null);
        }
        throw new C0699e("Got unexpected object type in response, class: " + object.getClass().getSimpleName());
    }

    /* renamed from: a */
    static List<C0713l> m2889a(List<GraphRequest> requests, HttpURLConnection connection, C0699e error) {
        int count = requests.size();
        List<C0713l> responses = new ArrayList(count);
        for (int i = 0; i < count; i++) {
            responses.add(new C0713l((GraphRequest) requests.get(i), connection, new FacebookRequestError(connection, (Exception) error)));
        }
        return responses;
    }
}

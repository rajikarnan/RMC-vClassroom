package com.facebook;

/* compiled from: FacebookException */
/* renamed from: com.facebook.e */
public class C0699e extends RuntimeException {
    public C0699e(String message) {
        super(message);
    }

    public C0699e(String message, Throwable throwable) {
        super(message, throwable);
    }

    public C0699e(Throwable throwable) {
        super(throwable);
    }

    public String toString() {
        return getMessage();
    }
}

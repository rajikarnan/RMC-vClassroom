package com.facebook;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import com.facebook.p014b.C0689q;
import com.facebook.p014b.C0690r;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class AccessToken implements Parcelable {
    public static final Creator<AccessToken> CREATOR = new C05711();
    /* renamed from: a */
    private static final Date f928a = new Date(Long.MAX_VALUE);
    /* renamed from: b */
    private static final Date f929b = f928a;
    /* renamed from: c */
    private static final Date f930c = new Date();
    /* renamed from: d */
    private static final C0698c f931d = C0698c.FACEBOOK_APPLICATION_WEB;
    /* renamed from: e */
    private final Date f932e;
    /* renamed from: f */
    private final Set<String> f933f;
    /* renamed from: g */
    private final Set<String> f934g;
    /* renamed from: h */
    private final String f935h;
    /* renamed from: i */
    private final C0698c f936i;
    /* renamed from: j */
    private final Date f937j;
    /* renamed from: k */
    private final String f938k;
    /* renamed from: l */
    private final String f939l;

    /* renamed from: com.facebook.AccessToken$1 */
    static class C05711 implements Creator {
        C05711() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m2374a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m2375a(i);
        }

        /* renamed from: a */
        public AccessToken m2374a(Parcel source) {
            return new AccessToken(source);
        }

        /* renamed from: a */
        public AccessToken[] m2375a(int size) {
            return new AccessToken[size];
        }
    }

    /* renamed from: com.facebook.AccessToken$a */
    public interface C0572a {
        /* renamed from: a */
        void m2376a(AccessToken accessToken);

        /* renamed from: a */
        void m2377a(C0699e c0699e);
    }

    public AccessToken(String accessToken, String applicationId, String userId, Collection<String> permissions, Collection<String> declinedPermissions, C0698c accessTokenSource, Date expirationTime, Date lastRefreshTime) {
        C0690r.m2806a(accessToken, "accessToken");
        C0690r.m2806a(applicationId, "applicationId");
        C0690r.m2806a(userId, "userId");
        if (expirationTime == null) {
            expirationTime = f929b;
        }
        this.f932e = expirationTime;
        this.f933f = Collections.unmodifiableSet(permissions != null ? new HashSet(permissions) : new HashSet());
        this.f934g = Collections.unmodifiableSet(declinedPermissions != null ? new HashSet(declinedPermissions) : new HashSet());
        this.f935h = accessToken;
        if (accessTokenSource == null) {
            accessTokenSource = f931d;
        }
        this.f936i = accessTokenSource;
        if (lastRefreshTime == null) {
            lastRefreshTime = f930c;
        }
        this.f937j = lastRefreshTime;
        this.f938k = applicationId;
        this.f939l = userId;
    }

    /* renamed from: a */
    public static AccessToken m2378a() {
        return C0697b.m2823a().m2833b();
    }

    /* renamed from: a */
    public static void m2382a(AccessToken accessToken) {
        C0697b.m2823a().m2832a(accessToken);
    }

    /* renamed from: b */
    public String m2385b() {
        return this.f935h;
    }

    /* renamed from: c */
    public Date m2386c() {
        return this.f932e;
    }

    /* renamed from: d */
    public Set<String> m2387d() {
        return this.f933f;
    }

    /* renamed from: e */
    public Set<String> m2388e() {
        return this.f934g;
    }

    /* renamed from: f */
    public C0698c m2389f() {
        return this.f936i;
    }

    /* renamed from: g */
    public Date m2390g() {
        return this.f937j;
    }

    /* renamed from: h */
    public String m2391h() {
        return this.f938k;
    }

    /* renamed from: i */
    public String m2392i() {
        return this.f939l;
    }

    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("{AccessToken");
        builder.append(" token:").append(m2384k());
        m2383a(builder);
        builder.append("}");
        return builder.toString();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean equals(java.lang.Object r6) {
        /*
        r5 = this;
        r1 = 1;
        r2 = 0;
        if (r5 != r6) goto L_0x0005;
    L_0x0004:
        return r1;
    L_0x0005:
        r3 = r6 instanceof com.facebook.AccessToken;
        if (r3 != 0) goto L_0x000b;
    L_0x0009:
        r1 = r2;
        goto L_0x0004;
    L_0x000b:
        r0 = r6;
        r0 = (com.facebook.AccessToken) r0;
        r3 = r5.f932e;
        r4 = r0.f932e;
        r3 = r3.equals(r4);
        if (r3 == 0) goto L_0x0058;
    L_0x0018:
        r3 = r5.f933f;
        r4 = r0.f933f;
        r3 = r3.equals(r4);
        if (r3 == 0) goto L_0x0058;
    L_0x0022:
        r3 = r5.f934g;
        r4 = r0.f934g;
        r3 = r3.equals(r4);
        if (r3 == 0) goto L_0x0058;
    L_0x002c:
        r3 = r5.f935h;
        r4 = r0.f935h;
        r3 = r3.equals(r4);
        if (r3 == 0) goto L_0x0058;
    L_0x0036:
        r3 = r5.f936i;
        r4 = r0.f936i;
        if (r3 != r4) goto L_0x0058;
    L_0x003c:
        r3 = r5.f937j;
        r4 = r0.f937j;
        r3 = r3.equals(r4);
        if (r3 == 0) goto L_0x0058;
    L_0x0046:
        r3 = r5.f938k;
        if (r3 != 0) goto L_0x005a;
    L_0x004a:
        r3 = r0.f938k;
        if (r3 != 0) goto L_0x0058;
    L_0x004e:
        r3 = r5.f939l;
        r4 = r0.f939l;
        r3 = r3.equals(r4);
        if (r3 != 0) goto L_0x0004;
    L_0x0058:
        r1 = r2;
        goto L_0x0004;
    L_0x005a:
        r3 = r5.f938k;
        r4 = r0.f938k;
        r3 = r3.equals(r4);
        if (r3 == 0) goto L_0x0058;
    L_0x0064:
        goto L_0x004e;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.AccessToken.equals(java.lang.Object):boolean");
    }

    public int hashCode() {
        return ((((((((((((((this.f932e.hashCode() + 527) * 31) + this.f933f.hashCode()) * 31) + this.f934g.hashCode()) * 31) + this.f935h.hashCode()) * 31) + this.f936i.hashCode()) * 31) + this.f937j.hashCode()) * 31) + (this.f938k == null ? 0 : this.f938k.hashCode())) * 31) + this.f939l.hashCode();
    }

    /* renamed from: a */
    static AccessToken m2379a(Bundle bundle) {
        List<String> permissions = m2381a(bundle, "com.facebook.TokenCachingStrategy.Permissions");
        List<String> declinedPermissions = m2381a(bundle, "com.facebook.TokenCachingStrategy.DeclinedPermissions");
        String applicationId = C0746n.m3080d(bundle);
        if (C0689q.m2782a(applicationId)) {
            applicationId = C0707g.m2858i();
        }
        String tokenString = C0746n.m3078b(bundle);
        try {
            return new AccessToken(tokenString, applicationId, C0689q.m2794d(tokenString).getString("id"), permissions, declinedPermissions, C0746n.m3079c(bundle), C0746n.m3075a(bundle, "com.facebook.TokenCachingStrategy.ExpirationDate"), C0746n.m3075a(bundle, "com.facebook.TokenCachingStrategy.LastRefreshDate"));
        } catch (JSONException e) {
            return null;
        }
    }

    /* renamed from: a */
    static List<String> m2381a(Bundle bundle, String key) {
        List<String> originalPermissions = bundle.getStringArrayList(key);
        if (originalPermissions == null) {
            return Collections.emptyList();
        }
        return Collections.unmodifiableList(new ArrayList(originalPermissions));
    }

    /* renamed from: j */
    JSONObject m2393j() throws JSONException {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("version", 1);
        jsonObject.put("token", this.f935h);
        jsonObject.put("expires_at", this.f932e.getTime());
        jsonObject.put("permissions", new JSONArray(this.f933f));
        jsonObject.put("declined_permissions", new JSONArray(this.f934g));
        jsonObject.put("last_refresh", this.f937j.getTime());
        jsonObject.put("source", this.f936i.name());
        jsonObject.put("application_id", this.f938k);
        jsonObject.put("user_id", this.f939l);
        return jsonObject;
    }

    /* renamed from: a */
    static AccessToken m2380a(JSONObject jsonObject) throws JSONException {
        if (jsonObject.getInt("version") > 1) {
            throw new C0699e("Unknown AccessToken serialization format.");
        }
        String token = jsonObject.getString("token");
        Date expiresAt = new Date(jsonObject.getLong("expires_at"));
        JSONArray permissionsArray = jsonObject.getJSONArray("permissions");
        JSONArray declinedPermissionsArray = jsonObject.getJSONArray("declined_permissions");
        Date lastRefresh = new Date(jsonObject.getLong("last_refresh"));
        return new AccessToken(token, jsonObject.getString("application_id"), jsonObject.getString("user_id"), C0689q.m2765a(permissionsArray), C0689q.m2765a(declinedPermissionsArray), C0698c.valueOf(jsonObject.getString("source")), expiresAt, lastRefresh);
    }

    /* renamed from: k */
    private String m2384k() {
        if (this.f935h == null) {
            return "null";
        }
        if (C0707g.m2847a(C0747o.INCLUDE_ACCESS_TOKENS)) {
            return this.f935h;
        }
        return "ACCESS_TOKEN_REMOVED";
    }

    /* renamed from: a */
    private void m2383a(StringBuilder builder) {
        builder.append(" permissions:");
        if (this.f933f == null) {
            builder.append("null");
            return;
        }
        builder.append("[");
        builder.append(TextUtils.join(", ", this.f933f));
        builder.append("]");
    }

    AccessToken(Parcel parcel) {
        this.f932e = new Date(parcel.readLong());
        ArrayList<String> permissionsList = new ArrayList();
        parcel.readStringList(permissionsList);
        this.f933f = Collections.unmodifiableSet(new HashSet(permissionsList));
        permissionsList.clear();
        parcel.readStringList(permissionsList);
        this.f934g = Collections.unmodifiableSet(new HashSet(permissionsList));
        this.f935h = parcel.readString();
        this.f936i = C0698c.valueOf(parcel.readString());
        this.f937j = new Date(parcel.readLong());
        this.f938k = parcel.readString();
        this.f939l = parcel.readString();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(this.f932e.getTime());
        dest.writeStringList(new ArrayList(this.f933f));
        dest.writeStringList(new ArrayList(this.f934g));
        dest.writeString(this.f935h);
        dest.writeString(this.f936i.name());
        dest.writeLong(this.f937j.getTime());
        dest.writeString(this.f938k);
        dest.writeString(this.f939l);
    }
}

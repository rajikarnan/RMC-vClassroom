package com.facebook;

/* compiled from: HttpMethod */
/* renamed from: com.facebook.m */
public enum C0745m {
    GET,
    POST,
    DELETE
}

package com.facebook;

import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.ParcelFileDescriptor.AutoCloseInputStream;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import android.util.Log;
import android.util.Pair;
import com.facebook.C0712k.C0633a;
import com.facebook.C0712k.C0711b;
import com.facebook.p014b.C0667j;
import com.facebook.p014b.C0670l;
import com.facebook.p014b.C0682p;
import com.facebook.p014b.C0689q;
import com.facebook.p014b.C0690r;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPOutputStream;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GraphRequest {
    /* renamed from: a */
    public static final String f991a = GraphRequest.class.getSimpleName();
    /* renamed from: b */
    private static String f992b;
    /* renamed from: c */
    private static Pattern f993c = Pattern.compile("^/?v\\d+\\.\\d+/(.*)");
    /* renamed from: q */
    private static volatile String f994q;
    /* renamed from: d */
    private AccessToken f995d;
    /* renamed from: e */
    private C0745m f996e;
    /* renamed from: f */
    private String f997f;
    /* renamed from: g */
    private JSONObject f998g;
    /* renamed from: h */
    private String f999h;
    /* renamed from: i */
    private String f1000i;
    /* renamed from: j */
    private boolean f1001j;
    /* renamed from: k */
    private Bundle f1002k;
    /* renamed from: l */
    private C0578b f1003l;
    /* renamed from: m */
    private String f1004m;
    /* renamed from: n */
    private Object f1005n;
    /* renamed from: o */
    private String f1006o;
    /* renamed from: p */
    private boolean f1007p;

    /* renamed from: com.facebook.GraphRequest$b */
    public interface C0578b {
        /* renamed from: a */
        void mo848a(C0713l c0713l);
    }

    /* renamed from: com.facebook.GraphRequest$1 */
    static class C05791 implements C0578b {
        /* renamed from: a */
        final /* synthetic */ C0586c f976a;

        /* renamed from: a */
        public void mo848a(C0713l response) {
            if (this.f976a != null) {
                this.f976a.m2420a(response.m2891b(), response);
            }
        }
    }

    /* renamed from: com.facebook.GraphRequest$d */
    private interface C0582d {
        /* renamed from: a */
        void mo849a(String str, String str2) throws IOException;
    }

    public static class ParcelableResourceWithMimeType<RESOURCE extends Parcelable> implements Parcelable {
        public static final Creator<ParcelableResourceWithMimeType> CREATOR = new C05841();
        /* renamed from: a */
        private final String f983a;
        /* renamed from: b */
        private final RESOURCE f984b;

        /* renamed from: com.facebook.GraphRequest$ParcelableResourceWithMimeType$1 */
        static class C05841 implements Creator<ParcelableResourceWithMimeType> {
            C05841() {
            }

            public /* synthetic */ Object createFromParcel(Parcel parcel) {
                return m2414a(parcel);
            }

            public /* synthetic */ Object[] newArray(int i) {
                return m2415a(i);
            }

            /* renamed from: a */
            public ParcelableResourceWithMimeType m2414a(Parcel in) {
                return new ParcelableResourceWithMimeType(in);
            }

            /* renamed from: a */
            public ParcelableResourceWithMimeType[] m2415a(int size) {
                return new ParcelableResourceWithMimeType[size];
            }
        }

        /* renamed from: a */
        public String m2416a() {
            return this.f983a;
        }

        /* renamed from: b */
        public RESOURCE m2417b() {
            return this.f984b;
        }

        public int describeContents() {
            return 1;
        }

        public void writeToParcel(Parcel out, int flags) {
            out.writeString(this.f983a);
            out.writeParcelable(this.f984b, flags);
        }

        private ParcelableResourceWithMimeType(Parcel in) {
            this.f983a = in.readString();
            this.f984b = in.readParcelable(C0707g.m2855f().getClassLoader());
        }
    }

    /* renamed from: com.facebook.GraphRequest$a */
    private static class C0585a {
        /* renamed from: a */
        private final GraphRequest f985a;
        /* renamed from: b */
        private final Object f986b;

        public C0585a(GraphRequest request, Object value) {
            this.f985a = request;
            this.f986b = value;
        }

        /* renamed from: a */
        public GraphRequest m2418a() {
            return this.f985a;
        }

        /* renamed from: b */
        public Object m2419b() {
            return this.f986b;
        }
    }

    /* renamed from: com.facebook.GraphRequest$c */
    public interface C0586c {
        /* renamed from: a */
        void m2420a(JSONObject jSONObject, C0713l c0713l);
    }

    /* renamed from: com.facebook.GraphRequest$e */
    public interface C0587e extends C0578b {
        /* renamed from: a */
        void m2421a(long j, long j2);
    }

    /* renamed from: com.facebook.GraphRequest$f */
    private static class C0588f implements C0582d {
        /* renamed from: a */
        private final OutputStream f987a;
        /* renamed from: b */
        private final C0670l f988b;
        /* renamed from: c */
        private boolean f989c = true;
        /* renamed from: d */
        private boolean f990d = false;

        public C0588f(OutputStream outputStream, C0670l logger, boolean useUrlEncode) {
            this.f987a = outputStream;
            this.f988b = logger;
            this.f990d = useUrlEncode;
        }

        /* renamed from: a */
        public void m2427a(String key, Object value, GraphRequest request) throws IOException {
            if (this.f987a instanceof C0750u) {
                ((C0750u) this.f987a).mo882a(request);
            }
            if (GraphRequest.m2464e(value)) {
                mo849a(key, GraphRequest.m2465f(value));
            } else if (value instanceof Bitmap) {
                m2424a(key, (Bitmap) value);
            } else if (value instanceof byte[]) {
                m2431a(key, (byte[]) value);
            } else if (value instanceof Uri) {
                m2425a(key, (Uri) value, null);
            } else if (value instanceof ParcelFileDescriptor) {
                m2426a(key, (ParcelFileDescriptor) value, null);
            } else if (value instanceof ParcelableResourceWithMimeType) {
                ParcelableResourceWithMimeType resourceWithMimeType = (ParcelableResourceWithMimeType) value;
                Parcelable resource = resourceWithMimeType.m2417b();
                String mimeType = resourceWithMimeType.m2416a();
                if (resource instanceof ParcelFileDescriptor) {
                    m2426a(key, (ParcelFileDescriptor) resource, mimeType);
                } else if (resource instanceof Uri) {
                    m2425a(key, (Uri) resource, mimeType);
                } else {
                    throw m2422b();
                }
            } else {
                throw m2422b();
            }
        }

        /* renamed from: b */
        private RuntimeException m2422b() {
            return new IllegalArgumentException("value is not a supported type.");
        }

        /* renamed from: a */
        public void m2430a(String key, JSONArray requestJsonArray, Collection<GraphRequest> requests) throws IOException, JSONException {
            if (this.f987a instanceof C0750u) {
                C0750u requestOutputStream = this.f987a;
                m2429a(key, null, null);
                m2432a("[", new Object[0]);
                int i = 0;
                for (GraphRequest request : requests) {
                    JSONObject requestJson = requestJsonArray.getJSONObject(i);
                    requestOutputStream.mo882a(request);
                    if (i > 0) {
                        m2432a(",%s", requestJson.toString());
                    } else {
                        m2432a("%s", requestJson.toString());
                    }
                    i++;
                }
                m2432a("]", new Object[0]);
                if (this.f988b != null) {
                    this.f988b.m2677a("    " + key, requestJsonArray.toString());
                    return;
                }
                return;
            }
            mo849a(key, requestJsonArray.toString());
        }

        /* renamed from: a */
        public void mo849a(String key, String value) throws IOException {
            m2429a(key, null, null);
            m2433b("%s", value);
            m2423a();
            if (this.f988b != null) {
                this.f988b.m2677a("    " + key, (Object) value);
            }
        }

        /* renamed from: a */
        public void m2424a(String key, Bitmap bitmap) throws IOException {
            m2429a(key, key, "image/png");
            bitmap.compress(CompressFormat.PNG, 100, this.f987a);
            m2433b("", new Object[0]);
            m2423a();
            if (this.f988b != null) {
                this.f988b.m2677a("    " + key, (Object) "<Image>");
            }
        }

        /* renamed from: a */
        public void m2431a(String key, byte[] bytes) throws IOException {
            m2429a(key, key, "content/unknown");
            this.f987a.write(bytes);
            m2433b("", new Object[0]);
            m2423a();
            if (this.f988b != null) {
                this.f988b.m2677a("    " + key, String.format(Locale.ROOT, "<Data: %d>", new Object[]{Integer.valueOf(bytes.length)}));
            }
        }

        /* renamed from: a */
        public void m2425a(String key, Uri contentUri, String mimeType) throws IOException {
            if (mimeType == null) {
                mimeType = "content/unknown";
            }
            m2429a(key, key, mimeType);
            int totalBytes = 0;
            if (this.f987a instanceof C0751r) {
                ((C0751r) this.f987a).m3094a(C0689q.m2748a(contentUri));
            } else {
                totalBytes = 0 + C0689q.m2746a(C0707g.m2855f().getContentResolver().openInputStream(contentUri), this.f987a);
            }
            m2433b("", new Object[0]);
            m2423a();
            if (this.f988b != null) {
                this.f988b.m2677a("    " + key, String.format(Locale.ROOT, "<Data: %d>", new Object[]{Integer.valueOf(totalBytes)}));
            }
        }

        /* renamed from: a */
        public void m2426a(String key, ParcelFileDescriptor descriptor, String mimeType) throws IOException {
            if (mimeType == null) {
                mimeType = "content/unknown";
            }
            m2429a(key, key, mimeType);
            int totalBytes = 0;
            if (this.f987a instanceof C0751r) {
                ((C0751r) this.f987a).m3094a(descriptor.getStatSize());
            } else {
                totalBytes = 0 + C0689q.m2746a(new AutoCloseInputStream(descriptor), this.f987a);
            }
            m2433b("", new Object[0]);
            m2423a();
            if (this.f988b != null) {
                this.f988b.m2677a("    " + key, String.format(Locale.ROOT, "<Data: %d>", new Object[]{Integer.valueOf(totalBytes)}));
            }
        }

        /* renamed from: a */
        public void m2423a() throws IOException {
            if (this.f990d) {
                this.f987a.write("&".getBytes());
                return;
            }
            m2433b("--%s", "3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f");
        }

        /* renamed from: a */
        public void m2429a(String name, String filename, String contentType) throws IOException {
            if (this.f990d) {
                this.f987a.write(String.format("%s=", new Object[]{name}).getBytes());
                return;
            }
            m2432a("Content-Disposition: form-data; name=\"%s\"", name);
            if (filename != null) {
                m2432a("; filename=\"%s\"", filename);
            }
            m2433b("", new Object[0]);
            if (contentType != null) {
                m2433b("%s: %s", "Content-Type", contentType);
            }
            m2433b("", new Object[0]);
        }

        /* renamed from: a */
        public void m2432a(String format, Object... args) throws IOException {
            if (this.f990d) {
                this.f987a.write(URLEncoder.encode(String.format(Locale.US, format, args), "UTF-8").getBytes());
                return;
            }
            if (this.f989c) {
                this.f987a.write("--".getBytes());
                this.f987a.write("3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f".getBytes());
                this.f987a.write("\r\n".getBytes());
                this.f989c = false;
            }
            this.f987a.write(String.format(format, args).getBytes());
        }

        /* renamed from: b */
        public void m2433b(String format, Object... args) throws IOException {
            m2432a(format, args);
            if (!this.f990d) {
                m2432a("\r\n", new Object[0]);
            }
        }
    }

    public GraphRequest() {
        this(null, null, null, null, null);
    }

    public GraphRequest(AccessToken accessToken, String graphPath, Bundle parameters, C0745m httpMethod, C0578b callback) {
        this(accessToken, graphPath, parameters, httpMethod, callback, null);
    }

    public GraphRequest(AccessToken accessToken, String graphPath, Bundle parameters, C0745m httpMethod, C0578b callback, String version) {
        this.f1001j = true;
        this.f1007p = false;
        this.f995d = accessToken;
        this.f997f = graphPath;
        this.f1006o = version;
        m2474a(callback);
        m2475a(httpMethod);
        if (parameters != null) {
            this.f1002k = new Bundle(parameters);
        } else {
            this.f1002k = new Bundle();
        }
        if (this.f1006o == null) {
            this.f1006o = C0682p.m2734d();
        }
    }

    /* renamed from: a */
    public static GraphRequest m2435a(AccessToken accessToken, String graphPath, JSONObject graphObject, C0578b callback) {
        GraphRequest request = new GraphRequest(accessToken, graphPath, null, C0745m.POST, callback);
        request.m2477a(graphObject);
        return request;
    }

    /* renamed from: a */
    public static GraphRequest m2434a(AccessToken accessToken, String graphPath, C0578b callback) {
        return new GraphRequest(accessToken, graphPath, null, null, callback);
    }

    /* renamed from: a */
    public final JSONObject m2472a() {
        return this.f998g;
    }

    /* renamed from: a */
    public final void m2477a(JSONObject graphObject) {
        this.f998g = graphObject;
    }

    /* renamed from: b */
    public final String m2479b() {
        return this.f997f;
    }

    /* renamed from: c */
    public final C0745m m2480c() {
        return this.f996e;
    }

    /* renamed from: a */
    public final void m2475a(C0745m httpMethod) {
        if (this.f1004m == null || httpMethod == C0745m.GET) {
            if (httpMethod == null) {
                httpMethod = C0745m.GET;
            }
            this.f996e = httpMethod;
            return;
        }
        throw new C0699e("Can't change HTTP method on request with overridden URL.");
    }

    /* renamed from: d */
    public final String m2481d() {
        return this.f1006o;
    }

    /* renamed from: a */
    public final void m2478a(boolean skipClientToken) {
        this.f1007p = skipClientToken;
    }

    /* renamed from: e */
    public final Bundle m2482e() {
        return this.f1002k;
    }

    /* renamed from: a */
    public final void m2473a(Bundle parameters) {
        this.f1002k = parameters;
    }

    /* renamed from: f */
    public final AccessToken m2483f() {
        return this.f995d;
    }

    /* renamed from: g */
    public final C0578b m2484g() {
        return this.f1003l;
    }

    /* renamed from: a */
    public final void m2474a(final C0578b callback) {
        if (C0707g.m2847a(C0747o.GRAPH_API_DEBUG_INFO) || C0707g.m2847a(C0747o.GRAPH_API_DEBUG_WARNING)) {
            this.f1003l = new C0578b(this) {
                /* renamed from: b */
                final /* synthetic */ GraphRequest f978b;

                /* renamed from: a */
                public void mo848a(C0713l response) {
                    JSONObject debug;
                    JSONArray debugMessages;
                    JSONObject responseObject = response.m2891b();
                    if (responseObject != null) {
                        debug = responseObject.optJSONObject("__debug__");
                    } else {
                        debug = null;
                    }
                    if (debug != null) {
                        debugMessages = debug.optJSONArray("messages");
                    } else {
                        debugMessages = null;
                    }
                    if (debugMessages != null) {
                        for (int i = 0; i < debugMessages.length(); i++) {
                            String debugMessage;
                            String debugMessageType;
                            String debugMessageLink;
                            JSONObject debugMessageObject = debugMessages.optJSONObject(i);
                            if (debugMessageObject != null) {
                                debugMessage = debugMessageObject.optString("message");
                            } else {
                                debugMessage = null;
                            }
                            if (debugMessageObject != null) {
                                debugMessageType = debugMessageObject.optString("type");
                            } else {
                                debugMessageType = null;
                            }
                            if (debugMessageObject != null) {
                                debugMessageLink = debugMessageObject.optString("link");
                            } else {
                                debugMessageLink = null;
                            }
                            if (!(debugMessage == null || debugMessageType == null)) {
                                C0747o behavior = C0747o.GRAPH_API_DEBUG_INFO;
                                if (debugMessageType.equals("warning")) {
                                    behavior = C0747o.GRAPH_API_DEBUG_WARNING;
                                }
                                if (!C0689q.m2782a(debugMessageLink)) {
                                    debugMessage = debugMessage + " Link: " + debugMessageLink;
                                }
                                C0670l.m2670a(behavior, GraphRequest.f991a, debugMessage);
                            }
                        }
                    }
                    if (callback != null) {
                        callback.mo848a(response);
                    }
                }
            };
        } else {
            this.f1003l = callback;
        }
    }

    /* renamed from: a */
    public final void m2476a(Object tag) {
        this.f1005n = tag;
    }

    /* renamed from: h */
    public final Object m2485h() {
        return this.f1005n;
    }

    /* renamed from: i */
    public final C0713l m2486i() {
        return m2436a(this);
    }

    /* renamed from: j */
    public final C0710j m2487j() {
        return m2454b(this);
    }

    /* renamed from: a */
    public static HttpURLConnection m2438a(C0712k requests) {
        Exception e;
        m2461d(requests);
        try {
            URL url;
            if (requests.size() == 1) {
                url = new URL(requests.m2868a(0).m2489l());
            } else {
                url = new URL(C0682p.m2732b());
            }
            URLConnection uRLConnection = null;
            try {
                uRLConnection = m2439a(url);
                m2446a(requests, (HttpURLConnection) uRLConnection);
                return uRLConnection;
            } catch (IOException e2) {
                e = e2;
                C0689q.m2777a(uRLConnection);
                throw new C0699e("could not construct request body", e);
            } catch (JSONException e3) {
                e = e3;
                C0689q.m2777a(uRLConnection);
                throw new C0699e("could not construct request body", e);
            }
        } catch (MalformedURLException e4) {
            throw new C0699e("could not construct URL for request", e4);
        }
    }

    /* renamed from: a */
    public static C0713l m2436a(GraphRequest request) {
        List<C0713l> responses = m2442a(request);
        if (responses != null && responses.size() == 1) {
            return (C0713l) responses.get(0);
        }
        throw new C0699e("invalid state: expected a single response");
    }

    /* renamed from: a */
    public static List<C0713l> m2442a(GraphRequest... requests) {
        C0690r.m2805a((Object) requests, "requests");
        return m2441a(Arrays.asList(requests));
    }

    /* renamed from: a */
    public static List<C0713l> m2441a(Collection<GraphRequest> requests) {
        return m2455b(new C0712k((Collection) requests));
    }

    /* renamed from: b */
    public static List<C0713l> m2455b(C0712k requests) {
        List<C0713l> responses;
        C0690r.m2813c(requests, "requests");
        URLConnection connection = null;
        try {
            connection = m2438a(requests);
            responses = m2440a((HttpURLConnection) connection, requests);
        } catch (Throwable ex) {
            responses = C0713l.m2889a(requests.m2877d(), null, new C0699e(ex));
            m2447a(requests, (List) responses);
        } finally {
            C0689q.m2777a(connection);
        }
        return responses;
    }

    /* renamed from: b */
    public static C0710j m2454b(GraphRequest... requests) {
        C0690r.m2805a((Object) requests, "requests");
        return m2453b(Arrays.asList(requests));
    }

    /* renamed from: b */
    public static C0710j m2453b(Collection<GraphRequest> requests) {
        return m2459c(new C0712k((Collection) requests));
    }

    /* renamed from: c */
    public static C0710j m2459c(C0712k requests) {
        C0690r.m2813c(requests, "requests");
        C0710j asyncTask = new C0710j(requests);
        asyncTask.executeOnExecutor(C0707g.m2853d(), new Void[0]);
        return asyncTask;
    }

    /* renamed from: a */
    public static List<C0713l> m2440a(HttpURLConnection connection, C0712k requests) {
        List responses = C0713l.m2887a(connection, requests);
        C0689q.m2777a((URLConnection) connection);
        if (requests.size() != responses.size()) {
            throw new C0699e(String.format(Locale.US, "Received %d responses while expecting %d", new Object[]{Integer.valueOf(responses.size()), Integer.valueOf(requests.size())}));
        }
        m2447a(requests, responses);
        C0697b.m2823a().m2835d();
        return responses;
    }

    public String toString() {
        return "{Request: " + " accessToken: " + (this.f995d == null ? "null" : this.f995d) + ", graphPath: " + this.f997f + ", graphObject: " + this.f998g + ", httpMethod: " + this.f996e + ", parameters: " + this.f1002k + "}";
    }

    /* renamed from: a */
    static void m2447a(final C0712k requests, List<C0713l> responses) {
        int numRequests = requests.size();
        final ArrayList<Pair<C0578b, C0713l>> callbacks = new ArrayList();
        for (int i = 0; i < numRequests; i++) {
            GraphRequest request = requests.m2868a(i);
            if (request.f1003l != null) {
                callbacks.add(new Pair(request.f1003l, responses.get(i)));
            }
        }
        if (callbacks.size() > 0) {
            Runnable runnable = new Runnable() {
                public void run() {
                    Iterator it = callbacks.iterator();
                    while (it.hasNext()) {
                        Pair<C0578b, C0713l> pair = (Pair) it.next();
                        ((C0578b) pair.first).mo848a((C0713l) pair.second);
                    }
                    for (C0633a batchCallback : requests.m2878e()) {
                        batchCallback.mo852a(requests);
                    }
                }
            };
            Handler callbackHandler = requests.m2876c();
            if (callbackHandler == null) {
                runnable.run();
            } else {
                callbackHandler.post(runnable);
            }
        }
    }

    /* renamed from: a */
    private static HttpURLConnection m2439a(URL url) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestProperty("User-Agent", m2471p());
        connection.setRequestProperty("Accept-Language", Locale.getDefault().toString());
        connection.setChunkedStreamingMode(0);
        return connection;
    }

    /* renamed from: m */
    private void m2468m() {
        if (this.f995d != null) {
            if (!this.f1002k.containsKey("access_token")) {
                String token = this.f995d.m2385b();
                C0670l.m2672a(token);
                this.f1002k.putString("access_token", token);
            }
        } else if (!(this.f1007p || this.f1002k.containsKey("access_token"))) {
            String appID = C0707g.m2858i();
            String clientToken = C0707g.m2859j();
            if (C0689q.m2782a(appID) || C0689q.m2782a(clientToken)) {
                Log.d(f991a, "Warning: Request without access token missing application ID or client token.");
            } else {
                this.f1002k.putString("access_token", appID + "|" + clientToken);
            }
        }
        this.f1002k.putString("sdk", "android");
        this.f1002k.putString("format", "json");
        if (C0707g.m2847a(C0747o.GRAPH_API_DEBUG_INFO)) {
            this.f1002k.putString("debug", "info");
        } else if (C0707g.m2847a(C0747o.GRAPH_API_DEBUG_WARNING)) {
            this.f1002k.putString("debug", "warning");
        }
    }

    /* renamed from: a */
    private String m2437a(String baseUrl) {
        Builder uriBuilder = Uri.parse(baseUrl).buildUpon();
        for (String key : this.f1002k.keySet()) {
            Object value = this.f1002k.get(key);
            if (value == null) {
                value = "";
            }
            if (m2464e(value)) {
                uriBuilder.appendQueryParameter(key, m2465f(value).toString());
            } else if (this.f996e == C0745m.GET) {
                throw new IllegalArgumentException(String.format(Locale.US, "Unsupported parameter type for GET request: %s", new Object[]{value.getClass().getSimpleName()}));
            }
        }
        return uriBuilder.toString();
    }

    /* renamed from: k */
    final String m2488k() {
        if (this.f1004m != null) {
            throw new C0699e("Can't override URL for a batch request");
        }
        String baseUrl = String.format("%s/%s", new Object[]{C0682p.m2732b(), m2469n()});
        m2468m();
        Uri uri = Uri.parse(m2437a(baseUrl));
        return String.format("%s?%s", new Object[]{uri.getPath(), uri.getQuery()});
    }

    /* renamed from: l */
    final String m2489l() {
        if (this.f1004m != null) {
            return this.f1004m.toString();
        }
        String graphBaseUrlBase;
        if (m2480c() == C0745m.POST && this.f997f != null && this.f997f.endsWith("/videos")) {
            graphBaseUrlBase = C0682p.m2733c();
        } else {
            graphBaseUrlBase = C0682p.m2732b();
        }
        String baseUrl = String.format("%s/%s", new Object[]{graphBaseUrlBase, m2469n()});
        m2468m();
        return m2437a(baseUrl);
    }

    /* renamed from: n */
    private String m2469n() {
        if (f993c.matcher(this.f997f).matches()) {
            return this.f997f;
        }
        return String.format("%s/%s", new Object[]{this.f1006o, this.f997f});
    }

    /* renamed from: a */
    private void m2451a(JSONArray batch, Map<String, C0585a> attachments) throws JSONException, IOException {
        JSONObject batchEntry = new JSONObject();
        if (this.f999h != null) {
            batchEntry.put("name", this.f999h);
            batchEntry.put("omit_response_on_success", this.f1001j);
        }
        if (this.f1000i != null) {
            batchEntry.put("depends_on", this.f1000i);
        }
        String relativeURL = m2488k();
        batchEntry.put("relative_url", relativeURL);
        batchEntry.put("method", this.f996e);
        if (this.f995d != null) {
            C0670l.m2672a(this.f995d.m2385b());
        }
        ArrayList<String> attachmentNames = new ArrayList();
        for (String key : this.f1002k.keySet()) {
            Object value = this.f1002k.get(key);
            if (m2462d(value)) {
                String name = String.format(Locale.ROOT, "%s%d", new Object[]{"file", Integer.valueOf(attachments.size())});
                attachmentNames.add(name);
                attachments.put(name, new C0585a(this, value));
            }
        }
        if (!attachmentNames.isEmpty()) {
            batchEntry.put("attached_files", TextUtils.join(",", attachmentNames));
        }
        if (this.f998g != null) {
            final ArrayList<String> keysAndValues = new ArrayList();
            m2452a(this.f998g, relativeURL, new C0582d(this) {
                /* renamed from: b */
                final /* synthetic */ GraphRequest f982b;

                /* renamed from: a */
                public void mo849a(String key, String value) throws IOException {
                    keysAndValues.add(String.format(Locale.US, "%s=%s", new Object[]{key, URLEncoder.encode(value, "UTF-8")}));
                }
            });
            batchEntry.put("body", TextUtils.join("&", keysAndValues));
        }
        batch.put(batchEntry);
    }

    /* renamed from: e */
    private static boolean m2463e(C0712k requests) {
        for (C0633a callback : requests.m2878e()) {
            if (callback instanceof C0711b) {
                return true;
            }
        }
        Iterator it = requests.iterator();
        while (it.hasNext()) {
            if (((GraphRequest) it.next()).m2484g() instanceof C0587e) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: a */
    private static void m2449a(HttpURLConnection connection, boolean shouldUseGzip) {
        if (shouldUseGzip) {
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            connection.setRequestProperty("Content-Encoding", "gzip");
            return;
        }
        connection.setRequestProperty("Content-Type", m2470o());
    }

    /* renamed from: f */
    private static boolean m2466f(C0712k requests) {
        Iterator it = requests.iterator();
        while (it.hasNext()) {
            GraphRequest request = (GraphRequest) it.next();
            for (String key : request.f1002k.keySet()) {
                if (m2462d(request.f1002k.get(key))) {
                    return false;
                }
            }
        }
        return true;
    }

    /* renamed from: b */
    static final boolean m2456b(GraphRequest request) {
        boolean z = false;
        String version = request.m2481d();
        if (C0689q.m2782a(version)) {
            return true;
        }
        if (version.startsWith("v")) {
            version = version.substring(1);
        }
        String[] versionParts = version.split("\\.");
        if ((versionParts.length >= 2 && Integer.parseInt(versionParts[0]) > 2) || (Integer.parseInt(versionParts[0]) >= 2 && Integer.parseInt(versionParts[1]) >= 4)) {
            z = true;
        }
        return z;
    }

    /* renamed from: d */
    static final void m2461d(C0712k requests) {
        Iterator it = requests.iterator();
        while (it.hasNext()) {
            GraphRequest request = (GraphRequest) it.next();
            if (C0745m.GET.equals(request.m2480c()) && m2456b(request)) {
                Bundle params = request.m2482e();
                if (!params.containsKey("fields") || C0689q.m2782a(params.getString("fields"))) {
                    C0670l.m2669a(C0747o.DEVELOPER_ERRORS, 5, "Request", "starting with Graph API v2.4, GET requests for /%s should contain an explicit \"fields\" parameter.", request.m2479b());
                }
            }
        }
    }

    /* renamed from: a */
    static final void m2446a(C0712k requests, HttpURLConnection connection) throws IOException, JSONException {
        Throwable th;
        C0670l c0670l = new C0670l(C0747o.REQUESTS, "Request");
        int numRequests = requests.size();
        boolean shouldUseGzip = m2466f(requests);
        C0745m connectionHttpMethod = numRequests == 1 ? requests.m2868a(0).f996e : C0745m.POST;
        connection.setRequestMethod(connectionHttpMethod.name());
        m2449a(connection, shouldUseGzip);
        URL url = connection.getURL();
        c0670l.m2680c("Request:\n");
        c0670l.m2677a("Id", requests.m2875b());
        c0670l.m2677a("URL", (Object) url);
        c0670l.m2677a("Method", connection.getRequestMethod());
        c0670l.m2677a("User-Agent", connection.getRequestProperty("User-Agent"));
        c0670l.m2677a("Content-Type", connection.getRequestProperty("Content-Type"));
        connection.setConnectTimeout(requests.m2867a());
        connection.setReadTimeout(requests.m2867a());
        if (connectionHttpMethod == C0745m.POST) {
            connection.setDoOutput(true);
            OutputStream outputStream = null;
            try {
                OutputStream outputStream2 = new BufferedOutputStream(connection.getOutputStream());
                if (shouldUseGzip) {
                    try {
                        outputStream2 = new GZIPOutputStream(outputStream2);
                    } catch (Throwable th2) {
                        th = th2;
                        outputStream = outputStream2;
                        if (outputStream != null) {
                            outputStream.close();
                        }
                        throw th;
                    }
                }
                if (m2463e(requests)) {
                    C0751r countingStream = new C0751r(requests.m2876c());
                    m2445a(requests, null, numRequests, url, countingStream, shouldUseGzip);
                    outputStream = new C0753s(outputStream2, requests, countingStream.m3096b(), (long) countingStream.m3093a());
                } else {
                    outputStream = outputStream2;
                }
                m2445a(requests, c0670l, numRequests, url, outputStream, shouldUseGzip);
                if (outputStream != null) {
                    outputStream.close();
                }
                c0670l.m2676a();
                return;
            } catch (Throwable th3) {
                th = th3;
                if (outputStream != null) {
                    outputStream.close();
                }
                throw th;
            }
        }
        c0670l.m2676a();
    }

    /* renamed from: a */
    private static void m2445a(C0712k requests, C0670l logger, int numRequests, URL url, OutputStream outputStream, boolean shouldUseGzip) throws IOException, JSONException {
        C0588f serializer = new C0588f(outputStream, logger, shouldUseGzip);
        Map attachments;
        if (numRequests == 1) {
            GraphRequest request = requests.m2868a(0);
            attachments = new HashMap();
            for (String key : request.f1002k.keySet()) {
                Object value = request.f1002k.get(key);
                if (m2462d(value)) {
                    attachments.put(key, new C0585a(request, value));
                }
            }
            if (logger != null) {
                logger.m2680c("  Parameters:\n");
            }
            m2443a(request.f1002k, serializer, request);
            if (logger != null) {
                logger.m2680c("  Attachments:\n");
            }
            m2450a(attachments, serializer);
            if (request.f998g != null) {
                m2452a(request.f998g, url.getPath(), (C0582d) serializer);
                return;
            }
            return;
        }
        String batchAppID = m2467g(requests);
        if (C0689q.m2782a(batchAppID)) {
            throw new C0699e("App ID was not specified at the request or Settings.");
        }
        serializer.mo849a("batch_app_id", batchAppID);
        attachments = new HashMap();
        m2444a(serializer, (Collection) requests, attachments);
        if (logger != null) {
            logger.m2680c("  Attachments:\n");
        }
        m2450a(attachments, serializer);
    }

    /* renamed from: b */
    private static boolean m2458b(String path) {
        Matcher matcher = f993c.matcher(path);
        if (matcher.matches()) {
            path = matcher.group(1);
        }
        if (path.startsWith("me/") || path.startsWith("/me/")) {
            return true;
        }
        return false;
    }

    /* renamed from: a */
    private static void m2452a(JSONObject graphObject, String path, C0582d serializer) throws IOException {
        boolean isOGAction = false;
        if (m2458b(path)) {
            int colonLocation = path.indexOf(":");
            int questionMarkLocation = path.indexOf("?");
            if (colonLocation <= 3 || (questionMarkLocation != -1 && colonLocation >= questionMarkLocation)) {
                isOGAction = false;
            } else {
                isOGAction = true;
            }
        }
        Iterator<String> keyIterator = graphObject.keys();
        while (keyIterator.hasNext()) {
            boolean passByValue;
            String key = (String) keyIterator.next();
            Object value = graphObject.opt(key);
            if (isOGAction && key.equalsIgnoreCase("image")) {
                passByValue = true;
            } else {
                passByValue = false;
            }
            m2448a(key, value, serializer, passByValue);
        }
    }

    /* renamed from: a */
    private static void m2448a(String key, Object value, C0582d serializer, boolean passByValue) throws IOException {
        Class<?> valueClass = value.getClass();
        if (JSONObject.class.isAssignableFrom(valueClass)) {
            JSONObject jsonObject = (JSONObject) value;
            if (passByValue) {
                Iterator<String> keys = jsonObject.keys();
                while (keys.hasNext()) {
                    Object[] objArr = new Object[]{key, (String) keys.next()};
                    m2448a(String.format("%s[%s]", objArr), jsonObject.opt((String) keys.next()), serializer, passByValue);
                }
            } else if (jsonObject.has("id")) {
                m2448a(key, jsonObject.optString("id"), serializer, passByValue);
            } else if (jsonObject.has("url")) {
                m2448a(key, jsonObject.optString("url"), serializer, passByValue);
            } else if (jsonObject.has("fbsdk:create_object")) {
                m2448a(key, jsonObject.toString(), serializer, passByValue);
            }
        } else if (JSONArray.class.isAssignableFrom(valueClass)) {
            JSONArray jsonArray = (JSONArray) value;
            int length = jsonArray.length();
            for (int i = 0; i < length; i++) {
                m2448a(String.format(Locale.ROOT, "%s[%d]", new Object[]{key, Integer.valueOf(i)}), jsonArray.opt(i), serializer, passByValue);
            }
        } else if (String.class.isAssignableFrom(valueClass) || Number.class.isAssignableFrom(valueClass) || Boolean.class.isAssignableFrom(valueClass)) {
            serializer.mo849a(key, value.toString());
        } else if (Date.class.isAssignableFrom(valueClass)) {
            C0582d c0582d = serializer;
            String str = key;
            c0582d.mo849a(str, new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US).format((Date) value));
        }
    }

    /* renamed from: a */
    private static void m2443a(Bundle bundle, C0588f serializer, GraphRequest request) throws IOException {
        for (String key : bundle.keySet()) {
            Object value = bundle.get(key);
            if (m2464e(value)) {
                serializer.m2427a(key, value, request);
            }
        }
    }

    /* renamed from: a */
    private static void m2450a(Map<String, C0585a> attachments, C0588f serializer) throws IOException {
        for (String key : attachments.keySet()) {
            C0585a attachment = (C0585a) attachments.get(key);
            if (m2462d(attachment.m2419b())) {
                serializer.m2427a(key, attachment.m2419b(), attachment.m2418a());
            }
        }
    }

    /* renamed from: a */
    private static void m2444a(C0588f serializer, Collection<GraphRequest> requests, Map<String, C0585a> attachments) throws JSONException, IOException {
        JSONArray batch = new JSONArray();
        for (GraphRequest request : requests) {
            request.m2451a(batch, (Map) attachments);
        }
        serializer.m2430a("batch", batch, (Collection) requests);
    }

    /* renamed from: o */
    private static String m2470o() {
        return String.format("multipart/form-data; boundary=%s", new Object[]{"3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f"});
    }

    /* renamed from: p */
    private static String m2471p() {
        if (f994q == null) {
            f994q = String.format("%s.%s", new Object[]{"FBAndroidSDK", "4.15.0"});
            if (!C0689q.m2782a(C0667j.m2664a())) {
                f994q = String.format(Locale.ROOT, "%s/%s", new Object[]{f994q, C0667j.m2664a()});
            }
        }
        return f994q;
    }

    /* renamed from: g */
    private static String m2467g(C0712k batch) {
        if (!C0689q.m2782a(batch.m2879f())) {
            return batch.m2879f();
        }
        Iterator it = batch.iterator();
        while (it.hasNext()) {
            AccessToken accessToken = ((GraphRequest) it.next()).f995d;
            if (accessToken != null) {
                String applicationId = accessToken.m2391h();
                if (applicationId != null) {
                    return applicationId;
                }
            }
        }
        if (C0689q.m2782a(f992b)) {
            return C0707g.m2858i();
        }
        return f992b;
    }

    /* renamed from: d */
    private static boolean m2462d(Object value) {
        return (value instanceof Bitmap) || (value instanceof byte[]) || (value instanceof Uri) || (value instanceof ParcelFileDescriptor) || (value instanceof ParcelableResourceWithMimeType);
    }

    /* renamed from: e */
    private static boolean m2464e(Object value) {
        return (value instanceof String) || (value instanceof Boolean) || (value instanceof Number) || (value instanceof Date);
    }

    /* renamed from: f */
    private static String m2465f(Object value) {
        if (value instanceof String) {
            return (String) value;
        }
        if ((value instanceof Boolean) || (value instanceof Number)) {
            return value.toString();
        }
        if (value instanceof Date) {
            return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US).format(value);
        }
        throw new IllegalArgumentException("Unsupported parameter type.");
    }
}

package com.facebook;

/* compiled from: AccessTokenSource */
/* renamed from: com.facebook.c */
public enum C0698c {
    NONE(false),
    FACEBOOK_APPLICATION_WEB(true),
    FACEBOOK_APPLICATION_NATIVE(true),
    FACEBOOK_APPLICATION_SERVICE(true),
    WEB_VIEW(true),
    CHROME_CUSTOM_TAB(true),
    TEST_USER(true),
    CLIENT_TOKEN(true),
    DEVICE_AUTH(true);
    
    /* renamed from: j */
    private final boolean f1273j;

    private C0698c(boolean canExtendToken) {
        this.f1273j = canExtendToken;
    }

    /* renamed from: a */
    boolean m2836a() {
        return this.f1273j;
    }
}

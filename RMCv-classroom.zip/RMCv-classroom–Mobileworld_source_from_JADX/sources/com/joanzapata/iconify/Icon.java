package com.joanzapata.iconify;

public interface Icon {
    char character();

    String key();
}

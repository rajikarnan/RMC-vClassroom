package com.joanzapata.iconify.internal;

import android.support.v4.view.ai;
import android.widget.TextView;

public interface HasOnViewAttachListener {

    public static class HasOnViewAttachListenerDelegate {
        private OnViewAttachListener listener;
        private final TextView view;

        public HasOnViewAttachListenerDelegate(TextView view) {
            this.view = view;
        }

        public void setOnViewAttachListener(OnViewAttachListener listener) {
            if (this.listener != null) {
                this.listener.onDetach();
            }
            this.listener = listener;
            if (ai.m1512x(this.view) && listener != null) {
                listener.onAttach();
            }
        }

        public void onAttachedToWindow() {
            if (this.listener != null) {
                this.listener.onAttach();
            }
        }

        public void onDetachedFromWindow() {
            if (this.listener != null) {
                this.listener.onDetach();
            }
        }
    }

    public interface OnViewAttachListener {
        void onAttach();

        void onDetach();
    }

    void setOnViewAttachListener(OnViewAttachListener onViewAttachListener);
}

package com.astuetz;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Typeface;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.rmc.app.R;
import android.support.v4.p011e.C0233h;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.C0249f;
import android.support.v4.view.ai;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import io.gonative.android.C1263q.C1262a;
import java.util.Locale;

public class PagerSlidingTabStrip extends HorizontalScrollView {
    /* renamed from: c */
    private static final int[] f889c = new int[]{16842901, 16842904, 16842966, 16842968, 16842806};
    /* renamed from: A */
    private int f890A;
    /* renamed from: B */
    private int f891B;
    /* renamed from: C */
    private boolean f892C;
    /* renamed from: D */
    private boolean f893D;
    /* renamed from: E */
    private boolean f894E;
    /* renamed from: F */
    private Typeface f895F;
    /* renamed from: G */
    private int f896G;
    /* renamed from: H */
    private int f897H;
    /* renamed from: I */
    private int f898I;
    /* renamed from: J */
    private int f899J;
    /* renamed from: K */
    private int f900K;
    /* renamed from: L */
    private Locale f901L;
    /* renamed from: M */
    private OnGlobalLayoutListener f902M;
    /* renamed from: a */
    public C0249f f903a;
    /* renamed from: b */
    private C0568b f904b;
    /* renamed from: d */
    private final C0570d f905d;
    /* renamed from: e */
    private LayoutParams f906e;
    /* renamed from: f */
    private LayoutParams f907f;
    /* renamed from: g */
    private final C0569c f908g;
    /* renamed from: h */
    private LinearLayout f909h;
    /* renamed from: i */
    private ViewPager f910i;
    /* renamed from: j */
    private int f911j;
    /* renamed from: k */
    private int f912k;
    /* renamed from: l */
    private float f913l;
    /* renamed from: m */
    private Paint f914m;
    /* renamed from: n */
    private Paint f915n;
    /* renamed from: o */
    private int f916o;
    /* renamed from: p */
    private int f917p;
    /* renamed from: q */
    private int f918q;
    /* renamed from: r */
    private int f919r;
    /* renamed from: s */
    private int f920s;
    /* renamed from: t */
    private int f921t;
    /* renamed from: u */
    private int f922u;
    /* renamed from: v */
    private int f923v;
    /* renamed from: w */
    private int f924w;
    /* renamed from: x */
    private ColorStateList f925x;
    /* renamed from: y */
    private float f926y;
    /* renamed from: z */
    private float f927z;

    /* renamed from: com.astuetz.PagerSlidingTabStrip$1 */
    class C05631 implements OnGlobalLayoutListener {
        /* renamed from: a */
        final /* synthetic */ PagerSlidingTabStrip f881a;

        C05631(PagerSlidingTabStrip this$0) {
            this.f881a = this$0;
        }

        @SuppressLint({"NewApi"})
        public void onGlobalLayout() {
            if (VERSION.SDK_INT < 16) {
                this.f881a.getViewTreeObserver().removeGlobalOnLayoutListener(this);
            } else {
                this.f881a.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            }
            this.f881a.f912k = this.f881a.f910i.getCurrentItem();
            this.f881a.f913l = 0.0f;
            this.f881a.m2352a(this.f881a.f912k, 0);
            this.f881a.m2351a(this.f881a.f912k);
        }
    }

    /* renamed from: com.astuetz.PagerSlidingTabStrip$3 */
    class C05653 implements OnGlobalLayoutListener {
        /* renamed from: a */
        final /* synthetic */ PagerSlidingTabStrip f884a;

        C05653(PagerSlidingTabStrip this$0) {
            this.f884a = this$0;
        }

        public void onGlobalLayout() {
            View view = this.f884a.f909h.getChildAt(0);
            if (VERSION.SDK_INT < 16) {
                this.f884a.getViewTreeObserver().removeGlobalOnLayoutListener(this);
            } else {
                this.f884a.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            }
            if (this.f884a.f894E) {
                this.f884a.f890A = this.f884a.f891B = (this.f884a.getWidth() / 2) - (view.getWidth() / 2);
            }
            this.f884a.setPadding(this.f884a.f890A, this.f884a.getPaddingTop(), this.f884a.f891B, this.f884a.getPaddingBottom());
            if (this.f884a.f898I == 0) {
                this.f884a.f898I = (this.f884a.getWidth() / 2) - this.f884a.f890A;
            }
        }
    }

    static class SavedState extends BaseSavedState {
        public static final Creator<SavedState> CREATOR = new C05661();
        /* renamed from: a */
        int f885a;

        /* renamed from: com.astuetz.PagerSlidingTabStrip$SavedState$1 */
        static class C05661 implements Creator<SavedState> {
            C05661() {
            }

            public /* synthetic */ Object createFromParcel(Parcel parcel) {
                return m2340a(parcel);
            }

            public /* synthetic */ Object[] newArray(int i) {
                return m2341a(i);
            }

            /* renamed from: a */
            public SavedState m2340a(Parcel in) {
                return new SavedState(in);
            }

            /* renamed from: a */
            public SavedState[] m2341a(int size) {
                return new SavedState[size];
            }
        }

        public SavedState(Parcelable superState) {
            super(superState);
        }

        private SavedState(Parcel in) {
            super(in);
            this.f885a = in.readInt();
        }

        public void writeToParcel(Parcel dest, int flags) {
            super.writeToParcel(dest, flags);
            dest.writeInt(this.f885a);
        }
    }

    /* renamed from: com.astuetz.PagerSlidingTabStrip$a */
    public interface C0567a {
        /* renamed from: a */
        View m2342a(ViewGroup viewGroup, int i);
    }

    /* renamed from: com.astuetz.PagerSlidingTabStrip$b */
    public interface C0568b {
        void a_(int i);
    }

    /* renamed from: com.astuetz.PagerSlidingTabStrip$c */
    private class C0569c implements C0249f {
        /* renamed from: a */
        final /* synthetic */ PagerSlidingTabStrip f886a;

        private C0569c(PagerSlidingTabStrip pagerSlidingTabStrip) {
            this.f886a = pagerSlidingTabStrip;
        }

        /* renamed from: a */
        public void mo846a(int position, float positionOffset, int positionOffsetPixels) {
            this.f886a.f912k = position;
            this.f886a.f913l = positionOffset;
            this.f886a.m2352a(position, this.f886a.f911j > 0 ? (int) (((float) this.f886a.f909h.getChildAt(position).getWidth()) * positionOffset) : 0);
            this.f886a.invalidate();
            if (this.f886a.f903a != null) {
                this.f886a.f903a.mo846a(position, positionOffset, positionOffsetPixels);
            }
        }

        /* renamed from: b */
        public void mo847b(int state) {
            if (state == 0) {
                this.f886a.m2352a(this.f886a.f910i.getCurrentItem(), 0);
            }
            this.f886a.m2360b(this.f886a.f909h.getChildAt(this.f886a.f910i.getCurrentItem()));
            if (this.f886a.f910i.getCurrentItem() - 1 >= 0) {
                this.f886a.m2354a(this.f886a.f909h.getChildAt(this.f886a.f910i.getCurrentItem() - 1));
            }
            if (this.f886a.f910i.getCurrentItem() + 1 <= this.f886a.f910i.getAdapter().mo1147a() - 1) {
                this.f886a.m2354a(this.f886a.f909h.getChildAt(this.f886a.f910i.getCurrentItem() + 1));
            }
            if (this.f886a.f903a != null) {
                this.f886a.f903a.mo847b(state);
            }
        }

        /* renamed from: a */
        public void mo845a(int position) {
            this.f886a.m2351a(position);
            if (this.f886a.f903a != null) {
                this.f886a.f903a.mo845a(position);
            }
        }
    }

    /* renamed from: com.astuetz.PagerSlidingTabStrip$d */
    private class C0570d extends DataSetObserver {
        /* renamed from: a */
        final /* synthetic */ PagerSlidingTabStrip f887a;
        /* renamed from: b */
        private boolean f888b;

        private C0570d(PagerSlidingTabStrip pagerSlidingTabStrip) {
            this.f887a = pagerSlidingTabStrip;
            this.f888b = false;
        }

        public void onChanged() {
            this.f887a.m2373a();
        }

        /* renamed from: a */
        public void m2346a(boolean attached) {
            this.f888b = attached;
        }

        /* renamed from: a */
        public boolean m2347a() {
            return this.f888b;
        }
    }

    public PagerSlidingTabStrip(Context context) {
        this(context, null);
    }

    public PagerSlidingTabStrip(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public PagerSlidingTabStrip(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.f905d = new C0570d();
        this.f908g = new C0569c();
        this.f912k = 0;
        this.f913l = 0.0f;
        this.f917p = 2;
        this.f918q = 0;
        this.f920s = 0;
        this.f921t = 0;
        this.f923v = 12;
        this.f924w = 14;
        this.f925x = null;
        this.f926y = 0.5f;
        this.f927z = 1.0f;
        this.f890A = 0;
        this.f891B = 0;
        this.f892C = false;
        this.f893D = true;
        this.f894E = false;
        this.f895F = null;
        this.f896G = 1;
        this.f897H = 1;
        this.f899J = 0;
        this.f900K = R.drawable.background_tab;
        this.f902M = new C05653(this);
        setFillViewport(true);
        setWillNotDraw(false);
        this.f909h = new LinearLayout(context);
        this.f909h.setOrientation(0);
        this.f909h.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        addView(this.f909h);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        this.f898I = (int) TypedValue.applyDimension(1, (float) this.f898I, dm);
        this.f917p = (int) TypedValue.applyDimension(1, (float) this.f917p, dm);
        this.f918q = (int) TypedValue.applyDimension(1, (float) this.f918q, dm);
        this.f921t = (int) TypedValue.applyDimension(1, (float) this.f921t, dm);
        this.f923v = (int) TypedValue.applyDimension(1, (float) this.f923v, dm);
        this.f920s = (int) TypedValue.applyDimension(1, (float) this.f920s, dm);
        this.f924w = (int) TypedValue.applyDimension(2, (float) this.f924w, dm);
        TypedArray a = context.obtainStyledAttributes(attrs, f889c);
        this.f924w = a.getDimensionPixelSize(0, this.f924w);
        ColorStateList colorStateList = a.getColorStateList(1);
        int textPrimaryColor = a.getColor(4, 17170443);
        TypedArray ta = context.obtainStyledAttributes(attrs, C1262a.PagerSlidingTabStrip);
        textPrimaryColor = ta.getColor(0, textPrimaryColor);
        ta.recycle();
        if (colorStateList != null) {
            this.f925x = colorStateList;
        } else {
            this.f925x = m2358b(textPrimaryColor);
        }
        this.f919r = textPrimaryColor;
        this.f922u = textPrimaryColor;
        this.f916o = textPrimaryColor;
        this.f890A = a.getDimensionPixelSize(2, this.f890A);
        this.f891B = a.getDimensionPixelSize(3, this.f891B);
        a.recycle();
        if (this.f891B < this.f890A) {
            this.f891B = this.f890A;
        }
        if (this.f890A < this.f891B) {
            this.f890A = this.f891B;
        }
        a = context.obtainStyledAttributes(attrs, C1262a.PagerSlidingTabStrip);
        this.f916o = a.getColor(1, this.f916o);
        this.f919r = a.getColor(2, this.f919r);
        this.f922u = a.getColor(3, this.f922u);
        this.f920s = a.getDimensionPixelSize(4, this.f920s);
        this.f917p = a.getDimensionPixelSize(5, this.f917p);
        this.f918q = a.getDimensionPixelSize(6, this.f918q);
        this.f921t = a.getDimensionPixelSize(7, this.f921t);
        this.f923v = a.getDimensionPixelSize(8, this.f923v);
        this.f900K = a.getResourceId(10, this.f900K);
        this.f892C = a.getBoolean(11, this.f892C);
        this.f898I = a.getDimensionPixelSize(9, this.f898I);
        this.f893D = a.getBoolean(12, this.f893D);
        this.f894E = a.getBoolean(13, this.f894E);
        this.f896G = a.getInt(14, 1);
        this.f897H = a.getInt(15, 1);
        this.f926y = a.getFloat(16, 0.5f);
        this.f927z = a.getFloat(17, 1.0f);
        a.recycle();
        this.f914m = new Paint();
        this.f914m.setAntiAlias(true);
        this.f914m.setStyle(Style.FILL);
        this.f915n = new Paint();
        this.f915n.setAntiAlias(true);
        this.f915n.setStrokeWidth((float) this.f920s);
        this.f906e = new LayoutParams(-2, -1);
        this.f907f = new LayoutParams(0, -1, 1.0f);
        if (this.f901L == null) {
            this.f901L = getResources().getConfiguration().locale;
        }
    }

    public void setViewPager(ViewPager pager) {
        this.f910i = pager;
        if (pager.getAdapter() == null) {
            throw new IllegalStateException("ViewPager does not have adapter instance.");
        }
        pager.setOnPageChangeListener(this.f908g);
        pager.getAdapter().m1282a(this.f905d);
        this.f905d.m2346a(true);
        m2373a();
    }

    /* renamed from: a */
    public void m2373a() {
        this.f909h.removeAllViews();
        this.f911j = this.f910i.getAdapter().mo1147a();
        for (int i = 0; i < this.f911j; i++) {
            View tabView;
            if (this.f910i.getAdapter() instanceof C0567a) {
                tabView = ((C0567a) this.f910i.getAdapter()).m2342a(this, i);
            } else {
                tabView = LayoutInflater.from(getContext()).inflate(R.layout.tab, this, false);
            }
            m2353a(i, this.f910i.getAdapter().mo1148a(i), tabView);
        }
        m2359b();
        getViewTreeObserver().addOnGlobalLayoutListener(new C05631(this));
    }

    /* renamed from: a */
    private void m2353a(final int position, CharSequence title, View tabView) {
        View textView = (TextView) tabView.findViewById(R.id.tab_title);
        if (textView != null) {
            if (title != null) {
                textView.setText(title);
            }
            ai.m1482b(textView, this.f910i.getCurrentItem() == position ? this.f927z : this.f926y);
        }
        tabView.setFocusable(true);
        tabView.setOnClickListener(new OnClickListener(this) {
            /* renamed from: b */
            final /* synthetic */ PagerSlidingTabStrip f883b;

            public void onClick(View v) {
                if (this.f883b.f904b != null) {
                    this.f883b.f904b.a_(position);
                }
                if (this.f883b.f910i.getCurrentItem() != position) {
                    this.f883b.m2354a(this.f883b.f909h.getChildAt(this.f883b.f910i.getCurrentItem()));
                    this.f883b.f910i.setCurrentItem(position);
                }
            }
        });
        tabView.setPadding(this.f923v, tabView.getPaddingTop(), this.f923v, tabView.getPaddingBottom());
        this.f909h.addView(tabView, position, this.f892C ? this.f907f : this.f906e);
    }

    /* renamed from: b */
    private void m2359b() {
        int i = 0;
        while (i < this.f911j) {
            View v = this.f909h.getChildAt(i);
            v.setBackgroundResource(this.f900K);
            TextView tab_title = (TextView) v.findViewById(R.id.tab_title);
            if (tab_title != null) {
                tab_title.setTextSize(0, (float) this.f924w);
                tab_title.setTypeface(this.f895F, this.f910i.getCurrentItem() == i ? this.f897H : this.f896G);
                if (this.f925x != null) {
                    tab_title.setTextColor(this.f925x);
                }
                if (this.f893D) {
                    if (VERSION.SDK_INT >= 14) {
                        tab_title.setAllCaps(true);
                    } else {
                        tab_title.setText(tab_title.getText().toString().toUpperCase(this.f901L));
                    }
                }
            }
            i++;
        }
    }

    /* renamed from: a */
    private void m2352a(int position, int offset) {
        if (this.f911j != 0) {
            int newScrollX = this.f909h.getChildAt(position).getLeft() + offset;
            if (position > 0 || offset > 0) {
                newScrollX -= this.f898I;
                C0233h<Float, Float> lines = getIndicatorCoordinates();
                newScrollX = (int) (((((Float) lines.f451b).floatValue() - ((Float) lines.f450a).floatValue()) / 2.0f) + ((float) newScrollX));
            }
            if (newScrollX != this.f899J) {
                this.f899J = newScrollX;
                scrollTo(newScrollX, 0);
            }
        }
    }

    private C0233h<Float, Float> getIndicatorCoordinates() {
        View currentTab = this.f909h.getChildAt(this.f912k);
        float lineLeft = (float) currentTab.getLeft();
        float lineRight = (float) currentTab.getRight();
        if (this.f913l > 0.0f && this.f912k < this.f911j - 1) {
            View nextTab = this.f909h.getChildAt(this.f912k + 1);
            lineLeft = (this.f913l * ((float) nextTab.getLeft())) + ((1.0f - this.f913l) * lineLeft);
            lineRight = (this.f913l * ((float) nextTab.getRight())) + ((1.0f - this.f913l) * lineRight);
        }
        return new C0233h(Float.valueOf(lineLeft), Float.valueOf(lineRight));
    }

    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        this.f909h.setMinimumWidth(getWidth());
        setClipToPadding(false);
        if (this.f909h.getChildCount() > 0) {
            this.f909h.getChildAt(0).getViewTreeObserver().addOnGlobalLayoutListener(this.f902M);
        }
        super.onLayout(changed, l, t, r, b);
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!isInEditMode() && this.f911j != 0) {
            int height = getHeight();
            this.f914m.setColor(this.f916o);
            C0233h<Float, Float> lines = getIndicatorCoordinates();
            Canvas canvas2 = canvas;
            canvas2.drawRect(((float) this.f890A) + ((Float) lines.f450a).floatValue(), (float) (height - this.f917p), ((float) this.f891B) + ((Float) lines.f451b).floatValue(), (float) height, this.f914m);
            this.f914m.setColor(this.f919r);
            canvas.drawRect((float) this.f890A, (float) (height - this.f918q), (float) (this.f909h.getWidth() + this.f891B), (float) height, this.f914m);
            if (this.f920s != 0) {
                this.f915n.setStrokeWidth((float) this.f920s);
                this.f915n.setColor(this.f922u);
                for (int i = 0; i < this.f911j - 1; i++) {
                    View tab = this.f909h.getChildAt(i);
                    canvas.drawLine((float) tab.getRight(), (float) this.f921t, (float) tab.getRight(), (float) (height - this.f921t), this.f915n);
                }
            }
        }
    }

    public void setOnPageChangeListener(C0249f listener) {
        this.f903a = listener;
    }

    /* renamed from: a */
    private void m2351a(int position) {
        int i = 0;
        while (i < this.f911j) {
            View tv = this.f909h.getChildAt(i);
            tv.setSelected(i == position);
            if (i == position) {
                m2360b(tv);
            } else {
                m2354a(tv);
            }
            i++;
        }
    }

    /* renamed from: a */
    private void m2354a(View tab) {
        View title = (TextView) tab.findViewById(R.id.tab_title);
        if (title != null) {
            title.setTypeface(this.f895F, this.f896G);
            ai.m1482b(title, this.f926y);
        }
    }

    /* renamed from: b */
    private void m2360b(View tab) {
        View title = (TextView) tab.findViewById(R.id.tab_title);
        if (title != null) {
            title.setTypeface(this.f895F, this.f897H);
            ai.m1482b(title, this.f927z);
        }
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.f910i != null && !this.f905d.m2347a()) {
            this.f910i.getAdapter().m1282a(this.f905d);
            this.f905d.m2346a(true);
        }
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.f910i != null && this.f905d.m2347a()) {
            this.f910i.getAdapter().m1291b(this.f905d);
            this.f905d.m2346a(false);
        }
    }

    public void onRestoreInstanceState(Parcelable state) {
        SavedState savedState = (SavedState) state;
        super.onRestoreInstanceState(savedState.getSuperState());
        this.f912k = savedState.f885a;
        if (this.f912k != 0 && this.f909h.getChildCount() > 0) {
            m2354a(this.f909h.getChildAt(0));
            m2360b(this.f909h.getChildAt(this.f912k));
        }
        requestLayout();
    }

    public Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.f885a = this.f912k;
        return savedState;
    }

    public int getIndicatorColor() {
        return this.f916o;
    }

    public int getIndicatorHeight() {
        return this.f917p;
    }

    public int getUnderlineColor() {
        return this.f919r;
    }

    public int getDividerColor() {
        return this.f922u;
    }

    public int getDividerWidth() {
        return this.f920s;
    }

    public int getUnderlineHeight() {
        return this.f918q;
    }

    public int getDividerPadding() {
        return this.f921t;
    }

    public int getScrollOffset() {
        return this.f898I;
    }

    public boolean getShouldExpand() {
        return this.f892C;
    }

    public int getTextSize() {
        return this.f924w;
    }

    public ColorStateList getTextColor() {
        return this.f925x;
    }

    public int getTabBackground() {
        return this.f900K;
    }

    public int getTabPaddingLeftRight() {
        return this.f923v;
    }

    public void setIndicatorColor(int indicatorColor) {
        this.f916o = indicatorColor;
        invalidate();
    }

    public void setIndicatorColorResource(int resId) {
        this.f916o = getResources().getColor(resId);
        invalidate();
    }

    public void setIndicatorHeight(int indicatorLineHeightPx) {
        this.f917p = indicatorLineHeightPx;
        invalidate();
    }

    public void setUnderlineColor(int underlineColor) {
        this.f919r = underlineColor;
        invalidate();
    }

    public void setUnderlineColorResource(int resId) {
        this.f919r = getResources().getColor(resId);
        invalidate();
    }

    public void setDividerColor(int dividerColor) {
        this.f922u = dividerColor;
        invalidate();
    }

    public void setDividerColorResource(int resId) {
        this.f922u = getResources().getColor(resId);
        invalidate();
    }

    public void setDividerWidth(int dividerWidthPx) {
        this.f920s = dividerWidthPx;
        invalidate();
    }

    public void setUnderlineHeight(int underlineHeightPx) {
        this.f918q = underlineHeightPx;
        invalidate();
    }

    public void setDividerPadding(int dividerPaddingPx) {
        this.f921t = dividerPaddingPx;
        invalidate();
    }

    public void setScrollOffset(int scrollOffsetPx) {
        this.f898I = scrollOffsetPx;
        invalidate();
    }

    public void setShouldExpand(boolean shouldExpand) {
        this.f892C = shouldExpand;
        if (this.f910i != null) {
            requestLayout();
        }
    }

    public void setAllCaps(boolean textAllCaps) {
        this.f893D = textAllCaps;
    }

    public void setTextSize(int textSizePx) {
        this.f924w = textSizePx;
        m2359b();
    }

    public void setTextColor(int textColor) {
        setTextColor(m2358b(textColor));
    }

    /* renamed from: b */
    private ColorStateList m2358b(int textColor) {
        return new ColorStateList(new int[][]{new int[0]}, new int[]{textColor});
    }

    public void setTextColor(ColorStateList colorStateList) {
        this.f925x = colorStateList;
        m2359b();
    }

    public void setTextColorResource(int resId) {
        setTextColor(getResources().getColor(resId));
    }

    public void setTextColorStateListResource(int resId) {
        setTextColor(getResources().getColorStateList(resId));
    }

    public void setTabBackground(int resId) {
        this.f900K = resId;
    }

    public void setTabPaddingLeftRight(int paddingPx) {
        this.f923v = paddingPx;
        m2359b();
    }

    public void setTabClickListener(C0568b tabClickListener) {
        this.f904b = tabClickListener;
    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        this.f909h.measure(widthMeasureSpec, heightMeasureSpec);
    }
}

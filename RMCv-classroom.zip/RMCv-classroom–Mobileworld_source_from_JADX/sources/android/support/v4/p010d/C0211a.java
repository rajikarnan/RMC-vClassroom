package android.support.v4.p010d;

import android.os.Build.VERSION;
import java.util.Locale;

/* compiled from: ICUCompat */
/* renamed from: android.support.v4.d.a */
public final class C0211a {
    /* renamed from: a */
    private static final C0207a f408a;

    /* compiled from: ICUCompat */
    /* renamed from: android.support.v4.d.a$a */
    interface C0207a {
        /* renamed from: a */
        String mo141a(Locale locale);
    }

    /* compiled from: ICUCompat */
    /* renamed from: android.support.v4.d.a$b */
    static class C0208b implements C0207a {
        C0208b() {
        }

        /* renamed from: a */
        public String mo141a(Locale locale) {
            return null;
        }
    }

    /* compiled from: ICUCompat */
    /* renamed from: android.support.v4.d.a$c */
    static class C0209c implements C0207a {
        C0209c() {
        }

        /* renamed from: a */
        public String mo141a(Locale locale) {
            return C0213c.m775a(locale);
        }
    }

    /* compiled from: ICUCompat */
    /* renamed from: android.support.v4.d.a$d */
    static class C0210d implements C0207a {
        C0210d() {
        }

        /* renamed from: a */
        public String mo141a(Locale locale) {
            return C0212b.m773a(locale);
        }
    }

    static {
        int version = VERSION.SDK_INT;
        if (version >= 21) {
            f408a = new C0210d();
        } else if (version >= 14) {
            f408a = new C0209c();
        } else {
            f408a = new C0208b();
        }
    }

    /* renamed from: a */
    public static String m772a(Locale locale) {
        return f408a.mo141a(locale);
    }
}

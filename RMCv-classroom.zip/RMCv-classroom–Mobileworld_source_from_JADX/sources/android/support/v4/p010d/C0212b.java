package android.support.v4.p010d;

import android.util.Log;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Locale;

/* compiled from: ICUCompatApi23 */
/* renamed from: android.support.v4.d.b */
class C0212b {
    /* renamed from: a */
    private static Method f409a;

    static {
        try {
            f409a = Class.forName("libcore.icu.ICU").getMethod("addLikelySubtags", new Class[]{Locale.class});
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    /* renamed from: a */
    public static String m773a(Locale locale) {
        try {
            return ((Locale) f409a.invoke(null, new Object[]{locale})).getScript();
        } catch (InvocationTargetException e) {
            Log.w("ICUCompatIcs", e);
            return locale.getScript();
        } catch (IllegalAccessException e2) {
            Log.w("ICUCompatIcs", e2);
            return locale.getScript();
        }
    }
}

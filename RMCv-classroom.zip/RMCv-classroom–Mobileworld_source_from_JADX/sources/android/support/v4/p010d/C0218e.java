package android.support.v4.p010d;

import android.text.TextUtils;
import java.util.Locale;

/* compiled from: TextUtilsCompatJellybeanMr1 */
/* renamed from: android.support.v4.d.e */
class C0218e {
    /* renamed from: a */
    public static int m783a(Locale locale) {
        return TextUtils.getLayoutDirectionFromLocale(locale);
    }
}

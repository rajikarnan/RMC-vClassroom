package android.support.v4.p010d;

import android.os.Build.VERSION;
import java.util.Locale;

/* compiled from: TextUtilsCompat */
/* renamed from: android.support.v4.d.d */
public final class C0217d {
    /* renamed from: a */
    public static final Locale f412a = new Locale("", "");
    /* renamed from: b */
    private static final C0215a f413b;
    /* renamed from: c */
    private static String f414c = "Arab";
    /* renamed from: d */
    private static String f415d = "Hebr";

    /* compiled from: TextUtilsCompat */
    /* renamed from: android.support.v4.d.d$a */
    private static class C0215a {
        private C0215a() {
        }

        /* renamed from: a */
        public int mo142a(Locale locale) {
            if (!(locale == null || locale.equals(C0217d.f412a))) {
                String scriptSubtag = C0211a.m772a(locale);
                if (scriptSubtag == null) {
                    return C0215a.m777b(locale);
                }
                if (scriptSubtag.equalsIgnoreCase(C0217d.f414c) || scriptSubtag.equalsIgnoreCase(C0217d.f415d)) {
                    return 1;
                }
            }
            return 0;
        }

        /* renamed from: b */
        private static int m777b(Locale locale) {
            switch (Character.getDirectionality(locale.getDisplayName(locale).charAt(0))) {
                case (byte) 1:
                case (byte) 2:
                    return 1;
                default:
                    return 0;
            }
        }
    }

    /* compiled from: TextUtilsCompat */
    /* renamed from: android.support.v4.d.d$b */
    private static class C0216b extends C0215a {
        private C0216b() {
            super();
        }

        /* renamed from: a */
        public int mo142a(Locale locale) {
            return C0218e.m783a(locale);
        }
    }

    static {
        if (VERSION.SDK_INT >= 17) {
            f413b = new C0216b();
        } else {
            f413b = new C0215a();
        }
    }

    /* renamed from: a */
    public static int m780a(Locale locale) {
        return f413b.mo142a(locale);
    }
}

package android.support.v4.p010d;

import android.util.Log;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Locale;

/* compiled from: ICUCompatIcs */
/* renamed from: android.support.v4.d.c */
class C0213c {
    /* renamed from: a */
    private static Method f410a;
    /* renamed from: b */
    private static Method f411b;

    static {
        try {
            Class<?> clazz = Class.forName("libcore.icu.ICU");
            if (clazz != null) {
                f410a = clazz.getMethod("getScript", new Class[]{String.class});
                f411b = clazz.getMethod("addLikelySubtags", new Class[]{String.class});
            }
        } catch (Exception e) {
            f410a = null;
            f411b = null;
            Log.w("ICUCompatIcs", e);
        }
    }

    /* renamed from: a */
    public static String m775a(Locale locale) {
        String localeWithSubtags = C0213c.m776b(locale);
        if (localeWithSubtags != null) {
            return C0213c.m774a(localeWithSubtags);
        }
        return null;
    }

    /* renamed from: a */
    private static String m774a(String localeStr) {
        try {
            if (f410a != null) {
                return (String) f410a.invoke(null, new Object[]{localeStr});
            }
        } catch (IllegalAccessException e) {
            Log.w("ICUCompatIcs", e);
        } catch (InvocationTargetException e2) {
            Log.w("ICUCompatIcs", e2);
        }
        return null;
    }

    /* renamed from: b */
    private static String m776b(Locale locale) {
        String localeStr = locale.toString();
        try {
            if (f411b != null) {
                return (String) f411b.invoke(null, new Object[]{localeStr});
            }
        } catch (IllegalAccessException e) {
            Log.w("ICUCompatIcs", e);
        } catch (InvocationTargetException e2) {
            Log.w("ICUCompatIcs", e2);
        }
        return localeStr;
    }
}

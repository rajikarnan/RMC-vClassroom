package android.support.v4.p011e;

/* compiled from: Pair */
/* renamed from: android.support.v4.e.h */
public class C0233h<F, S> {
    /* renamed from: a */
    public final F f450a;
    /* renamed from: b */
    public final S f451b;

    public C0233h(F first, S second) {
        this.f450a = first;
        this.f451b = second;
    }

    public boolean equals(Object o) {
        if (!(o instanceof C0233h)) {
            return false;
        }
        C0233h<?, ?> p = (C0233h) o;
        if (C0233h.m844a(p.f450a, this.f450a) && C0233h.m844a(p.f451b, this.f451b)) {
            return true;
        }
        return false;
    }

    /* renamed from: a */
    private static boolean m844a(Object a, Object b) {
        return a == b || (a != null && a.equals(b));
    }

    public int hashCode() {
        int i = 0;
        int hashCode = this.f450a == null ? 0 : this.f450a.hashCode();
        if (this.f451b != null) {
            i = this.f451b.hashCode();
        }
        return hashCode ^ i;
    }
}

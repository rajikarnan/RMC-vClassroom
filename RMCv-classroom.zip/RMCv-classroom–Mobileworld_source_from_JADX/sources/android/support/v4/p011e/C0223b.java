package android.support.v4.p011e;

/* compiled from: ContainerHelpers */
/* renamed from: android.support.v4.e.b */
class C0223b {
    /* renamed from: a */
    static final int[] f428a = new int[0];
    /* renamed from: b */
    static final long[] f429b = new long[0];
    /* renamed from: c */
    static final Object[] f430c = new Object[0];

    /* renamed from: a */
    public static int m825a(int need) {
        return C0223b.m830c(need * 4) / 4;
    }

    /* renamed from: b */
    public static int m829b(int need) {
        return C0223b.m830c(need * 8) / 8;
    }

    /* renamed from: c */
    public static int m830c(int need) {
        for (int i = 4; i < 32; i++) {
            if (need <= (1 << i) - 12) {
                return (1 << i) - 12;
            }
        }
        return need;
    }

    /* renamed from: a */
    public static boolean m828a(Object a, Object b) {
        return a == b || (a != null && a.equals(b));
    }

    /* renamed from: a */
    static int m826a(int[] array, int size, int value) {
        int lo = 0;
        int hi = size - 1;
        while (lo <= hi) {
            int i = (lo + hi) >>> 1;
            int midVal = array[i];
            if (midVal < value) {
                lo = i + 1;
            } else if (midVal <= value) {
                return i;
            } else {
                hi = i - 1;
            }
        }
        return lo ^ -1;
    }

    /* renamed from: a */
    static int m827a(long[] array, int size, long value) {
        int lo = 0;
        int hi = size - 1;
        while (lo <= hi) {
            int i = (lo + hi) >>> 1;
            long midVal = array[i];
            if (midVal < value) {
                lo = i + 1;
            } else if (midVal <= value) {
                return i;
            } else {
                hi = i - 1;
            }
        }
        return lo ^ -1;
    }
}

package android.support.v4.p011e;

/* compiled from: SparseArrayCompat */
/* renamed from: android.support.v4.e.j */
public class C0234j<E> implements Cloneable {
    /* renamed from: a */
    private static final Object f452a = new Object();
    /* renamed from: b */
    private boolean f453b;
    /* renamed from: c */
    private int[] f454c;
    /* renamed from: d */
    private Object[] f455d;
    /* renamed from: e */
    private int f456e;

    public /* synthetic */ Object clone() throws CloneNotSupportedException {
        return m846a();
    }

    public C0234j() {
        this(10);
    }

    public C0234j(int initialCapacity) {
        this.f453b = false;
        if (initialCapacity == 0) {
            this.f454c = C0223b.f428a;
            this.f455d = C0223b.f430c;
        } else {
            initialCapacity = C0223b.m825a(initialCapacity);
            this.f454c = new int[initialCapacity];
            this.f455d = new Object[initialCapacity];
        }
        this.f456e = 0;
    }

    /* renamed from: a */
    public C0234j<E> m846a() {
        C0234j<E> clone = null;
        try {
            clone = (C0234j) super.clone();
            clone.f454c = (int[]) this.f454c.clone();
            clone.f455d = (Object[]) this.f455d.clone();
            return clone;
        } catch (CloneNotSupportedException e) {
            return clone;
        }
    }

    /* renamed from: a */
    public E m847a(int key) {
        return m848a(key, null);
    }

    /* renamed from: a */
    public E m848a(int key, E valueIfKeyNotFound) {
        int i = C0223b.m826a(this.f454c, this.f456e, key);
        return (i < 0 || this.f455d[i] == f452a) ? valueIfKeyNotFound : this.f455d[i];
    }

    /* renamed from: b */
    public void m850b(int key) {
        int i = C0223b.m826a(this.f454c, this.f456e, key);
        if (i >= 0 && this.f455d[i] != f452a) {
            this.f455d[i] = f452a;
            this.f453b = true;
        }
    }

    /* renamed from: c */
    public void m853c(int key) {
        m850b(key);
    }

    /* renamed from: d */
    private void m845d() {
        int n = this.f456e;
        int o = 0;
        int[] keys = this.f454c;
        Object[] values = this.f455d;
        for (int i = 0; i < n; i++) {
            Object val = values[i];
            if (val != f452a) {
                if (i != o) {
                    keys[o] = keys[i];
                    values[o] = val;
                    values[i] = null;
                }
                o++;
            }
        }
        this.f453b = false;
        this.f456e = o;
    }

    /* renamed from: b */
    public void m851b(int key, E value) {
        int i = C0223b.m826a(this.f454c, this.f456e, key);
        if (i >= 0) {
            this.f455d[i] = value;
            return;
        }
        i ^= -1;
        if (i >= this.f456e || this.f455d[i] != f452a) {
            if (this.f453b && this.f456e >= this.f454c.length) {
                m845d();
                i = C0223b.m826a(this.f454c, this.f456e, key) ^ -1;
            }
            if (this.f456e >= this.f454c.length) {
                int n = C0223b.m825a(this.f456e + 1);
                int[] nkeys = new int[n];
                Object[] nvalues = new Object[n];
                System.arraycopy(this.f454c, 0, nkeys, 0, this.f454c.length);
                System.arraycopy(this.f455d, 0, nvalues, 0, this.f455d.length);
                this.f454c = nkeys;
                this.f455d = nvalues;
            }
            if (this.f456e - i != 0) {
                System.arraycopy(this.f454c, i, this.f454c, i + 1, this.f456e - i);
                System.arraycopy(this.f455d, i, this.f455d, i + 1, this.f456e - i);
            }
            this.f454c[i] = key;
            this.f455d[i] = value;
            this.f456e++;
            return;
        }
        this.f454c[i] = key;
        this.f455d[i] = value;
    }

    /* renamed from: b */
    public int m849b() {
        if (this.f453b) {
            m845d();
        }
        return this.f456e;
    }

    /* renamed from: d */
    public int m854d(int index) {
        if (this.f453b) {
            m845d();
        }
        return this.f454c[index];
    }

    /* renamed from: e */
    public E m855e(int index) {
        if (this.f453b) {
            m845d();
        }
        return this.f455d[index];
    }

    /* renamed from: f */
    public int m856f(int key) {
        if (this.f453b) {
            m845d();
        }
        return C0223b.m826a(this.f454c, this.f456e, key);
    }

    /* renamed from: c */
    public void m852c() {
        int n = this.f456e;
        Object[] values = this.f455d;
        for (int i = 0; i < n; i++) {
            values[i] = null;
        }
        this.f456e = 0;
        this.f453b = false;
    }

    public String toString() {
        if (m849b() <= 0) {
            return "{}";
        }
        StringBuilder buffer = new StringBuilder(this.f456e * 28);
        buffer.append('{');
        for (int i = 0; i < this.f456e; i++) {
            if (i > 0) {
                buffer.append(", ");
            }
            buffer.append(m854d(i));
            buffer.append('=');
            C0234j value = m855e(i);
            if (value != this) {
                buffer.append(value);
            } else {
                buffer.append("(this Map)");
            }
        }
        buffer.append('}');
        return buffer.toString();
    }
}

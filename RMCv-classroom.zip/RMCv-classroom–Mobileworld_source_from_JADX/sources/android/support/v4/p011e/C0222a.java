package android.support.v4.p011e;

import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/* compiled from: ArrayMap */
/* renamed from: android.support.v4.e.a */
public class C0222a<K, V> extends C0221i<K, V> implements Map<K, V> {
    /* renamed from: a */
    C0219g<K, V> f427a;

    /* compiled from: ArrayMap */
    /* renamed from: android.support.v4.e.a$1 */
    class C02201 extends C0219g<K, V> {
        /* renamed from: a */
        final /* synthetic */ C0222a f419a;

        C02201(C0222a c0222a) {
            this.f419a = c0222a;
        }

        /* renamed from: a */
        protected int mo143a() {
            return this.f419a.h;
        }

        /* renamed from: a */
        protected Object mo145a(int index, int offset) {
            return this.f419a.g[(index << 1) + offset];
        }

        /* renamed from: a */
        protected int mo144a(Object key) {
            return this.f419a.m814a(key);
        }

        /* renamed from: b */
        protected int mo149b(Object value) {
            return this.f419a.m819b(value);
        }

        /* renamed from: b */
        protected Map<K, V> mo150b() {
            return this.f419a;
        }

        /* renamed from: a */
        protected void mo148a(K key, V value) {
            this.f419a.put(key, value);
        }

        /* renamed from: a */
        protected V mo146a(int index, V value) {
            return this.f419a.m816a(index, (Object) value);
        }

        /* renamed from: a */
        protected void mo147a(int index) {
            this.f419a.m822d(index);
        }

        /* renamed from: c */
        protected void mo151c() {
            this.f419a.clear();
        }
    }

    public C0222a(int capacity) {
        super(capacity);
    }

    /* renamed from: b */
    private C0219g<K, V> m823b() {
        if (this.f427a == null) {
            this.f427a = new C02201(this);
        }
        return this.f427a;
    }

    public void putAll(Map<? extends K, ? extends V> map) {
        m817a(this.h + map.size());
        for (Entry<? extends K, ? extends V> entry : map.entrySet()) {
            put(entry.getKey(), entry.getValue());
        }
    }

    /* renamed from: a */
    public boolean m824a(Collection<?> collection) {
        return C0219g.m787c(this, collection);
    }

    public Set<Entry<K, V>> entrySet() {
        return m823b().m799d();
    }

    public Set<K> keySet() {
        return m823b().m800e();
    }

    public Collection<V> values() {
        return m823b().m801f();
    }
}

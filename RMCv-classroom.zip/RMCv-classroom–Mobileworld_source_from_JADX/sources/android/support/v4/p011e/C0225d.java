package android.support.v4.p011e;

import android.support.v4.app.ag;
import android.util.Log;
import java.io.Writer;

/* compiled from: LogWriter */
/* renamed from: android.support.v4.e.d */
public class C0225d extends Writer {
    /* renamed from: a */
    private final String f431a;
    /* renamed from: b */
    private StringBuilder f432b = new StringBuilder(ag.FLAG_HIGH_PRIORITY);

    public C0225d(String tag) {
        this.f431a = tag;
    }

    public void close() {
        m832a();
    }

    public void flush() {
        m832a();
    }

    public void write(char[] buf, int offset, int count) {
        for (int i = 0; i < count; i++) {
            char c = buf[offset + i];
            if (c == '\n') {
                m832a();
            } else {
                this.f432b.append(c);
            }
        }
    }

    /* renamed from: a */
    private void m832a() {
        if (this.f432b.length() > 0) {
            Log.d(this.f431a, this.f432b.toString());
            this.f432b.delete(0, this.f432b.length());
        }
    }
}

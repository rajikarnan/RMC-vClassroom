package android.support.v4.p011e;

import java.util.Map;

/* compiled from: SimpleArrayMap */
/* renamed from: android.support.v4.e.i */
public class C0221i<K, V> {
    /* renamed from: b */
    static Object[] f420b;
    /* renamed from: c */
    static int f421c;
    /* renamed from: d */
    static Object[] f422d;
    /* renamed from: e */
    static int f423e;
    /* renamed from: f */
    int[] f424f;
    /* renamed from: g */
    Object[] f425g;
    /* renamed from: h */
    int f426h;

    /* renamed from: a */
    int m815a(Object key, int hash) {
        int N = this.f426h;
        if (N == 0) {
            return -1;
        }
        int index = C0223b.m826a(this.f424f, N, hash);
        if (index < 0 || key.equals(this.f425g[index << 1])) {
            return index;
        }
        int end = index + 1;
        while (end < N && this.f424f[end] == hash) {
            if (key.equals(this.f425g[end << 1])) {
                return end;
            }
            end++;
        }
        int i = index - 1;
        while (i >= 0 && this.f424f[i] == hash) {
            if (key.equals(this.f425g[i << 1])) {
                return i;
            }
            i--;
        }
        return end ^ -1;
    }

    /* renamed from: a */
    int m813a() {
        int N = this.f426h;
        if (N == 0) {
            return -1;
        }
        int index = C0223b.m826a(this.f424f, N, 0);
        if (index < 0 || this.f425g[index << 1] == null) {
            return index;
        }
        int end = index + 1;
        while (end < N && this.f424f[end] == 0) {
            if (this.f425g[end << 1] == null) {
                return end;
            }
            end++;
        }
        int i = index - 1;
        while (i >= 0 && this.f424f[i] == 0) {
            if (this.f425g[i << 1] == null) {
                return i;
            }
            i--;
        }
        return end ^ -1;
    }

    /* renamed from: e */
    private void m812e(int size) {
        Object[] array;
        if (size == 8) {
            synchronized (C0222a.class) {
                if (f422d != null) {
                    array = f422d;
                    this.f425g = array;
                    f422d = (Object[]) array[0];
                    this.f424f = (int[]) array[1];
                    array[1] = null;
                    array[0] = null;
                    f423e--;
                    return;
                }
            }
        } else if (size == 4) {
            synchronized (C0222a.class) {
                if (f420b != null) {
                    array = f420b;
                    this.f425g = array;
                    f420b = (Object[]) array[0];
                    this.f424f = (int[]) array[1];
                    array[1] = null;
                    array[0] = null;
                    f421c--;
                    return;
                }
            }
        }
        this.f424f = new int[size];
        this.f425g = new Object[(size << 1)];
    }

    /* renamed from: a */
    private static void m811a(int[] hashes, Object[] array, int size) {
        int i;
        if (hashes.length == 8) {
            synchronized (C0222a.class) {
                if (f423e < 10) {
                    array[0] = f422d;
                    array[1] = hashes;
                    for (i = (size << 1) - 1; i >= 2; i--) {
                        array[i] = null;
                    }
                    f422d = array;
                    f423e++;
                }
            }
        } else if (hashes.length == 4) {
            synchronized (C0222a.class) {
                if (f421c < 10) {
                    array[0] = f420b;
                    array[1] = hashes;
                    for (i = (size << 1) - 1; i >= 2; i--) {
                        array[i] = null;
                    }
                    f420b = array;
                    f421c++;
                }
            }
        }
    }

    public C0221i() {
        this.f424f = C0223b.f428a;
        this.f425g = C0223b.f430c;
        this.f426h = 0;
    }

    public C0221i(int capacity) {
        if (capacity == 0) {
            this.f424f = C0223b.f428a;
            this.f425g = C0223b.f430c;
        } else {
            m812e(capacity);
        }
        this.f426h = 0;
    }

    public void clear() {
        if (this.f426h != 0) {
            C0221i.m811a(this.f424f, this.f425g, this.f426h);
            this.f424f = C0223b.f428a;
            this.f425g = C0223b.f430c;
            this.f426h = 0;
        }
    }

    /* renamed from: a */
    public void m817a(int minimumCapacity) {
        if (this.f424f.length < minimumCapacity) {
            int[] ohashes = this.f424f;
            Object[] oarray = this.f425g;
            m812e(minimumCapacity);
            if (this.f426h > 0) {
                System.arraycopy(ohashes, 0, this.f424f, 0, this.f426h);
                System.arraycopy(oarray, 0, this.f425g, 0, this.f426h << 1);
            }
            C0221i.m811a(ohashes, oarray, this.f426h);
        }
    }

    public boolean containsKey(Object key) {
        return m814a(key) >= 0;
    }

    /* renamed from: a */
    public int m814a(Object key) {
        return key == null ? m813a() : m815a(key, key.hashCode());
    }

    /* renamed from: b */
    int m819b(Object value) {
        int N = this.f426h * 2;
        Object[] array = this.f425g;
        int i;
        if (value == null) {
            for (i = 1; i < N; i += 2) {
                if (array[i] == null) {
                    return i >> 1;
                }
            }
        } else {
            for (i = 1; i < N; i += 2) {
                if (value.equals(array[i])) {
                    return i >> 1;
                }
            }
        }
        return -1;
    }

    public boolean containsValue(Object value) {
        return m819b(value) >= 0;
    }

    public V get(Object key) {
        int index = m814a(key);
        return index >= 0 ? this.f425g[(index << 1) + 1] : null;
    }

    /* renamed from: b */
    public K m820b(int index) {
        return this.f425g[index << 1];
    }

    /* renamed from: c */
    public V m821c(int index) {
        return this.f425g[(index << 1) + 1];
    }

    /* renamed from: a */
    public V m816a(int index, V value) {
        index = (index << 1) + 1;
        V old = this.f425g[index];
        this.f425g[index] = value;
        return old;
    }

    public boolean isEmpty() {
        return this.f426h <= 0;
    }

    public V put(K key, V value) {
        int hash;
        int index;
        int n = 8;
        if (key == null) {
            hash = 0;
            index = m813a();
        } else {
            hash = key.hashCode();
            index = m815a((Object) key, hash);
        }
        if (index >= 0) {
            index = (index << 1) + 1;
            V old = this.f425g[index];
            this.f425g[index] = value;
            return old;
        }
        index ^= -1;
        if (this.f426h >= this.f424f.length) {
            if (this.f426h >= 8) {
                n = this.f426h + (this.f426h >> 1);
            } else if (this.f426h < 4) {
                n = 4;
            }
            int[] ohashes = this.f424f;
            Object[] oarray = this.f425g;
            m812e(n);
            if (this.f424f.length > 0) {
                System.arraycopy(ohashes, 0, this.f424f, 0, ohashes.length);
                System.arraycopy(oarray, 0, this.f425g, 0, oarray.length);
            }
            C0221i.m811a(ohashes, oarray, this.f426h);
        }
        if (index < this.f426h) {
            System.arraycopy(this.f424f, index, this.f424f, index + 1, this.f426h - index);
            System.arraycopy(this.f425g, index << 1, this.f425g, (index + 1) << 1, (this.f426h - index) << 1);
        }
        this.f424f[index] = hash;
        this.f425g[index << 1] = key;
        this.f425g[(index << 1) + 1] = value;
        this.f426h++;
        return null;
    }

    /* renamed from: a */
    public void m818a(C0221i<? extends K, ? extends V> array) {
        int N = array.f426h;
        m817a(this.f426h + N);
        if (this.f426h != 0) {
            for (int i = 0; i < N; i++) {
                put(array.m820b(i), array.m821c(i));
            }
        } else if (N > 0) {
            System.arraycopy(array.f424f, 0, this.f424f, 0, N);
            System.arraycopy(array.f425g, 0, this.f425g, 0, N << 1);
            this.f426h = N;
        }
    }

    public V remove(Object key) {
        int index = m814a(key);
        if (index >= 0) {
            return m822d(index);
        }
        return null;
    }

    /* renamed from: d */
    public V m822d(int index) {
        int n = 8;
        Object old = this.f425g[(index << 1) + 1];
        if (this.f426h <= 1) {
            C0221i.m811a(this.f424f, this.f425g, this.f426h);
            this.f424f = C0223b.f428a;
            this.f425g = C0223b.f430c;
            this.f426h = 0;
        } else if (this.f424f.length <= 8 || this.f426h >= this.f424f.length / 3) {
            this.f426h--;
            if (index < this.f426h) {
                System.arraycopy(this.f424f, index + 1, this.f424f, index, this.f426h - index);
                System.arraycopy(this.f425g, (index + 1) << 1, this.f425g, index << 1, (this.f426h - index) << 1);
            }
            this.f425g[this.f426h << 1] = null;
            this.f425g[(this.f426h << 1) + 1] = null;
        } else {
            if (this.f426h > 8) {
                n = this.f426h + (this.f426h >> 1);
            }
            int[] ohashes = this.f424f;
            Object[] oarray = this.f425g;
            m812e(n);
            this.f426h--;
            if (index > 0) {
                System.arraycopy(ohashes, 0, this.f424f, 0, index);
                System.arraycopy(oarray, 0, this.f425g, 0, index << 1);
            }
            if (index < this.f426h) {
                System.arraycopy(ohashes, index + 1, this.f424f, index, this.f426h - index);
                System.arraycopy(oarray, (index + 1) << 1, this.f425g, index << 1, (this.f426h - index) << 1);
            }
        }
        return old;
    }

    public int size() {
        return this.f426h;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof Map)) {
            return false;
        }
        Map<?, ?> map = (Map) object;
        if (size() != map.size()) {
            return false;
        }
        int i = 0;
        while (i < this.f426h) {
            try {
                K key = m820b(i);
                V mine = m821c(i);
                Object theirs = map.get(key);
                if (mine == null) {
                    if (theirs != null || !map.containsKey(key)) {
                        return false;
                    }
                } else if (!mine.equals(theirs)) {
                    return false;
                }
                i++;
            } catch (NullPointerException e) {
                return false;
            } catch (ClassCastException e2) {
                return false;
            }
        }
        return true;
    }

    public int hashCode() {
        int[] hashes = this.f424f;
        Object[] array = this.f425g;
        int result = 0;
        int i = 0;
        int v = 1;
        int s = this.f426h;
        while (i < s) {
            Object value = array[v];
            result += (value == null ? 0 : value.hashCode()) ^ hashes[i];
            i++;
            v += 2;
        }
        return result;
    }

    public String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder buffer = new StringBuilder(this.f426h * 28);
        buffer.append('{');
        for (int i = 0; i < this.f426h; i++) {
            if (i > 0) {
                buffer.append(", ");
            }
            C0221i key = m820b(i);
            if (key != this) {
                buffer.append(key);
            } else {
                buffer.append("(this Map)");
            }
            buffer.append('=');
            C0221i value = m821c(i);
            if (value != this) {
                buffer.append(value);
            } else {
                buffer.append("(this Map)");
            }
        }
        buffer.append('}');
        return buffer.toString();
    }
}

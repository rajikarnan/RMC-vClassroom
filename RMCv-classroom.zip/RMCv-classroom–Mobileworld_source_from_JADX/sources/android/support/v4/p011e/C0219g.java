package android.support.v4.p011e;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/* compiled from: MapCollections */
/* renamed from: android.support.v4.e.g */
abstract class C0219g<K, V> {
    /* renamed from: b */
    C0229b f416b;
    /* renamed from: c */
    C0230c f417c;
    /* renamed from: d */
    C0232e f418d;

    /* compiled from: MapCollections */
    /* renamed from: android.support.v4.e.g$a */
    final class C0228a<T> implements Iterator<T> {
        /* renamed from: a */
        final int f438a;
        /* renamed from: b */
        int f439b;
        /* renamed from: c */
        int f440c;
        /* renamed from: d */
        boolean f441d = false;
        /* renamed from: e */
        final /* synthetic */ C0219g f442e;

        C0228a(C0219g c0219g, int offset) {
            this.f442e = c0219g;
            this.f438a = offset;
            this.f439b = c0219g.mo143a();
        }

        public boolean hasNext() {
            return this.f440c < this.f439b;
        }

        public T next() {
            Object res = this.f442e.mo145a(this.f440c, this.f438a);
            this.f440c++;
            this.f441d = true;
            return res;
        }

        public void remove() {
            if (this.f441d) {
                this.f440c--;
                this.f439b--;
                this.f441d = false;
                this.f442e.mo147a(this.f440c);
                return;
            }
            throw new IllegalStateException();
        }
    }

    /* compiled from: MapCollections */
    /* renamed from: android.support.v4.e.g$b */
    final class C0229b implements Set<Entry<K, V>> {
        /* renamed from: a */
        final /* synthetic */ C0219g f443a;

        C0229b(C0219g c0219g) {
            this.f443a = c0219g;
        }

        public /* synthetic */ boolean add(Object obj) {
            return m842a((Entry) obj);
        }

        /* renamed from: a */
        public boolean m842a(Entry<K, V> entry) {
            throw new UnsupportedOperationException();
        }

        public boolean addAll(Collection<? extends Entry<K, V>> collection) {
            int oldSize = this.f443a.mo143a();
            for (Entry<K, V> entry : collection) {
                this.f443a.mo148a(entry.getKey(), entry.getValue());
            }
            return oldSize != this.f443a.mo143a();
        }

        public void clear() {
            this.f443a.mo151c();
        }

        public boolean contains(Object o) {
            if (!(o instanceof Entry)) {
                return false;
            }
            Entry<?, ?> e = (Entry) o;
            int index = this.f443a.mo144a(e.getKey());
            if (index >= 0) {
                return C0223b.m828a(this.f443a.mo145a(index, 1), e.getValue());
            }
            return false;
        }

        public boolean containsAll(Collection<?> collection) {
            for (Object contains : collection) {
                if (!contains(contains)) {
                    return false;
                }
            }
            return true;
        }

        public boolean isEmpty() {
            return this.f443a.mo143a() == 0;
        }

        public Iterator<Entry<K, V>> iterator() {
            return new C0231d(this.f443a);
        }

        public boolean remove(Object object) {
            throw new UnsupportedOperationException();
        }

        public boolean removeAll(Collection<?> collection) {
            throw new UnsupportedOperationException();
        }

        public boolean retainAll(Collection<?> collection) {
            throw new UnsupportedOperationException();
        }

        public int size() {
            return this.f443a.mo143a();
        }

        public Object[] toArray() {
            throw new UnsupportedOperationException();
        }

        public <T> T[] toArray(T[] tArr) {
            throw new UnsupportedOperationException();
        }

        public boolean equals(Object object) {
            return C0219g.m785a((Set) this, object);
        }

        public int hashCode() {
            int result = 0;
            for (int i = this.f443a.mo143a() - 1; i >= 0; i--) {
                Object key = this.f443a.mo145a(i, 0);
                Object value = this.f443a.mo145a(i, 1);
                result += (value == null ? 0 : value.hashCode()) ^ (key == null ? 0 : key.hashCode());
            }
            return result;
        }
    }

    /* compiled from: MapCollections */
    /* renamed from: android.support.v4.e.g$c */
    final class C0230c implements Set<K> {
        /* renamed from: a */
        final /* synthetic */ C0219g f444a;

        C0230c(C0219g c0219g) {
            this.f444a = c0219g;
        }

        public boolean add(K k) {
            throw new UnsupportedOperationException();
        }

        public boolean addAll(Collection<? extends K> collection) {
            throw new UnsupportedOperationException();
        }

        public void clear() {
            this.f444a.mo151c();
        }

        public boolean contains(Object object) {
            return this.f444a.mo144a(object) >= 0;
        }

        public boolean containsAll(Collection<?> collection) {
            return C0219g.m784a(this.f444a.mo150b(), (Collection) collection);
        }

        public boolean isEmpty() {
            return this.f444a.mo143a() == 0;
        }

        public Iterator<K> iterator() {
            return new C0228a(this.f444a, 0);
        }

        public boolean remove(Object object) {
            int index = this.f444a.mo144a(object);
            if (index < 0) {
                return false;
            }
            this.f444a.mo147a(index);
            return true;
        }

        public boolean removeAll(Collection<?> collection) {
            return C0219g.m786b(this.f444a.mo150b(), collection);
        }

        public boolean retainAll(Collection<?> collection) {
            return C0219g.m787c(this.f444a.mo150b(), collection);
        }

        public int size() {
            return this.f444a.mo143a();
        }

        public Object[] toArray() {
            return this.f444a.m797b(0);
        }

        public <T> T[] toArray(T[] array) {
            return this.f444a.m794a((Object[]) array, 0);
        }

        public boolean equals(Object object) {
            return C0219g.m785a((Set) this, object);
        }

        public int hashCode() {
            int result = 0;
            for (int i = this.f444a.mo143a() - 1; i >= 0; i--) {
                Object obj = this.f444a.mo145a(i, 0);
                result += obj == null ? 0 : obj.hashCode();
            }
            return result;
        }
    }

    /* compiled from: MapCollections */
    /* renamed from: android.support.v4.e.g$d */
    final class C0231d implements Iterator<Entry<K, V>>, Entry<K, V> {
        /* renamed from: a */
        int f445a;
        /* renamed from: b */
        int f446b;
        /* renamed from: c */
        boolean f447c = false;
        /* renamed from: d */
        final /* synthetic */ C0219g f448d;

        public /* synthetic */ Object next() {
            return m843a();
        }

        C0231d(C0219g c0219g) {
            this.f448d = c0219g;
            this.f445a = c0219g.mo143a() - 1;
            this.f446b = -1;
        }

        public boolean hasNext() {
            return this.f446b < this.f445a;
        }

        /* renamed from: a */
        public Entry<K, V> m843a() {
            this.f446b++;
            this.f447c = true;
            return this;
        }

        public void remove() {
            if (this.f447c) {
                this.f448d.mo147a(this.f446b);
                this.f446b--;
                this.f445a--;
                this.f447c = false;
                return;
            }
            throw new IllegalStateException();
        }

        public K getKey() {
            if (this.f447c) {
                return this.f448d.mo145a(this.f446b, 0);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public V getValue() {
            if (this.f447c) {
                return this.f448d.mo145a(this.f446b, 1);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public V setValue(V object) {
            if (this.f447c) {
                return this.f448d.mo146a(this.f446b, (Object) object);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public final boolean equals(Object o) {
            boolean z = true;
            if (!this.f447c) {
                throw new IllegalStateException("This container does not support retaining Map.Entry objects");
            } else if (!(o instanceof Entry)) {
                return false;
            } else {
                Entry<?, ?> e = (Entry) o;
                if (!(C0223b.m828a(e.getKey(), this.f448d.mo145a(this.f446b, 0)) && C0223b.m828a(e.getValue(), this.f448d.mo145a(this.f446b, 1)))) {
                    z = false;
                }
                return z;
            }
        }

        public final int hashCode() {
            int i = 0;
            if (this.f447c) {
                Object key = this.f448d.mo145a(this.f446b, 0);
                Object value = this.f448d.mo145a(this.f446b, 1);
                int hashCode = key == null ? 0 : key.hashCode();
                if (value != null) {
                    i = value.hashCode();
                }
                return i ^ hashCode;
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public final String toString() {
            return getKey() + "=" + getValue();
        }
    }

    /* compiled from: MapCollections */
    /* renamed from: android.support.v4.e.g$e */
    final class C0232e implements Collection<V> {
        /* renamed from: a */
        final /* synthetic */ C0219g f449a;

        C0232e(C0219g c0219g) {
            this.f449a = c0219g;
        }

        public boolean add(V v) {
            throw new UnsupportedOperationException();
        }

        public boolean addAll(Collection<? extends V> collection) {
            throw new UnsupportedOperationException();
        }

        public void clear() {
            this.f449a.mo151c();
        }

        public boolean contains(Object object) {
            return this.f449a.mo149b(object) >= 0;
        }

        public boolean containsAll(Collection<?> collection) {
            for (Object contains : collection) {
                if (!contains(contains)) {
                    return false;
                }
            }
            return true;
        }

        public boolean isEmpty() {
            return this.f449a.mo143a() == 0;
        }

        public Iterator<V> iterator() {
            return new C0228a(this.f449a, 1);
        }

        public boolean remove(Object object) {
            int index = this.f449a.mo149b(object);
            if (index < 0) {
                return false;
            }
            this.f449a.mo147a(index);
            return true;
        }

        public boolean removeAll(Collection<?> collection) {
            int N = this.f449a.mo143a();
            boolean changed = false;
            int i = 0;
            while (i < N) {
                if (collection.contains(this.f449a.mo145a(i, 1))) {
                    this.f449a.mo147a(i);
                    i--;
                    N--;
                    changed = true;
                }
                i++;
            }
            return changed;
        }

        public boolean retainAll(Collection<?> collection) {
            int N = this.f449a.mo143a();
            boolean changed = false;
            int i = 0;
            while (i < N) {
                if (!collection.contains(this.f449a.mo145a(i, 1))) {
                    this.f449a.mo147a(i);
                    i--;
                    N--;
                    changed = true;
                }
                i++;
            }
            return changed;
        }

        public int size() {
            return this.f449a.mo143a();
        }

        public Object[] toArray() {
            return this.f449a.m797b(1);
        }

        public <T> T[] toArray(T[] array) {
            return this.f449a.m794a((Object[]) array, 1);
        }
    }

    /* renamed from: a */
    protected abstract int mo143a();

    /* renamed from: a */
    protected abstract int mo144a(Object obj);

    /* renamed from: a */
    protected abstract Object mo145a(int i, int i2);

    /* renamed from: a */
    protected abstract V mo146a(int i, V v);

    /* renamed from: a */
    protected abstract void mo147a(int i);

    /* renamed from: a */
    protected abstract void mo148a(K k, V v);

    /* renamed from: b */
    protected abstract int mo149b(Object obj);

    /* renamed from: b */
    protected abstract Map<K, V> mo150b();

    /* renamed from: c */
    protected abstract void mo151c();

    C0219g() {
    }

    /* renamed from: a */
    public static <K, V> boolean m784a(Map<K, V> map, Collection<?> collection) {
        for (Object containsKey : collection) {
            if (!map.containsKey(containsKey)) {
                return false;
            }
        }
        return true;
    }

    /* renamed from: b */
    public static <K, V> boolean m786b(Map<K, V> map, Collection<?> collection) {
        int oldSize = map.size();
        for (Object remove : collection) {
            map.remove(remove);
        }
        return oldSize != map.size();
    }

    /* renamed from: c */
    public static <K, V> boolean m787c(Map<K, V> map, Collection<?> collection) {
        int oldSize = map.size();
        Iterator<K> it = map.keySet().iterator();
        while (it.hasNext()) {
            if (!collection.contains(it.next())) {
                it.remove();
            }
        }
        return oldSize != map.size();
    }

    /* renamed from: b */
    public Object[] m797b(int offset) {
        int N = mo143a();
        Object[] result = new Object[N];
        for (int i = 0; i < N; i++) {
            result[i] = mo145a(i, offset);
        }
        return result;
    }

    /* renamed from: a */
    public <T> T[] m794a(T[] array, int offset) {
        int N = mo143a();
        if (array.length < N) {
            array = (Object[]) ((Object[]) Array.newInstance(array.getClass().getComponentType(), N));
        }
        for (int i = 0; i < N; i++) {
            array[i] = mo145a(i, offset);
        }
        if (array.length > N) {
            array[N] = null;
        }
        return array;
    }

    /* renamed from: a */
    public static <T> boolean m785a(Set<T> set, Object object) {
        boolean z = true;
        if (set == object) {
            return true;
        }
        if (!(object instanceof Set)) {
            return false;
        }
        Set<?> s = (Set) object;
        try {
            if (!(set.size() == s.size() && set.containsAll(s))) {
                z = false;
            }
            return z;
        } catch (NullPointerException e) {
            return false;
        } catch (ClassCastException e2) {
            return false;
        }
    }

    /* renamed from: d */
    public Set<Entry<K, V>> m799d() {
        if (this.f416b == null) {
            this.f416b = new C0229b(this);
        }
        return this.f416b;
    }

    /* renamed from: e */
    public Set<K> m800e() {
        if (this.f417c == null) {
            this.f417c = new C0230c(this);
        }
        return this.f417c;
    }

    /* renamed from: f */
    public Collection<V> m801f() {
        if (this.f418d == null) {
            this.f418d = new C0232e(this);
        }
        return this.f418d;
    }
}

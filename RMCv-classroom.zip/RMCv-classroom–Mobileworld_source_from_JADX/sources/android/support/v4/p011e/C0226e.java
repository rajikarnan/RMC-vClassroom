package android.support.v4.p011e;

/* compiled from: LongSparseArray */
/* renamed from: android.support.v4.e.e */
public class C0226e<E> implements Cloneable {
    /* renamed from: a */
    private static final Object f433a = new Object();
    /* renamed from: b */
    private boolean f434b;
    /* renamed from: c */
    private long[] f435c;
    /* renamed from: d */
    private Object[] f436d;
    /* renamed from: e */
    private int f437e;

    public /* synthetic */ Object clone() throws CloneNotSupportedException {
        return m835a();
    }

    public C0226e() {
        this(10);
    }

    public C0226e(int initialCapacity) {
        this.f434b = false;
        if (initialCapacity == 0) {
            this.f435c = C0223b.f429b;
            this.f436d = C0223b.f430c;
        } else {
            initialCapacity = C0223b.m829b(initialCapacity);
            this.f435c = new long[initialCapacity];
            this.f436d = new Object[initialCapacity];
        }
        this.f437e = 0;
    }

    /* renamed from: a */
    public C0226e<E> m835a() {
        C0226e<E> clone = null;
        try {
            clone = (C0226e) super.clone();
            clone.f435c = (long[]) this.f435c.clone();
            clone.f436d = (Object[]) this.f436d.clone();
            return clone;
        } catch (CloneNotSupportedException e) {
            return clone;
        }
    }

    /* renamed from: a */
    public E m836a(long key) {
        return m837a(key, null);
    }

    /* renamed from: a */
    public E m837a(long key, E valueIfKeyNotFound) {
        int i = C0223b.m827a(this.f435c, this.f437e, key);
        return (i < 0 || this.f436d[i] == f433a) ? valueIfKeyNotFound : this.f436d[i];
    }

    /* renamed from: b */
    public void m840b(long key) {
        int i = C0223b.m827a(this.f435c, this.f437e, key);
        if (i >= 0 && this.f436d[i] != f433a) {
            this.f436d[i] = f433a;
            this.f434b = true;
        }
    }

    /* renamed from: c */
    private void m833c() {
        int n = this.f437e;
        int o = 0;
        long[] keys = this.f435c;
        Object[] values = this.f436d;
        for (int i = 0; i < n; i++) {
            Object val = values[i];
            if (val != f433a) {
                if (i != o) {
                    keys[o] = keys[i];
                    values[o] = val;
                    values[i] = null;
                }
                o++;
            }
        }
        this.f434b = false;
        this.f437e = o;
    }

    /* renamed from: b */
    public void m841b(long key, E value) {
        int i = C0223b.m827a(this.f435c, this.f437e, key);
        if (i >= 0) {
            this.f436d[i] = value;
            return;
        }
        i ^= -1;
        if (i >= this.f437e || this.f436d[i] != f433a) {
            if (this.f434b && this.f437e >= this.f435c.length) {
                m833c();
                i = C0223b.m827a(this.f435c, this.f437e, key) ^ -1;
            }
            if (this.f437e >= this.f435c.length) {
                int n = C0223b.m829b(this.f437e + 1);
                long[] nkeys = new long[n];
                Object[] nvalues = new Object[n];
                System.arraycopy(this.f435c, 0, nkeys, 0, this.f435c.length);
                System.arraycopy(this.f436d, 0, nvalues, 0, this.f436d.length);
                this.f435c = nkeys;
                this.f436d = nvalues;
            }
            if (this.f437e - i != 0) {
                System.arraycopy(this.f435c, i, this.f435c, i + 1, this.f437e - i);
                System.arraycopy(this.f436d, i, this.f436d, i + 1, this.f437e - i);
            }
            this.f435c[i] = key;
            this.f436d[i] = value;
            this.f437e++;
            return;
        }
        this.f435c[i] = key;
        this.f436d[i] = value;
    }

    /* renamed from: b */
    public int m838b() {
        if (this.f434b) {
            m833c();
        }
        return this.f437e;
    }

    /* renamed from: a */
    public long m834a(int index) {
        if (this.f434b) {
            m833c();
        }
        return this.f435c[index];
    }

    /* renamed from: b */
    public E m839b(int index) {
        if (this.f434b) {
            m833c();
        }
        return this.f436d[index];
    }

    public String toString() {
        if (m838b() <= 0) {
            return "{}";
        }
        StringBuilder buffer = new StringBuilder(this.f437e * 28);
        buffer.append('{');
        for (int i = 0; i < this.f437e; i++) {
            if (i > 0) {
                buffer.append(", ");
            }
            buffer.append(m834a(i));
            buffer.append('=');
            C0226e value = m839b(i);
            if (value != this) {
                buffer.append(value);
            } else {
                buffer.append("(this Map)");
            }
        }
        buffer.append('}');
        return buffer.toString();
    }
}

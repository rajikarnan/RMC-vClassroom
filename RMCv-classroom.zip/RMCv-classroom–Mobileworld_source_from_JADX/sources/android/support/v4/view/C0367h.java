package android.support.v4.view;

import android.view.KeyEvent;

/* compiled from: KeyEventCompatEclair */
/* renamed from: android.support.v4.view.h */
class C0367h {
    /* renamed from: a */
    public static void m1737a(KeyEvent event) {
        event.startTracking();
    }
}

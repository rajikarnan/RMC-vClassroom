package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.ViewConfiguration;

/* compiled from: ViewConfigurationCompat */
public final class au {
    /* renamed from: a */
    static final C0319e f583a;

    /* compiled from: ViewConfigurationCompat */
    /* renamed from: android.support.v4.view.au$e */
    interface C0319e {
        /* renamed from: a */
        int mo295a(ViewConfiguration viewConfiguration);

        /* renamed from: b */
        boolean mo296b(ViewConfiguration viewConfiguration);
    }

    /* compiled from: ViewConfigurationCompat */
    /* renamed from: android.support.v4.view.au$a */
    static class C0320a implements C0319e {
        C0320a() {
        }

        /* renamed from: a */
        public int mo295a(ViewConfiguration config) {
            return config.getScaledTouchSlop();
        }

        /* renamed from: b */
        public boolean mo296b(ViewConfiguration config) {
            return true;
        }
    }

    /* compiled from: ViewConfigurationCompat */
    /* renamed from: android.support.v4.view.au$b */
    static class C0321b extends C0320a {
        C0321b() {
        }

        /* renamed from: a */
        public int mo295a(ViewConfiguration config) {
            return av.m1588a(config);
        }
    }

    /* compiled from: ViewConfigurationCompat */
    /* renamed from: android.support.v4.view.au$c */
    static class C0322c extends C0321b {
        C0322c() {
        }

        /* renamed from: b */
        public boolean mo296b(ViewConfiguration config) {
            return false;
        }
    }

    /* compiled from: ViewConfigurationCompat */
    /* renamed from: android.support.v4.view.au$d */
    static class C0323d extends C0322c {
        C0323d() {
        }

        /* renamed from: b */
        public boolean mo296b(ViewConfiguration config) {
            return aw.m1589a(config);
        }
    }

    static {
        if (VERSION.SDK_INT >= 14) {
            f583a = new C0323d();
        } else if (VERSION.SDK_INT >= 11) {
            f583a = new C0322c();
        } else if (VERSION.SDK_INT >= 8) {
            f583a = new C0321b();
        } else {
            f583a = new C0320a();
        }
    }

    /* renamed from: a */
    public static int m1586a(ViewConfiguration config) {
        return f583a.mo295a(config);
    }

    /* renamed from: b */
    public static boolean m1587b(ViewConfiguration config) {
        return f583a.mo296b(config);
    }
}

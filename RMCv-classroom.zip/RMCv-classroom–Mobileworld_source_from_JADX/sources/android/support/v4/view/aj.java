package android.support.v4.view;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.view.View;
import android.view.ViewParent;
import java.lang.reflect.Field;

/* compiled from: ViewCompatBase */
class aj {
    /* renamed from: a */
    private static Field f578a;
    /* renamed from: b */
    private static boolean f579b;

    /* renamed from: a */
    static ColorStateList m1514a(View view) {
        return view instanceof af ? ((af) view).getSupportBackgroundTintList() : null;
    }

    /* renamed from: a */
    static void m1516a(View view, ColorStateList tintList) {
        if (view instanceof af) {
            ((af) view).setSupportBackgroundTintList(tintList);
        }
    }

    /* renamed from: b */
    static Mode m1518b(View view) {
        return view instanceof af ? ((af) view).getSupportBackgroundTintMode() : null;
    }

    /* renamed from: a */
    static void m1517a(View view, Mode mode) {
        if (view instanceof af) {
            ((af) view).setSupportBackgroundTintMode(mode);
        }
    }

    /* renamed from: c */
    static boolean m1520c(View view) {
        return view.getWidth() > 0 && view.getHeight() > 0;
    }

    /* renamed from: d */
    static int m1521d(View view) {
        if (!f579b) {
            try {
                f578a = View.class.getDeclaredField("mMinHeight");
                f578a.setAccessible(true);
            } catch (NoSuchFieldException e) {
            }
            f579b = true;
        }
        if (f578a != null) {
            try {
                return ((Integer) f578a.get(view)).intValue();
            } catch (Exception e2) {
            }
        }
        return 0;
    }

    /* renamed from: e */
    static boolean m1522e(View view) {
        return view.getWindowToken() != null;
    }

    /* renamed from: a */
    static void m1515a(View view, int offset) {
        int currentTop = view.getTop();
        view.offsetTopAndBottom(offset);
        if (offset != 0) {
            ViewParent parent = view.getParent();
            if (parent instanceof View) {
                int absOffset = Math.abs(offset);
                ((View) parent).invalidate(view.getLeft(), currentTop - absOffset, view.getRight(), (view.getHeight() + currentTop) + absOffset);
                return;
            }
            view.invalidate();
        }
    }

    /* renamed from: b */
    static void m1519b(View view, int offset) {
        int currentLeft = view.getLeft();
        view.offsetLeftAndRight(offset);
        if (offset != 0) {
            ViewParent parent = view.getParent();
            if (parent instanceof View) {
                int absOffset = Math.abs(offset);
                ((View) parent).invalidate(currentLeft - absOffset, view.getTop(), (view.getWidth() + currentLeft) + absOffset, view.getBottom());
                return;
            }
            view.invalidate();
        }
    }
}

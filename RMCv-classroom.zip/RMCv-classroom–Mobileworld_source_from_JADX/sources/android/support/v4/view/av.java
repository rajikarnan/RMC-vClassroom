package android.support.v4.view;

import android.view.ViewConfiguration;

/* compiled from: ViewConfigurationCompatFroyo */
class av {
    /* renamed from: a */
    public static int m1588a(ViewConfiguration config) {
        return config.getScaledPagingTouchSlop();
    }
}

package android.support.v4.view;

import android.os.Build.VERSION;
import android.support.v4.app.ag;
import android.view.KeyEvent;

/* compiled from: KeyEventCompat */
/* renamed from: android.support.v4.view.g */
public final class C0366g {
    /* renamed from: a */
    static final C0362d f611a;

    /* compiled from: KeyEventCompat */
    /* renamed from: android.support.v4.view.g$d */
    interface C0362d {
        /* renamed from: a */
        void mo326a(KeyEvent keyEvent);

        /* renamed from: a */
        boolean mo327a(int i, int i2);

        /* renamed from: b */
        boolean mo328b(int i);
    }

    /* compiled from: KeyEventCompat */
    /* renamed from: android.support.v4.view.g$a */
    static class C0363a implements C0362d {
        C0363a() {
        }

        /* renamed from: a */
        private static int m1725a(int metaState, int modifiers, int basic, int left, int right) {
            boolean wantBasic;
            boolean wantLeftOrRight = true;
            if ((modifiers & basic) != 0) {
                wantBasic = true;
            } else {
                wantBasic = false;
            }
            int directional = left | right;
            if ((modifiers & directional) == 0) {
                wantLeftOrRight = false;
            }
            if (wantBasic) {
                if (!wantLeftOrRight) {
                    return metaState & (directional ^ -1);
                }
                throw new IllegalArgumentException("bad arguments");
            } else if (wantLeftOrRight) {
                return metaState & (basic ^ -1);
            } else {
                return metaState;
            }
        }

        /* renamed from: a */
        public int mo329a(int metaState) {
            if ((metaState & 192) != 0) {
                metaState |= 1;
            }
            if ((metaState & 48) != 0) {
                metaState |= 2;
            }
            return metaState & 247;
        }

        /* renamed from: a */
        public boolean mo327a(int metaState, int modifiers) {
            if (C0363a.m1725a(C0363a.m1725a(mo329a(metaState) & 247, modifiers, 1, 64, ag.FLAG_HIGH_PRIORITY), modifiers, 2, 16, 32) == modifiers) {
                return true;
            }
            return false;
        }

        /* renamed from: b */
        public boolean mo328b(int metaState) {
            return (mo329a(metaState) & 247) == 0;
        }

        /* renamed from: a */
        public void mo326a(KeyEvent event) {
        }
    }

    /* compiled from: KeyEventCompat */
    /* renamed from: android.support.v4.view.g$b */
    static class C0364b extends C0363a {
        C0364b() {
        }

        /* renamed from: a */
        public void mo326a(KeyEvent event) {
            C0367h.m1737a(event);
        }
    }

    /* compiled from: KeyEventCompat */
    /* renamed from: android.support.v4.view.g$c */
    static class C0365c extends C0364b {
        C0365c() {
        }

        /* renamed from: a */
        public int mo329a(int metaState) {
            return C0368i.m1738a(metaState);
        }

        /* renamed from: a */
        public boolean mo327a(int metaState, int modifiers) {
            return C0368i.m1739a(metaState, modifiers);
        }

        /* renamed from: b */
        public boolean mo328b(int metaState) {
            return C0368i.m1740b(metaState);
        }
    }

    static {
        if (VERSION.SDK_INT >= 11) {
            f611a = new C0365c();
        } else {
            f611a = new C0363a();
        }
    }

    /* renamed from: a */
    public static boolean m1735a(KeyEvent event, int modifiers) {
        return f611a.mo327a(event.getMetaState(), modifiers);
    }

    /* renamed from: a */
    public static boolean m1734a(KeyEvent event) {
        return f611a.mo328b(event.getMetaState());
    }

    /* renamed from: b */
    public static void m1736b(KeyEvent event) {
        f611a.mo326a(event);
    }
}

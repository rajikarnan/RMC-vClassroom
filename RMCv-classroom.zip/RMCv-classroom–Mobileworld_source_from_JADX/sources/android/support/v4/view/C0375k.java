package android.support.v4.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.LayoutInflater.Factory;
import android.view.View;

/* compiled from: LayoutInflaterCompatBase */
/* renamed from: android.support.v4.view.k */
class C0375k {

    /* compiled from: LayoutInflaterCompatBase */
    /* renamed from: android.support.v4.view.k$a */
    static class C0374a implements Factory {
        /* renamed from: a */
        final C0165n f613a;

        C0374a(C0165n delegateFactory) {
            this.f613a = delegateFactory;
        }

        public View onCreateView(String name, Context context, AttributeSet attrs) {
            return this.f613a.onCreateView(null, name, context, attrs);
        }

        public String toString() {
            return getClass().getName() + "{" + this.f613a + "}";
        }
    }

    /* renamed from: a */
    static void m1750a(LayoutInflater inflater, C0165n factory) {
        inflater.setFactory(factory != null ? new C0374a(factory) : null);
    }

    /* renamed from: a */
    static C0165n m1749a(LayoutInflater inflater) {
        Factory factory = inflater.getFactory();
        if (factory instanceof C0374a) {
            return ((C0374a) factory).f613a;
        }
        return null;
    }
}

package android.support.v4.view;

import android.view.View;

/* compiled from: ViewCompatICSMr1 */
class ao {
    /* renamed from: a */
    public static boolean m1546a(View v) {
        return v.hasOnClickListeners();
    }
}

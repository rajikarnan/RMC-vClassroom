package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.LayoutInflater;

/* compiled from: LayoutInflaterCompat */
/* renamed from: android.support.v4.view.j */
public final class C0373j {
    /* renamed from: a */
    static final C0369a f612a;

    /* compiled from: LayoutInflaterCompat */
    /* renamed from: android.support.v4.view.j$a */
    interface C0369a {
        /* renamed from: a */
        C0165n mo330a(LayoutInflater layoutInflater);

        /* renamed from: a */
        void mo331a(LayoutInflater layoutInflater, C0165n c0165n);
    }

    /* compiled from: LayoutInflaterCompat */
    /* renamed from: android.support.v4.view.j$b */
    static class C0370b implements C0369a {
        C0370b() {
        }

        /* renamed from: a */
        public void mo331a(LayoutInflater layoutInflater, C0165n factory) {
            C0375k.m1750a(layoutInflater, factory);
        }

        /* renamed from: a */
        public C0165n mo330a(LayoutInflater layoutInflater) {
            return C0375k.m1749a(layoutInflater);
        }
    }

    /* compiled from: LayoutInflaterCompat */
    /* renamed from: android.support.v4.view.j$c */
    static class C0371c extends C0370b {
        C0371c() {
        }

        /* renamed from: a */
        public void mo331a(LayoutInflater layoutInflater, C0165n factory) {
            C0377l.m1751a(layoutInflater, factory);
        }
    }

    /* compiled from: LayoutInflaterCompat */
    /* renamed from: android.support.v4.view.j$d */
    static class C0372d extends C0371c {
        C0372d() {
        }

        /* renamed from: a */
        public void mo331a(LayoutInflater layoutInflater, C0165n factory) {
            C0378m.m1753a(layoutInflater, factory);
        }
    }

    static {
        int version = VERSION.SDK_INT;
        if (version >= 21) {
            f612a = new C0372d();
        } else if (version >= 11) {
            f612a = new C0371c();
        } else {
            f612a = new C0370b();
        }
    }

    /* renamed from: a */
    public static void m1748a(LayoutInflater inflater, C0165n factory) {
        f612a.mo331a(inflater, factory);
    }

    /* renamed from: a */
    public static C0165n m1747a(LayoutInflater inflater) {
        return f612a.mo330a(inflater);
    }
}

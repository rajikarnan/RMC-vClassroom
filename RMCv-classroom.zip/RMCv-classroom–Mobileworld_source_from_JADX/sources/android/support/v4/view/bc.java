package android.support.v4.view;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.animation.Interpolator;

/* compiled from: ViewPropertyAnimatorCompatICS */
class bc {
    /* renamed from: a */
    public static void m1692a(View view, long value) {
        view.animate().setDuration(value);
    }

    /* renamed from: a */
    public static void m1691a(View view, float value) {
        view.animate().alpha(value);
    }

    /* renamed from: b */
    public static void m1696b(View view, float value) {
        view.animate().translationY(value);
    }

    /* renamed from: a */
    public static long m1690a(View view) {
        return view.animate().getDuration();
    }

    /* renamed from: a */
    public static void m1694a(View view, Interpolator value) {
        view.animate().setInterpolator(value);
    }

    /* renamed from: b */
    public static void m1697b(View view, long value) {
        view.animate().setStartDelay(value);
    }

    /* renamed from: b */
    public static void m1695b(View view) {
        view.animate().cancel();
    }

    /* renamed from: c */
    public static void m1698c(View view) {
        view.animate().start();
    }

    /* renamed from: a */
    public static void m1693a(final View view, final bf listener) {
        if (listener != null) {
            view.animate().setListener(new AnimatorListenerAdapter() {
                public void onAnimationCancel(Animator animation) {
                    listener.onAnimationCancel(view);
                }

                public void onAnimationEnd(Animator animation) {
                    listener.onAnimationEnd(view);
                }

                public void onAnimationStart(Animator animation) {
                    listener.onAnimationStart(view);
                }
            });
        } else {
            view.animate().setListener(null);
        }
    }
}

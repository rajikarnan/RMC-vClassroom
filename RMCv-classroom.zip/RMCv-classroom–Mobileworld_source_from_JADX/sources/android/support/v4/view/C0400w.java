package android.support.v4.view;

import android.view.MotionEvent;

/* compiled from: MotionEventCompatGingerbread */
/* renamed from: android.support.v4.view.w */
class C0400w {
    /* renamed from: a */
    public static int m1832a(MotionEvent event) {
        return event.getSource();
    }
}

package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.MotionEvent;

/* compiled from: MotionEventCompat */
/* renamed from: android.support.v4.view.u */
public final class C0398u {
    /* renamed from: a */
    static final C0393e f618a;

    /* compiled from: MotionEventCompat */
    /* renamed from: android.support.v4.view.u$e */
    interface C0393e {
        /* renamed from: a */
        int mo340a(MotionEvent motionEvent);

        /* renamed from: a */
        int mo341a(MotionEvent motionEvent, int i);

        /* renamed from: b */
        int mo342b(MotionEvent motionEvent);

        /* renamed from: b */
        int mo343b(MotionEvent motionEvent, int i);

        /* renamed from: c */
        float mo344c(MotionEvent motionEvent, int i);

        /* renamed from: d */
        float mo345d(MotionEvent motionEvent, int i);

        /* renamed from: e */
        float mo346e(MotionEvent motionEvent, int i);
    }

    /* compiled from: MotionEventCompat */
    /* renamed from: android.support.v4.view.u$a */
    static class C0394a implements C0393e {
        C0394a() {
        }

        /* renamed from: a */
        public int mo341a(MotionEvent event, int pointerId) {
            if (pointerId == 0) {
                return 0;
            }
            return -1;
        }

        /* renamed from: b */
        public int mo343b(MotionEvent event, int pointerIndex) {
            if (pointerIndex == 0) {
                return 0;
            }
            throw new IndexOutOfBoundsException("Pre-Eclair does not support multiple pointers");
        }

        /* renamed from: c */
        public float mo344c(MotionEvent event, int pointerIndex) {
            if (pointerIndex == 0) {
                return event.getX();
            }
            throw new IndexOutOfBoundsException("Pre-Eclair does not support multiple pointers");
        }

        /* renamed from: d */
        public float mo345d(MotionEvent event, int pointerIndex) {
            if (pointerIndex == 0) {
                return event.getY();
            }
            throw new IndexOutOfBoundsException("Pre-Eclair does not support multiple pointers");
        }

        /* renamed from: a */
        public int mo340a(MotionEvent event) {
            return 1;
        }

        /* renamed from: b */
        public int mo342b(MotionEvent event) {
            return 0;
        }

        /* renamed from: e */
        public float mo346e(MotionEvent event, int axis) {
            return 0.0f;
        }
    }

    /* compiled from: MotionEventCompat */
    /* renamed from: android.support.v4.view.u$b */
    static class C0395b extends C0394a {
        C0395b() {
        }

        /* renamed from: a */
        public int mo341a(MotionEvent event, int pointerId) {
            return C0399v.m1828a(event, pointerId);
        }

        /* renamed from: b */
        public int mo343b(MotionEvent event, int pointerIndex) {
            return C0399v.m1829b(event, pointerIndex);
        }

        /* renamed from: c */
        public float mo344c(MotionEvent event, int pointerIndex) {
            return C0399v.m1830c(event, pointerIndex);
        }

        /* renamed from: d */
        public float mo345d(MotionEvent event, int pointerIndex) {
            return C0399v.m1831d(event, pointerIndex);
        }

        /* renamed from: a */
        public int mo340a(MotionEvent event) {
            return C0399v.m1827a(event);
        }
    }

    /* compiled from: MotionEventCompat */
    /* renamed from: android.support.v4.view.u$c */
    static class C0396c extends C0395b {
        C0396c() {
        }

        /* renamed from: b */
        public int mo342b(MotionEvent event) {
            return C0400w.m1832a(event);
        }
    }

    /* compiled from: MotionEventCompat */
    /* renamed from: android.support.v4.view.u$d */
    static class C0397d extends C0396c {
        C0397d() {
        }

        /* renamed from: e */
        public float mo346e(MotionEvent event, int axis) {
            return C0401x.m1833a(event, axis);
        }
    }

    static {
        if (VERSION.SDK_INT >= 12) {
            f618a = new C0397d();
        } else if (VERSION.SDK_INT >= 9) {
            f618a = new C0396c();
        } else if (VERSION.SDK_INT >= 5) {
            f618a = new C0395b();
        } else {
            f618a = new C0394a();
        }
    }

    /* renamed from: a */
    public static int m1818a(MotionEvent event) {
        return event.getAction() & 255;
    }

    /* renamed from: b */
    public static int m1820b(MotionEvent event) {
        return (event.getAction() & 65280) >> 8;
    }

    /* renamed from: a */
    public static int m1819a(MotionEvent event, int pointerId) {
        return f618a.mo341a(event, pointerId);
    }

    /* renamed from: b */
    public static int m1821b(MotionEvent event, int pointerIndex) {
        return f618a.mo343b(event, pointerIndex);
    }

    /* renamed from: c */
    public static float m1822c(MotionEvent event, int pointerIndex) {
        return f618a.mo344c(event, pointerIndex);
    }

    /* renamed from: d */
    public static float m1824d(MotionEvent event, int pointerIndex) {
        return f618a.mo345d(event, pointerIndex);
    }

    /* renamed from: c */
    public static int m1823c(MotionEvent event) {
        return f618a.mo340a(event);
    }

    /* renamed from: d */
    public static int m1825d(MotionEvent event) {
        return f618a.mo342b(event);
    }

    /* renamed from: e */
    public static float m1826e(MotionEvent event, int axis) {
        return f618a.mo346e(event, axis);
    }
}

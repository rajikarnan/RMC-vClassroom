package android.support.v4.view;

import android.support.v4.view.C0377l.C0376a;
import android.view.LayoutInflater;

/* compiled from: LayoutInflaterCompatLollipop */
/* renamed from: android.support.v4.view.m */
class C0378m {
    /* renamed from: a */
    static void m1753a(LayoutInflater inflater, C0165n factory) {
        inflater.setFactory2(factory != null ? new C0376a(factory) : null);
    }
}

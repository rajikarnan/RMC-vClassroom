package android.support.v4.view;

import android.view.View;
import android.view.ViewGroup;

/* compiled from: NestedScrollingParentHelper */
public class ab {
    /* renamed from: a */
    private final ViewGroup f570a;
    /* renamed from: b */
    private int f571b;

    public ab(ViewGroup viewGroup) {
        this.f570a = viewGroup;
    }

    /* renamed from: a */
    public void m1276a(View child, View target, int axes) {
        this.f571b = axes;
    }

    /* renamed from: a */
    public int m1274a() {
        return this.f571b;
    }

    /* renamed from: a */
    public void m1275a(View target) {
        this.f571b = 0;
    }
}

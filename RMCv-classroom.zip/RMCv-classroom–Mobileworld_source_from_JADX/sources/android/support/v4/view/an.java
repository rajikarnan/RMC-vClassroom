package android.support.v4.view;

import android.view.View;
import android.view.View.AccessibilityDelegate;

/* compiled from: ViewCompatICS */
class an {
    /* renamed from: a */
    public static boolean m1544a(View v, int direction) {
        return v.canScrollHorizontally(direction);
    }

    /* renamed from: b */
    public static boolean m1545b(View v, int direction) {
        return v.canScrollVertically(direction);
    }

    /* renamed from: a */
    public static void m1543a(View v, Object delegate) {
        v.setAccessibilityDelegate((AccessibilityDelegate) delegate);
    }
}

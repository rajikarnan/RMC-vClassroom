package android.support.v4.view;

import android.content.Context;
import android.support.v4.view.C0375k.C0374a;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.LayoutInflater.Factory;
import android.view.LayoutInflater.Factory2;
import android.view.View;
import java.lang.reflect.Field;

/* compiled from: LayoutInflaterCompatHC */
/* renamed from: android.support.v4.view.l */
class C0377l {
    /* renamed from: a */
    private static Field f614a;
    /* renamed from: b */
    private static boolean f615b;

    /* compiled from: LayoutInflaterCompatHC */
    /* renamed from: android.support.v4.view.l$a */
    static class C0376a extends C0374a implements Factory2 {
        C0376a(C0165n delegateFactory) {
            super(delegateFactory);
        }

        public View onCreateView(View parent, String name, Context context, AttributeSet attributeSet) {
            return this.a.onCreateView(parent, name, context, attributeSet);
        }
    }

    /* renamed from: a */
    static void m1751a(LayoutInflater inflater, C0165n factory) {
        Factory2 factory2 = factory != null ? new C0376a(factory) : null;
        inflater.setFactory2(factory2);
        Factory f = inflater.getFactory();
        if (f instanceof Factory2) {
            C0377l.m1752a(inflater, (Factory2) f);
        } else {
            C0377l.m1752a(inflater, factory2);
        }
    }

    /* renamed from: a */
    static void m1752a(LayoutInflater inflater, Factory2 factory) {
        if (!f615b) {
            try {
                f614a = LayoutInflater.class.getDeclaredField("mFactory2");
                f614a.setAccessible(true);
            } catch (NoSuchFieldException e) {
                Log.e("LayoutInflaterCompatHC", "forceSetFactory2 Could not find field 'mFactory2' on class " + LayoutInflater.class.getName() + "; inflation may have unexpected results.", e);
            }
            f615b = true;
        }
        if (f614a != null) {
            try {
                f614a.set(inflater, factory);
            } catch (IllegalAccessException e2) {
                Log.e("LayoutInflaterCompatHC", "forceSetFactory2 could not set the Factory2 on LayoutInflater " + inflater + "; inflation may have unexpected results.", e2);
            }
        }
    }
}

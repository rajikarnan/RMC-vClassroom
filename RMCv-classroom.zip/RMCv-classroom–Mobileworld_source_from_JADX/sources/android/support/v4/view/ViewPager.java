package android.support.v4.view;

import android.content.Context;
import android.content.res.Resources.NotFoundException;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.p008c.C0183c;
import android.support.v4.p008c.C0184d;
import android.support.v4.view.p012a.C0265a;
import android.support.v4.view.p012a.C0276b;
import android.support.v4.view.p012a.C0299j;
import android.support.v4.widget.C0456k;
import android.util.AttributeSet;
import android.util.Log;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SoundEffectConstants;
import android.view.VelocityTracker;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.MeasureSpec;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import android.widget.Scroller;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ViewPager extends ViewGroup {
    /* renamed from: a */
    private static final int[] f481a = new int[]{16842931};
    private static final C0252i ai = new C0252i();
    /* renamed from: c */
    private static final Comparator<C0244b> f482c = new C02381();
    /* renamed from: d */
    private static final Interpolator f483d = new C02392();
    /* renamed from: A */
    private int f484A = 1;
    /* renamed from: B */
    private boolean f485B;
    /* renamed from: C */
    private boolean f486C;
    /* renamed from: D */
    private int f487D;
    /* renamed from: E */
    private int f488E;
    /* renamed from: F */
    private int f489F;
    /* renamed from: G */
    private float f490G;
    /* renamed from: H */
    private float f491H;
    /* renamed from: I */
    private float f492I;
    /* renamed from: J */
    private float f493J;
    /* renamed from: K */
    private int f494K = -1;
    /* renamed from: L */
    private VelocityTracker f495L;
    /* renamed from: M */
    private int f496M;
    /* renamed from: N */
    private int f497N;
    /* renamed from: O */
    private int f498O;
    /* renamed from: P */
    private int f499P;
    /* renamed from: Q */
    private boolean f500Q;
    /* renamed from: R */
    private C0456k f501R;
    /* renamed from: S */
    private C0456k f502S;
    /* renamed from: T */
    private boolean f503T = true;
    /* renamed from: U */
    private boolean f504U = false;
    /* renamed from: V */
    private boolean f505V;
    /* renamed from: W */
    private int f506W;
    private List<C0249f> aa;
    private C0249f ab;
    private C0249f ac;
    private C0248e ad;
    private C0250g ae;
    private Method af;
    private int ag;
    private ArrayList<View> ah;
    private final Runnable aj = new C02403(this);
    private int ak = 0;
    /* renamed from: b */
    private int f507b;
    /* renamed from: e */
    private final ArrayList<C0244b> f508e = new ArrayList();
    /* renamed from: f */
    private final C0244b f509f = new C0244b();
    /* renamed from: g */
    private final Rect f510g = new Rect();
    /* renamed from: h */
    private ad f511h;
    /* renamed from: i */
    private int f512i;
    /* renamed from: j */
    private int f513j = -1;
    /* renamed from: k */
    private Parcelable f514k = null;
    /* renamed from: l */
    private ClassLoader f515l = null;
    /* renamed from: m */
    private Scroller f516m;
    /* renamed from: n */
    private boolean f517n;
    /* renamed from: o */
    private C0251h f518o;
    /* renamed from: p */
    private int f519p;
    /* renamed from: q */
    private Drawable f520q;
    /* renamed from: r */
    private int f521r;
    /* renamed from: s */
    private int f522s;
    /* renamed from: t */
    private float f523t = -3.4028235E38f;
    /* renamed from: u */
    private float f524u = Float.MAX_VALUE;
    /* renamed from: v */
    private int f525v;
    /* renamed from: w */
    private int f526w;
    /* renamed from: x */
    private boolean f527x;
    /* renamed from: y */
    private boolean f528y;
    /* renamed from: z */
    private boolean f529z;

    /* renamed from: android.support.v4.view.ViewPager$1 */
    static class C02381 implements Comparator<C0244b> {
        C02381() {
        }

        public /* synthetic */ int compare(Object obj, Object obj2) {
            return m862a((C0244b) obj, (C0244b) obj2);
        }

        /* renamed from: a */
        public int m862a(C0244b lhs, C0244b rhs) {
            return lhs.f466b - rhs.f466b;
        }
    }

    /* renamed from: android.support.v4.view.ViewPager$2 */
    static class C02392 implements Interpolator {
        C02392() {
        }

        public float getInterpolation(float t) {
            t -= 1.0f;
            return ((((t * t) * t) * t) * t) + 1.0f;
        }
    }

    /* renamed from: android.support.v4.view.ViewPager$3 */
    class C02403 implements Runnable {
        /* renamed from: a */
        final /* synthetic */ ViewPager f459a;

        C02403(ViewPager viewPager) {
            this.f459a = viewPager;
        }

        public void run() {
            this.f459a.setScrollState(0);
            this.f459a.m924c();
        }
    }

    /* renamed from: android.support.v4.view.ViewPager$4 */
    class C02414 implements ac {
        /* renamed from: a */
        final /* synthetic */ ViewPager f460a;
        /* renamed from: b */
        private final Rect f461b = new Rect();

        C02414(ViewPager viewPager) {
            this.f460a = viewPager;
        }

        public bi onApplyWindowInsets(View v, bi originalInsets) {
            bi applied = ai.m1467a(v, originalInsets);
            if (applied.mo324e()) {
                return applied;
            }
            Rect res = this.f461b;
            res.left = applied.mo319a();
            res.top = applied.mo321b();
            res.right = applied.mo322c();
            res.bottom = applied.mo323d();
            int count = this.f460a.getChildCount();
            for (int i = 0; i < count; i++) {
                bi childInsets = ai.m1480b(this.f460a.getChildAt(i), applied);
                res.left = Math.min(childInsets.mo319a(), res.left);
                res.top = Math.min(childInsets.mo321b(), res.top);
                res.right = Math.min(childInsets.mo322c(), res.right);
                res.bottom = Math.min(childInsets.mo323d(), res.bottom);
            }
            return applied.mo320a(res.left, res.top, res.right, res.bottom);
        }
    }

    public static class SavedState extends BaseSavedState {
        public static final Creator<SavedState> CREATOR = C0183c.m722a(new C02421());
        /* renamed from: a */
        int f462a;
        /* renamed from: b */
        Parcelable f463b;
        /* renamed from: c */
        ClassLoader f464c;

        /* renamed from: android.support.v4.view.ViewPager$SavedState$1 */
        static class C02421 implements C0184d<SavedState> {
            C02421() {
            }

            public /* synthetic */ Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return m863a(parcel, classLoader);
            }

            public /* synthetic */ Object[] newArray(int i) {
                return m864a(i);
            }

            /* renamed from: a */
            public SavedState m863a(Parcel in, ClassLoader loader) {
                return new SavedState(in, loader);
            }

            /* renamed from: a */
            public SavedState[] m864a(int size) {
                return new SavedState[size];
            }
        }

        public SavedState(Parcelable superState) {
            super(superState);
        }

        public void writeToParcel(Parcel out, int flags) {
            super.writeToParcel(out, flags);
            out.writeInt(this.f462a);
            out.writeParcelable(this.f463b, flags);
        }

        public String toString() {
            return "FragmentPager.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " position=" + this.f462a + "}";
        }

        SavedState(Parcel in, ClassLoader loader) {
            super(in);
            if (loader == null) {
                loader = getClass().getClassLoader();
            }
            this.f462a = in.readInt();
            this.f463b = in.readParcelable(loader);
            this.f464c = loader;
        }
    }

    /* renamed from: android.support.v4.view.ViewPager$a */
    interface C0243a {
    }

    /* renamed from: android.support.v4.view.ViewPager$b */
    static class C0244b {
        /* renamed from: a */
        Object f465a;
        /* renamed from: b */
        int f466b;
        /* renamed from: c */
        boolean f467c;
        /* renamed from: d */
        float f468d;
        /* renamed from: e */
        float f469e;

        C0244b() {
        }
    }

    /* renamed from: android.support.v4.view.ViewPager$c */
    public static class C0245c extends LayoutParams {
        /* renamed from: a */
        public boolean f470a;
        /* renamed from: b */
        public int f471b;
        /* renamed from: c */
        float f472c = 0.0f;
        /* renamed from: d */
        boolean f473d;
        /* renamed from: e */
        int f474e;
        /* renamed from: f */
        int f475f;

        public C0245c() {
            super(-1, -1);
        }

        public C0245c(Context context, AttributeSet attrs) {
            super(context, attrs);
            TypedArray a = context.obtainStyledAttributes(attrs, ViewPager.f481a);
            this.f471b = a.getInteger(0, 48);
            a.recycle();
        }
    }

    /* renamed from: android.support.v4.view.ViewPager$d */
    class C0247d extends C0246a {
        /* renamed from: b */
        final /* synthetic */ ViewPager f479b;

        C0247d(ViewPager viewPager) {
            this.f479b = viewPager;
        }

        /* renamed from: d */
        public void mo157d(View host, AccessibilityEvent event) {
            super.mo157d(host, event);
            event.setClassName(ViewPager.class.getName());
            C0299j recordCompat = C0265a.m994a(event);
            recordCompat.m1259a(m875b());
            if (event.getEventType() == 4096 && this.f479b.f511h != null) {
                recordCompat.m1258a(this.f479b.f511h.mo1147a());
                recordCompat.m1260b(this.f479b.f512i);
                recordCompat.m1261c(this.f479b.f512i);
            }
        }

        /* renamed from: a */
        public void mo155a(View host, C0276b info) {
            super.mo155a(host, info);
            info.m1136b(ViewPager.class.getName());
            info.m1154i(m875b());
            if (this.f479b.canScrollHorizontally(1)) {
                info.m1127a(4096);
            }
            if (this.f479b.canScrollHorizontally(-1)) {
                info.m1127a(8192);
            }
        }

        /* renamed from: a */
        public boolean mo156a(View host, int action, Bundle args) {
            if (super.mo156a(host, action, args)) {
                return true;
            }
            switch (action) {
                case 4096:
                    if (!this.f479b.canScrollHorizontally(1)) {
                        return false;
                    }
                    this.f479b.setCurrentItem(this.f479b.f512i + 1);
                    return true;
                case 8192:
                    if (!this.f479b.canScrollHorizontally(-1)) {
                        return false;
                    }
                    this.f479b.setCurrentItem(this.f479b.f512i - 1);
                    return true;
                default:
                    return false;
            }
        }

        /* renamed from: b */
        private boolean m875b() {
            return this.f479b.f511h != null && this.f479b.f511h.mo1147a() > 1;
        }
    }

    /* renamed from: android.support.v4.view.ViewPager$e */
    interface C0248e {
        /* renamed from: a */
        void m879a(ad adVar, ad adVar2);
    }

    /* renamed from: android.support.v4.view.ViewPager$f */
    public interface C0249f {
        /* renamed from: a */
        void mo845a(int i);

        /* renamed from: a */
        void mo846a(int i, float f, int i2);

        /* renamed from: b */
        void mo847b(int i);
    }

    /* renamed from: android.support.v4.view.ViewPager$g */
    public interface C0250g {
        /* renamed from: a */
        void m883a(View view, float f);
    }

    /* renamed from: android.support.v4.view.ViewPager$h */
    private class C0251h extends DataSetObserver {
        /* renamed from: a */
        final /* synthetic */ ViewPager f480a;

        private C0251h(ViewPager viewPager) {
            this.f480a = viewPager;
        }

        public void onChanged() {
            this.f480a.m923b();
        }

        public void onInvalidated() {
            this.f480a.m923b();
        }
    }

    /* renamed from: android.support.v4.view.ViewPager$i */
    static class C0252i implements Comparator<View> {
        C0252i() {
        }

        public /* synthetic */ int compare(Object obj, Object obj2) {
            return m884a((View) obj, (View) obj2);
        }

        /* renamed from: a */
        public int m884a(View lhs, View rhs) {
            C0245c llp = (C0245c) lhs.getLayoutParams();
            C0245c rlp = (C0245c) rhs.getLayoutParams();
            if (llp.f470a != rlp.f470a) {
                return llp.f470a ? 1 : -1;
            } else {
                return llp.f474e - rlp.f474e;
            }
        }
    }

    public ViewPager(Context context) {
        super(context);
        m912a();
    }

    public ViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
        m912a();
    }

    /* renamed from: a */
    void m912a() {
        setWillNotDraw(false);
        setDescendantFocusability(262144);
        setFocusable(true);
        Context context = getContext();
        this.f516m = new Scroller(context, f483d);
        ViewConfiguration configuration = ViewConfiguration.get(context);
        float density = context.getResources().getDisplayMetrics().density;
        this.f489F = au.m1586a(configuration);
        this.f496M = (int) (400.0f * density);
        this.f497N = configuration.getScaledMaximumFlingVelocity();
        this.f501R = new C0456k(context);
        this.f502S = new C0456k(context);
        this.f498O = (int) (25.0f * density);
        this.f499P = (int) (2.0f * density);
        this.f487D = (int) (16.0f * density);
        ai.m1473a((View) this, new C0247d(this));
        if (ai.m1485c(this) == 0) {
            ai.m1487c((View) this, 1);
        }
        ai.m1474a((View) this, new C02414(this));
    }

    protected void onDetachedFromWindow() {
        removeCallbacks(this.aj);
        if (!(this.f516m == null || this.f516m.isFinished())) {
            this.f516m.abortAnimation();
        }
        super.onDetachedFromWindow();
    }

    private void setScrollState(int newState) {
        if (this.ak != newState) {
            this.ak = newState;
            if (this.ae != null) {
                m897b(newState != 0);
            }
            m902f(newState);
        }
    }

    public void setAdapter(ad adapter) {
        if (this.f511h != null) {
            this.f511h.m1297c(null);
            this.f511h.m1286a((ViewGroup) this);
            for (int i = 0; i < this.f508e.size(); i++) {
                C0244b ii = (C0244b) this.f508e.get(i);
                this.f511h.mo1150a((ViewGroup) this, ii.f466b, ii.f465a);
            }
            this.f511h.m1294b((ViewGroup) this);
            this.f508e.clear();
            m904g();
            this.f512i = 0;
            scrollTo(0, 0);
        }
        ad oldAdapter = this.f511h;
        this.f511h = adapter;
        this.f507b = 0;
        if (this.f511h != null) {
            if (this.f518o == null) {
                this.f518o = new C0251h();
            }
            this.f511h.m1297c(this.f518o);
            this.f529z = false;
            boolean wasFirstLayout = this.f503T;
            this.f503T = true;
            this.f507b = this.f511h.mo1147a();
            if (this.f513j >= 0) {
                this.f511h.m1283a(this.f514k, this.f515l);
                m917a(this.f513j, false, true);
                this.f513j = -1;
                this.f514k = null;
                this.f515l = null;
            } else if (wasFirstLayout) {
                requestLayout();
            } else {
                m924c();
            }
        }
        if (this.ad != null && oldAdapter != adapter) {
            this.ad.m879a(oldAdapter, adapter);
        }
    }

    /* renamed from: g */
    private void m904g() {
        int i = 0;
        while (i < getChildCount()) {
            if (!((C0245c) getChildAt(i).getLayoutParams()).f470a) {
                removeViewAt(i);
                i--;
            }
            i++;
        }
    }

    public ad getAdapter() {
        return this.f511h;
    }

    void setOnAdapterChangeListener(C0248e listener) {
        this.ad = listener;
    }

    private int getClientWidth() {
        return (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
    }

    public void setCurrentItem(int item) {
        boolean z;
        this.f529z = false;
        if (this.f503T) {
            z = false;
        } else {
            z = true;
        }
        m917a(item, z, false);
    }

    /* renamed from: a */
    public void m916a(int item, boolean smoothScroll) {
        this.f529z = false;
        m917a(item, smoothScroll, false);
    }

    public int getCurrentItem() {
        return this.f512i;
    }

    /* renamed from: a */
    void m917a(int item, boolean smoothScroll, boolean always) {
        m918a(item, smoothScroll, always, 0);
    }

    /* renamed from: a */
    void m918a(int item, boolean smoothScroll, boolean always, int velocity) {
        boolean dispatchSelected = true;
        if (this.f511h == null || this.f511h.mo1147a() <= 0) {
            setScrollingCacheEnabled(false);
        } else if (always || this.f512i != item || this.f508e.size() == 0) {
            if (item < 0) {
                item = 0;
            } else if (item >= this.f511h.mo1147a()) {
                item = this.f511h.mo1147a() - 1;
            }
            int pageLimit = this.f484A;
            if (item > this.f512i + pageLimit || item < this.f512i - pageLimit) {
                for (int i = 0; i < this.f508e.size(); i++) {
                    ((C0244b) this.f508e.get(i)).f467c = true;
                }
            }
            if (this.f512i == item) {
                dispatchSelected = false;
            }
            if (this.f503T) {
                this.f512i = item;
                if (dispatchSelected) {
                    m901e(item);
                }
                requestLayout();
                return;
            }
            m913a(item);
            m889a(item, smoothScroll, velocity, dispatchSelected);
        } else {
            setScrollingCacheEnabled(false);
        }
    }

    /* renamed from: a */
    private void m889a(int item, boolean smoothScroll, int velocity, boolean dispatchSelected) {
        C0244b curInfo = m921b(item);
        int destX = 0;
        if (curInfo != null) {
            destX = (int) (((float) getClientWidth()) * Math.max(this.f523t, Math.min(curInfo.f469e, this.f524u)));
        }
        if (smoothScroll) {
            m915a(destX, 0, velocity);
            if (dispatchSelected) {
                m901e(item);
                return;
            }
            return;
        }
        if (dispatchSelected) {
            m901e(item);
        }
        m893a(false);
        scrollTo(destX, 0);
        m900d(destX);
    }

    @Deprecated
    public void setOnPageChangeListener(C0249f listener) {
        this.ab = listener;
    }

    void setChildrenDrawingOrderEnabledCompat(boolean enable) {
        if (VERSION.SDK_INT >= 7) {
            if (this.af == null) {
                try {
                    this.af = ViewGroup.class.getDeclaredMethod("setChildrenDrawingOrderEnabled", new Class[]{Boolean.TYPE});
                } catch (NoSuchMethodException e) {
                    Log.e("ViewPager", "Can't find setChildrenDrawingOrderEnabled", e);
                }
            }
            try {
                this.af.invoke(this, new Object[]{Boolean.valueOf(enable)});
            } catch (Exception e2) {
                Log.e("ViewPager", "Error changing children drawing order", e2);
            }
        }
    }

    protected int getChildDrawingOrder(int childCount, int i) {
        int index;
        if (this.ag == 2) {
            index = (childCount - 1) - i;
        } else {
            index = i;
        }
        return ((C0245c) ((View) this.ah.get(index)).getLayoutParams()).f475f;
    }

    public int getOffscreenPageLimit() {
        return this.f484A;
    }

    public void setOffscreenPageLimit(int limit) {
        if (limit < 1) {
            Log.w("ViewPager", "Requested offscreen page limit " + limit + " too small; defaulting to " + 1);
            limit = 1;
        }
        if (limit != this.f484A) {
            this.f484A = limit;
            m924c();
        }
    }

    public void setPageMargin(int marginPixels) {
        int oldMargin = this.f519p;
        this.f519p = marginPixels;
        int width = getWidth();
        m888a(width, width, marginPixels, oldMargin);
        requestLayout();
    }

    public int getPageMargin() {
        return this.f519p;
    }

    public void setPageMarginDrawable(Drawable d) {
        this.f520q = d;
        if (d != null) {
            refreshDrawableState();
        }
        setWillNotDraw(d == null);
        invalidate();
    }

    public void setPageMarginDrawable(int resId) {
        setPageMarginDrawable(getContext().getResources().getDrawable(resId));
    }

    protected boolean verifyDrawable(Drawable who) {
        return super.verifyDrawable(who) || who == this.f520q;
    }

    protected void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable d = this.f520q;
        if (d != null && d.isStateful()) {
            d.setState(getDrawableState());
        }
    }

    /* renamed from: a */
    float m909a(float f) {
        return (float) Math.sin((double) ((float) (((double) (f - 0.5f)) * 0.4712389167638204d)));
    }

    /* renamed from: a */
    void m915a(int x, int y, int velocity) {
        if (getChildCount() == 0) {
            setScrollingCacheEnabled(false);
            return;
        }
        int sx;
        boolean wasScrolling = (this.f516m == null || this.f516m.isFinished()) ? false : true;
        if (wasScrolling) {
            sx = this.f517n ? this.f516m.getCurrX() : this.f516m.getStartX();
            this.f516m.abortAnimation();
            setScrollingCacheEnabled(false);
        } else {
            sx = getScrollX();
        }
        int sy = getScrollY();
        int dx = x - sx;
        int dy = y - sy;
        if (dx == 0 && dy == 0) {
            m893a(false);
            m924c();
            setScrollState(0);
            return;
        }
        int duration;
        setScrollingCacheEnabled(true);
        setScrollState(2);
        int width = getClientWidth();
        int halfWidth = width / 2;
        float distance = ((float) halfWidth) + (((float) halfWidth) * m909a(Math.min(1.0f, (1.0f * ((float) Math.abs(dx))) / ((float) width))));
        velocity = Math.abs(velocity);
        if (velocity > 0) {
            duration = Math.round(1000.0f * Math.abs(distance / ((float) velocity))) * 4;
        } else {
            duration = (int) ((1.0f + (((float) Math.abs(dx)) / (((float) this.f519p) + (((float) width) * this.f511h.m1289b(this.f512i))))) * 100.0f);
        }
        duration = Math.min(duration, 600);
        this.f517n = false;
        this.f516m.startScroll(sx, sy, dx, dy, duration);
        ai.m1481b(this);
    }

    /* renamed from: a */
    C0244b m910a(int position, int index) {
        C0244b ii = new C0244b();
        ii.f466b = position;
        ii.f465a = this.f511h.mo1149a((ViewGroup) this, position);
        ii.f468d = this.f511h.m1289b(position);
        if (index < 0 || index >= this.f508e.size()) {
            this.f508e.add(ii);
        } else {
            this.f508e.add(index, ii);
        }
        return ii;
    }

    /* renamed from: b */
    void m923b() {
        boolean needPopulate;
        int adapterCount = this.f511h.mo1147a();
        this.f507b = adapterCount;
        if (this.f508e.size() >= (this.f484A * 2) + 1 || this.f508e.size() >= adapterCount) {
            needPopulate = false;
        } else {
            needPopulate = true;
        }
        int newCurrItem = this.f512i;
        boolean isUpdating = false;
        int i = 0;
        while (i < this.f508e.size()) {
            C0244b ii = (C0244b) this.f508e.get(i);
            int newPos = this.f511h.m1278a(ii.f465a);
            if (newPos != -1) {
                if (newPos == -2) {
                    this.f508e.remove(i);
                    i--;
                    if (!isUpdating) {
                        this.f511h.m1286a((ViewGroup) this);
                        isUpdating = true;
                    }
                    this.f511h.mo1150a((ViewGroup) this, ii.f466b, ii.f465a);
                    needPopulate = true;
                    if (this.f512i == ii.f466b) {
                        newCurrItem = Math.max(0, Math.min(this.f512i, adapterCount - 1));
                        needPopulate = true;
                    }
                } else if (ii.f466b != newPos) {
                    if (ii.f466b == this.f512i) {
                        newCurrItem = newPos;
                    }
                    ii.f466b = newPos;
                    needPopulate = true;
                }
            }
            i++;
        }
        if (isUpdating) {
            this.f511h.m1294b((ViewGroup) this);
        }
        Collections.sort(this.f508e, f482c);
        if (needPopulate) {
            int childCount = getChildCount();
            for (i = 0; i < childCount; i++) {
                C0245c lp = (C0245c) getChildAt(i).getLayoutParams();
                if (!lp.f470a) {
                    lp.f472c = 0.0f;
                }
            }
            m917a(newCurrItem, false, true);
            requestLayout();
        }
    }

    /* renamed from: c */
    void m924c() {
        m913a(this.f512i);
    }

    /* renamed from: a */
    void m913a(int newCurrentItem) {
        C0244b oldCurInfo = null;
        if (this.f512i != newCurrentItem) {
            oldCurInfo = m921b(this.f512i);
            this.f512i = newCurrentItem;
        }
        if (this.f511h == null) {
            m905h();
        } else if (this.f529z) {
            m905h();
        } else if (getWindowToken() != null) {
            this.f511h.m1286a((ViewGroup) this);
            int pageLimit = this.f484A;
            int startPos = Math.max(0, this.f512i - pageLimit);
            int N = this.f511h.mo1147a();
            int endPos = Math.min(N - 1, this.f512i + pageLimit);
            if (N != this.f507b) {
                String resName;
                try {
                    resName = getResources().getResourceName(getId());
                } catch (NotFoundException e) {
                    resName = Integer.toHexString(getId());
                }
                throw new IllegalStateException("The application's PagerAdapter changed the adapter's contents without calling PagerAdapter#notifyDataSetChanged! Expected adapter item count: " + this.f507b + ", found: " + N + " Pager id: " + resName + " Pager class: " + getClass() + " Problematic adapter: " + this.f511h.getClass());
            }
            C0244b ii;
            float extraWidthLeft;
            int itemIndex;
            int clientWidth;
            float leftWidthNeeded;
            int pos;
            float extraWidthRight;
            float rightWidthNeeded;
            int childCount;
            int i;
            View child;
            C0245c lp;
            View currentFocused;
            C0244b curItem = null;
            int curIndex = 0;
            while (curIndex < this.f508e.size()) {
                ii = (C0244b) this.f508e.get(curIndex);
                if (ii.f466b >= this.f512i) {
                    if (ii.f466b == this.f512i) {
                        curItem = ii;
                    }
                    if (curItem == null && N > 0) {
                        curItem = m910a(this.f512i, curIndex);
                    }
                    if (curItem != null) {
                        extraWidthLeft = 0.0f;
                        itemIndex = curIndex - 1;
                        ii = itemIndex < 0 ? (C0244b) this.f508e.get(itemIndex) : null;
                        clientWidth = getClientWidth();
                        leftWidthNeeded = clientWidth > 0 ? 0.0f : (2.0f - curItem.f468d) + (((float) getPaddingLeft()) / ((float) clientWidth));
                        pos = this.f512i - 1;
                        while (pos >= 0) {
                            if (extraWidthLeft >= leftWidthNeeded || pos >= startPos) {
                                if (ii == null && pos == ii.f466b) {
                                    extraWidthLeft += ii.f468d;
                                    itemIndex--;
                                    ii = itemIndex >= 0 ? (C0244b) this.f508e.get(itemIndex) : null;
                                } else {
                                    extraWidthLeft += m910a(pos, itemIndex + 1).f468d;
                                    curIndex++;
                                    ii = itemIndex < 0 ? (C0244b) this.f508e.get(itemIndex) : null;
                                }
                            } else if (ii == null) {
                                break;
                            } else {
                                if (pos == ii.f466b && !ii.f467c) {
                                    this.f508e.remove(itemIndex);
                                    this.f511h.mo1150a((ViewGroup) this, pos, ii.f465a);
                                    itemIndex--;
                                    curIndex--;
                                    if (itemIndex >= 0) {
                                        ii = (C0244b) this.f508e.get(itemIndex);
                                    } else {
                                        ii = null;
                                    }
                                }
                            }
                            pos--;
                        }
                        extraWidthRight = curItem.f468d;
                        itemIndex = curIndex + 1;
                        if (extraWidthRight < 2.0f) {
                            ii = itemIndex >= this.f508e.size() ? (C0244b) this.f508e.get(itemIndex) : null;
                            rightWidthNeeded = clientWidth > 0 ? 0.0f : (((float) getPaddingRight()) / ((float) clientWidth)) + 2.0f;
                            pos = this.f512i + 1;
                            while (pos < N) {
                                if (extraWidthRight >= rightWidthNeeded || pos <= endPos) {
                                    if (ii == null && pos == ii.f466b) {
                                        extraWidthRight += ii.f468d;
                                        itemIndex++;
                                        ii = itemIndex < this.f508e.size() ? (C0244b) this.f508e.get(itemIndex) : null;
                                    } else {
                                        itemIndex++;
                                        extraWidthRight += m910a(pos, itemIndex).f468d;
                                        ii = itemIndex >= this.f508e.size() ? (C0244b) this.f508e.get(itemIndex) : null;
                                    }
                                } else if (ii == null) {
                                    break;
                                } else {
                                    if (pos == ii.f466b && !ii.f467c) {
                                        this.f508e.remove(itemIndex);
                                        this.f511h.mo1150a((ViewGroup) this, pos, ii.f465a);
                                        if (itemIndex < this.f508e.size()) {
                                            ii = (C0244b) this.f508e.get(itemIndex);
                                        } else {
                                            ii = null;
                                        }
                                    }
                                }
                                pos++;
                            }
                        }
                        m890a(curItem, curIndex, oldCurInfo);
                    }
                    this.f511h.m1295b((ViewGroup) this, this.f512i, curItem == null ? curItem.f465a : null);
                    this.f511h.m1294b((ViewGroup) this);
                    childCount = getChildCount();
                    for (i = 0; i < childCount; i++) {
                        child = getChildAt(i);
                        lp = (C0245c) child.getLayoutParams();
                        lp.f475f = i;
                        if (!lp.f470a && lp.f472c == 0.0f) {
                            ii = m911a(child);
                            if (ii != null) {
                                lp.f472c = ii.f468d;
                                lp.f474e = ii.f466b;
                            }
                        }
                    }
                    m905h();
                    if (hasFocus()) {
                        currentFocused = findFocus();
                        ii = currentFocused == null ? m922b(currentFocused) : null;
                        if (ii != null || ii.f466b != this.f512i) {
                            while (i < getChildCount()) {
                                child = getChildAt(i);
                                ii = m911a(child);
                                if (ii != null || ii.f466b != this.f512i || !child.requestFocus(2)) {
                                } else {
                                    return;
                                }
                            }
                        }
                        return;
                    }
                }
                curIndex++;
            }
            curItem = m910a(this.f512i, curIndex);
            if (curItem != null) {
                extraWidthLeft = 0.0f;
                itemIndex = curIndex - 1;
                if (itemIndex < 0) {
                }
                clientWidth = getClientWidth();
                if (clientWidth > 0) {
                }
                pos = this.f512i - 1;
                while (pos >= 0) {
                    if (extraWidthLeft >= leftWidthNeeded) {
                    }
                    if (ii == null) {
                    }
                    extraWidthLeft += m910a(pos, itemIndex + 1).f468d;
                    curIndex++;
                    if (itemIndex < 0) {
                    }
                    pos--;
                }
                extraWidthRight = curItem.f468d;
                itemIndex = curIndex + 1;
                if (extraWidthRight < 2.0f) {
                    if (itemIndex >= this.f508e.size()) {
                    }
                    if (clientWidth > 0) {
                    }
                    pos = this.f512i + 1;
                    while (pos < N) {
                        if (extraWidthRight >= rightWidthNeeded) {
                        }
                        if (ii == null) {
                        }
                        itemIndex++;
                        extraWidthRight += m910a(pos, itemIndex).f468d;
                        if (itemIndex >= this.f508e.size()) {
                        }
                        pos++;
                    }
                }
                m890a(curItem, curIndex, oldCurInfo);
            }
            if (curItem == null) {
            }
            this.f511h.m1295b((ViewGroup) this, this.f512i, curItem == null ? curItem.f465a : null);
            this.f511h.m1294b((ViewGroup) this);
            childCount = getChildCount();
            for (i = 0; i < childCount; i++) {
                child = getChildAt(i);
                lp = (C0245c) child.getLayoutParams();
                lp.f475f = i;
                ii = m911a(child);
                if (ii != null) {
                    lp.f472c = ii.f468d;
                    lp.f474e = ii.f466b;
                }
            }
            m905h();
            if (hasFocus()) {
                currentFocused = findFocus();
                if (currentFocused == null) {
                }
                if (ii != null) {
                }
                for (i = 0; i < getChildCount(); i++) {
                    child = getChildAt(i);
                    ii = m911a(child);
                    if (ii != null) {
                    }
                }
            }
        }
    }

    /* renamed from: h */
    private void m905h() {
        if (this.ag != 0) {
            if (this.ah == null) {
                this.ah = new ArrayList();
            } else {
                this.ah.clear();
            }
            int childCount = getChildCount();
            for (int i = 0; i < childCount; i++) {
                this.ah.add(getChildAt(i));
            }
            Collections.sort(this.ah, ai);
        }
    }

    /* renamed from: a */
    private void m890a(C0244b curItem, int curIndex, C0244b oldCurInfo) {
        float offset;
        int pos;
        C0244b ii;
        int N = this.f511h.mo1147a();
        int width = getClientWidth();
        float marginOffset = width > 0 ? ((float) this.f519p) / ((float) width) : 0.0f;
        if (oldCurInfo != null) {
            int oldCurPosition = oldCurInfo.f466b;
            int itemIndex;
            if (oldCurPosition < curItem.f466b) {
                itemIndex = 0;
                offset = (oldCurInfo.f469e + oldCurInfo.f468d) + marginOffset;
                pos = oldCurPosition + 1;
                while (pos <= curItem.f466b && itemIndex < this.f508e.size()) {
                    ii = (C0244b) this.f508e.get(itemIndex);
                    while (pos > ii.f466b && itemIndex < this.f508e.size() - 1) {
                        itemIndex++;
                        ii = (C0244b) this.f508e.get(itemIndex);
                    }
                    while (pos < ii.f466b) {
                        offset += this.f511h.m1289b(pos) + marginOffset;
                        pos++;
                    }
                    ii.f469e = offset;
                    offset += ii.f468d + marginOffset;
                    pos++;
                }
            } else if (oldCurPosition > curItem.f466b) {
                itemIndex = this.f508e.size() - 1;
                offset = oldCurInfo.f469e;
                pos = oldCurPosition - 1;
                while (pos >= curItem.f466b && itemIndex >= 0) {
                    ii = (C0244b) this.f508e.get(itemIndex);
                    while (pos < ii.f466b && itemIndex > 0) {
                        itemIndex--;
                        ii = (C0244b) this.f508e.get(itemIndex);
                    }
                    while (pos > ii.f466b) {
                        offset -= this.f511h.m1289b(pos) + marginOffset;
                        pos--;
                    }
                    offset -= ii.f468d + marginOffset;
                    ii.f469e = offset;
                    pos--;
                }
            }
        }
        int itemCount = this.f508e.size();
        offset = curItem.f469e;
        pos = curItem.f466b - 1;
        this.f523t = curItem.f466b == 0 ? curItem.f469e : -3.4028235E38f;
        this.f524u = curItem.f466b == N + -1 ? (curItem.f469e + curItem.f468d) - 1.0f : Float.MAX_VALUE;
        int i = curIndex - 1;
        while (i >= 0) {
            ii = (C0244b) this.f508e.get(i);
            while (pos > ii.f466b) {
                offset -= this.f511h.m1289b(pos) + marginOffset;
                pos--;
            }
            offset -= ii.f468d + marginOffset;
            ii.f469e = offset;
            if (ii.f466b == 0) {
                this.f523t = offset;
            }
            i--;
            pos--;
        }
        offset = (curItem.f469e + curItem.f468d) + marginOffset;
        pos = curItem.f466b + 1;
        i = curIndex + 1;
        while (i < itemCount) {
            ii = (C0244b) this.f508e.get(i);
            while (pos < ii.f466b) {
                offset += this.f511h.m1289b(pos) + marginOffset;
                pos++;
            }
            if (ii.f466b == N - 1) {
                this.f524u = (ii.f468d + offset) - 1.0f;
            }
            ii.f469e = offset;
            offset += ii.f468d + marginOffset;
            i++;
            pos++;
        }
        this.f504U = false;
    }

    public Parcelable onSaveInstanceState() {
        SavedState ss = new SavedState(super.onSaveInstanceState());
        ss.f462a = this.f512i;
        if (this.f511h != null) {
            ss.f463b = this.f511h.m1290b();
        }
        return ss;
    }

    public void onRestoreInstanceState(Parcelable state) {
        if (state instanceof SavedState) {
            SavedState ss = (SavedState) state;
            super.onRestoreInstanceState(ss.getSuperState());
            if (this.f511h != null) {
                this.f511h.m1283a(ss.f463b, ss.f464c);
                m917a(ss.f462a, false, true);
                return;
            }
            this.f513j = ss.f462a;
            this.f514k = ss.f463b;
            this.f515l = ss.f464c;
            return;
        }
        super.onRestoreInstanceState(state);
    }

    public void addView(View child, int index, LayoutParams params) {
        if (!checkLayoutParams(params)) {
            params = generateLayoutParams(params);
        }
        C0245c lp = (C0245c) params;
        lp.f470a |= child instanceof C0243a;
        if (!this.f527x) {
            super.addView(child, index, params);
        } else if (lp == null || !lp.f470a) {
            lp.f473d = true;
            addViewInLayout(child, index, params);
        } else {
            throw new IllegalStateException("Cannot add pager decor view during layout");
        }
    }

    public void removeView(View view) {
        if (this.f527x) {
            removeViewInLayout(view);
        } else {
            super.removeView(view);
        }
    }

    /* renamed from: a */
    C0244b m911a(View child) {
        for (int i = 0; i < this.f508e.size(); i++) {
            C0244b ii = (C0244b) this.f508e.get(i);
            if (this.f511h.mo1151a(child, ii.f465a)) {
                return ii;
            }
        }
        return null;
    }

    /* renamed from: b */
    C0244b m922b(View child) {
        while (true) {
            View parent = child.getParent();
            if (parent == this) {
                return m911a(child);
            }
            if (parent != null && (parent instanceof View)) {
                child = parent;
            }
        }
        return null;
    }

    /* renamed from: b */
    C0244b m921b(int position) {
        for (int i = 0; i < this.f508e.size(); i++) {
            C0244b ii = (C0244b) this.f508e.get(i);
            if (ii.f466b == position) {
                return ii;
            }
        }
        return null;
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f503T = true;
    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int i;
        setMeasuredDimension(getDefaultSize(0, widthMeasureSpec), getDefaultSize(0, heightMeasureSpec));
        int measuredWidth = getMeasuredWidth();
        this.f488E = Math.min(measuredWidth / 10, this.f487D);
        int childWidthSize = (measuredWidth - getPaddingLeft()) - getPaddingRight();
        int childHeightSize = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
        int size = getChildCount();
        for (i = 0; i < size; i++) {
            C0245c lp;
            View child = getChildAt(i);
            if (child.getVisibility() != 8) {
                lp = (C0245c) child.getLayoutParams();
                if (lp != null && lp.f470a) {
                    int hgrav = lp.f471b & 7;
                    int vgrav = lp.f471b & 112;
                    int widthMode = RtlSpacingHelper.UNDEFINED;
                    int heightMode = RtlSpacingHelper.UNDEFINED;
                    boolean consumeVertical = vgrav == 48 || vgrav == 80;
                    boolean consumeHorizontal = hgrav == 3 || hgrav == 5;
                    if (consumeVertical) {
                        widthMode = 1073741824;
                    } else if (consumeHorizontal) {
                        heightMode = 1073741824;
                    }
                    int widthSize = childWidthSize;
                    int heightSize = childHeightSize;
                    if (lp.width != -2) {
                        widthMode = 1073741824;
                        if (lp.width != -1) {
                            widthSize = lp.width;
                        }
                    }
                    if (lp.height != -2) {
                        heightMode = 1073741824;
                        if (lp.height != -1) {
                            heightSize = lp.height;
                        }
                    }
                    child.measure(MeasureSpec.makeMeasureSpec(widthSize, widthMode), MeasureSpec.makeMeasureSpec(heightSize, heightMode));
                    if (consumeVertical) {
                        childHeightSize -= child.getMeasuredHeight();
                    } else if (consumeHorizontal) {
                        childWidthSize -= child.getMeasuredWidth();
                    }
                }
            }
        }
        this.f525v = MeasureSpec.makeMeasureSpec(childWidthSize, 1073741824);
        this.f526w = MeasureSpec.makeMeasureSpec(childHeightSize, 1073741824);
        this.f527x = true;
        m924c();
        this.f527x = false;
        size = getChildCount();
        for (i = 0; i < size; i++) {
            child = getChildAt(i);
            if (child.getVisibility() != 8) {
                lp = (C0245c) child.getLayoutParams();
                if (lp == null || !lp.f470a) {
                    child.measure(MeasureSpec.makeMeasureSpec((int) (((float) childWidthSize) * lp.f472c), 1073741824), this.f526w);
                }
            }
        }
    }

    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w != oldw) {
            m888a(w, oldw, this.f519p, this.f519p);
        }
    }

    /* renamed from: a */
    private void m888a(int width, int oldWidth, int margin, int oldMargin) {
        if (oldWidth <= 0 || this.f508e.isEmpty()) {
            C0244b ii = m921b(this.f512i);
            int scrollPos = (int) (((float) ((width - getPaddingLeft()) - getPaddingRight())) * (ii != null ? Math.min(ii.f469e, this.f524u) : 0.0f));
            if (scrollPos != getScrollX()) {
                m893a(false);
                scrollTo(scrollPos, getScrollY());
            }
        } else if (this.f516m.isFinished()) {
            scrollTo((int) (((float) (((width - getPaddingLeft()) - getPaddingRight()) + margin)) * (((float) getScrollX()) / ((float) (((oldWidth - getPaddingLeft()) - getPaddingRight()) + oldMargin)))), getScrollY());
        } else {
            this.f516m.setFinalX(getCurrentItem() * getClientWidth());
        }
    }

    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int i;
        C0245c lp;
        int childLeft;
        int childTop;
        int count = getChildCount();
        int width = r - l;
        int height = b - t;
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingRight = getPaddingRight();
        int paddingBottom = getPaddingBottom();
        int scrollX = getScrollX();
        int decorCount = 0;
        for (i = 0; i < count; i++) {
            View child = getChildAt(i);
            if (child.getVisibility() != 8) {
                lp = (C0245c) child.getLayoutParams();
                if (lp.f470a) {
                    int vgrav = lp.f471b & 112;
                    switch (lp.f471b & 7) {
                        case 1:
                            childLeft = Math.max((width - child.getMeasuredWidth()) / 2, paddingLeft);
                            break;
                        case 3:
                            childLeft = paddingLeft;
                            paddingLeft += child.getMeasuredWidth();
                            break;
                        case 5:
                            childLeft = (width - paddingRight) - child.getMeasuredWidth();
                            paddingRight += child.getMeasuredWidth();
                            break;
                        default:
                            childLeft = paddingLeft;
                            break;
                    }
                    switch (vgrav) {
                        case 16:
                            childTop = Math.max((height - child.getMeasuredHeight()) / 2, paddingTop);
                            break;
                        case 48:
                            childTop = paddingTop;
                            paddingTop += child.getMeasuredHeight();
                            break;
                        case 80:
                            childTop = (height - paddingBottom) - child.getMeasuredHeight();
                            paddingBottom += child.getMeasuredHeight();
                            break;
                        default:
                            childTop = paddingTop;
                            break;
                    }
                    childLeft += scrollX;
                    child.layout(childLeft, childTop, child.getMeasuredWidth() + childLeft, child.getMeasuredHeight() + childTop);
                    decorCount++;
                }
            }
        }
        int childWidth = (width - paddingLeft) - paddingRight;
        for (i = 0; i < count; i++) {
            child = getChildAt(i);
            if (child.getVisibility() != 8) {
                lp = (C0245c) child.getLayoutParams();
                if (!lp.f470a) {
                    C0244b ii = m911a(child);
                    if (ii != null) {
                        childLeft = paddingLeft + ((int) (((float) childWidth) * ii.f469e));
                        childTop = paddingTop;
                        if (lp.f473d) {
                            lp.f473d = false;
                            child.measure(MeasureSpec.makeMeasureSpec((int) (((float) childWidth) * lp.f472c), 1073741824), MeasureSpec.makeMeasureSpec((height - paddingTop) - paddingBottom, 1073741824));
                        }
                        child.layout(childLeft, childTop, child.getMeasuredWidth() + childLeft, child.getMeasuredHeight() + childTop);
                    }
                }
            }
        }
        this.f521r = paddingTop;
        this.f522s = height - paddingBottom;
        this.f506W = decorCount;
        if (this.f503T) {
            m889a(this.f512i, false, 0, false);
        }
        this.f503T = false;
    }

    public void computeScroll() {
        this.f517n = true;
        if (this.f516m.isFinished() || !this.f516m.computeScrollOffset()) {
            m893a(true);
            return;
        }
        int oldX = getScrollX();
        int oldY = getScrollY();
        int x = this.f516m.getCurrX();
        int y = this.f516m.getCurrY();
        if (!(oldX == x && oldY == y)) {
            scrollTo(x, y);
            if (!m900d(x)) {
                this.f516m.abortAnimation();
                scrollTo(0, y);
            }
        }
        ai.m1481b(this);
    }

    /* renamed from: d */
    private boolean m900d(int xpos) {
        if (this.f508e.size() != 0) {
            C0244b ii = m907j();
            int width = getClientWidth();
            int widthWithMargin = width + this.f519p;
            float marginOffset = ((float) this.f519p) / ((float) width);
            int currentPage = ii.f466b;
            float pageOffset = ((((float) xpos) / ((float) width)) - ii.f469e) / (ii.f468d + marginOffset);
            int offsetPixels = (int) (((float) widthWithMargin) * pageOffset);
            this.f505V = false;
            m914a(currentPage, pageOffset, offsetPixels);
            if (this.f505V) {
                return true;
            }
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        } else if (this.f503T) {
            return false;
        } else {
            this.f505V = false;
            m914a(0, 0.0f, 0);
            if (this.f505V) {
                return false;
            }
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        }
    }

    /* renamed from: a */
    protected void m914a(int position, float offset, int offsetPixels) {
        int scrollX;
        int childCount;
        int i;
        View child;
        if (this.f506W > 0) {
            scrollX = getScrollX();
            int paddingLeft = getPaddingLeft();
            int paddingRight = getPaddingRight();
            int width = getWidth();
            childCount = getChildCount();
            for (i = 0; i < childCount; i++) {
                child = getChildAt(i);
                C0245c lp = (C0245c) child.getLayoutParams();
                if (lp.f470a) {
                    int childLeft;
                    switch (lp.f471b & 7) {
                        case 1:
                            childLeft = Math.max((width - child.getMeasuredWidth()) / 2, paddingLeft);
                            break;
                        case 3:
                            childLeft = paddingLeft;
                            paddingLeft += child.getWidth();
                            break;
                        case 5:
                            childLeft = (width - paddingRight) - child.getMeasuredWidth();
                            paddingRight += child.getMeasuredWidth();
                            break;
                        default:
                            childLeft = paddingLeft;
                            break;
                    }
                    int childOffset = (childLeft + scrollX) - child.getLeft();
                    if (childOffset != 0) {
                        child.offsetLeftAndRight(childOffset);
                    }
                }
            }
        }
        m896b(position, offset, offsetPixels);
        if (this.ae != null) {
            scrollX = getScrollX();
            childCount = getChildCount();
            for (i = 0; i < childCount; i++) {
                child = getChildAt(i);
                if (!((C0245c) child.getLayoutParams()).f470a) {
                    this.ae.m883a(child, ((float) (child.getLeft() - scrollX)) / ((float) getClientWidth()));
                }
            }
        }
        this.f505V = true;
    }

    /* renamed from: b */
    private void m896b(int position, float offset, int offsetPixels) {
        if (this.ab != null) {
            this.ab.mo846a(position, offset, offsetPixels);
        }
        if (this.aa != null) {
            int z = this.aa.size();
            for (int i = 0; i < z; i++) {
                C0249f listener = (C0249f) this.aa.get(i);
                if (listener != null) {
                    listener.mo846a(position, offset, offsetPixels);
                }
            }
        }
        if (this.ac != null) {
            this.ac.mo846a(position, offset, offsetPixels);
        }
    }

    /* renamed from: e */
    private void m901e(int position) {
        if (this.ab != null) {
            this.ab.mo845a(position);
        }
        if (this.aa != null) {
            int z = this.aa.size();
            for (int i = 0; i < z; i++) {
                C0249f listener = (C0249f) this.aa.get(i);
                if (listener != null) {
                    listener.mo845a(position);
                }
            }
        }
        if (this.ac != null) {
            this.ac.mo845a(position);
        }
    }

    /* renamed from: f */
    private void m902f(int state) {
        if (this.ab != null) {
            this.ab.mo847b(state);
        }
        if (this.aa != null) {
            int z = this.aa.size();
            for (int i = 0; i < z; i++) {
                C0249f listener = (C0249f) this.aa.get(i);
                if (listener != null) {
                    listener.mo847b(state);
                }
            }
        }
        if (this.ac != null) {
            this.ac.mo847b(state);
        }
    }

    /* renamed from: a */
    private void m893a(boolean postEvents) {
        boolean needPopulate;
        boolean wasScrolling = true;
        if (this.ak == 2) {
            needPopulate = true;
        } else {
            needPopulate = false;
        }
        if (needPopulate) {
            setScrollingCacheEnabled(false);
            if (this.f516m.isFinished()) {
                wasScrolling = false;
            }
            if (wasScrolling) {
                this.f516m.abortAnimation();
                int oldX = getScrollX();
                int oldY = getScrollY();
                int x = this.f516m.getCurrX();
                int y = this.f516m.getCurrY();
                if (!(oldX == x && oldY == y)) {
                    scrollTo(x, y);
                    if (x != oldX) {
                        m900d(x);
                    }
                }
            }
        }
        this.f529z = false;
        for (int i = 0; i < this.f508e.size(); i++) {
            C0244b ii = (C0244b) this.f508e.get(i);
            if (ii.f467c) {
                needPopulate = true;
                ii.f467c = false;
            }
        }
        if (!needPopulate) {
            return;
        }
        if (postEvents) {
            ai.m1475a((View) this, this.aj);
        } else {
            this.aj.run();
        }
    }

    /* renamed from: a */
    private boolean m894a(float x, float dx) {
        return (x < ((float) this.f488E) && dx > 0.0f) || (x > ((float) (getWidth() - this.f488E)) && dx < 0.0f);
    }

    /* renamed from: b */
    private void m897b(boolean enable) {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            ai.m1470a(getChildAt(i), enable ? 2 : 0, null);
        }
    }

    public boolean onInterceptTouchEvent(MotionEvent ev) {
        int action = ev.getAction() & 255;
        if (action == 3 || action == 1) {
            m906i();
            return false;
        }
        if (action != 0) {
            if (this.f485B) {
                return true;
            }
            if (this.f486C) {
                return false;
            }
        }
        switch (action) {
            case 0:
                float x = ev.getX();
                this.f492I = x;
                this.f490G = x;
                x = ev.getY();
                this.f493J = x;
                this.f491H = x;
                this.f494K = C0398u.m1821b(ev, 0);
                this.f486C = false;
                this.f517n = true;
                this.f516m.computeScrollOffset();
                if (this.ak == 2 && Math.abs(this.f516m.getFinalX() - this.f516m.getCurrX()) > this.f499P) {
                    this.f516m.abortAnimation();
                    this.f529z = false;
                    m924c();
                    this.f485B = true;
                    m899c(true);
                    setScrollState(1);
                    break;
                }
                m893a(false);
                this.f485B = false;
                break;
            case 2:
                int activePointerId = this.f494K;
                if (activePointerId != -1) {
                    int pointerIndex = C0398u.m1819a(ev, activePointerId);
                    float x2 = C0398u.m1822c(ev, pointerIndex);
                    float dx = x2 - this.f490G;
                    float xDiff = Math.abs(dx);
                    float y = C0398u.m1824d(ev, pointerIndex);
                    float yDiff = Math.abs(y - this.f493J);
                    if (dx == 0.0f || m894a(this.f490G, dx) || !m920a(this, false, (int) dx, (int) x2, (int) y)) {
                        if (xDiff > ((float) this.f489F) && 0.5f * xDiff > yDiff) {
                            this.f485B = true;
                            m899c(true);
                            setScrollState(1);
                            this.f490G = dx > 0.0f ? this.f492I + ((float) this.f489F) : this.f492I - ((float) this.f489F);
                            this.f491H = y;
                            setScrollingCacheEnabled(true);
                        } else if (yDiff > ((float) this.f489F)) {
                            this.f486C = true;
                        }
                        if (this.f485B && m898b(x2)) {
                            ai.m1481b(this);
                            break;
                        }
                    }
                    this.f490G = x2;
                    this.f491H = y;
                    this.f486C = true;
                    return false;
                }
                break;
            case 6:
                m892a(ev);
                break;
        }
        if (this.f495L == null) {
            this.f495L = VelocityTracker.obtain();
        }
        this.f495L.addMovement(ev);
        return this.f485B;
    }

    public boolean onTouchEvent(MotionEvent ev) {
        if (this.f500Q) {
            return true;
        }
        if (ev.getAction() == 0 && ev.getEdgeFlags() != 0) {
            return false;
        }
        if (this.f511h == null || this.f511h.mo1147a() == 0) {
            return false;
        }
        if (this.f495L == null) {
            this.f495L = VelocityTracker.obtain();
        }
        this.f495L.addMovement(ev);
        boolean needsInvalidate = false;
        float x;
        switch (ev.getAction() & 255) {
            case 0:
                this.f516m.abortAnimation();
                this.f529z = false;
                m924c();
                x = ev.getX();
                this.f492I = x;
                this.f490G = x;
                x = ev.getY();
                this.f493J = x;
                this.f491H = x;
                this.f494K = C0398u.m1821b(ev, 0);
                break;
            case 1:
                if (this.f485B) {
                    VelocityTracker velocityTracker = this.f495L;
                    velocityTracker.computeCurrentVelocity(1000, (float) this.f497N);
                    int initialVelocity = (int) ag.m1304a(velocityTracker, this.f494K);
                    this.f529z = true;
                    int width = getClientWidth();
                    int scrollX = getScrollX();
                    C0244b ii = m907j();
                    float marginOffset = ((float) this.f519p) / ((float) width);
                    m918a(m885a(ii.f466b, ((((float) scrollX) / ((float) width)) - ii.f469e) / (ii.f468d + marginOffset), initialVelocity, (int) (C0398u.m1822c(ev, C0398u.m1819a(ev, this.f494K)) - this.f492I)), true, true, initialVelocity);
                    needsInvalidate = m906i();
                    break;
                }
                break;
            case 2:
                if (!this.f485B) {
                    int pointerIndex = C0398u.m1819a(ev, this.f494K);
                    if (pointerIndex == -1) {
                        needsInvalidate = m906i();
                        break;
                    }
                    float x2 = C0398u.m1822c(ev, pointerIndex);
                    float xDiff = Math.abs(x2 - this.f490G);
                    float y = C0398u.m1824d(ev, pointerIndex);
                    float yDiff = Math.abs(y - this.f491H);
                    if (xDiff > ((float) this.f489F) && xDiff > yDiff) {
                        this.f485B = true;
                        m899c(true);
                        if (x2 - this.f492I > 0.0f) {
                            x = this.f492I + ((float) this.f489F);
                        } else {
                            x = this.f492I - ((float) this.f489F);
                        }
                        this.f490G = x;
                        this.f491H = y;
                        setScrollState(1);
                        setScrollingCacheEnabled(true);
                        ViewParent parent = getParent();
                        if (parent != null) {
                            parent.requestDisallowInterceptTouchEvent(true);
                        }
                    }
                }
                if (this.f485B) {
                    needsInvalidate = false | m898b(C0398u.m1822c(ev, C0398u.m1819a(ev, this.f494K)));
                    break;
                }
                break;
            case 3:
                if (this.f485B) {
                    m889a(this.f512i, true, 0, false);
                    needsInvalidate = m906i();
                    break;
                }
                break;
            case 5:
                int index = C0398u.m1820b(ev);
                this.f490G = C0398u.m1822c(ev, index);
                this.f494K = C0398u.m1821b(ev, index);
                break;
            case 6:
                m892a(ev);
                this.f490G = C0398u.m1822c(ev, C0398u.m1819a(ev, this.f494K));
                break;
        }
        if (needsInvalidate) {
            ai.m1481b(this);
        }
        return true;
    }

    /* renamed from: i */
    private boolean m906i() {
        this.f494K = -1;
        m908k();
        return this.f501R.m2175c() | this.f502S.m2175c();
    }

    /* renamed from: c */
    private void m899c(boolean disallowIntercept) {
        ViewParent parent = getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(disallowIntercept);
        }
    }

    /* renamed from: b */
    private boolean m898b(float x) {
        boolean needsInvalidate = false;
        float deltaX = this.f490G - x;
        this.f490G = x;
        float scrollX = ((float) getScrollX()) + deltaX;
        int width = getClientWidth();
        float leftBound = ((float) width) * this.f523t;
        float rightBound = ((float) width) * this.f524u;
        boolean leftAbsolute = true;
        boolean rightAbsolute = true;
        C0244b firstItem = (C0244b) this.f508e.get(0);
        C0244b lastItem = (C0244b) this.f508e.get(this.f508e.size() - 1);
        if (firstItem.f466b != 0) {
            leftAbsolute = false;
            leftBound = firstItem.f469e * ((float) width);
        }
        if (lastItem.f466b != this.f511h.mo1147a() - 1) {
            rightAbsolute = false;
            rightBound = lastItem.f469e * ((float) width);
        }
        if (scrollX < leftBound) {
            if (leftAbsolute) {
                needsInvalidate = this.f501R.m2170a(Math.abs(leftBound - scrollX) / ((float) width));
            }
            scrollX = leftBound;
        } else if (scrollX > rightBound) {
            if (rightAbsolute) {
                needsInvalidate = this.f502S.m2170a(Math.abs(scrollX - rightBound) / ((float) width));
            }
            scrollX = rightBound;
        }
        this.f490G += scrollX - ((float) ((int) scrollX));
        scrollTo((int) scrollX, getScrollY());
        m900d((int) scrollX);
        return needsInvalidate;
    }

    /* renamed from: j */
    private C0244b m907j() {
        float scrollOffset;
        float marginOffset = 0.0f;
        int width = getClientWidth();
        if (width > 0) {
            scrollOffset = ((float) getScrollX()) / ((float) width);
        } else {
            scrollOffset = 0.0f;
        }
        if (width > 0) {
            marginOffset = ((float) this.f519p) / ((float) width);
        }
        int lastPos = -1;
        float lastOffset = 0.0f;
        float lastWidth = 0.0f;
        boolean first = true;
        C0244b lastItem = null;
        int i = 0;
        while (i < this.f508e.size()) {
            C0244b ii = (C0244b) this.f508e.get(i);
            if (!(first || ii.f466b == lastPos + 1)) {
                ii = this.f509f;
                ii.f469e = (lastOffset + lastWidth) + marginOffset;
                ii.f466b = lastPos + 1;
                ii.f468d = this.f511h.m1289b(ii.f466b);
                i--;
            }
            float offset = ii.f469e;
            float leftBound = offset;
            float rightBound = (ii.f468d + offset) + marginOffset;
            if (!first && scrollOffset < leftBound) {
                return lastItem;
            }
            if (scrollOffset < rightBound || i == this.f508e.size() - 1) {
                return ii;
            }
            first = false;
            lastPos = ii.f466b;
            lastOffset = offset;
            lastWidth = ii.f468d;
            lastItem = ii;
            i++;
        }
        return lastItem;
    }

    /* renamed from: a */
    private int m885a(int currentPage, float pageOffset, int velocity, int deltaX) {
        int targetPage;
        if (Math.abs(deltaX) <= this.f498O || Math.abs(velocity) <= this.f496M) {
            targetPage = (int) ((((float) currentPage) + pageOffset) + (currentPage >= this.f512i ? 0.4f : 0.6f));
        } else {
            targetPage = velocity > 0 ? currentPage : currentPage + 1;
        }
        if (this.f508e.size() <= 0) {
            return targetPage;
        }
        return Math.max(((C0244b) this.f508e.get(0)).f466b, Math.min(targetPage, ((C0244b) this.f508e.get(this.f508e.size() - 1)).f466b));
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        boolean needsInvalidate = false;
        int overScrollMode = ai.m1466a(this);
        if (overScrollMode == 0 || (overScrollMode == 1 && this.f511h != null && this.f511h.mo1147a() > 1)) {
            int restoreCount;
            int height;
            int width;
            if (!this.f501R.m2169a()) {
                restoreCount = canvas.save();
                height = (getHeight() - getPaddingTop()) - getPaddingBottom();
                width = getWidth();
                canvas.rotate(270.0f);
                canvas.translate((float) ((-height) + getPaddingTop()), this.f523t * ((float) width));
                this.f501R.m2168a(height, width);
                needsInvalidate = false | this.f501R.m2173a(canvas);
                canvas.restoreToCount(restoreCount);
            }
            if (!this.f502S.m2169a()) {
                restoreCount = canvas.save();
                width = getWidth();
                height = (getHeight() - getPaddingTop()) - getPaddingBottom();
                canvas.rotate(90.0f);
                canvas.translate((float) (-getPaddingTop()), (-(this.f524u + 1.0f)) * ((float) width));
                this.f502S.m2168a(height, width);
                needsInvalidate |= this.f502S.m2173a(canvas);
                canvas.restoreToCount(restoreCount);
            }
        } else {
            this.f501R.m2174b();
            this.f502S.m2174b();
        }
        if (needsInvalidate) {
            ai.m1481b(this);
        }
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f519p > 0 && this.f520q != null && this.f508e.size() > 0 && this.f511h != null) {
            int scrollX = getScrollX();
            int width = getWidth();
            float marginOffset = ((float) this.f519p) / ((float) width);
            int itemIndex = 0;
            C0244b ii = (C0244b) this.f508e.get(0);
            float offset = ii.f469e;
            int itemCount = this.f508e.size();
            int firstPos = ii.f466b;
            int lastPos = ((C0244b) this.f508e.get(itemCount - 1)).f466b;
            int pos = firstPos;
            while (pos < lastPos) {
                float drawAt;
                while (pos > ii.f466b && itemIndex < itemCount) {
                    itemIndex++;
                    ii = (C0244b) this.f508e.get(itemIndex);
                }
                if (pos == ii.f466b) {
                    drawAt = (ii.f469e + ii.f468d) * ((float) width);
                    offset = (ii.f469e + ii.f468d) + marginOffset;
                } else {
                    float widthFactor = this.f511h.m1289b(pos);
                    drawAt = (offset + widthFactor) * ((float) width);
                    offset += widthFactor + marginOffset;
                }
                if (((float) this.f519p) + drawAt > ((float) scrollX)) {
                    this.f520q.setBounds(Math.round(drawAt), this.f521r, Math.round(((float) this.f519p) + drawAt), this.f522s);
                    this.f520q.draw(canvas);
                }
                if (drawAt <= ((float) (scrollX + width))) {
                    pos++;
                } else {
                    return;
                }
            }
        }
    }

    /* renamed from: a */
    private void m892a(MotionEvent ev) {
        int pointerIndex = C0398u.m1820b(ev);
        if (C0398u.m1821b(ev, pointerIndex) == this.f494K) {
            int newPointerIndex = pointerIndex == 0 ? 1 : 0;
            this.f490G = C0398u.m1822c(ev, newPointerIndex);
            this.f494K = C0398u.m1821b(ev, newPointerIndex);
            if (this.f495L != null) {
                this.f495L.clear();
            }
        }
    }

    /* renamed from: k */
    private void m908k() {
        this.f485B = false;
        this.f486C = false;
        if (this.f495L != null) {
            this.f495L.recycle();
            this.f495L = null;
        }
    }

    private void setScrollingCacheEnabled(boolean enabled) {
        if (this.f528y != enabled) {
            this.f528y = enabled;
        }
    }

    public boolean canScrollHorizontally(int direction) {
        boolean z = true;
        if (this.f511h == null) {
            return false;
        }
        int width = getClientWidth();
        int scrollX = getScrollX();
        if (direction < 0) {
            if (scrollX <= ((int) (((float) width) * this.f523t))) {
                z = false;
            }
            return z;
        } else if (direction <= 0) {
            return false;
        } else {
            if (scrollX >= ((int) (((float) width) * this.f524u))) {
                z = false;
            }
            return z;
        }
    }

    /* renamed from: a */
    protected boolean m920a(View v, boolean checkV, int dx, int x, int y) {
        if (v instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) v;
            int scrollX = v.getScrollX();
            int scrollY = v.getScrollY();
            for (int i = group.getChildCount() - 1; i >= 0; i--) {
                View child = group.getChildAt(i);
                if (x + scrollX >= child.getLeft() && x + scrollX < child.getRight() && y + scrollY >= child.getTop() && y + scrollY < child.getBottom()) {
                    if (m920a(child, true, dx, (x + scrollX) - child.getLeft(), (y + scrollY) - child.getTop())) {
                        return true;
                    }
                }
            }
        }
        return checkV && ai.m1479a(v, -dx);
    }

    public boolean dispatchKeyEvent(KeyEvent event) {
        return super.dispatchKeyEvent(event) || m919a(event);
    }

    /* renamed from: a */
    public boolean m919a(KeyEvent event) {
        if (event.getAction() != 0) {
            return false;
        }
        switch (event.getKeyCode()) {
            case 21:
                return m925c(17);
            case 22:
                return m925c(66);
            case 61:
                if (VERSION.SDK_INT < 11) {
                    return false;
                }
                if (C0366g.m1734a(event)) {
                    return m925c(2);
                }
                if (C0366g.m1735a(event, 1)) {
                    return m925c(1);
                }
                return false;
            default:
                return false;
        }
    }

    /* renamed from: c */
    public boolean m925c(int direction) {
        View currentFocused = findFocus();
        if (currentFocused == this) {
            currentFocused = null;
        } else if (currentFocused != null) {
            boolean isChild = false;
            for (ViewPager parent = currentFocused.getParent(); parent instanceof ViewGroup; parent = parent.getParent()) {
                if (parent == this) {
                    isChild = true;
                    break;
                }
            }
            if (!isChild) {
                StringBuilder sb = new StringBuilder();
                sb.append(currentFocused.getClass().getSimpleName());
                for (ViewParent parent2 = currentFocused.getParent(); parent2 instanceof ViewGroup; parent2 = parent2.getParent()) {
                    sb.append(" => ").append(parent2.getClass().getSimpleName());
                }
                Log.e("ViewPager", "arrowScroll tried to find focus based on non-child current focused view " + sb.toString());
                currentFocused = null;
            }
        }
        boolean handled = false;
        View nextFocused = FocusFinder.getInstance().findNextFocus(this, currentFocused, direction);
        if (nextFocused == null || nextFocused == currentFocused) {
            if (direction == 17 || direction == 1) {
                handled = m926d();
            } else if (direction == 66 || direction == 2) {
                handled = m927e();
            }
        } else if (direction == 17) {
            handled = (currentFocused == null || m886a(this.f510g, nextFocused).left < m886a(this.f510g, currentFocused).left) ? nextFocused.requestFocus() : m926d();
        } else if (direction == 66) {
            handled = (currentFocused == null || m886a(this.f510g, nextFocused).left > m886a(this.f510g, currentFocused).left) ? nextFocused.requestFocus() : m927e();
        }
        if (handled) {
            playSoundEffect(SoundEffectConstants.getContantForFocusDirection(direction));
        }
        return handled;
    }

    /* renamed from: a */
    private Rect m886a(Rect outRect, View child) {
        if (outRect == null) {
            outRect = new Rect();
        }
        if (child == null) {
            outRect.set(0, 0, 0, 0);
        } else {
            outRect.left = child.getLeft();
            outRect.right = child.getRight();
            outRect.top = child.getTop();
            outRect.bottom = child.getBottom();
            ViewGroup parent = child.getParent();
            while ((parent instanceof ViewGroup) && parent != this) {
                ViewGroup group = parent;
                outRect.left += group.getLeft();
                outRect.right += group.getRight();
                outRect.top += group.getTop();
                outRect.bottom += group.getBottom();
                parent = group.getParent();
            }
        }
        return outRect;
    }

    /* renamed from: d */
    boolean m926d() {
        if (this.f512i <= 0) {
            return false;
        }
        m916a(this.f512i - 1, true);
        return true;
    }

    /* renamed from: e */
    boolean m927e() {
        if (this.f511h == null || this.f512i >= this.f511h.mo1147a() - 1) {
            return false;
        }
        m916a(this.f512i + 1, true);
        return true;
    }

    public void addFocusables(ArrayList<View> views, int direction, int focusableMode) {
        int focusableCount = views.size();
        int descendantFocusability = getDescendantFocusability();
        if (descendantFocusability != 393216) {
            for (int i = 0; i < getChildCount(); i++) {
                View child = getChildAt(i);
                if (child.getVisibility() == 0) {
                    C0244b ii = m911a(child);
                    if (ii != null && ii.f466b == this.f512i) {
                        child.addFocusables(views, direction, focusableMode);
                    }
                }
            }
        }
        if ((descendantFocusability == 262144 && focusableCount != views.size()) || !isFocusable()) {
            return;
        }
        if (((focusableMode & 1) != 1 || !isInTouchMode() || isFocusableInTouchMode()) && views != null) {
            views.add(this);
        }
    }

    public void addTouchables(ArrayList<View> views) {
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            if (child.getVisibility() == 0) {
                C0244b ii = m911a(child);
                if (ii != null && ii.f466b == this.f512i) {
                    child.addTouchables(views);
                }
            }
        }
    }

    protected boolean onRequestFocusInDescendants(int direction, Rect previouslyFocusedRect) {
        int index;
        int increment;
        int end;
        int count = getChildCount();
        if ((direction & 2) != 0) {
            index = 0;
            increment = 1;
            end = count;
        } else {
            index = count - 1;
            increment = -1;
            end = -1;
        }
        for (int i = index; i != end; i += increment) {
            View child = getChildAt(i);
            if (child.getVisibility() == 0) {
                C0244b ii = m911a(child);
                if (ii != null && ii.f466b == this.f512i && child.requestFocus(direction, previouslyFocusedRect)) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() == 4096) {
            return super.dispatchPopulateAccessibilityEvent(event);
        }
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View child = getChildAt(i);
            if (child.getVisibility() == 0) {
                C0244b ii = m911a(child);
                if (ii != null && ii.f466b == this.f512i && child.dispatchPopulateAccessibilityEvent(event)) {
                    return true;
                }
            }
        }
        return false;
    }

    protected LayoutParams generateDefaultLayoutParams() {
        return new C0245c();
    }

    protected LayoutParams generateLayoutParams(LayoutParams p) {
        return generateDefaultLayoutParams();
    }

    protected boolean checkLayoutParams(LayoutParams p) {
        return (p instanceof C0245c) && super.checkLayoutParams(p);
    }

    public LayoutParams generateLayoutParams(AttributeSet attrs) {
        return new C0245c(getContext(), attrs);
    }
}

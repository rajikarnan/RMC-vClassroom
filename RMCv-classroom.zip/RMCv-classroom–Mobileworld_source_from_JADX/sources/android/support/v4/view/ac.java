package android.support.v4.view;

import android.view.View;

/* compiled from: OnApplyWindowInsetsListener */
public interface ac {
    bi onApplyWindowInsets(View view, bi biVar);
}

package android.support.v4.view;

import android.animation.ValueAnimator;
import android.graphics.Paint;
import android.view.View;
import android.view.ViewParent;

/* compiled from: ViewCompatHC */
class am {
    /* renamed from: a */
    static long m1527a() {
        return ValueAnimator.getFrameDelay();
    }

    /* renamed from: a */
    public static void m1530a(View view, int layerType, Paint paint) {
        view.setLayerType(layerType, paint);
    }

    /* renamed from: a */
    public static int m1526a(View view) {
        return view.getLayerType();
    }

    /* renamed from: a */
    public static int m1525a(int size, int measureSpec, int childMeasuredState) {
        return View.resolveSizeAndState(size, measureSpec, childMeasuredState);
    }

    /* renamed from: b */
    public static int m1532b(View view) {
        return view.getMeasuredWidthAndState();
    }

    /* renamed from: c */
    public static int m1536c(View view) {
        return view.getMeasuredState();
    }

    /* renamed from: d */
    public static float m1538d(View view) {
        return view.getTranslationY();
    }

    /* renamed from: e */
    public static float m1540e(View view) {
        return view.getScaleX();
    }

    /* renamed from: a */
    public static void m1528a(View view, float value) {
        view.setTranslationY(value);
    }

    /* renamed from: b */
    public static void m1533b(View view, float value) {
        view.setAlpha(value);
    }

    /* renamed from: c */
    public static void m1537c(View view, float value) {
        view.setScaleX(value);
    }

    /* renamed from: d */
    public static void m1539d(View view, float value) {
        view.setScaleY(value);
    }

    /* renamed from: f */
    public static void m1541f(View view) {
        view.jumpDrawablesToCurrentState();
    }

    /* renamed from: a */
    public static void m1531a(View view, boolean enabled) {
        view.setSaveFromParentEnabled(enabled);
    }

    /* renamed from: b */
    public static void m1535b(View view, boolean activated) {
        view.setActivated(activated);
    }

    /* renamed from: a */
    static void m1529a(View view, int offset) {
        view.offsetTopAndBottom(offset);
        m1542g(view);
        ViewParent parent = view.getParent();
        if (parent instanceof View) {
            m1542g((View) parent);
        }
    }

    /* renamed from: b */
    static void m1534b(View view, int offset) {
        view.offsetLeftAndRight(offset);
        m1542g(view);
        ViewParent parent = view.getParent();
        if (parent instanceof View) {
            m1542g((View) parent);
        }
    }

    /* renamed from: g */
    private static void m1542g(View view) {
        float y = view.getTranslationY();
        view.setTranslationY(1.0f + y);
        view.setTranslationY(y);
    }
}

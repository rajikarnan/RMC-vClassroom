package android.support.v4.view;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.view.View;
import android.view.View.OnApplyWindowInsetsListener;
import android.view.ViewParent;
import android.view.WindowInsets;

/* compiled from: ViewCompatLollipop */
class as {
    /* renamed from: a */
    private static ThreadLocal<Rect> f582a;

    /* renamed from: a */
    public static void m1563a(View view) {
        view.requestApplyInsets();
    }

    /* renamed from: a */
    public static void m1564a(View view, float elevation) {
        view.setElevation(elevation);
    }

    /* renamed from: b */
    public static float m1569b(View view) {
        return view.getElevation();
    }

    /* renamed from: a */
    public static void m1568a(View view, final ac listener) {
        if (listener == null) {
            view.setOnApplyWindowInsetsListener(null);
        } else {
            view.setOnApplyWindowInsetsListener(new OnApplyWindowInsetsListener() {
                public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
                    return ((bj) listener.onApplyWindowInsets(view, new bj(windowInsets))).m1713f();
                }
            });
        }
    }

    /* renamed from: c */
    static ColorStateList m1572c(View view) {
        return view.getBackgroundTintList();
    }

    /* renamed from: a */
    static void m1566a(View view, ColorStateList tintList) {
        view.setBackgroundTintList(tintList);
        if (VERSION.SDK_INT == 21) {
            Drawable background = view.getBackground();
            boolean hasTint = (view.getBackgroundTintList() == null || view.getBackgroundTintMode() == null) ? false : true;
            if (background != null && hasTint) {
                if (background.isStateful()) {
                    background.setState(view.getDrawableState());
                }
                view.setBackground(background);
            }
        }
    }

    /* renamed from: d */
    static Mode m1573d(View view) {
        return view.getBackgroundTintMode();
    }

    /* renamed from: a */
    static void m1567a(View view, Mode mode) {
        view.setBackgroundTintMode(mode);
        if (VERSION.SDK_INT == 21) {
            Drawable background = view.getBackground();
            boolean hasTint = (view.getBackgroundTintList() == null || view.getBackgroundTintMode() == null) ? false : true;
            if (background != null && hasTint) {
                if (background.isStateful()) {
                    background.setState(view.getDrawableState());
                }
                view.setBackground(background);
            }
        }
    }

    /* renamed from: a */
    public static bi m1562a(View v, bi insets) {
        if (!(insets instanceof bj)) {
            return insets;
        }
        WindowInsets unwrapped = ((bj) insets).m1713f();
        WindowInsets result = v.onApplyWindowInsets(unwrapped);
        if (result != unwrapped) {
            return new bj(result);
        }
        return insets;
    }

    /* renamed from: b */
    public static bi m1570b(View v, bi insets) {
        if (!(insets instanceof bj)) {
            return insets;
        }
        WindowInsets unwrapped = ((bj) insets).m1713f();
        WindowInsets result = v.dispatchApplyWindowInsets(unwrapped);
        if (result != unwrapped) {
            return new bj(result);
        }
        return insets;
    }

    /* renamed from: e */
    public static boolean m1574e(View view) {
        return view.isNestedScrollingEnabled();
    }

    /* renamed from: f */
    public static void m1575f(View view) {
        view.stopNestedScroll();
    }

    /* renamed from: a */
    static void m1565a(View view, int offset) {
        Rect parentRect = m1561a();
        boolean needInvalidateWorkaround = false;
        ViewParent parent = view.getParent();
        if (parent instanceof View) {
            View p = (View) parent;
            parentRect.set(p.getLeft(), p.getTop(), p.getRight(), p.getBottom());
            needInvalidateWorkaround = !parentRect.intersects(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
        am.m1529a(view, offset);
        if (needInvalidateWorkaround && parentRect.intersect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom())) {
            ((View) parent).invalidate(parentRect);
        }
    }

    /* renamed from: b */
    static void m1571b(View view, int offset) {
        Rect parentRect = m1561a();
        boolean needInvalidateWorkaround = false;
        ViewParent parent = view.getParent();
        if (parent instanceof View) {
            View p = (View) parent;
            parentRect.set(p.getLeft(), p.getTop(), p.getRight(), p.getBottom());
            needInvalidateWorkaround = !parentRect.intersects(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
        am.m1534b(view, offset);
        if (needInvalidateWorkaround && parentRect.intersect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom())) {
            ((View) parent).invalidate(parentRect);
        }
    }

    /* renamed from: a */
    private static Rect m1561a() {
        if (f582a == null) {
            f582a = new ThreadLocal();
        }
        Rect rect = (Rect) f582a.get();
        if (rect == null) {
            rect = new Rect();
            f582a.set(rect);
        }
        rect.setEmpty();
        return rect;
    }
}

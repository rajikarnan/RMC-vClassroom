package android.support.v4.view.p013b;

import android.view.animation.Interpolator;

/* compiled from: LookupTableInterpolator */
/* renamed from: android.support.v4.view.b.b */
abstract class C0336b implements Interpolator {
    /* renamed from: a */
    private final float[] f587a;
    /* renamed from: b */
    private final float f588b = (1.0f / ((float) (this.f587a.length - 1)));

    public C0336b(float[] values) {
        this.f587a = values;
    }

    public float getInterpolation(float input) {
        if (input >= 1.0f) {
            return 1.0f;
        }
        if (input <= 0.0f) {
            return 0.0f;
        }
        int position = Math.min((int) (((float) (this.f587a.length - 1)) * input), this.f587a.length - 2);
        return this.f587a[position] + ((this.f587a[position + 1] - this.f587a[position]) * ((input - (((float) position) * this.f588b)) / this.f588b));
    }
}

package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.ViewGroup.MarginLayoutParams;

/* compiled from: MarginLayoutParamsCompat */
/* renamed from: android.support.v4.view.o */
public final class C0382o {
    /* renamed from: a */
    static final C0379a f616a;

    /* compiled from: MarginLayoutParamsCompat */
    /* renamed from: android.support.v4.view.o$a */
    interface C0379a {
        /* renamed from: a */
        int mo332a(MarginLayoutParams marginLayoutParams);

        /* renamed from: b */
        int mo333b(MarginLayoutParams marginLayoutParams);
    }

    /* compiled from: MarginLayoutParamsCompat */
    /* renamed from: android.support.v4.view.o$b */
    static class C0380b implements C0379a {
        C0380b() {
        }

        /* renamed from: a */
        public int mo332a(MarginLayoutParams lp) {
            return lp.leftMargin;
        }

        /* renamed from: b */
        public int mo333b(MarginLayoutParams lp) {
            return lp.rightMargin;
        }
    }

    /* compiled from: MarginLayoutParamsCompat */
    /* renamed from: android.support.v4.view.o$c */
    static class C0381c implements C0379a {
        C0381c() {
        }

        /* renamed from: a */
        public int mo332a(MarginLayoutParams lp) {
            return C0383p.m1762a(lp);
        }

        /* renamed from: b */
        public int mo333b(MarginLayoutParams lp) {
            return C0383p.m1763b(lp);
        }
    }

    static {
        if (VERSION.SDK_INT >= 17) {
            f616a = new C0381c();
        } else {
            f616a = new C0380b();
        }
    }

    /* renamed from: a */
    public static int m1760a(MarginLayoutParams lp) {
        return f616a.mo332a(lp);
    }

    /* renamed from: b */
    public static int m1761b(MarginLayoutParams lp) {
        return f616a.mo333b(lp);
    }
}

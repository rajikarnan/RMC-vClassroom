package android.support.v4.view;

/* compiled from: WindowInsetsCompat */
public class bi {
    bi() {
    }

    /* renamed from: a */
    public int mo319a() {
        return 0;
    }

    /* renamed from: b */
    public int mo321b() {
        return 0;
    }

    /* renamed from: c */
    public int mo322c() {
        return 0;
    }

    /* renamed from: d */
    public int mo323d() {
        return 0;
    }

    /* renamed from: e */
    public boolean mo324e() {
        return false;
    }

    /* renamed from: a */
    public bi mo320a(int left, int top, int right, int bottom) {
        return this;
    }
}

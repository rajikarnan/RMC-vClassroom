package android.support.v4.view;

/* compiled from: MenuCompat */
/* renamed from: android.support.v4.view.q */
public final class C0384q {
    private C0384q() {
    }
}

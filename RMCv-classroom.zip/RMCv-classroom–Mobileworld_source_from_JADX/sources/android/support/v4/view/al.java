package android.support.v4.view;

import android.view.View;

/* compiled from: ViewCompatGingerbread */
class al {
    /* renamed from: a */
    public static int m1524a(View v) {
        return v.getOverScrollMode();
    }
}

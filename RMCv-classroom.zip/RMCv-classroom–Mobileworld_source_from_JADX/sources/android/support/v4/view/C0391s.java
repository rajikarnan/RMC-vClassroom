package android.support.v4.view;

import android.view.MenuItem;
import android.view.View;

/* compiled from: MenuItemCompatHoneycomb */
/* renamed from: android.support.v4.view.s */
class C0391s {
    /* renamed from: a */
    public static void m1793a(MenuItem item, int actionEnum) {
        item.setShowAsAction(actionEnum);
    }

    /* renamed from: a */
    public static MenuItem m1791a(MenuItem item, View view) {
        return item.setActionView(view);
    }

    /* renamed from: b */
    public static MenuItem m1794b(MenuItem item, int resId) {
        return item.setActionView(resId);
    }

    /* renamed from: a */
    public static View m1792a(MenuItem item) {
        return item.getActionView();
    }
}

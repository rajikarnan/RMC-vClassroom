package android.support.v4.view;

import android.os.Build.VERSION;
import android.support.v4.p006b.p007a.C0178b;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

/* compiled from: MenuItemCompat */
/* renamed from: android.support.v4.view.r */
public final class C0390r {
    /* renamed from: a */
    static final C0385d f617a;

    /* compiled from: MenuItemCompat */
    /* renamed from: android.support.v4.view.r$d */
    interface C0385d {
        /* renamed from: a */
        MenuItem mo334a(MenuItem menuItem, View view);

        /* renamed from: a */
        View mo335a(MenuItem menuItem);

        /* renamed from: a */
        void mo336a(MenuItem menuItem, int i);

        /* renamed from: b */
        MenuItem mo337b(MenuItem menuItem, int i);

        /* renamed from: b */
        boolean mo338b(MenuItem menuItem);

        /* renamed from: c */
        boolean mo339c(MenuItem menuItem);
    }

    /* compiled from: MenuItemCompat */
    /* renamed from: android.support.v4.view.r$a */
    static class C0386a implements C0385d {
        C0386a() {
        }

        /* renamed from: a */
        public void mo336a(MenuItem item, int actionEnum) {
        }

        /* renamed from: a */
        public MenuItem mo334a(MenuItem item, View view) {
            return item;
        }

        /* renamed from: b */
        public MenuItem mo337b(MenuItem item, int resId) {
            return item;
        }

        /* renamed from: a */
        public View mo335a(MenuItem item) {
            return null;
        }

        /* renamed from: b */
        public boolean mo338b(MenuItem item) {
            return false;
        }

        /* renamed from: c */
        public boolean mo339c(MenuItem item) {
            return false;
        }
    }

    /* compiled from: MenuItemCompat */
    /* renamed from: android.support.v4.view.r$b */
    static class C0387b implements C0385d {
        C0387b() {
        }

        /* renamed from: a */
        public void mo336a(MenuItem item, int actionEnum) {
            C0391s.m1793a(item, actionEnum);
        }

        /* renamed from: a */
        public MenuItem mo334a(MenuItem item, View view) {
            return C0391s.m1791a(item, view);
        }

        /* renamed from: b */
        public MenuItem mo337b(MenuItem item, int resId) {
            return C0391s.m1794b(item, resId);
        }

        /* renamed from: a */
        public View mo335a(MenuItem item) {
            return C0391s.m1792a(item);
        }

        /* renamed from: b */
        public boolean mo338b(MenuItem item) {
            return false;
        }

        /* renamed from: c */
        public boolean mo339c(MenuItem item) {
            return false;
        }
    }

    /* compiled from: MenuItemCompat */
    /* renamed from: android.support.v4.view.r$c */
    static class C0388c extends C0387b {
        C0388c() {
        }

        /* renamed from: b */
        public boolean mo338b(MenuItem item) {
            return C0392t.m1795a(item);
        }

        /* renamed from: c */
        public boolean mo339c(MenuItem item) {
            return C0392t.m1796b(item);
        }
    }

    /* compiled from: MenuItemCompat */
    /* renamed from: android.support.v4.view.r$e */
    public interface C0389e {
        boolean onMenuItemActionCollapse(MenuItem menuItem);

        boolean onMenuItemActionExpand(MenuItem menuItem);
    }

    static {
        int version = VERSION.SDK_INT;
        if (version >= 14) {
            f617a = new C0388c();
        } else if (version >= 11) {
            f617a = new C0387b();
        } else {
            f617a = new C0386a();
        }
    }

    /* renamed from: a */
    public static void m1787a(MenuItem item, int actionEnum) {
        if (item instanceof C0178b) {
            ((C0178b) item).setShowAsAction(actionEnum);
        } else {
            f617a.mo336a(item, actionEnum);
        }
    }

    /* renamed from: a */
    public static MenuItem m1785a(MenuItem item, View view) {
        if (item instanceof C0178b) {
            return ((C0178b) item).setActionView(view);
        }
        return f617a.mo334a(item, view);
    }

    /* renamed from: b */
    public static MenuItem m1788b(MenuItem item, int resId) {
        if (item instanceof C0178b) {
            return ((C0178b) item).setActionView(resId);
        }
        return f617a.mo337b(item, resId);
    }

    /* renamed from: a */
    public static View m1786a(MenuItem item) {
        if (item instanceof C0178b) {
            return ((C0178b) item).getActionView();
        }
        return f617a.mo335a(item);
    }

    /* renamed from: a */
    public static MenuItem m1784a(MenuItem item, C0356d provider) {
        if (item instanceof C0178b) {
            return ((C0178b) item).setSupportActionProvider(provider);
        }
        Log.w("MenuItemCompat", "setActionProvider: item does not implement SupportMenuItem; ignoring");
        return item;
    }

    /* renamed from: b */
    public static boolean m1789b(MenuItem item) {
        if (item instanceof C0178b) {
            return ((C0178b) item).expandActionView();
        }
        return f617a.mo338b(item);
    }

    /* renamed from: c */
    public static boolean m1790c(MenuItem item) {
        if (item instanceof C0178b) {
            return ((C0178b) item).isActionViewExpanded();
        }
        return f617a.mo339c(item);
    }
}

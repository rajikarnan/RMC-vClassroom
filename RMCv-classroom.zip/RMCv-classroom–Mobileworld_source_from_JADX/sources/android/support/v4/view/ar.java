package android.support.v4.view;

import android.view.View;

/* compiled from: ViewCompatKitKat */
class ar {
    /* renamed from: a */
    public static boolean m1559a(View view) {
        return view.isLaidOut();
    }

    /* renamed from: b */
    public static boolean m1560b(View view) {
        return view.isAttachedToWindow();
    }
}

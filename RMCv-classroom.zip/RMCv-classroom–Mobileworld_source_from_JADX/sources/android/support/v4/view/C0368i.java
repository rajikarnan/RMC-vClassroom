package android.support.v4.view;

import android.view.KeyEvent;

/* compiled from: KeyEventCompatHoneycomb */
/* renamed from: android.support.v4.view.i */
class C0368i {
    /* renamed from: a */
    public static int m1738a(int metaState) {
        return KeyEvent.normalizeMetaState(metaState);
    }

    /* renamed from: a */
    public static boolean m1739a(int metaState, int modifiers) {
        return KeyEvent.metaStateHasModifiers(metaState, modifiers);
    }

    /* renamed from: b */
    public static boolean m1740b(int metaState) {
        return KeyEvent.metaStateHasNoModifiers(metaState);
    }
}

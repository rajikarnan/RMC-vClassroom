package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.View;
import android.view.ViewParent;

/* compiled from: ViewParentCompat */
public final class az {
    /* renamed from: a */
    static final C0330b f585a;

    /* compiled from: ViewParentCompat */
    /* renamed from: android.support.v4.view.az$b */
    interface C0330b {
        /* renamed from: a */
        void mo298a(ViewParent viewParent, View view);

        /* renamed from: a */
        void mo299a(ViewParent viewParent, View view, int i, int i2, int i3, int i4);

        /* renamed from: a */
        void mo300a(ViewParent viewParent, View view, int i, int i2, int[] iArr);

        /* renamed from: a */
        boolean mo301a(ViewParent viewParent, View view, float f, float f2);

        /* renamed from: a */
        boolean mo302a(ViewParent viewParent, View view, float f, float f2, boolean z);

        /* renamed from: a */
        boolean mo303a(ViewParent viewParent, View view, View view2, int i);

        /* renamed from: b */
        void mo304b(ViewParent viewParent, View view, View view2, int i);
    }

    /* compiled from: ViewParentCompat */
    /* renamed from: android.support.v4.view.az$e */
    static class C0331e implements C0330b {
        C0331e() {
        }

        /* renamed from: a */
        public boolean mo303a(ViewParent parent, View child, View target, int nestedScrollAxes) {
            if (parent instanceof aa) {
                return ((aa) parent).onStartNestedScroll(child, target, nestedScrollAxes);
            }
            return false;
        }

        /* renamed from: b */
        public void mo304b(ViewParent parent, View child, View target, int nestedScrollAxes) {
            if (parent instanceof aa) {
                ((aa) parent).onNestedScrollAccepted(child, target, nestedScrollAxes);
            }
        }

        /* renamed from: a */
        public void mo298a(ViewParent parent, View target) {
            if (parent instanceof aa) {
                ((aa) parent).onStopNestedScroll(target);
            }
        }

        /* renamed from: a */
        public void mo299a(ViewParent parent, View target, int dxConsumed, int dyConsumed, int dxUnconsumed, int dyUnconsumed) {
            if (parent instanceof aa) {
                ((aa) parent).onNestedScroll(target, dxConsumed, dyConsumed, dxUnconsumed, dyUnconsumed);
            }
        }

        /* renamed from: a */
        public void mo300a(ViewParent parent, View target, int dx, int dy, int[] consumed) {
            if (parent instanceof aa) {
                ((aa) parent).onNestedPreScroll(target, dx, dy, consumed);
            }
        }

        /* renamed from: a */
        public boolean mo302a(ViewParent parent, View target, float velocityX, float velocityY, boolean consumed) {
            if (parent instanceof aa) {
                return ((aa) parent).onNestedFling(target, velocityX, velocityY, consumed);
            }
            return false;
        }

        /* renamed from: a */
        public boolean mo301a(ViewParent parent, View target, float velocityX, float velocityY) {
            if (parent instanceof aa) {
                return ((aa) parent).onNestedPreFling(target, velocityX, velocityY);
            }
            return false;
        }
    }

    /* compiled from: ViewParentCompat */
    /* renamed from: android.support.v4.view.az$a */
    static class C0332a extends C0331e {
        C0332a() {
        }
    }

    /* compiled from: ViewParentCompat */
    /* renamed from: android.support.v4.view.az$c */
    static class C0333c extends C0332a {
        C0333c() {
        }
    }

    /* compiled from: ViewParentCompat */
    /* renamed from: android.support.v4.view.az$d */
    static class C0334d extends C0333c {
        C0334d() {
        }

        /* renamed from: a */
        public boolean mo303a(ViewParent parent, View child, View target, int nestedScrollAxes) {
            return ba.m1637a(parent, child, target, nestedScrollAxes);
        }

        /* renamed from: b */
        public void mo304b(ViewParent parent, View child, View target, int nestedScrollAxes) {
            ba.m1638b(parent, child, target, nestedScrollAxes);
        }

        /* renamed from: a */
        public void mo298a(ViewParent parent, View target) {
            ba.m1632a(parent, target);
        }

        /* renamed from: a */
        public void mo299a(ViewParent parent, View target, int dxConsumed, int dyConsumed, int dxUnconsumed, int dyUnconsumed) {
            ba.m1633a(parent, target, dxConsumed, dyConsumed, dxUnconsumed, dyUnconsumed);
        }

        /* renamed from: a */
        public void mo300a(ViewParent parent, View target, int dx, int dy, int[] consumed) {
            ba.m1634a(parent, target, dx, dy, consumed);
        }

        /* renamed from: a */
        public boolean mo302a(ViewParent parent, View target, float velocityX, float velocityY, boolean consumed) {
            return ba.m1636a(parent, target, velocityX, velocityY, consumed);
        }

        /* renamed from: a */
        public boolean mo301a(ViewParent parent, View target, float velocityX, float velocityY) {
            return ba.m1635a(parent, target, velocityX, velocityY);
        }
    }

    static {
        int version = VERSION.SDK_INT;
        if (version >= 21) {
            f585a = new C0334d();
        } else if (version >= 19) {
            f585a = new C0333c();
        } else if (version >= 14) {
            f585a = new C0332a();
        } else {
            f585a = new C0331e();
        }
    }

    /* renamed from: a */
    public static boolean m1621a(ViewParent parent, View child, View target, int nestedScrollAxes) {
        return f585a.mo303a(parent, child, target, nestedScrollAxes);
    }

    /* renamed from: b */
    public static void m1622b(ViewParent parent, View child, View target, int nestedScrollAxes) {
        f585a.mo304b(parent, child, target, nestedScrollAxes);
    }

    /* renamed from: a */
    public static void m1616a(ViewParent parent, View target) {
        f585a.mo298a(parent, target);
    }

    /* renamed from: a */
    public static void m1617a(ViewParent parent, View target, int dxConsumed, int dyConsumed, int dxUnconsumed, int dyUnconsumed) {
        f585a.mo299a(parent, target, dxConsumed, dyConsumed, dxUnconsumed, dyUnconsumed);
    }

    /* renamed from: a */
    public static void m1618a(ViewParent parent, View target, int dx, int dy, int[] consumed) {
        f585a.mo300a(parent, target, dx, dy, consumed);
    }

    /* renamed from: a */
    public static boolean m1620a(ViewParent parent, View target, float velocityX, float velocityY, boolean consumed) {
        return f585a.mo302a(parent, target, velocityX, velocityY, consumed);
    }

    /* renamed from: a */
    public static boolean m1619a(ViewParent parent, View target, float velocityX, float velocityY) {
        return f585a.mo301a(parent, target, velocityX, velocityY);
    }
}

package android.support.v4.view;

/* compiled from: NestedScrollingChild */
/* renamed from: android.support.v4.view.y */
public interface C0402y {
    boolean isNestedScrollingEnabled();

    void stopNestedScroll();
}

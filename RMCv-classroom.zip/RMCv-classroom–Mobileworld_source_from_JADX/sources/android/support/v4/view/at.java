package android.support.v4.view;

import android.view.View;

/* compiled from: ViewCompatMarshmallow */
class at {
    /* renamed from: a */
    public static void m1577a(View view, int indicators, int mask) {
        view.setScrollIndicators(indicators, mask);
    }

    /* renamed from: a */
    static void m1576a(View view, int offset) {
        view.offsetTopAndBottom(offset);
    }

    /* renamed from: b */
    static void m1578b(View view, int offset) {
        view.offsetLeftAndRight(offset);
    }
}

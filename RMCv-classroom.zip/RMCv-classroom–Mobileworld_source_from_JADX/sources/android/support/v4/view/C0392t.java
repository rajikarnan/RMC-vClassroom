package android.support.v4.view;

import android.view.MenuItem;

/* compiled from: MenuItemCompatIcs */
/* renamed from: android.support.v4.view.t */
class C0392t {
    /* renamed from: a */
    public static boolean m1795a(MenuItem item) {
        return item.expandActionView();
    }

    /* renamed from: b */
    public static boolean m1796b(MenuItem item) {
        return item.isActionViewExpanded();
    }
}

package android.support.v4.view;

import android.view.MotionEvent;

/* compiled from: MotionEventCompatEclair */
/* renamed from: android.support.v4.view.v */
class C0399v {
    /* renamed from: a */
    public static int m1828a(MotionEvent event, int pointerId) {
        return event.findPointerIndex(pointerId);
    }

    /* renamed from: b */
    public static int m1829b(MotionEvent event, int pointerIndex) {
        return event.getPointerId(pointerIndex);
    }

    /* renamed from: c */
    public static float m1830c(MotionEvent event, int pointerIndex) {
        return event.getX(pointerIndex);
    }

    /* renamed from: d */
    public static float m1831d(MotionEvent event, int pointerIndex) {
        return event.getY(pointerIndex);
    }

    /* renamed from: a */
    public static int m1827a(MotionEvent event) {
        return event.getPointerCount();
    }
}

package android.support.v4.view;

import android.content.res.ColorStateList;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.os.Build.VERSION;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.util.WeakHashMap;

/* compiled from: ViewCompat */
public final class ai {
    /* renamed from: a */
    static final C0305m f577a;

    /* compiled from: ViewCompat */
    /* renamed from: android.support.v4.view.ai$m */
    interface C0305m {
        /* renamed from: a */
        int mo245a(int i, int i2, int i3);

        /* renamed from: a */
        int mo246a(View view);

        /* renamed from: a */
        bi mo247a(View view, bi biVar);

        /* renamed from: a */
        void mo248a(View view, float f);

        /* renamed from: a */
        void mo249a(View view, int i, int i2);

        /* renamed from: a */
        void mo250a(View view, int i, Paint paint);

        /* renamed from: a */
        void mo251a(View view, ColorStateList colorStateList);

        /* renamed from: a */
        void mo252a(View view, Mode mode);

        /* renamed from: a */
        void mo253a(View view, C0246a c0246a);

        /* renamed from: a */
        void mo254a(View view, ac acVar);

        /* renamed from: a */
        void mo255a(View view, Runnable runnable);

        /* renamed from: a */
        void mo256a(View view, Runnable runnable, long j);

        /* renamed from: a */
        void mo257a(View view, boolean z);

        /* renamed from: a */
        void mo258a(ViewGroup viewGroup, boolean z);

        /* renamed from: a */
        boolean mo259a(View view, int i);

        /* renamed from: b */
        bi mo260b(View view, bi biVar);

        /* renamed from: b */
        void mo261b(View view);

        /* renamed from: b */
        void mo262b(View view, float f);

        /* renamed from: b */
        void mo263b(View view, boolean z);

        /* renamed from: b */
        boolean mo264b(View view, int i);

        /* renamed from: c */
        int mo265c(View view);

        /* renamed from: c */
        void mo266c(View view, float f);

        /* renamed from: c */
        void mo267c(View view, int i);

        /* renamed from: d */
        int mo268d(View view);

        /* renamed from: d */
        void mo269d(View view, float f);

        /* renamed from: d */
        void mo270d(View view, int i);

        /* renamed from: e */
        int mo271e(View view);

        /* renamed from: e */
        void mo272e(View view, float f);

        /* renamed from: e */
        void mo273e(View view, int i);

        /* renamed from: f */
        ViewParent mo274f(View view);

        /* renamed from: g */
        int mo275g(View view);

        /* renamed from: h */
        int mo276h(View view);

        /* renamed from: i */
        boolean mo277i(View view);

        /* renamed from: j */
        float mo278j(View view);

        /* renamed from: k */
        float mo279k(View view);

        /* renamed from: l */
        int mo280l(View view);

        /* renamed from: m */
        bb mo281m(View view);

        /* renamed from: n */
        int mo282n(View view);

        /* renamed from: o */
        void mo283o(View view);

        /* renamed from: p */
        float mo284p(View view);

        /* renamed from: q */
        boolean mo285q(View view);

        /* renamed from: r */
        void mo286r(View view);

        /* renamed from: s */
        boolean mo287s(View view);

        /* renamed from: t */
        ColorStateList mo288t(View view);

        /* renamed from: u */
        Mode mo289u(View view);

        /* renamed from: v */
        void mo290v(View view);

        /* renamed from: w */
        boolean mo291w(View view);

        /* renamed from: x */
        boolean mo292x(View view);

        /* renamed from: y */
        boolean mo293y(View view);
    }

    /* compiled from: ViewCompat */
    /* renamed from: android.support.v4.view.ai$a */
    static class C0306a implements C0305m {
        /* renamed from: a */
        WeakHashMap<View, bb> f575a = null;

        C0306a() {
        }

        /* renamed from: a */
        public boolean mo259a(View v, int direction) {
            return (v instanceof ae) && m1357a((ae) v, direction);
        }

        /* renamed from: b */
        public boolean mo264b(View v, int direction) {
            return (v instanceof ae) && m1358b((ae) v, direction);
        }

        /* renamed from: a */
        public int mo246a(View v) {
            return 2;
        }

        /* renamed from: a */
        public void mo253a(View v, C0246a delegate) {
        }

        /* renamed from: b */
        public void mo261b(View view) {
            view.invalidate();
        }

        /* renamed from: a */
        public void mo255a(View view, Runnable action) {
            view.postDelayed(action, mo294a());
        }

        /* renamed from: a */
        public void mo256a(View view, Runnable action, long delayMillis) {
            view.postDelayed(action, mo294a() + delayMillis);
        }

        /* renamed from: a */
        long mo294a() {
            return 10;
        }

        /* renamed from: c */
        public int mo265c(View view) {
            return 0;
        }

        /* renamed from: c */
        public void mo267c(View view, int mode) {
        }

        /* renamed from: a */
        public void mo250a(View view, int layerType, Paint paint) {
        }

        /* renamed from: d */
        public int mo268d(View view) {
            return 0;
        }

        /* renamed from: e */
        public int mo271e(View view) {
            return 0;
        }

        /* renamed from: f */
        public ViewParent mo274f(View view) {
            return view.getParent();
        }

        /* renamed from: a */
        public int mo245a(int size, int measureSpec, int childMeasuredState) {
            return View.resolveSize(size, measureSpec);
        }

        /* renamed from: g */
        public int mo275g(View view) {
            return view.getMeasuredWidth();
        }

        /* renamed from: h */
        public int mo276h(View view) {
            return 0;
        }

        /* renamed from: i */
        public boolean mo277i(View view) {
            return true;
        }

        /* renamed from: j */
        public float mo278j(View view) {
            return 0.0f;
        }

        /* renamed from: k */
        public float mo279k(View view) {
            return 0.0f;
        }

        /* renamed from: l */
        public int mo280l(View view) {
            return aj.m1521d(view);
        }

        /* renamed from: m */
        public bb mo281m(View view) {
            return new bb(view);
        }

        /* renamed from: a */
        public void mo248a(View view, float value) {
        }

        /* renamed from: b */
        public void mo262b(View view, float value) {
        }

        /* renamed from: c */
        public void mo266c(View view, float value) {
        }

        /* renamed from: d */
        public void mo269d(View view, float value) {
        }

        /* renamed from: n */
        public int mo282n(View view) {
            return 0;
        }

        /* renamed from: o */
        public void mo283o(View view) {
        }

        /* renamed from: e */
        public void mo272e(View view, float elevation) {
        }

        /* renamed from: p */
        public float mo284p(View view) {
            return 0.0f;
        }

        /* renamed from: a */
        public void mo258a(ViewGroup viewGroup, boolean enabled) {
        }

        /* renamed from: q */
        public boolean mo285q(View view) {
            return false;
        }

        /* renamed from: r */
        public void mo286r(View view) {
        }

        /* renamed from: a */
        public void mo254a(View view, ac listener) {
        }

        /* renamed from: a */
        public bi mo247a(View v, bi insets) {
            return insets;
        }

        /* renamed from: b */
        public bi mo260b(View v, bi insets) {
            return insets;
        }

        /* renamed from: a */
        public void mo257a(View v, boolean enabled) {
        }

        /* renamed from: b */
        public void mo263b(View view, boolean activated) {
        }

        /* renamed from: s */
        public boolean mo287s(View view) {
            if (view instanceof C0402y) {
                return ((C0402y) view).isNestedScrollingEnabled();
            }
            return false;
        }

        /* renamed from: t */
        public ColorStateList mo288t(View view) {
            return aj.m1514a(view);
        }

        /* renamed from: a */
        public void mo251a(View view, ColorStateList tintList) {
            aj.m1516a(view, tintList);
        }

        /* renamed from: a */
        public void mo252a(View view, Mode mode) {
            aj.m1517a(view, mode);
        }

        /* renamed from: u */
        public Mode mo289u(View view) {
            return aj.m1518b(view);
        }

        /* renamed from: a */
        private boolean m1357a(ae view, int direction) {
            int offset = view.computeHorizontalScrollOffset();
            int range = view.computeHorizontalScrollRange() - view.computeHorizontalScrollExtent();
            if (range == 0) {
                return false;
            }
            if (direction < 0) {
                if (offset <= 0) {
                    return false;
                }
                return true;
            } else if (offset >= range - 1) {
                return false;
            } else {
                return true;
            }
        }

        /* renamed from: b */
        private boolean m1358b(ae view, int direction) {
            int offset = view.computeVerticalScrollOffset();
            int range = view.computeVerticalScrollRange() - view.computeVerticalScrollExtent();
            if (range == 0) {
                return false;
            }
            if (direction < 0) {
                if (offset <= 0) {
                    return false;
                }
                return true;
            } else if (offset >= range - 1) {
                return false;
            } else {
                return true;
            }
        }

        /* renamed from: v */
        public void mo290v(View view) {
            if (view instanceof C0402y) {
                ((C0402y) view).stopNestedScroll();
            }
        }

        /* renamed from: w */
        public boolean mo291w(View view) {
            return aj.m1520c(view);
        }

        /* renamed from: x */
        public boolean mo292x(View view) {
            return aj.m1522e(view);
        }

        /* renamed from: y */
        public boolean mo293y(View view) {
            return false;
        }

        /* renamed from: a */
        public void mo249a(View view, int indicators, int mask) {
        }

        /* renamed from: d */
        public void mo270d(View view, int offset) {
            aj.m1519b(view, offset);
        }

        /* renamed from: e */
        public void mo273e(View view, int offset) {
            aj.m1515a(view, offset);
        }
    }

    /* compiled from: ViewCompat */
    /* renamed from: android.support.v4.view.ai$b */
    static class C0307b extends C0306a {
        C0307b() {
        }

        /* renamed from: a */
        public void mo258a(ViewGroup viewGroup, boolean enabled) {
            ak.m1523a(viewGroup, enabled);
        }
    }

    /* compiled from: ViewCompat */
    /* renamed from: android.support.v4.view.ai$c */
    static class C0308c extends C0307b {
        C0308c() {
        }

        /* renamed from: a */
        public int mo246a(View v) {
            return al.m1524a(v);
        }
    }

    /* compiled from: ViewCompat */
    /* renamed from: android.support.v4.view.ai$d */
    static class C0309d extends C0308c {
        C0309d() {
        }

        /* renamed from: a */
        long mo294a() {
            return am.m1527a();
        }

        /* renamed from: a */
        public void mo250a(View view, int layerType, Paint paint) {
            am.m1530a(view, layerType, paint);
        }

        /* renamed from: d */
        public int mo268d(View view) {
            return am.m1526a(view);
        }

        /* renamed from: a */
        public int mo245a(int size, int measureSpec, int childMeasuredState) {
            return am.m1525a(size, measureSpec, childMeasuredState);
        }

        /* renamed from: g */
        public int mo275g(View view) {
            return am.m1532b(view);
        }

        /* renamed from: h */
        public int mo276h(View view) {
            return am.m1536c(view);
        }

        /* renamed from: j */
        public float mo278j(View view) {
            return am.m1538d(view);
        }

        /* renamed from: a */
        public void mo248a(View view, float value) {
            am.m1528a(view, value);
        }

        /* renamed from: b */
        public void mo262b(View view, float value) {
            am.m1533b(view, value);
        }

        /* renamed from: c */
        public void mo266c(View view, float value) {
            am.m1537c(view, value);
        }

        /* renamed from: d */
        public void mo269d(View view, float value) {
            am.m1539d(view, value);
        }

        /* renamed from: k */
        public float mo279k(View view) {
            return am.m1540e(view);
        }

        /* renamed from: r */
        public void mo286r(View view) {
            am.m1541f(view);
        }

        /* renamed from: a */
        public void mo257a(View view, boolean enabled) {
            am.m1531a(view, enabled);
        }

        /* renamed from: b */
        public void mo263b(View view, boolean activated) {
            am.m1535b(view, activated);
        }

        /* renamed from: d */
        public void mo270d(View view, int offset) {
            am.m1534b(view, offset);
        }

        /* renamed from: e */
        public void mo273e(View view, int offset) {
            am.m1529a(view, offset);
        }
    }

    /* compiled from: ViewCompat */
    /* renamed from: android.support.v4.view.ai$f */
    static class C0310f extends C0309d {
        /* renamed from: b */
        static boolean f576b = false;

        C0310f() {
        }

        /* renamed from: a */
        public boolean mo259a(View v, int direction) {
            return an.m1544a(v, direction);
        }

        /* renamed from: b */
        public boolean mo264b(View v, int direction) {
            return an.m1545b(v, direction);
        }

        /* renamed from: a */
        public void mo253a(View v, C0246a delegate) {
            an.m1543a(v, delegate == null ? null : delegate.m866a());
        }

        /* renamed from: m */
        public bb mo281m(View view) {
            if (this.a == null) {
                this.a = new WeakHashMap();
            }
            bb vpa = (bb) this.a.get(view);
            if (vpa != null) {
                return vpa;
            }
            vpa = new bb(view);
            this.a.put(view, vpa);
            return vpa;
        }
    }

    /* compiled from: ViewCompat */
    /* renamed from: android.support.v4.view.ai$e */
    static class C0311e extends C0310f {
        C0311e() {
        }

        /* renamed from: y */
        public boolean mo293y(View view) {
            return ao.m1546a(view);
        }
    }

    /* compiled from: ViewCompat */
    /* renamed from: android.support.v4.view.ai$g */
    static class C0312g extends C0311e {
        C0312g() {
        }

        /* renamed from: b */
        public void mo261b(View view) {
            ap.m1547a(view);
        }

        /* renamed from: a */
        public void mo255a(View view, Runnable action) {
            ap.m1549a(view, action);
        }

        /* renamed from: a */
        public void mo256a(View view, Runnable action, long delayMillis) {
            ap.m1550a(view, action, delayMillis);
        }

        /* renamed from: c */
        public int mo265c(View view) {
            return ap.m1551b(view);
        }

        /* renamed from: c */
        public void mo267c(View view, int mode) {
            if (mode == 4) {
                mode = 2;
            }
            ap.m1548a(view, mode);
        }

        /* renamed from: f */
        public ViewParent mo274f(View view) {
            return ap.m1552c(view);
        }

        /* renamed from: l */
        public int mo280l(View view) {
            return ap.m1553d(view);
        }

        /* renamed from: o */
        public void mo283o(View view) {
            ap.m1554e(view);
        }

        /* renamed from: q */
        public boolean mo285q(View view) {
            return ap.m1555f(view);
        }

        /* renamed from: i */
        public boolean mo277i(View view) {
            return ap.m1556g(view);
        }
    }

    /* compiled from: ViewCompat */
    /* renamed from: android.support.v4.view.ai$h */
    static class C0313h extends C0312g {
        C0313h() {
        }

        /* renamed from: e */
        public int mo271e(View view) {
            return aq.m1557a(view);
        }

        /* renamed from: n */
        public int mo282n(View view) {
            return aq.m1558b(view);
        }
    }

    /* compiled from: ViewCompat */
    /* renamed from: android.support.v4.view.ai$i */
    static class C0314i extends C0313h {
        C0314i() {
        }
    }

    /* compiled from: ViewCompat */
    /* renamed from: android.support.v4.view.ai$j */
    static class C0315j extends C0314i {
        C0315j() {
        }

        /* renamed from: c */
        public void mo267c(View view, int mode) {
            ap.m1548a(view, mode);
        }

        /* renamed from: w */
        public boolean mo291w(View view) {
            return ar.m1559a(view);
        }

        /* renamed from: x */
        public boolean mo292x(View view) {
            return ar.m1560b(view);
        }
    }

    /* compiled from: ViewCompat */
    /* renamed from: android.support.v4.view.ai$k */
    static class C0316k extends C0315j {
        C0316k() {
        }

        /* renamed from: o */
        public void mo283o(View view) {
            as.m1563a(view);
        }

        /* renamed from: e */
        public void mo272e(View view, float elevation) {
            as.m1564a(view, elevation);
        }

        /* renamed from: p */
        public float mo284p(View view) {
            return as.m1569b(view);
        }

        /* renamed from: a */
        public void mo254a(View view, ac listener) {
            as.m1568a(view, listener);
        }

        /* renamed from: s */
        public boolean mo287s(View view) {
            return as.m1574e(view);
        }

        /* renamed from: v */
        public void mo290v(View view) {
            as.m1575f(view);
        }

        /* renamed from: t */
        public ColorStateList mo288t(View view) {
            return as.m1572c(view);
        }

        /* renamed from: a */
        public void mo251a(View view, ColorStateList tintList) {
            as.m1566a(view, tintList);
        }

        /* renamed from: a */
        public void mo252a(View view, Mode mode) {
            as.m1567a(view, mode);
        }

        /* renamed from: u */
        public Mode mo289u(View view) {
            return as.m1573d(view);
        }

        /* renamed from: a */
        public bi mo247a(View v, bi insets) {
            return as.m1562a(v, insets);
        }

        /* renamed from: b */
        public bi mo260b(View v, bi insets) {
            return as.m1570b(v, insets);
        }

        /* renamed from: d */
        public void mo270d(View view, int offset) {
            as.m1571b(view, offset);
        }

        /* renamed from: e */
        public void mo273e(View view, int offset) {
            as.m1565a(view, offset);
        }
    }

    /* compiled from: ViewCompat */
    /* renamed from: android.support.v4.view.ai$l */
    static class C0317l extends C0316k {
        C0317l() {
        }

        /* renamed from: a */
        public void mo249a(View view, int indicators, int mask) {
            at.m1577a(view, indicators, mask);
        }

        /* renamed from: d */
        public void mo270d(View view, int offset) {
            at.m1578b(view, offset);
        }

        /* renamed from: e */
        public void mo273e(View view, int offset) {
            at.m1576a(view, offset);
        }
    }

    static {
        int version = VERSION.SDK_INT;
        if (version >= 23) {
            f577a = new C0317l();
        } else if (version >= 21) {
            f577a = new C0316k();
        } else if (version >= 19) {
            f577a = new C0315j();
        } else if (version >= 17) {
            f577a = new C0313h();
        } else if (version >= 16) {
            f577a = new C0312g();
        } else if (version >= 15) {
            f577a = new C0311e();
        } else if (version >= 14) {
            f577a = new C0310f();
        } else if (version >= 11) {
            f577a = new C0309d();
        } else if (version >= 9) {
            f577a = new C0308c();
        } else if (version >= 7) {
            f577a = new C0307b();
        } else {
            f577a = new C0306a();
        }
    }

    /* renamed from: a */
    public static boolean m1479a(View v, int direction) {
        return f577a.mo259a(v, direction);
    }

    /* renamed from: b */
    public static boolean m1484b(View v, int direction) {
        return f577a.mo264b(v, direction);
    }

    /* renamed from: a */
    public static int m1466a(View v) {
        return f577a.mo246a(v);
    }

    /* renamed from: a */
    public static void m1473a(View v, C0246a delegate) {
        f577a.mo253a(v, delegate);
    }

    /* renamed from: b */
    public static void m1481b(View view) {
        f577a.mo261b(view);
    }

    /* renamed from: a */
    public static void m1475a(View view, Runnable action) {
        f577a.mo255a(view, action);
    }

    /* renamed from: a */
    public static void m1476a(View view, Runnable action, long delayMillis) {
        f577a.mo256a(view, action, delayMillis);
    }

    /* renamed from: c */
    public static int m1485c(View view) {
        return f577a.mo265c(view);
    }

    /* renamed from: c */
    public static void m1487c(View view, int mode) {
        f577a.mo267c(view, mode);
    }

    /* renamed from: a */
    public static void m1470a(View view, int layerType, Paint paint) {
        f577a.mo250a(view, layerType, paint);
    }

    /* renamed from: d */
    public static int m1488d(View view) {
        return f577a.mo268d(view);
    }

    /* renamed from: e */
    public static int m1491e(View view) {
        return f577a.mo271e(view);
    }

    /* renamed from: f */
    public static ViewParent m1494f(View view) {
        return f577a.mo274f(view);
    }

    /* renamed from: a */
    public static int m1465a(int size, int measureSpec, int childMeasuredState) {
        return f577a.mo245a(size, measureSpec, childMeasuredState);
    }

    /* renamed from: g */
    public static int m1495g(View view) {
        return f577a.mo275g(view);
    }

    /* renamed from: h */
    public static int m1496h(View view) {
        return f577a.mo276h(view);
    }

    /* renamed from: i */
    public static float m1497i(View view) {
        return f577a.mo278j(view);
    }

    /* renamed from: j */
    public static int m1498j(View view) {
        return f577a.mo280l(view);
    }

    /* renamed from: k */
    public static bb m1499k(View view) {
        return f577a.mo281m(view);
    }

    /* renamed from: a */
    public static void m1468a(View view, float value) {
        f577a.mo248a(view, value);
    }

    /* renamed from: b */
    public static void m1482b(View view, float value) {
        f577a.mo262b(view, value);
    }

    /* renamed from: c */
    public static void m1486c(View view, float value) {
        f577a.mo266c(view, value);
    }

    /* renamed from: d */
    public static void m1489d(View view, float value) {
        f577a.mo269d(view, value);
    }

    /* renamed from: l */
    public static float m1500l(View view) {
        return f577a.mo279k(view);
    }

    /* renamed from: e */
    public static void m1492e(View view, float elevation) {
        f577a.mo272e(view, elevation);
    }

    /* renamed from: m */
    public static float m1501m(View view) {
        return f577a.mo284p(view);
    }

    /* renamed from: n */
    public static int m1502n(View view) {
        return f577a.mo282n(view);
    }

    /* renamed from: o */
    public static void m1503o(View view) {
        f577a.mo283o(view);
    }

    /* renamed from: a */
    public static void m1478a(ViewGroup viewGroup, boolean enabled) {
        f577a.mo258a(viewGroup, enabled);
    }

    /* renamed from: p */
    public static boolean m1504p(View v) {
        return f577a.mo285q(v);
    }

    /* renamed from: q */
    public static void m1505q(View v) {
        f577a.mo286r(v);
    }

    /* renamed from: a */
    public static void m1474a(View v, ac listener) {
        f577a.mo254a(v, listener);
    }

    /* renamed from: a */
    public static bi m1467a(View view, bi insets) {
        return f577a.mo247a(view, insets);
    }

    /* renamed from: b */
    public static bi m1480b(View view, bi insets) {
        return f577a.mo260b(view, insets);
    }

    /* renamed from: a */
    public static void m1477a(View v, boolean enabled) {
        f577a.mo257a(v, enabled);
    }

    /* renamed from: b */
    public static void m1483b(View view, boolean activated) {
        f577a.mo263b(view, activated);
    }

    /* renamed from: r */
    public static boolean m1506r(View view) {
        return f577a.mo277i(view);
    }

    /* renamed from: s */
    public static ColorStateList m1507s(View view) {
        return f577a.mo288t(view);
    }

    /* renamed from: a */
    public static void m1471a(View view, ColorStateList tintList) {
        f577a.mo251a(view, tintList);
    }

    /* renamed from: t */
    public static Mode m1508t(View view) {
        return f577a.mo289u(view);
    }

    /* renamed from: a */
    public static void m1472a(View view, Mode mode) {
        f577a.mo252a(view, mode);
    }

    /* renamed from: u */
    public static boolean m1509u(View view) {
        return f577a.mo287s(view);
    }

    /* renamed from: v */
    public static void m1510v(View view) {
        f577a.mo290v(view);
    }

    /* renamed from: w */
    public static boolean m1511w(View view) {
        return f577a.mo291w(view);
    }

    /* renamed from: d */
    public static void m1490d(View view, int offset) {
        f577a.mo273e(view, offset);
    }

    /* renamed from: e */
    public static void m1493e(View view, int offset) {
        f577a.mo270d(view, offset);
    }

    /* renamed from: x */
    public static boolean m1512x(View view) {
        return f577a.mo292x(view);
    }

    /* renamed from: y */
    public static boolean m1513y(View view) {
        return f577a.mo293y(view);
    }

    /* renamed from: a */
    public static void m1469a(View view, int indicators, int mask) {
        f577a.mo249a(view, indicators, mask);
    }
}

package android.support.v4.view;

import android.view.View;
import android.view.View.AccessibilityDelegate;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

/* compiled from: AccessibilityDelegateCompatIcs */
/* renamed from: android.support.v4.view.b */
class C0338b {

    /* compiled from: AccessibilityDelegateCompatIcs */
    /* renamed from: android.support.v4.view.b$a */
    public interface C0253a {
        /* renamed from: a */
        void mo158a(View view, int i);

        /* renamed from: a */
        void mo159a(View view, Object obj);

        /* renamed from: a */
        boolean mo160a(View view, AccessibilityEvent accessibilityEvent);

        /* renamed from: a */
        boolean mo161a(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent);

        /* renamed from: b */
        void mo162b(View view, AccessibilityEvent accessibilityEvent);

        /* renamed from: c */
        void mo163c(View view, AccessibilityEvent accessibilityEvent);

        /* renamed from: d */
        void mo164d(View view, AccessibilityEvent accessibilityEvent);
    }

    /* renamed from: a */
    public static Object m1623a() {
        return new AccessibilityDelegate();
    }

    /* renamed from: a */
    public static Object m1624a(final C0253a bridge) {
        return new AccessibilityDelegate() {
            public boolean dispatchPopulateAccessibilityEvent(View host, AccessibilityEvent event) {
                return bridge.mo160a(host, event);
            }

            public void onInitializeAccessibilityEvent(View host, AccessibilityEvent event) {
                bridge.mo162b(host, event);
            }

            public void onInitializeAccessibilityNodeInfo(View host, AccessibilityNodeInfo info) {
                bridge.mo159a(host, (Object) info);
            }

            public void onPopulateAccessibilityEvent(View host, AccessibilityEvent event) {
                bridge.mo163c(host, event);
            }

            public boolean onRequestSendAccessibilityEvent(ViewGroup host, View child, AccessibilityEvent event) {
                return bridge.mo161a(host, child, event);
            }

            public void sendAccessibilityEvent(View host, int eventType) {
                bridge.mo158a(host, eventType);
            }

            public void sendAccessibilityEventUnchecked(View host, AccessibilityEvent event) {
                bridge.mo164d(host, event);
            }
        };
    }

    /* renamed from: a */
    public static boolean m1627a(Object delegate, View host, AccessibilityEvent event) {
        return ((AccessibilityDelegate) delegate).dispatchPopulateAccessibilityEvent(host, event);
    }

    /* renamed from: b */
    public static void m1629b(Object delegate, View host, AccessibilityEvent event) {
        ((AccessibilityDelegate) delegate).onInitializeAccessibilityEvent(host, event);
    }

    /* renamed from: a */
    public static void m1626a(Object delegate, View host, Object info) {
        ((AccessibilityDelegate) delegate).onInitializeAccessibilityNodeInfo(host, (AccessibilityNodeInfo) info);
    }

    /* renamed from: c */
    public static void m1630c(Object delegate, View host, AccessibilityEvent event) {
        ((AccessibilityDelegate) delegate).onPopulateAccessibilityEvent(host, event);
    }

    /* renamed from: a */
    public static boolean m1628a(Object delegate, ViewGroup host, View child, AccessibilityEvent event) {
        return ((AccessibilityDelegate) delegate).onRequestSendAccessibilityEvent(host, child, event);
    }

    /* renamed from: a */
    public static void m1625a(Object delegate, View host, int eventType) {
        ((AccessibilityDelegate) delegate).sendAccessibilityEvent(host, eventType);
    }

    /* renamed from: d */
    public static void m1631d(Object delegate, View host, AccessibilityEvent event) {
        ((AccessibilityDelegate) delegate).sendAccessibilityEventUnchecked(host, event);
    }
}

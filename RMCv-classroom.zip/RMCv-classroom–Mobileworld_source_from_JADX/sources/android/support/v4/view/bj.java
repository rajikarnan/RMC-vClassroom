package android.support.v4.view;

import android.view.WindowInsets;

/* compiled from: WindowInsetsCompatApi21 */
class bj extends bi {
    /* renamed from: a */
    private final WindowInsets f608a;

    bj(WindowInsets source) {
        this.f608a = source;
    }

    /* renamed from: a */
    public int mo319a() {
        return this.f608a.getSystemWindowInsetLeft();
    }

    /* renamed from: b */
    public int mo321b() {
        return this.f608a.getSystemWindowInsetTop();
    }

    /* renamed from: c */
    public int mo322c() {
        return this.f608a.getSystemWindowInsetRight();
    }

    /* renamed from: d */
    public int mo323d() {
        return this.f608a.getSystemWindowInsetBottom();
    }

    /* renamed from: e */
    public boolean mo324e() {
        return this.f608a.isConsumed();
    }

    /* renamed from: a */
    public bi mo320a(int left, int top, int right, int bottom) {
        return new bj(this.f608a.replaceSystemWindowInsets(left, top, right, bottom));
    }

    /* renamed from: f */
    WindowInsets m1713f() {
        return this.f608a;
    }
}

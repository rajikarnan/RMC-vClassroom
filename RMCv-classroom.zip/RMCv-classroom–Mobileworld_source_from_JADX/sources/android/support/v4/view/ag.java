package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.VelocityTracker;

/* compiled from: VelocityTrackerCompat */
public final class ag {
    /* renamed from: a */
    static final C0302c f574a;

    /* compiled from: VelocityTrackerCompat */
    /* renamed from: android.support.v4.view.ag$c */
    interface C0302c {
        /* renamed from: a */
        float mo243a(VelocityTracker velocityTracker, int i);

        /* renamed from: b */
        float mo244b(VelocityTracker velocityTracker, int i);
    }

    /* compiled from: VelocityTrackerCompat */
    /* renamed from: android.support.v4.view.ag$a */
    static class C0303a implements C0302c {
        C0303a() {
        }

        /* renamed from: a */
        public float mo243a(VelocityTracker tracker, int pointerId) {
            return tracker.getXVelocity();
        }

        /* renamed from: b */
        public float mo244b(VelocityTracker tracker, int pointerId) {
            return tracker.getYVelocity();
        }
    }

    /* compiled from: VelocityTrackerCompat */
    /* renamed from: android.support.v4.view.ag$b */
    static class C0304b implements C0302c {
        C0304b() {
        }

        /* renamed from: a */
        public float mo243a(VelocityTracker tracker, int pointerId) {
            return ah.m1306a(tracker, pointerId);
        }

        /* renamed from: b */
        public float mo244b(VelocityTracker tracker, int pointerId) {
            return ah.m1307b(tracker, pointerId);
        }
    }

    static {
        if (VERSION.SDK_INT >= 11) {
            f574a = new C0304b();
        } else {
            f574a = new C0303a();
        }
    }

    /* renamed from: a */
    public static float m1304a(VelocityTracker tracker, int pointerId) {
        return f574a.mo243a(tracker, pointerId);
    }

    /* renamed from: b */
    public static float m1305b(VelocityTracker tracker, int pointerId) {
        return f574a.mo244b(tracker, pointerId);
    }
}

package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.ViewGroup;

/* compiled from: ViewGroupCompat */
public final class ax {
    /* renamed from: a */
    static final C0324c f584a;

    /* compiled from: ViewGroupCompat */
    /* renamed from: android.support.v4.view.ax$c */
    interface C0324c {
        /* renamed from: a */
        void mo297a(ViewGroup viewGroup, boolean z);
    }

    /* compiled from: ViewGroupCompat */
    /* renamed from: android.support.v4.view.ax$f */
    static class C0325f implements C0324c {
        C0325f() {
        }

        /* renamed from: a */
        public void mo297a(ViewGroup group, boolean split) {
        }
    }

    /* compiled from: ViewGroupCompat */
    /* renamed from: android.support.v4.view.ax$a */
    static class C0326a extends C0325f {
        C0326a() {
        }

        /* renamed from: a */
        public void mo297a(ViewGroup group, boolean split) {
            ay.m1594a(group, split);
        }
    }

    /* compiled from: ViewGroupCompat */
    /* renamed from: android.support.v4.view.ax$b */
    static class C0327b extends C0326a {
        C0327b() {
        }
    }

    /* compiled from: ViewGroupCompat */
    /* renamed from: android.support.v4.view.ax$d */
    static class C0328d extends C0327b {
        C0328d() {
        }
    }

    /* compiled from: ViewGroupCompat */
    /* renamed from: android.support.v4.view.ax$e */
    static class C0329e extends C0328d {
        C0329e() {
        }
    }

    static {
        int version = VERSION.SDK_INT;
        if (version >= 21) {
            f584a = new C0329e();
        } else if (version >= 18) {
            f584a = new C0328d();
        } else if (version >= 14) {
            f584a = new C0327b();
        } else if (version >= 11) {
            f584a = new C0326a();
        } else {
            f584a = new C0325f();
        }
    }

    /* renamed from: a */
    public static void m1593a(ViewGroup group, boolean split) {
        f584a.mo297a(group, split);
    }
}

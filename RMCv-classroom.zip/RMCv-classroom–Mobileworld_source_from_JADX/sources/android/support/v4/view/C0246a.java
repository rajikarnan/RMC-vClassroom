package android.support.v4.view;

import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.view.C0338b.C0253a;
import android.support.v4.view.C0353c.C0258a;
import android.support.v4.view.p012a.C0276b;
import android.support.v4.view.p012a.C0289g;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;

/* compiled from: AccessibilityDelegateCompat */
/* renamed from: android.support.v4.view.a */
public class C0246a {
    /* renamed from: b */
    private static final C0255b f476b;
    /* renamed from: c */
    private static final Object f477c = f476b.mo166a();
    /* renamed from: a */
    final Object f478a = f476b.mo167a(this);

    /* compiled from: AccessibilityDelegateCompat */
    /* renamed from: android.support.v4.view.a$b */
    interface C0255b {
        /* renamed from: a */
        C0289g mo165a(Object obj, View view);

        /* renamed from: a */
        Object mo166a();

        /* renamed from: a */
        Object mo167a(C0246a c0246a);

        /* renamed from: a */
        void mo168a(Object obj, View view, int i);

        /* renamed from: a */
        void mo169a(Object obj, View view, C0276b c0276b);

        /* renamed from: a */
        boolean mo170a(Object obj, View view, int i, Bundle bundle);

        /* renamed from: a */
        boolean mo171a(Object obj, View view, AccessibilityEvent accessibilityEvent);

        /* renamed from: a */
        boolean mo172a(Object obj, ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent);

        /* renamed from: b */
        void mo173b(Object obj, View view, AccessibilityEvent accessibilityEvent);

        /* renamed from: c */
        void mo174c(Object obj, View view, AccessibilityEvent accessibilityEvent);

        /* renamed from: d */
        void mo175d(Object obj, View view, AccessibilityEvent accessibilityEvent);
    }

    /* compiled from: AccessibilityDelegateCompat */
    /* renamed from: android.support.v4.view.a$d */
    static class C0256d implements C0255b {
        C0256d() {
        }

        /* renamed from: a */
        public Object mo166a() {
            return null;
        }

        /* renamed from: a */
        public Object mo167a(C0246a listener) {
            return null;
        }

        /* renamed from: a */
        public boolean mo171a(Object delegate, View host, AccessibilityEvent event) {
            return false;
        }

        /* renamed from: b */
        public void mo173b(Object delegate, View host, AccessibilityEvent event) {
        }

        /* renamed from: a */
        public void mo169a(Object delegate, View host, C0276b info) {
        }

        /* renamed from: c */
        public void mo174c(Object delegate, View host, AccessibilityEvent event) {
        }

        /* renamed from: a */
        public boolean mo172a(Object delegate, ViewGroup host, View child, AccessibilityEvent event) {
            return true;
        }

        /* renamed from: a */
        public void mo168a(Object delegate, View host, int eventType) {
        }

        /* renamed from: d */
        public void mo175d(Object delegate, View host, AccessibilityEvent event) {
        }

        /* renamed from: a */
        public C0289g mo165a(Object delegate, View host) {
            return null;
        }

        /* renamed from: a */
        public boolean mo170a(Object delegate, View host, int action, Bundle args) {
            return false;
        }
    }

    /* compiled from: AccessibilityDelegateCompat */
    /* renamed from: android.support.v4.view.a$a */
    static class C0257a extends C0256d {
        C0257a() {
        }

        /* renamed from: a */
        public Object mo166a() {
            return C0338b.m1623a();
        }

        /* renamed from: a */
        public Object mo167a(final C0246a compat) {
            return C0338b.m1624a(new C0253a(this) {
                /* renamed from: b */
                final /* synthetic */ C0257a f531b;

                /* renamed from: a */
                public boolean mo160a(View host, AccessibilityEvent event) {
                    return compat.mo348b(host, event);
                }

                /* renamed from: b */
                public void mo162b(View host, AccessibilityEvent event) {
                    compat.mo157d(host, event);
                }

                /* renamed from: a */
                public void mo159a(View host, Object info) {
                    compat.mo155a(host, new C0276b(info));
                }

                /* renamed from: c */
                public void mo163c(View host, AccessibilityEvent event) {
                    compat.m873c(host, event);
                }

                /* renamed from: a */
                public boolean mo161a(ViewGroup host, View child, AccessibilityEvent event) {
                    return compat.mo347a(host, child, event);
                }

                /* renamed from: a */
                public void mo158a(View host, int eventType) {
                    compat.m867a(host, eventType);
                }

                /* renamed from: d */
                public void mo164d(View host, AccessibilityEvent event) {
                    compat.m869a(host, event);
                }
            });
        }

        /* renamed from: a */
        public boolean mo171a(Object delegate, View host, AccessibilityEvent event) {
            return C0338b.m1627a(delegate, host, event);
        }

        /* renamed from: b */
        public void mo173b(Object delegate, View host, AccessibilityEvent event) {
            C0338b.m1629b(delegate, host, event);
        }

        /* renamed from: a */
        public void mo169a(Object delegate, View host, C0276b info) {
            C0338b.m1626a(delegate, host, info.m1126a());
        }

        /* renamed from: c */
        public void mo174c(Object delegate, View host, AccessibilityEvent event) {
            C0338b.m1630c(delegate, host, event);
        }

        /* renamed from: a */
        public boolean mo172a(Object delegate, ViewGroup host, View child, AccessibilityEvent event) {
            return C0338b.m1628a(delegate, host, child, event);
        }

        /* renamed from: a */
        public void mo168a(Object delegate, View host, int eventType) {
            C0338b.m1625a(delegate, host, eventType);
        }

        /* renamed from: d */
        public void mo175d(Object delegate, View host, AccessibilityEvent event) {
            C0338b.m1631d(delegate, host, event);
        }
    }

    /* compiled from: AccessibilityDelegateCompat */
    /* renamed from: android.support.v4.view.a$c */
    static class C0260c extends C0257a {
        C0260c() {
        }

        /* renamed from: a */
        public Object mo167a(final C0246a compat) {
            return C0353c.m1714a(new C0258a(this) {
                /* renamed from: b */
                final /* synthetic */ C0260c f533b;

                /* renamed from: a */
                public boolean mo180a(View host, AccessibilityEvent event) {
                    return compat.mo348b(host, event);
                }

                /* renamed from: b */
                public void mo182b(View host, AccessibilityEvent event) {
                    compat.mo157d(host, event);
                }

                /* renamed from: a */
                public void mo178a(View host, Object info) {
                    compat.mo155a(host, new C0276b(info));
                }

                /* renamed from: c */
                public void mo183c(View host, AccessibilityEvent event) {
                    compat.m873c(host, event);
                }

                /* renamed from: a */
                public boolean mo181a(ViewGroup host, View child, AccessibilityEvent event) {
                    return compat.mo347a(host, child, event);
                }

                /* renamed from: a */
                public void mo177a(View host, int eventType) {
                    compat.m867a(host, eventType);
                }

                /* renamed from: d */
                public void mo184d(View host, AccessibilityEvent event) {
                    compat.m869a(host, event);
                }

                /* renamed from: a */
                public Object mo176a(View host) {
                    C0289g provider = compat.m865a(host);
                    return provider != null ? provider.m1228a() : null;
                }

                /* renamed from: a */
                public boolean mo179a(View host, int action, Bundle args) {
                    return compat.mo156a(host, action, args);
                }
            });
        }

        /* renamed from: a */
        public C0289g mo165a(Object delegate, View host) {
            Object provider = C0353c.m1715a(delegate, host);
            if (provider != null) {
                return new C0289g(provider);
            }
            return null;
        }

        /* renamed from: a */
        public boolean mo170a(Object delegate, View host, int action, Bundle args) {
            return C0353c.m1716a(delegate, host, action, args);
        }
    }

    static {
        if (VERSION.SDK_INT >= 16) {
            f476b = new C0260c();
        } else if (VERSION.SDK_INT >= 14) {
            f476b = new C0257a();
        } else {
            f476b = new C0256d();
        }
    }

    /* renamed from: a */
    Object m866a() {
        return this.f478a;
    }

    /* renamed from: a */
    public void m867a(View host, int eventType) {
        f476b.mo168a(f477c, host, eventType);
    }

    /* renamed from: a */
    public void m869a(View host, AccessibilityEvent event) {
        f476b.mo175d(f477c, host, event);
    }

    /* renamed from: b */
    public boolean mo348b(View host, AccessibilityEvent event) {
        return f476b.mo171a(f477c, host, event);
    }

    /* renamed from: c */
    public void m873c(View host, AccessibilityEvent event) {
        f476b.mo174c(f477c, host, event);
    }

    /* renamed from: d */
    public void mo157d(View host, AccessibilityEvent event) {
        f476b.mo173b(f477c, host, event);
    }

    /* renamed from: a */
    public void mo155a(View host, C0276b info) {
        f476b.mo169a(f477c, host, info);
    }

    /* renamed from: a */
    public boolean mo347a(ViewGroup host, View child, AccessibilityEvent event) {
        return f476b.mo172a(f477c, host, child, event);
    }

    /* renamed from: a */
    public C0289g m865a(View host) {
        return f476b.mo165a(f477c, host);
    }

    /* renamed from: a */
    public boolean mo156a(View host, int action, Bundle args) {
        return f476b.mo170a(f477c, host, action, args);
    }
}

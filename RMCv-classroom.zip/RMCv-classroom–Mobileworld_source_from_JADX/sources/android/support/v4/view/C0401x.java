package android.support.v4.view;

import android.view.MotionEvent;

/* compiled from: MotionEventCompatHoneycombMr1 */
/* renamed from: android.support.v4.view.x */
class C0401x {
    /* renamed from: a */
    static float m1833a(MotionEvent event, int axis) {
        return event.getAxisValue(axis);
    }
}

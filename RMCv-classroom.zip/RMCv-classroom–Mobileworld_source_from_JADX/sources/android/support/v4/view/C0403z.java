package android.support.v4.view;

import android.view.View;
import android.view.ViewParent;

/* compiled from: NestedScrollingChildHelper */
/* renamed from: android.support.v4.view.z */
public class C0403z {
    /* renamed from: a */
    private final View f619a;
    /* renamed from: b */
    private ViewParent f620b;
    /* renamed from: c */
    private boolean f621c;
    /* renamed from: d */
    private int[] f622d;

    public C0403z(View view) {
        this.f619a = view;
    }

    /* renamed from: a */
    public void m1834a(boolean enabled) {
        if (this.f621c) {
            ai.m1510v(this.f619a);
        }
        this.f621c = enabled;
    }

    /* renamed from: a */
    public boolean m1835a() {
        return this.f621c;
    }

    /* renamed from: b */
    public boolean m1841b() {
        return this.f620b != null;
    }

    /* renamed from: a */
    public boolean m1838a(int axes) {
        if (m1841b()) {
            return true;
        }
        if (m1835a()) {
            View child = this.f619a;
            for (ViewParent p = this.f619a.getParent(); p != null; p = p.getParent()) {
                if (az.m1621a(p, child, this.f619a, axes)) {
                    this.f620b = p;
                    az.m1622b(p, child, this.f619a, axes);
                    return true;
                }
                if (p instanceof View) {
                    child = (View) p;
                }
            }
        }
        return false;
    }

    /* renamed from: c */
    public void m1842c() {
        if (this.f620b != null) {
            az.m1616a(this.f620b, this.f619a);
            this.f620b = null;
        }
    }

    /* renamed from: a */
    public boolean m1839a(int dxConsumed, int dyConsumed, int dxUnconsumed, int dyUnconsumed, int[] offsetInWindow) {
        if (m1835a() && this.f620b != null) {
            if (dxConsumed != 0 || dyConsumed != 0 || dxUnconsumed != 0 || dyUnconsumed != 0) {
                int startX = 0;
                int startY = 0;
                if (offsetInWindow != null) {
                    this.f619a.getLocationInWindow(offsetInWindow);
                    startX = offsetInWindow[0];
                    startY = offsetInWindow[1];
                }
                az.m1617a(this.f620b, this.f619a, dxConsumed, dyConsumed, dxUnconsumed, dyUnconsumed);
                if (offsetInWindow != null) {
                    this.f619a.getLocationInWindow(offsetInWindow);
                    offsetInWindow[0] = offsetInWindow[0] - startX;
                    offsetInWindow[1] = offsetInWindow[1] - startY;
                }
                return true;
            } else if (offsetInWindow != null) {
                offsetInWindow[0] = 0;
                offsetInWindow[1] = 0;
            }
        }
        return false;
    }

    /* renamed from: a */
    public boolean m1840a(int dx, int dy, int[] consumed, int[] offsetInWindow) {
        if (!m1835a() || this.f620b == null) {
            return false;
        }
        if (dx != 0 || dy != 0) {
            int startX = 0;
            int startY = 0;
            if (offsetInWindow != null) {
                this.f619a.getLocationInWindow(offsetInWindow);
                startX = offsetInWindow[0];
                startY = offsetInWindow[1];
            }
            if (consumed == null) {
                if (this.f622d == null) {
                    this.f622d = new int[2];
                }
                consumed = this.f622d;
            }
            consumed[0] = 0;
            consumed[1] = 0;
            az.m1618a(this.f620b, this.f619a, dx, dy, consumed);
            if (offsetInWindow != null) {
                this.f619a.getLocationInWindow(offsetInWindow);
                offsetInWindow[0] = offsetInWindow[0] - startX;
                offsetInWindow[1] = offsetInWindow[1] - startY;
            }
            if (consumed[0] == 0 && consumed[1] == 0) {
                return false;
            }
            return true;
        } else if (offsetInWindow == null) {
            return false;
        } else {
            offsetInWindow[0] = 0;
            offsetInWindow[1] = 0;
            return false;
        }
    }

    /* renamed from: a */
    public boolean m1837a(float velocityX, float velocityY, boolean consumed) {
        if (!m1835a() || this.f620b == null) {
            return false;
        }
        return az.m1620a(this.f620b, this.f619a, velocityX, velocityY, consumed);
    }

    /* renamed from: a */
    public boolean m1836a(float velocityX, float velocityY) {
        if (!m1835a() || this.f620b == null) {
            return false;
        }
        return az.m1619a(this.f620b, this.f619a, velocityX, velocityY);
    }
}

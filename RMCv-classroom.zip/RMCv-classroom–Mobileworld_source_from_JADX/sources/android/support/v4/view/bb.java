package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.View;
import android.view.animation.Interpolator;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;

/* compiled from: ViewPropertyAnimatorCompat */
public final class bb {
    /* renamed from: a */
    static final C0341g f597a;
    /* renamed from: b */
    private WeakReference<View> f598b;
    /* renamed from: c */
    private Runnable f599c = null;
    /* renamed from: d */
    private Runnable f600d = null;
    /* renamed from: e */
    private int f601e = -1;

    /* compiled from: ViewPropertyAnimatorCompat */
    /* renamed from: android.support.v4.view.bb$g */
    interface C0341g {
        /* renamed from: a */
        long mo306a(bb bbVar, View view);

        /* renamed from: a */
        void mo307a(bb bbVar, View view, float f);

        /* renamed from: a */
        void mo308a(bb bbVar, View view, long j);

        /* renamed from: a */
        void mo309a(bb bbVar, View view, bf bfVar);

        /* renamed from: a */
        void mo310a(bb bbVar, View view, bh bhVar);

        /* renamed from: a */
        void mo311a(bb bbVar, View view, Interpolator interpolator);

        /* renamed from: b */
        void mo312b(bb bbVar, View view);

        /* renamed from: b */
        void mo313b(bb bbVar, View view, float f);

        /* renamed from: b */
        void mo314b(bb bbVar, View view, long j);

        /* renamed from: c */
        void mo315c(bb bbVar, View view);
    }

    /* compiled from: ViewPropertyAnimatorCompat */
    /* renamed from: android.support.v4.view.bb$a */
    static class C0342a implements C0341g {
        /* renamed from: a */
        WeakHashMap<View, Runnable> f593a = null;

        /* compiled from: ViewPropertyAnimatorCompat */
        /* renamed from: android.support.v4.view.bb$a$a */
        class C0340a implements Runnable {
            /* renamed from: a */
            WeakReference<View> f590a;
            /* renamed from: b */
            bb f591b;
            /* renamed from: c */
            final /* synthetic */ C0342a f592c;

            private C0340a(C0342a c0342a, bb vpa, View view) {
                this.f592c = c0342a;
                this.f590a = new WeakReference(view);
                this.f591b = vpa;
            }

            public void run() {
                View view = (View) this.f590a.get();
                if (view != null) {
                    this.f592c.m1651d(this.f591b, view);
                }
            }
        }

        C0342a() {
        }

        /* renamed from: a */
        public void mo308a(bb vpa, View view, long value) {
        }

        /* renamed from: a */
        public void mo307a(bb vpa, View view, float value) {
            m1652e(vpa, view);
        }

        /* renamed from: b */
        public void mo313b(bb vpa, View view, float value) {
            m1652e(vpa, view);
        }

        /* renamed from: a */
        public long mo306a(bb vpa, View view) {
            return 0;
        }

        /* renamed from: a */
        public void mo311a(bb vpa, View view, Interpolator value) {
        }

        /* renamed from: b */
        public void mo314b(bb vpa, View view, long value) {
        }

        /* renamed from: b */
        public void mo312b(bb vpa, View view) {
            m1652e(vpa, view);
        }

        /* renamed from: c */
        public void mo315c(bb vpa, View view) {
            m1650a(view);
            m1651d(vpa, view);
        }

        /* renamed from: a */
        public void mo309a(bb vpa, View view, bf listener) {
            view.setTag(2113929216, listener);
        }

        /* renamed from: a */
        public void mo310a(bb vpa, View view, bh listener) {
        }

        /* renamed from: d */
        private void m1651d(bb vpa, View view) {
            bf listenerTag = view.getTag(2113929216);
            bf listener = null;
            if (listenerTag instanceof bf) {
                listener = listenerTag;
            }
            Runnable startAction = vpa.f599c;
            Runnable endAction = vpa.f600d;
            vpa.f599c = null;
            vpa.f600d = null;
            if (startAction != null) {
                startAction.run();
            }
            if (listener != null) {
                listener.onAnimationStart(view);
                listener.onAnimationEnd(view);
            }
            if (endAction != null) {
                endAction.run();
            }
            if (this.f593a != null) {
                this.f593a.remove(view);
            }
        }

        /* renamed from: a */
        private void m1650a(View view) {
            if (this.f593a != null) {
                Runnable starter = (Runnable) this.f593a.get(view);
                if (starter != null) {
                    view.removeCallbacks(starter);
                }
            }
        }

        /* renamed from: e */
        private void m1652e(bb vpa, View view) {
            Runnable runnable = null;
            if (this.f593a != null) {
                runnable = (Runnable) this.f593a.get(view);
            }
            if (runnable == null) {
                runnable = new C0340a(vpa, view);
                if (this.f593a == null) {
                    this.f593a = new WeakHashMap();
                }
                this.f593a.put(view, runnable);
            }
            view.removeCallbacks(runnable);
            view.post(runnable);
        }
    }

    /* compiled from: ViewPropertyAnimatorCompat */
    /* renamed from: android.support.v4.view.bb$b */
    static class C0344b extends C0342a {
        /* renamed from: b */
        WeakHashMap<View, Integer> f596b = null;

        /* compiled from: ViewPropertyAnimatorCompat */
        /* renamed from: android.support.v4.view.bb$b$a */
        static class C0343a implements bf {
            /* renamed from: a */
            bb f594a;
            /* renamed from: b */
            boolean f595b;

            C0343a(bb vpa) {
                this.f594a = vpa;
            }

            public void onAnimationStart(View view) {
                this.f595b = false;
                if (this.f594a.f601e >= 0) {
                    ai.m1470a(view, 2, null);
                }
                if (this.f594a.f599c != null) {
                    Runnable startAction = this.f594a.f599c;
                    this.f594a.f599c = null;
                    startAction.run();
                }
                bf listenerTag = view.getTag(2113929216);
                bf listener = null;
                if (listenerTag instanceof bf) {
                    listener = listenerTag;
                }
                if (listener != null) {
                    listener.onAnimationStart(view);
                }
            }

            public void onAnimationEnd(View view) {
                if (this.f594a.f601e >= 0) {
                    ai.m1470a(view, this.f594a.f601e, null);
                    this.f594a.f601e = -1;
                }
                if (VERSION.SDK_INT >= 16 || !this.f595b) {
                    if (this.f594a.f600d != null) {
                        Runnable endAction = this.f594a.f600d;
                        this.f594a.f600d = null;
                        endAction.run();
                    }
                    bf listenerTag = view.getTag(2113929216);
                    bf listener = null;
                    if (listenerTag instanceof bf) {
                        listener = listenerTag;
                    }
                    if (listener != null) {
                        listener.onAnimationEnd(view);
                    }
                    this.f595b = true;
                }
            }

            public void onAnimationCancel(View view) {
                bf listenerTag = view.getTag(2113929216);
                bf listener = null;
                if (listenerTag instanceof bf) {
                    listener = listenerTag;
                }
                if (listener != null) {
                    listener.onAnimationCancel(view);
                }
            }
        }

        C0344b() {
        }

        /* renamed from: a */
        public void mo308a(bb vpa, View view, long value) {
            bc.m1692a(view, value);
        }

        /* renamed from: a */
        public void mo307a(bb vpa, View view, float value) {
            bc.m1691a(view, value);
        }

        /* renamed from: b */
        public void mo313b(bb vpa, View view, float value) {
            bc.m1696b(view, value);
        }

        /* renamed from: a */
        public long mo306a(bb vpa, View view) {
            return bc.m1690a(view);
        }

        /* renamed from: a */
        public void mo311a(bb vpa, View view, Interpolator value) {
            bc.m1694a(view, value);
        }

        /* renamed from: b */
        public void mo314b(bb vpa, View view, long value) {
            bc.m1697b(view, value);
        }

        /* renamed from: b */
        public void mo312b(bb vpa, View view) {
            bc.m1695b(view);
        }

        /* renamed from: c */
        public void mo315c(bb vpa, View view) {
            bc.m1698c(view);
        }

        /* renamed from: a */
        public void mo309a(bb vpa, View view, bf listener) {
            view.setTag(2113929216, listener);
            bc.m1693a(view, new C0343a(vpa));
        }
    }

    /* compiled from: ViewPropertyAnimatorCompat */
    /* renamed from: android.support.v4.view.bb$d */
    static class C0345d extends C0344b {
        C0345d() {
        }

        /* renamed from: a */
        public void mo309a(bb vpa, View view, bf listener) {
            bd.m1699a(view, listener);
        }
    }

    /* compiled from: ViewPropertyAnimatorCompat */
    /* renamed from: android.support.v4.view.bb$c */
    static class C0346c extends C0345d {
        C0346c() {
        }
    }

    /* compiled from: ViewPropertyAnimatorCompat */
    /* renamed from: android.support.v4.view.bb$e */
    static class C0347e extends C0346c {
        C0347e() {
        }

        /* renamed from: a */
        public void mo310a(bb vpa, View view, bh listener) {
            be.m1700a(view, listener);
        }
    }

    /* compiled from: ViewPropertyAnimatorCompat */
    /* renamed from: android.support.v4.view.bb$f */
    static class C0348f extends C0347e {
        C0348f() {
        }
    }

    bb(View view) {
        this.f598b = new WeakReference(view);
    }

    static {
        int version = VERSION.SDK_INT;
        if (version >= 21) {
            f597a = new C0348f();
        } else if (version >= 19) {
            f597a = new C0347e();
        } else if (version >= 18) {
            f597a = new C0346c();
        } else if (version >= 16) {
            f597a = new C0345d();
        } else if (version >= 14) {
            f597a = new C0344b();
        } else {
            f597a = new C0342a();
        }
    }

    /* renamed from: a */
    public bb m1682a(long value) {
        View view = (View) this.f598b.get();
        if (view != null) {
            f597a.mo308a(this, view, value);
        }
        return this;
    }

    /* renamed from: a */
    public bb m1681a(float value) {
        View view = (View) this.f598b.get();
        if (view != null) {
            f597a.mo307a(this, view, value);
        }
        return this;
    }

    /* renamed from: b */
    public bb m1686b(float value) {
        View view = (View) this.f598b.get();
        if (view != null) {
            f597a.mo313b(this, view, value);
        }
        return this;
    }

    /* renamed from: a */
    public long m1680a() {
        View view = (View) this.f598b.get();
        if (view != null) {
            return f597a.mo306a(this, view);
        }
        return 0;
    }

    /* renamed from: a */
    public bb m1685a(Interpolator value) {
        View view = (View) this.f598b.get();
        if (view != null) {
            f597a.mo311a(this, view, value);
        }
        return this;
    }

    /* renamed from: b */
    public bb m1687b(long value) {
        View view = (View) this.f598b.get();
        if (view != null) {
            f597a.mo314b(this, view, value);
        }
        return this;
    }

    /* renamed from: b */
    public void m1688b() {
        View view = (View) this.f598b.get();
        if (view != null) {
            f597a.mo312b(this, view);
        }
    }

    /* renamed from: c */
    public void m1689c() {
        View view = (View) this.f598b.get();
        if (view != null) {
            f597a.mo315c(this, view);
        }
    }

    /* renamed from: a */
    public bb m1683a(bf listener) {
        View view = (View) this.f598b.get();
        if (view != null) {
            f597a.mo309a(this, view, listener);
        }
        return this;
    }

    /* renamed from: a */
    public bb m1684a(bh listener) {
        View view = (View) this.f598b.get();
        if (view != null) {
            f597a.mo310a(this, view, listener);
        }
        return this;
    }
}

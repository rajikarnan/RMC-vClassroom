package android.support.v4.view;

import android.view.ViewGroup;

/* compiled from: ViewGroupCompatHC */
class ay {
    /* renamed from: a */
    public static void m1594a(ViewGroup group, boolean split) {
        group.setMotionEventSplittingEnabled(split);
    }
}

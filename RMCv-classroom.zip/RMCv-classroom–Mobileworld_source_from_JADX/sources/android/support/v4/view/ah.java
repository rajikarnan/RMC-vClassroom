package android.support.v4.view;

import android.view.VelocityTracker;

/* compiled from: VelocityTrackerCompatHoneycomb */
class ah {
    /* renamed from: a */
    public static float m1306a(VelocityTracker tracker, int pointerId) {
        return tracker.getXVelocity(pointerId);
    }

    /* renamed from: b */
    public static float m1307b(VelocityTracker tracker, int pointerId) {
        return tracker.getYVelocity(pointerId);
    }
}

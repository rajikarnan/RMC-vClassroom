package android.support.v4.view;

import android.view.View;
import android.view.ViewParent;

/* compiled from: ViewCompatJB */
class ap {
    /* renamed from: a */
    public static void m1547a(View view) {
        view.postInvalidateOnAnimation();
    }

    /* renamed from: a */
    public static void m1549a(View view, Runnable action) {
        view.postOnAnimation(action);
    }

    /* renamed from: a */
    public static void m1550a(View view, Runnable action, long delayMillis) {
        view.postOnAnimationDelayed(action, delayMillis);
    }

    /* renamed from: b */
    public static int m1551b(View view) {
        return view.getImportantForAccessibility();
    }

    /* renamed from: a */
    public static void m1548a(View view, int mode) {
        view.setImportantForAccessibility(mode);
    }

    /* renamed from: c */
    public static ViewParent m1552c(View view) {
        return view.getParentForAccessibility();
    }

    /* renamed from: d */
    public static int m1553d(View view) {
        return view.getMinimumHeight();
    }

    /* renamed from: e */
    public static void m1554e(View view) {
        view.requestFitSystemWindows();
    }

    /* renamed from: f */
    public static boolean m1555f(View view) {
        return view.getFitsSystemWindows();
    }

    /* renamed from: g */
    public static boolean m1556g(View view) {
        return view.hasOverlappingRendering();
    }
}

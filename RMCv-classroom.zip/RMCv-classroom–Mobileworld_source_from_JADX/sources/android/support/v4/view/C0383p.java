package android.support.v4.view;

import android.view.ViewGroup.MarginLayoutParams;

/* compiled from: MarginLayoutParamsCompatJellybeanMr1 */
/* renamed from: android.support.v4.view.p */
class C0383p {
    /* renamed from: a */
    public static int m1762a(MarginLayoutParams lp) {
        return lp.getMarginStart();
    }

    /* renamed from: b */
    public static int m1763b(MarginLayoutParams lp) {
        return lp.getMarginEnd();
    }
}

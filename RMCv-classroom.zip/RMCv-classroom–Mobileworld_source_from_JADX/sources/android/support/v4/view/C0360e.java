package android.support.v4.view;

import android.os.Build.VERSION;

/* compiled from: GravityCompat */
/* renamed from: android.support.v4.view.e */
public final class C0360e {
    /* renamed from: a */
    static final C0357a f610a;

    /* compiled from: GravityCompat */
    /* renamed from: android.support.v4.view.e$a */
    interface C0357a {
        /* renamed from: a */
        int mo325a(int i, int i2);
    }

    /* compiled from: GravityCompat */
    /* renamed from: android.support.v4.view.e$b */
    static class C0358b implements C0357a {
        C0358b() {
        }

        /* renamed from: a */
        public int mo325a(int gravity, int layoutDirection) {
            return -8388609 & gravity;
        }
    }

    /* compiled from: GravityCompat */
    /* renamed from: android.support.v4.view.e$c */
    static class C0359c implements C0357a {
        C0359c() {
        }

        /* renamed from: a */
        public int mo325a(int gravity, int layoutDirection) {
            return C0361f.m1721a(gravity, layoutDirection);
        }
    }

    static {
        if (VERSION.SDK_INT >= 17) {
            f610a = new C0359c();
        } else {
            f610a = new C0358b();
        }
    }

    /* renamed from: a */
    public static int m1720a(int gravity, int layoutDirection) {
        return f610a.mo325a(gravity, layoutDirection);
    }
}

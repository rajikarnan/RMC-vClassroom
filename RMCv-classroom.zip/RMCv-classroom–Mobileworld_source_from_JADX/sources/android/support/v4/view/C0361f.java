package android.support.v4.view;

import android.view.Gravity;

/* compiled from: GravityCompatJellybeanMr1 */
/* renamed from: android.support.v4.view.f */
class C0361f {
    /* renamed from: a */
    public static int m1721a(int gravity, int layoutDirection) {
        return Gravity.getAbsoluteGravity(gravity, layoutDirection);
    }
}

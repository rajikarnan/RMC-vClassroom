package android.support.v4.view;

import android.view.View;

/* compiled from: ViewCompatJellybeanMr1 */
class aq {
    /* renamed from: a */
    public static int m1557a(View view) {
        return view.getLayoutDirection();
    }

    /* renamed from: b */
    public static int m1558b(View view) {
        return view.getWindowSystemUiVisibility();
    }
}

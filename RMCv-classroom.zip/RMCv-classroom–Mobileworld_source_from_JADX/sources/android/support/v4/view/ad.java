package android.support.v4.view;

import android.database.DataSetObservable;
import android.database.DataSetObserver;
import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;

/* compiled from: PagerAdapter */
public abstract class ad {
    /* renamed from: a */
    private final DataSetObservable f572a = new DataSetObservable();
    /* renamed from: b */
    private DataSetObserver f573b;

    /* renamed from: a */
    public abstract int mo1147a();

    /* renamed from: a */
    public abstract boolean mo1151a(View view, Object obj);

    /* renamed from: a */
    public void m1286a(ViewGroup container) {
        m1284a((View) container);
    }

    /* renamed from: a */
    public Object mo1149a(ViewGroup container, int position) {
        return m1280a((View) container, position);
    }

    /* renamed from: a */
    public void mo1150a(ViewGroup container, int position, Object object) {
        m1285a((View) container, position, object);
    }

    /* renamed from: b */
    public void m1295b(ViewGroup container, int position, Object object) {
        m1293b((View) container, position, object);
    }

    /* renamed from: b */
    public void m1294b(ViewGroup container) {
        m1292b((View) container);
    }

    /* renamed from: a */
    public void m1284a(View container) {
    }

    /* renamed from: a */
    public Object m1280a(View container, int position) {
        throw new UnsupportedOperationException("Required method instantiateItem was not overridden");
    }

    /* renamed from: a */
    public void m1285a(View container, int position, Object object) {
        throw new UnsupportedOperationException("Required method destroyItem was not overridden");
    }

    /* renamed from: b */
    public void m1293b(View container, int position, Object object) {
    }

    /* renamed from: b */
    public void m1292b(View container) {
    }

    /* renamed from: b */
    public Parcelable m1290b() {
        return null;
    }

    /* renamed from: a */
    public void m1283a(Parcelable state, ClassLoader loader) {
    }

    /* renamed from: a */
    public int m1278a(Object object) {
        return -1;
    }

    /* renamed from: c */
    public void m1296c() {
        synchronized (this) {
            if (this.f573b != null) {
                this.f573b.onChanged();
            }
        }
        this.f572a.notifyChanged();
    }

    /* renamed from: a */
    public void m1282a(DataSetObserver observer) {
        this.f572a.registerObserver(observer);
    }

    /* renamed from: b */
    public void m1291b(DataSetObserver observer) {
        this.f572a.unregisterObserver(observer);
    }

    /* renamed from: c */
    void m1297c(DataSetObserver observer) {
        synchronized (this) {
            this.f573b = observer;
        }
    }

    /* renamed from: a */
    public CharSequence mo1148a(int position) {
        return null;
    }

    /* renamed from: b */
    public float m1289b(int position) {
        return 1.0f;
    }
}

package android.support.v4.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

/* compiled from: LayoutInflaterFactory */
/* renamed from: android.support.v4.view.n */
public interface C0165n {
    View onCreateView(View view, String str, Context context, AttributeSet attributeSet);
}

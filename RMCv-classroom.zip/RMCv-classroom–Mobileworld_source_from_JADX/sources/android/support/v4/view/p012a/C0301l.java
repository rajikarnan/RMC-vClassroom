package android.support.v4.view.p012a;

import android.view.accessibility.AccessibilityRecord;

/* compiled from: AccessibilityRecordCompatIcsMr1 */
/* renamed from: android.support.v4.view.a.l */
class C0301l {
    /* renamed from: a */
    public static void m1272a(Object record, int maxScrollX) {
        ((AccessibilityRecord) record).setMaxScrollX(maxScrollX);
    }

    /* renamed from: b */
    public static void m1273b(Object record, int maxScrollY) {
        ((AccessibilityRecord) record).setMaxScrollY(maxScrollY);
    }
}

package android.support.v4.view.p012a;

import android.os.Build.VERSION;
import android.view.accessibility.AccessibilityEvent;

/* compiled from: AccessibilityEventCompat */
/* renamed from: android.support.v4.view.a.a */
public final class C0265a {
    /* renamed from: a */
    private static final C0261d f534a;

    /* compiled from: AccessibilityEventCompat */
    /* renamed from: android.support.v4.view.a.a$d */
    interface C0261d {
    }

    /* compiled from: AccessibilityEventCompat */
    /* renamed from: android.support.v4.view.a.a$c */
    static class C0262c implements C0261d {
        C0262c() {
        }
    }

    /* compiled from: AccessibilityEventCompat */
    /* renamed from: android.support.v4.view.a.a$a */
    static class C0263a extends C0262c {
        C0263a() {
        }
    }

    /* compiled from: AccessibilityEventCompat */
    /* renamed from: android.support.v4.view.a.a$b */
    static class C0264b extends C0263a {
        C0264b() {
        }
    }

    static {
        if (VERSION.SDK_INT >= 19) {
            f534a = new C0264b();
        } else if (VERSION.SDK_INT >= 14) {
            f534a = new C0263a();
        } else {
            f534a = new C0262c();
        }
    }

    /* renamed from: a */
    public static C0299j m994a(AccessibilityEvent event) {
        return new C0299j(event);
    }
}

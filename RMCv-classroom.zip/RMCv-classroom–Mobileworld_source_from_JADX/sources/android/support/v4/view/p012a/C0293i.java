package android.support.v4.view.p012a;

import android.os.Bundle;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import java.util.List;

/* compiled from: AccessibilityNodeProviderCompatKitKat */
/* renamed from: android.support.v4.view.a.i */
class C0293i {

    /* compiled from: AccessibilityNodeProviderCompatKitKat */
    /* renamed from: android.support.v4.view.a.i$a */
    interface C0286a {
        /* renamed from: a */
        Object mo231a(int i);

        /* renamed from: a */
        List<Object> mo232a(String str, int i);

        /* renamed from: a */
        boolean mo233a(int i, int i2, Bundle bundle);

        /* renamed from: b */
        Object mo234b(int i);
    }

    /* renamed from: a */
    public static Object m1233a(final C0286a bridge) {
        return new AccessibilityNodeProvider() {
            public AccessibilityNodeInfo createAccessibilityNodeInfo(int virtualViewId) {
                return (AccessibilityNodeInfo) bridge.mo231a(virtualViewId);
            }

            public List<AccessibilityNodeInfo> findAccessibilityNodeInfosByText(String text, int virtualViewId) {
                return bridge.mo232a(text, virtualViewId);
            }

            public boolean performAction(int virtualViewId, int action, Bundle arguments) {
                return bridge.mo233a(virtualViewId, action, arguments);
            }

            public AccessibilityNodeInfo findFocus(int focus) {
                return (AccessibilityNodeInfo) bridge.mo234b(focus);
            }
        };
    }
}

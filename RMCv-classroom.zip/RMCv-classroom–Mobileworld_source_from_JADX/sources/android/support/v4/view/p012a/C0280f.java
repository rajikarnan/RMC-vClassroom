package android.support.v4.view.p012a;

import android.view.accessibility.AccessibilityNodeInfo;

/* compiled from: AccessibilityNodeInfoCompatJellybeanMr2 */
/* renamed from: android.support.v4.view.a.f */
class C0280f {
    /* renamed from: a */
    public static String m1208a(Object info) {
        return ((AccessibilityNodeInfo) info).getViewIdResourceName();
    }
}

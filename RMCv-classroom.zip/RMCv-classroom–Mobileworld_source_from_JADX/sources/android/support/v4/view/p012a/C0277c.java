package android.support.v4.view.p012a;

import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeInfo.AccessibilityAction;

/* compiled from: AccessibilityNodeInfoCompatApi21 */
/* renamed from: android.support.v4.view.a.c */
class C0277c {
    /* renamed from: a */
    public static boolean m1168a(Object info, Object action) {
        return ((AccessibilityNodeInfo) info).removeAction((AccessibilityAction) action);
    }

    /* renamed from: a */
    static Object m1167a(int actionId, CharSequence label) {
        return new AccessibilityAction(actionId, label);
    }
}

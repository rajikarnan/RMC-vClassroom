package android.support.v4.view.p012a;

import android.os.Build.VERSION;

/* compiled from: AccessibilityRecordCompat */
/* renamed from: android.support.v4.view.a.j */
public class C0299j {
    /* renamed from: a */
    private static final C0294c f568a;
    /* renamed from: b */
    private final Object f569b;

    /* compiled from: AccessibilityRecordCompat */
    /* renamed from: android.support.v4.view.a.j$c */
    interface C0294c {
        /* renamed from: a */
        void mo235a(Object obj, int i);

        /* renamed from: a */
        void mo236a(Object obj, boolean z);

        /* renamed from: b */
        void mo237b(Object obj, int i);

        /* renamed from: c */
        void mo238c(Object obj, int i);

        /* renamed from: d */
        void mo239d(Object obj, int i);

        /* renamed from: e */
        void mo240e(Object obj, int i);

        /* renamed from: f */
        void mo241f(Object obj, int i);

        /* renamed from: g */
        void mo242g(Object obj, int i);
    }

    /* compiled from: AccessibilityRecordCompat */
    /* renamed from: android.support.v4.view.a.j$e */
    static class C0295e implements C0294c {
        C0295e() {
        }

        /* renamed from: a */
        public void mo235a(Object record, int fromIndex) {
        }

        /* renamed from: b */
        public void mo237b(Object record, int itemCount) {
        }

        /* renamed from: f */
        public void mo241f(Object record, int maxScrollX) {
        }

        /* renamed from: g */
        public void mo242g(Object record, int maxScrollY) {
        }

        /* renamed from: c */
        public void mo238c(Object record, int scrollX) {
        }

        /* renamed from: d */
        public void mo239d(Object record, int scrollY) {
        }

        /* renamed from: a */
        public void mo236a(Object record, boolean scrollable) {
        }

        /* renamed from: e */
        public void mo240e(Object record, int toIndex) {
        }
    }

    /* compiled from: AccessibilityRecordCompat */
    /* renamed from: android.support.v4.view.a.j$a */
    static class C0296a extends C0295e {
        C0296a() {
        }

        /* renamed from: a */
        public void mo235a(Object record, int fromIndex) {
            C0300k.m1266a(record, fromIndex);
        }

        /* renamed from: b */
        public void mo237b(Object record, int itemCount) {
            C0300k.m1268b(record, itemCount);
        }

        /* renamed from: c */
        public void mo238c(Object record, int scrollX) {
            C0300k.m1269c(record, scrollX);
        }

        /* renamed from: d */
        public void mo239d(Object record, int scrollY) {
            C0300k.m1270d(record, scrollY);
        }

        /* renamed from: a */
        public void mo236a(Object record, boolean scrollable) {
            C0300k.m1267a(record, scrollable);
        }

        /* renamed from: e */
        public void mo240e(Object record, int toIndex) {
            C0300k.m1271e(record, toIndex);
        }
    }

    /* compiled from: AccessibilityRecordCompat */
    /* renamed from: android.support.v4.view.a.j$b */
    static class C0297b extends C0296a {
        C0297b() {
        }

        /* renamed from: f */
        public void mo241f(Object record, int maxScrollX) {
            C0301l.m1272a(record, maxScrollX);
        }

        /* renamed from: g */
        public void mo242g(Object record, int maxScrollY) {
            C0301l.m1273b(record, maxScrollY);
        }
    }

    /* compiled from: AccessibilityRecordCompat */
    /* renamed from: android.support.v4.view.a.j$d */
    static class C0298d extends C0297b {
        C0298d() {
        }
    }

    static {
        if (VERSION.SDK_INT >= 16) {
            f568a = new C0298d();
        } else if (VERSION.SDK_INT >= 15) {
            f568a = new C0297b();
        } else if (VERSION.SDK_INT >= 14) {
            f568a = new C0296a();
        } else {
            f568a = new C0295e();
        }
    }

    public C0299j(Object record) {
        this.f569b = record;
    }

    /* renamed from: a */
    public void m1259a(boolean scrollable) {
        f568a.mo236a(this.f569b, scrollable);
    }

    /* renamed from: a */
    public void m1258a(int itemCount) {
        f568a.mo237b(this.f569b, itemCount);
    }

    /* renamed from: b */
    public void m1260b(int fromIndex) {
        f568a.mo235a(this.f569b, fromIndex);
    }

    /* renamed from: c */
    public void m1261c(int toIndex) {
        f568a.mo240e(this.f569b, toIndex);
    }

    /* renamed from: d */
    public void m1262d(int scrollX) {
        f568a.mo238c(this.f569b, scrollX);
    }

    /* renamed from: e */
    public void m1263e(int scrollY) {
        f568a.mo239d(this.f569b, scrollY);
    }

    /* renamed from: f */
    public void m1264f(int maxScrollX) {
        f568a.mo241f(this.f569b, maxScrollX);
    }

    /* renamed from: g */
    public void m1265g(int maxScrollY) {
        f568a.mo242g(this.f569b, maxScrollY);
    }

    public int hashCode() {
        return this.f569b == null ? 0 : this.f569b.hashCode();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        C0299j other = (C0299j) obj;
        if (this.f569b == null) {
            if (other.f569b != null) {
                return false;
            }
            return true;
        } else if (this.f569b.equals(other.f569b)) {
            return true;
        } else {
            return false;
        }
    }
}

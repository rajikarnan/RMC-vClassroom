package android.support.v4.view.p012a;

import android.view.accessibility.AccessibilityRecord;

/* compiled from: AccessibilityRecordCompatIcs */
/* renamed from: android.support.v4.view.a.k */
class C0300k {
    /* renamed from: a */
    public static void m1266a(Object record, int fromIndex) {
        ((AccessibilityRecord) record).setFromIndex(fromIndex);
    }

    /* renamed from: b */
    public static void m1268b(Object record, int itemCount) {
        ((AccessibilityRecord) record).setItemCount(itemCount);
    }

    /* renamed from: c */
    public static void m1269c(Object record, int scrollX) {
        ((AccessibilityRecord) record).setScrollX(scrollX);
    }

    /* renamed from: d */
    public static void m1270d(Object record, int scrollY) {
        ((AccessibilityRecord) record).setScrollY(scrollY);
    }

    /* renamed from: a */
    public static void m1267a(Object record, boolean scrollable) {
        ((AccessibilityRecord) record).setScrollable(scrollable);
    }

    /* renamed from: e */
    public static void m1271e(Object record, int toIndex) {
        ((AccessibilityRecord) record).setToIndex(toIndex);
    }
}

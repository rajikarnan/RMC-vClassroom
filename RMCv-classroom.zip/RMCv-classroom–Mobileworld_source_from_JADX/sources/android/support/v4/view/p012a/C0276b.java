package android.support.v4.view.p012a;

import android.graphics.Rect;
import android.os.Build.VERSION;
import android.support.v4.app.ag;
import android.view.View;

/* compiled from: AccessibilityNodeInfoCompat */
/* renamed from: android.support.v4.view.a.b */
public class C0276b {
    /* renamed from: a */
    private static final C0267e f558a;
    /* renamed from: b */
    private final Object f559b;

    /* compiled from: AccessibilityNodeInfoCompat */
    /* renamed from: android.support.v4.view.a.b$a */
    public static class C0266a {
        /* renamed from: a */
        public static final C0266a f535a = new C0266a(1, null);
        /* renamed from: b */
        public static final C0266a f536b = new C0266a(2, null);
        /* renamed from: c */
        public static final C0266a f537c = new C0266a(4, null);
        /* renamed from: d */
        public static final C0266a f538d = new C0266a(8, null);
        /* renamed from: e */
        public static final C0266a f539e = new C0266a(16, null);
        /* renamed from: f */
        public static final C0266a f540f = new C0266a(32, null);
        /* renamed from: g */
        public static final C0266a f541g = new C0266a(64, null);
        /* renamed from: h */
        public static final C0266a f542h = new C0266a(ag.FLAG_HIGH_PRIORITY, null);
        /* renamed from: i */
        public static final C0266a f543i = new C0266a(ag.FLAG_LOCAL_ONLY, null);
        /* renamed from: j */
        public static final C0266a f544j = new C0266a(ag.FLAG_GROUP_SUMMARY, null);
        /* renamed from: k */
        public static final C0266a f545k = new C0266a(1024, null);
        /* renamed from: l */
        public static final C0266a f546l = new C0266a(2048, null);
        /* renamed from: m */
        public static final C0266a f547m = new C0266a(4096, null);
        /* renamed from: n */
        public static final C0266a f548n = new C0266a(8192, null);
        /* renamed from: o */
        public static final C0266a f549o = new C0266a(16384, null);
        /* renamed from: p */
        public static final C0266a f550p = new C0266a(32768, null);
        /* renamed from: q */
        public static final C0266a f551q = new C0266a(65536, null);
        /* renamed from: r */
        public static final C0266a f552r = new C0266a(131072, null);
        /* renamed from: s */
        public static final C0266a f553s = new C0266a(262144, null);
        /* renamed from: t */
        public static final C0266a f554t = new C0266a(524288, null);
        /* renamed from: u */
        public static final C0266a f555u = new C0266a(1048576, null);
        /* renamed from: v */
        public static final C0266a f556v = new C0266a(2097152, null);
        /* renamed from: w */
        private final Object f557w;

        public C0266a(int actionId, CharSequence label) {
            this(C0276b.f558a.mo185a(actionId, label));
        }

        private C0266a(Object action) {
            this.f557w = action;
        }
    }

    /* compiled from: AccessibilityNodeInfoCompat */
    /* renamed from: android.support.v4.view.a.b$e */
    interface C0267e {
        /* renamed from: a */
        Object mo185a(int i, CharSequence charSequence);

        /* renamed from: a */
        Object mo186a(Object obj);

        /* renamed from: a */
        void mo187a(Object obj, int i);

        /* renamed from: a */
        void mo188a(Object obj, Rect rect);

        /* renamed from: a */
        void mo189a(Object obj, View view);

        /* renamed from: a */
        void mo190a(Object obj, CharSequence charSequence);

        /* renamed from: a */
        void mo191a(Object obj, boolean z);

        /* renamed from: a */
        boolean mo192a(Object obj, Object obj2);

        /* renamed from: b */
        int mo193b(Object obj);

        /* renamed from: b */
        void mo194b(Object obj, Rect rect);

        /* renamed from: b */
        void mo195b(Object obj, View view);

        /* renamed from: b */
        void mo196b(Object obj, CharSequence charSequence);

        /* renamed from: b */
        void mo197b(Object obj, boolean z);

        /* renamed from: c */
        CharSequence mo198c(Object obj);

        /* renamed from: c */
        void mo199c(Object obj, Rect rect);

        /* renamed from: c */
        void mo200c(Object obj, View view);

        /* renamed from: c */
        void mo201c(Object obj, CharSequence charSequence);

        /* renamed from: c */
        void mo202c(Object obj, boolean z);

        /* renamed from: d */
        CharSequence mo203d(Object obj);

        /* renamed from: d */
        void mo204d(Object obj, Rect rect);

        /* renamed from: d */
        void mo205d(Object obj, boolean z);

        /* renamed from: e */
        CharSequence mo206e(Object obj);

        /* renamed from: e */
        void mo207e(Object obj, boolean z);

        /* renamed from: f */
        CharSequence mo208f(Object obj);

        /* renamed from: f */
        void mo209f(Object obj, boolean z);

        /* renamed from: g */
        void mo210g(Object obj, boolean z);

        /* renamed from: g */
        boolean mo211g(Object obj);

        /* renamed from: h */
        void mo212h(Object obj, boolean z);

        /* renamed from: h */
        boolean mo213h(Object obj);

        /* renamed from: i */
        void mo214i(Object obj, boolean z);

        /* renamed from: i */
        boolean mo215i(Object obj);

        /* renamed from: j */
        boolean mo216j(Object obj);

        /* renamed from: k */
        boolean mo217k(Object obj);

        /* renamed from: l */
        boolean mo218l(Object obj);

        /* renamed from: m */
        boolean mo219m(Object obj);

        /* renamed from: n */
        boolean mo220n(Object obj);

        /* renamed from: o */
        boolean mo221o(Object obj);

        /* renamed from: p */
        boolean mo222p(Object obj);

        /* renamed from: q */
        void mo223q(Object obj);

        /* renamed from: r */
        boolean mo224r(Object obj);

        /* renamed from: s */
        boolean mo225s(Object obj);

        /* renamed from: t */
        String mo226t(Object obj);
    }

    /* compiled from: AccessibilityNodeInfoCompat */
    /* renamed from: android.support.v4.view.a.b$j */
    static class C0268j implements C0267e {
        C0268j() {
        }

        /* renamed from: a */
        public Object mo185a(int actionId, CharSequence label) {
            return null;
        }

        /* renamed from: a */
        public Object mo186a(Object info) {
            return null;
        }

        /* renamed from: a */
        public void mo187a(Object info, int action) {
        }

        /* renamed from: a */
        public boolean mo192a(Object info, Object action) {
            return false;
        }

        /* renamed from: a */
        public void mo189a(Object info, View child) {
        }

        /* renamed from: b */
        public int mo193b(Object info) {
            return 0;
        }

        /* renamed from: a */
        public void mo188a(Object info, Rect outBounds) {
        }

        /* renamed from: b */
        public void mo194b(Object info, Rect outBounds) {
        }

        /* renamed from: c */
        public CharSequence mo198c(Object info) {
            return null;
        }

        /* renamed from: d */
        public CharSequence mo203d(Object info) {
            return null;
        }

        /* renamed from: e */
        public CharSequence mo206e(Object info) {
            return null;
        }

        /* renamed from: f */
        public CharSequence mo208f(Object info) {
            return null;
        }

        /* renamed from: g */
        public boolean mo211g(Object info) {
            return false;
        }

        /* renamed from: h */
        public boolean mo213h(Object info) {
            return false;
        }

        /* renamed from: i */
        public boolean mo215i(Object info) {
            return false;
        }

        /* renamed from: j */
        public boolean mo216j(Object info) {
            return false;
        }

        /* renamed from: k */
        public boolean mo217k(Object info) {
            return false;
        }

        /* renamed from: l */
        public boolean mo218l(Object info) {
            return false;
        }

        /* renamed from: r */
        public boolean mo224r(Object info) {
            return false;
        }

        /* renamed from: s */
        public boolean mo225s(Object info) {
            return false;
        }

        /* renamed from: m */
        public boolean mo219m(Object info) {
            return false;
        }

        /* renamed from: n */
        public boolean mo220n(Object info) {
            return false;
        }

        /* renamed from: o */
        public boolean mo221o(Object info) {
            return false;
        }

        /* renamed from: p */
        public boolean mo222p(Object info) {
            return false;
        }

        /* renamed from: c */
        public void mo199c(Object info, Rect bounds) {
        }

        /* renamed from: d */
        public void mo204d(Object info, Rect bounds) {
        }

        /* renamed from: a */
        public void mo190a(Object info, CharSequence className) {
        }

        /* renamed from: a */
        public void mo191a(Object info, boolean clickable) {
        }

        /* renamed from: b */
        public void mo196b(Object info, CharSequence contentDescription) {
        }

        /* renamed from: b */
        public void mo197b(Object info, boolean enabled) {
        }

        /* renamed from: c */
        public void mo202c(Object info, boolean focusable) {
        }

        /* renamed from: d */
        public void mo205d(Object info, boolean focused) {
        }

        /* renamed from: h */
        public void mo212h(Object info, boolean visibleToUser) {
        }

        /* renamed from: i */
        public void mo214i(Object info, boolean focused) {
        }

        /* renamed from: e */
        public void mo207e(Object info, boolean longClickable) {
        }

        /* renamed from: c */
        public void mo201c(Object info, CharSequence packageName) {
        }

        /* renamed from: b */
        public void mo195b(Object info, View parent) {
        }

        /* renamed from: f */
        public void mo209f(Object info, boolean scrollable) {
        }

        /* renamed from: g */
        public void mo210g(Object info, boolean selected) {
        }

        /* renamed from: c */
        public void mo200c(Object info, View source) {
        }

        /* renamed from: q */
        public void mo223q(Object info) {
        }

        /* renamed from: t */
        public String mo226t(Object info) {
            return null;
        }
    }

    /* compiled from: AccessibilityNodeInfoCompat */
    /* renamed from: android.support.v4.view.a.b$d */
    static class C0269d extends C0268j {
        C0269d() {
        }

        /* renamed from: a */
        public Object mo186a(Object info) {
            return C0278d.m1169a(info);
        }

        /* renamed from: a */
        public void mo187a(Object info, int action) {
            C0278d.m1170a(info, action);
        }

        /* renamed from: a */
        public void mo189a(Object info, View child) {
            C0278d.m1172a(info, child);
        }

        /* renamed from: b */
        public int mo193b(Object info) {
            return C0278d.m1175b(info);
        }

        /* renamed from: a */
        public void mo188a(Object info, Rect outBounds) {
            C0278d.m1171a(info, outBounds);
        }

        /* renamed from: b */
        public void mo194b(Object info, Rect outBounds) {
            C0278d.m1176b(info, outBounds);
        }

        /* renamed from: c */
        public CharSequence mo198c(Object info) {
            return C0278d.m1180c(info);
        }

        /* renamed from: d */
        public CharSequence mo203d(Object info) {
            return C0278d.m1185d(info);
        }

        /* renamed from: e */
        public CharSequence mo206e(Object info) {
            return C0278d.m1188e(info);
        }

        /* renamed from: f */
        public CharSequence mo208f(Object info) {
            return C0278d.m1190f(info);
        }

        /* renamed from: g */
        public boolean mo211g(Object info) {
            return C0278d.m1193g(info);
        }

        /* renamed from: h */
        public boolean mo213h(Object info) {
            return C0278d.m1194h(info);
        }

        /* renamed from: i */
        public boolean mo215i(Object info) {
            return C0278d.m1195i(info);
        }

        /* renamed from: j */
        public boolean mo216j(Object info) {
            return C0278d.m1196j(info);
        }

        /* renamed from: k */
        public boolean mo217k(Object info) {
            return C0278d.m1197k(info);
        }

        /* renamed from: l */
        public boolean mo218l(Object info) {
            return C0278d.m1198l(info);
        }

        /* renamed from: m */
        public boolean mo219m(Object info) {
            return C0278d.m1199m(info);
        }

        /* renamed from: n */
        public boolean mo220n(Object info) {
            return C0278d.m1200n(info);
        }

        /* renamed from: o */
        public boolean mo221o(Object info) {
            return C0278d.m1201o(info);
        }

        /* renamed from: p */
        public boolean mo222p(Object info) {
            return C0278d.m1202p(info);
        }

        /* renamed from: c */
        public void mo199c(Object info, Rect bounds) {
            C0278d.m1181c(info, bounds);
        }

        /* renamed from: d */
        public void mo204d(Object info, Rect bounds) {
            C0278d.m1186d(info, bounds);
        }

        /* renamed from: a */
        public void mo190a(Object info, CharSequence className) {
            C0278d.m1173a(info, className);
        }

        /* renamed from: a */
        public void mo191a(Object info, boolean clickable) {
            C0278d.m1174a(info, clickable);
        }

        /* renamed from: b */
        public void mo196b(Object info, CharSequence contentDescription) {
            C0278d.m1178b(info, contentDescription);
        }

        /* renamed from: b */
        public void mo197b(Object info, boolean enabled) {
            C0278d.m1179b(info, enabled);
        }

        /* renamed from: c */
        public void mo202c(Object info, boolean focusable) {
            C0278d.m1184c(info, focusable);
        }

        /* renamed from: d */
        public void mo205d(Object info, boolean focused) {
            C0278d.m1187d(info, focused);
        }

        /* renamed from: e */
        public void mo207e(Object info, boolean longClickable) {
            C0278d.m1189e(info, longClickable);
        }

        /* renamed from: c */
        public void mo201c(Object info, CharSequence packageName) {
            C0278d.m1183c(info, packageName);
        }

        /* renamed from: b */
        public void mo195b(Object info, View parent) {
            C0278d.m1177b(info, parent);
        }

        /* renamed from: f */
        public void mo209f(Object info, boolean scrollable) {
            C0278d.m1191f(info, scrollable);
        }

        /* renamed from: g */
        public void mo210g(Object info, boolean selected) {
            C0278d.m1192g(info, selected);
        }

        /* renamed from: c */
        public void mo200c(Object info, View source) {
            C0278d.m1182c(info, source);
        }

        /* renamed from: q */
        public void mo223q(Object info) {
            C0278d.m1203q(info);
        }
    }

    /* compiled from: AccessibilityNodeInfoCompat */
    /* renamed from: android.support.v4.view.a.b$f */
    static class C0270f extends C0269d {
        C0270f() {
        }

        /* renamed from: r */
        public boolean mo224r(Object info) {
            return C0279e.m1205a(info);
        }

        /* renamed from: h */
        public void mo212h(Object info, boolean visibleToUser) {
            C0279e.m1204a(info, visibleToUser);
        }

        /* renamed from: s */
        public boolean mo225s(Object info) {
            return C0279e.m1207b(info);
        }

        /* renamed from: i */
        public void mo214i(Object info, boolean focused) {
            C0279e.m1206b(info, focused);
        }
    }

    /* compiled from: AccessibilityNodeInfoCompat */
    /* renamed from: android.support.v4.view.a.b$g */
    static class C0271g extends C0270f {
        C0271g() {
        }
    }

    /* compiled from: AccessibilityNodeInfoCompat */
    /* renamed from: android.support.v4.view.a.b$h */
    static class C0272h extends C0271g {
        C0272h() {
        }

        /* renamed from: t */
        public String mo226t(Object info) {
            return C0280f.m1208a(info);
        }
    }

    /* compiled from: AccessibilityNodeInfoCompat */
    /* renamed from: android.support.v4.view.a.b$i */
    static class C0273i extends C0272h {
        C0273i() {
        }
    }

    /* compiled from: AccessibilityNodeInfoCompat */
    /* renamed from: android.support.v4.view.a.b$b */
    static class C0274b extends C0273i {
        C0274b() {
        }

        /* renamed from: a */
        public Object mo185a(int actionId, CharSequence label) {
            return C0277c.m1167a(actionId, label);
        }

        /* renamed from: a */
        public boolean mo192a(Object info, Object action) {
            return C0277c.m1168a(info, action);
        }
    }

    /* compiled from: AccessibilityNodeInfoCompat */
    /* renamed from: android.support.v4.view.a.b$c */
    static class C0275c extends C0274b {
        C0275c() {
        }
    }

    static {
        if (VERSION.SDK_INT >= 22) {
            f558a = new C0275c();
        } else if (VERSION.SDK_INT >= 21) {
            f558a = new C0274b();
        } else if (VERSION.SDK_INT >= 19) {
            f558a = new C0273i();
        } else if (VERSION.SDK_INT >= 18) {
            f558a = new C0272h();
        } else if (VERSION.SDK_INT >= 17) {
            f558a = new C0271g();
        } else if (VERSION.SDK_INT >= 16) {
            f558a = new C0270f();
        } else if (VERSION.SDK_INT >= 14) {
            f558a = new C0269d();
        } else {
            f558a = new C0268j();
        }
    }

    /* renamed from: a */
    static C0276b m1123a(Object object) {
        if (object != null) {
            return new C0276b(object);
        }
        return null;
    }

    public C0276b(Object info) {
        this.f559b = info;
    }

    /* renamed from: a */
    public Object m1126a() {
        return this.f559b;
    }

    /* renamed from: a */
    public static C0276b m1122a(C0276b info) {
        return C0276b.m1123a(f558a.mo186a(info.f559b));
    }

    /* renamed from: a */
    public void m1129a(View source) {
        f558a.mo200c(this.f559b, source);
    }

    /* renamed from: b */
    public void m1135b(View child) {
        f558a.mo189a(this.f559b, child);
    }

    /* renamed from: b */
    public int m1133b() {
        return f558a.mo193b(this.f559b);
    }

    /* renamed from: a */
    public void m1127a(int action) {
        f558a.mo187a(this.f559b, action);
    }

    /* renamed from: a */
    public boolean m1132a(C0266a action) {
        return f558a.mo192a(this.f559b, action.f557w);
    }

    /* renamed from: c */
    public void m1139c(View parent) {
        f558a.mo195b(this.f559b, parent);
    }

    /* renamed from: a */
    public void m1128a(Rect outBounds) {
        f558a.mo188a(this.f559b, outBounds);
    }

    /* renamed from: b */
    public void m1134b(Rect bounds) {
        f558a.mo199c(this.f559b, bounds);
    }

    /* renamed from: c */
    public void m1138c(Rect outBounds) {
        f558a.mo194b(this.f559b, outBounds);
    }

    /* renamed from: d */
    public void m1143d(Rect bounds) {
        f558a.mo204d(this.f559b, bounds);
    }

    /* renamed from: c */
    public boolean m1142c() {
        return f558a.mo211g(this.f559b);
    }

    /* renamed from: d */
    public boolean m1145d() {
        return f558a.mo213h(this.f559b);
    }

    /* renamed from: e */
    public boolean m1147e() {
        return f558a.mo217k(this.f559b);
    }

    /* renamed from: a */
    public void m1131a(boolean focusable) {
        f558a.mo202c(this.f559b, focusable);
    }

    /* renamed from: f */
    public boolean m1149f() {
        return f558a.mo218l(this.f559b);
    }

    /* renamed from: b */
    public void m1137b(boolean focused) {
        f558a.mo205d(this.f559b, focused);
    }

    /* renamed from: g */
    public boolean m1151g() {
        return f558a.mo224r(this.f559b);
    }

    /* renamed from: c */
    public void m1141c(boolean visibleToUser) {
        f558a.mo212h(this.f559b, visibleToUser);
    }

    /* renamed from: h */
    public boolean m1153h() {
        return f558a.mo225s(this.f559b);
    }

    /* renamed from: d */
    public void m1144d(boolean focused) {
        f558a.mo214i(this.f559b, focused);
    }

    /* renamed from: i */
    public boolean m1155i() {
        return f558a.mo222p(this.f559b);
    }

    /* renamed from: e */
    public void m1146e(boolean selected) {
        f558a.mo210g(this.f559b, selected);
    }

    /* renamed from: j */
    public boolean m1156j() {
        return f558a.mo215i(this.f559b);
    }

    /* renamed from: f */
    public void m1148f(boolean clickable) {
        f558a.mo191a(this.f559b, clickable);
    }

    /* renamed from: k */
    public boolean m1157k() {
        return f558a.mo219m(this.f559b);
    }

    /* renamed from: g */
    public void m1150g(boolean longClickable) {
        f558a.mo207e(this.f559b, longClickable);
    }

    /* renamed from: l */
    public boolean m1158l() {
        return f558a.mo216j(this.f559b);
    }

    /* renamed from: h */
    public void m1152h(boolean enabled) {
        f558a.mo197b(this.f559b, enabled);
    }

    /* renamed from: m */
    public boolean m1159m() {
        return f558a.mo220n(this.f559b);
    }

    /* renamed from: n */
    public boolean m1160n() {
        return f558a.mo221o(this.f559b);
    }

    /* renamed from: i */
    public void m1154i(boolean scrollable) {
        f558a.mo209f(this.f559b, scrollable);
    }

    /* renamed from: o */
    public CharSequence m1161o() {
        return f558a.mo206e(this.f559b);
    }

    /* renamed from: a */
    public void m1130a(CharSequence packageName) {
        f558a.mo201c(this.f559b, packageName);
    }

    /* renamed from: p */
    public CharSequence m1162p() {
        return f558a.mo198c(this.f559b);
    }

    /* renamed from: b */
    public void m1136b(CharSequence className) {
        f558a.mo190a(this.f559b, className);
    }

    /* renamed from: q */
    public CharSequence m1163q() {
        return f558a.mo208f(this.f559b);
    }

    /* renamed from: r */
    public CharSequence m1164r() {
        return f558a.mo203d(this.f559b);
    }

    /* renamed from: c */
    public void m1140c(CharSequence contentDescription) {
        f558a.mo196b(this.f559b, contentDescription);
    }

    /* renamed from: s */
    public void m1165s() {
        f558a.mo223q(this.f559b);
    }

    /* renamed from: t */
    public String m1166t() {
        return f558a.mo226t(this.f559b);
    }

    public int hashCode() {
        return this.f559b == null ? 0 : this.f559b.hashCode();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        C0276b other = (C0276b) obj;
        if (this.f559b == null) {
            if (other.f559b != null) {
                return false;
            }
            return true;
        } else if (this.f559b.equals(other.f559b)) {
            return true;
        } else {
            return false;
        }
    }

    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(super.toString());
        Rect bounds = new Rect();
        m1128a(bounds);
        builder.append("; boundsInParent: " + bounds);
        m1138c(bounds);
        builder.append("; boundsInScreen: " + bounds);
        builder.append("; packageName: ").append(m1161o());
        builder.append("; className: ").append(m1162p());
        builder.append("; text: ").append(m1163q());
        builder.append("; contentDescription: ").append(m1164r());
        builder.append("; viewId: ").append(m1166t());
        builder.append("; checkable: ").append(m1142c());
        builder.append("; checked: ").append(m1145d());
        builder.append("; focusable: ").append(m1147e());
        builder.append("; focused: ").append(m1149f());
        builder.append("; selected: ").append(m1155i());
        builder.append("; clickable: ").append(m1156j());
        builder.append("; longClickable: ").append(m1157k());
        builder.append("; enabled: ").append(m1158l());
        builder.append("; password: ").append(m1159m());
        builder.append("; scrollable: " + m1160n());
        builder.append("; [");
        int actionBits = m1133b();
        while (actionBits != 0) {
            int action = 1 << Integer.numberOfTrailingZeros(actionBits);
            actionBits &= action ^ -1;
            builder.append(C0276b.m1124b(action));
            if (actionBits != 0) {
                builder.append(", ");
            }
        }
        builder.append("]");
        return builder.toString();
    }

    /* renamed from: b */
    private static String m1124b(int action) {
        switch (action) {
            case 1:
                return "ACTION_FOCUS";
            case 2:
                return "ACTION_CLEAR_FOCUS";
            case 4:
                return "ACTION_SELECT";
            case 8:
                return "ACTION_CLEAR_SELECTION";
            case 16:
                return "ACTION_CLICK";
            case 32:
                return "ACTION_LONG_CLICK";
            case 64:
                return "ACTION_ACCESSIBILITY_FOCUS";
            case ag.FLAG_HIGH_PRIORITY /*128*/:
                return "ACTION_CLEAR_ACCESSIBILITY_FOCUS";
            case ag.FLAG_LOCAL_ONLY /*256*/:
                return "ACTION_NEXT_AT_MOVEMENT_GRANULARITY";
            case ag.FLAG_GROUP_SUMMARY /*512*/:
                return "ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY";
            case 1024:
                return "ACTION_NEXT_HTML_ELEMENT";
            case 2048:
                return "ACTION_PREVIOUS_HTML_ELEMENT";
            case 4096:
                return "ACTION_SCROLL_FORWARD";
            case 8192:
                return "ACTION_SCROLL_BACKWARD";
            case 16384:
                return "ACTION_COPY";
            case 32768:
                return "ACTION_PASTE";
            case 65536:
                return "ACTION_CUT";
            case 131072:
                return "ACTION_SET_SELECTION";
            default:
                return "ACTION_UNKNOWN";
        }
    }
}

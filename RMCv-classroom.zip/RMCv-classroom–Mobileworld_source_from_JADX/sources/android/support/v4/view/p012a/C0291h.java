package android.support.v4.view.p012a;

import android.os.Bundle;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import java.util.List;

/* compiled from: AccessibilityNodeProviderCompatJellyBean */
/* renamed from: android.support.v4.view.a.h */
class C0291h {

    /* compiled from: AccessibilityNodeProviderCompatJellyBean */
    /* renamed from: android.support.v4.view.a.h$a */
    interface C0282a {
        /* renamed from: a */
        Object mo227a(int i);

        /* renamed from: a */
        List<Object> mo228a(String str, int i);

        /* renamed from: a */
        boolean mo229a(int i, int i2, Bundle bundle);
    }

    /* renamed from: a */
    public static Object m1232a(final C0282a bridge) {
        return new AccessibilityNodeProvider() {
            public AccessibilityNodeInfo createAccessibilityNodeInfo(int virtualViewId) {
                return (AccessibilityNodeInfo) bridge.mo227a(virtualViewId);
            }

            public List<AccessibilityNodeInfo> findAccessibilityNodeInfosByText(String text, int virtualViewId) {
                return bridge.mo228a(text, virtualViewId);
            }

            public boolean performAction(int virtualViewId, int action, Bundle arguments) {
                return bridge.mo229a(virtualViewId, action, arguments);
            }
        };
    }
}

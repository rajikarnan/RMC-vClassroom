package android.support.v4.view.p012a;

import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.view.p012a.C0291h.C0282a;
import android.support.v4.view.p012a.C0293i.C0286a;
import java.util.ArrayList;
import java.util.List;

/* compiled from: AccessibilityNodeProviderCompat */
/* renamed from: android.support.v4.view.a.g */
public class C0289g {
    /* renamed from: a */
    private static final C0281a f564a;
    /* renamed from: b */
    private final Object f565b;

    /* compiled from: AccessibilityNodeProviderCompat */
    /* renamed from: android.support.v4.view.a.g$a */
    interface C0281a {
        /* renamed from: a */
        Object mo230a(C0289g c0289g);
    }

    /* compiled from: AccessibilityNodeProviderCompat */
    /* renamed from: android.support.v4.view.a.g$d */
    static class C0284d implements C0281a {
        C0284d() {
        }

        /* renamed from: a */
        public Object mo230a(C0289g compat) {
            return null;
        }
    }

    /* compiled from: AccessibilityNodeProviderCompat */
    /* renamed from: android.support.v4.view.a.g$b */
    static class C0285b extends C0284d {
        C0285b() {
        }

        /* renamed from: a */
        public Object mo230a(final C0289g compat) {
            return C0291h.m1232a(new C0282a(this) {
                /* renamed from: b */
                final /* synthetic */ C0285b f561b;

                /* renamed from: a */
                public boolean mo229a(int virtualViewId, int action, Bundle arguments) {
                    return compat.m1230a(virtualViewId, action, arguments);
                }

                /* renamed from: a */
                public List<Object> mo228a(String text, int virtualViewId) {
                    List<C0276b> compatInfos = compat.m1229a(text, virtualViewId);
                    List<Object> infos = new ArrayList();
                    int infoCount = compatInfos.size();
                    for (int i = 0; i < infoCount; i++) {
                        infos.add(((C0276b) compatInfos.get(i)).m1126a());
                    }
                    return infos;
                }

                /* renamed from: a */
                public Object mo227a(int virtualViewId) {
                    C0276b compatInfo = compat.m1227a(virtualViewId);
                    if (compatInfo == null) {
                        return null;
                    }
                    return compatInfo.m1126a();
                }
            });
        }
    }

    /* compiled from: AccessibilityNodeProviderCompat */
    /* renamed from: android.support.v4.view.a.g$c */
    static class C0288c extends C0284d {
        C0288c() {
        }

        /* renamed from: a */
        public Object mo230a(final C0289g compat) {
            return C0293i.m1233a(new C0286a(this) {
                /* renamed from: b */
                final /* synthetic */ C0288c f563b;

                /* renamed from: a */
                public boolean mo233a(int virtualViewId, int action, Bundle arguments) {
                    return compat.m1230a(virtualViewId, action, arguments);
                }

                /* renamed from: a */
                public List<Object> mo232a(String text, int virtualViewId) {
                    List<C0276b> compatInfos = compat.m1229a(text, virtualViewId);
                    List<Object> infos = new ArrayList();
                    int infoCount = compatInfos.size();
                    for (int i = 0; i < infoCount; i++) {
                        infos.add(((C0276b) compatInfos.get(i)).m1126a());
                    }
                    return infos;
                }

                /* renamed from: a */
                public Object mo231a(int virtualViewId) {
                    C0276b compatInfo = compat.m1227a(virtualViewId);
                    if (compatInfo == null) {
                        return null;
                    }
                    return compatInfo.m1126a();
                }

                /* renamed from: b */
                public Object mo234b(int focus) {
                    C0276b compatInfo = compat.m1231b(focus);
                    if (compatInfo == null) {
                        return null;
                    }
                    return compatInfo.m1126a();
                }
            });
        }
    }

    static {
        if (VERSION.SDK_INT >= 19) {
            f564a = new C0288c();
        } else if (VERSION.SDK_INT >= 16) {
            f564a = new C0285b();
        } else {
            f564a = new C0284d();
        }
    }

    public C0289g() {
        this.f565b = f564a.mo230a(this);
    }

    public C0289g(Object provider) {
        this.f565b = provider;
    }

    /* renamed from: a */
    public Object m1228a() {
        return this.f565b;
    }

    /* renamed from: a */
    public C0276b m1227a(int virtualViewId) {
        return null;
    }

    /* renamed from: a */
    public boolean m1230a(int virtualViewId, int action, Bundle arguments) {
        return false;
    }

    /* renamed from: a */
    public List<C0276b> m1229a(String text, int virtualViewId) {
        return null;
    }

    /* renamed from: b */
    public C0276b m1231b(int focus) {
        return null;
    }
}

package android.support.v4.view.p012a;

import android.view.accessibility.AccessibilityNodeInfo;

/* compiled from: AccessibilityNodeInfoCompatJellyBean */
/* renamed from: android.support.v4.view.a.e */
class C0279e {
    /* renamed from: a */
    public static boolean m1205a(Object info) {
        return ((AccessibilityNodeInfo) info).isVisibleToUser();
    }

    /* renamed from: a */
    public static void m1204a(Object info, boolean visibleToUser) {
        ((AccessibilityNodeInfo) info).setVisibleToUser(visibleToUser);
    }

    /* renamed from: b */
    public static boolean m1207b(Object info) {
        return ((AccessibilityNodeInfo) info).isAccessibilityFocused();
    }

    /* renamed from: b */
    public static void m1206b(Object info, boolean focused) {
        ((AccessibilityNodeInfo) info).setAccessibilityFocused(focused);
    }
}

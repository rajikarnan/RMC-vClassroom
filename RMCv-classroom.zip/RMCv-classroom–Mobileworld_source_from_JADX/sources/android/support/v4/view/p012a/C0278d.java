package android.support.v4.view.p012a;

import android.graphics.Rect;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;

/* compiled from: AccessibilityNodeInfoCompatIcs */
/* renamed from: android.support.v4.view.a.d */
class C0278d {
    /* renamed from: a */
    public static Object m1169a(Object info) {
        return AccessibilityNodeInfo.obtain((AccessibilityNodeInfo) info);
    }

    /* renamed from: a */
    public static void m1170a(Object info, int action) {
        ((AccessibilityNodeInfo) info).addAction(action);
    }

    /* renamed from: a */
    public static void m1172a(Object info, View child) {
        ((AccessibilityNodeInfo) info).addChild(child);
    }

    /* renamed from: b */
    public static int m1175b(Object info) {
        return ((AccessibilityNodeInfo) info).getActions();
    }

    /* renamed from: a */
    public static void m1171a(Object info, Rect outBounds) {
        ((AccessibilityNodeInfo) info).getBoundsInParent(outBounds);
    }

    /* renamed from: b */
    public static void m1176b(Object info, Rect outBounds) {
        ((AccessibilityNodeInfo) info).getBoundsInScreen(outBounds);
    }

    /* renamed from: c */
    public static CharSequence m1180c(Object info) {
        return ((AccessibilityNodeInfo) info).getClassName();
    }

    /* renamed from: d */
    public static CharSequence m1185d(Object info) {
        return ((AccessibilityNodeInfo) info).getContentDescription();
    }

    /* renamed from: e */
    public static CharSequence m1188e(Object info) {
        return ((AccessibilityNodeInfo) info).getPackageName();
    }

    /* renamed from: f */
    public static CharSequence m1190f(Object info) {
        return ((AccessibilityNodeInfo) info).getText();
    }

    /* renamed from: g */
    public static boolean m1193g(Object info) {
        return ((AccessibilityNodeInfo) info).isCheckable();
    }

    /* renamed from: h */
    public static boolean m1194h(Object info) {
        return ((AccessibilityNodeInfo) info).isChecked();
    }

    /* renamed from: i */
    public static boolean m1195i(Object info) {
        return ((AccessibilityNodeInfo) info).isClickable();
    }

    /* renamed from: j */
    public static boolean m1196j(Object info) {
        return ((AccessibilityNodeInfo) info).isEnabled();
    }

    /* renamed from: k */
    public static boolean m1197k(Object info) {
        return ((AccessibilityNodeInfo) info).isFocusable();
    }

    /* renamed from: l */
    public static boolean m1198l(Object info) {
        return ((AccessibilityNodeInfo) info).isFocused();
    }

    /* renamed from: m */
    public static boolean m1199m(Object info) {
        return ((AccessibilityNodeInfo) info).isLongClickable();
    }

    /* renamed from: n */
    public static boolean m1200n(Object info) {
        return ((AccessibilityNodeInfo) info).isPassword();
    }

    /* renamed from: o */
    public static boolean m1201o(Object info) {
        return ((AccessibilityNodeInfo) info).isScrollable();
    }

    /* renamed from: p */
    public static boolean m1202p(Object info) {
        return ((AccessibilityNodeInfo) info).isSelected();
    }

    /* renamed from: c */
    public static void m1181c(Object info, Rect bounds) {
        ((AccessibilityNodeInfo) info).setBoundsInParent(bounds);
    }

    /* renamed from: d */
    public static void m1186d(Object info, Rect bounds) {
        ((AccessibilityNodeInfo) info).setBoundsInScreen(bounds);
    }

    /* renamed from: a */
    public static void m1173a(Object info, CharSequence className) {
        ((AccessibilityNodeInfo) info).setClassName(className);
    }

    /* renamed from: a */
    public static void m1174a(Object info, boolean clickable) {
        ((AccessibilityNodeInfo) info).setClickable(clickable);
    }

    /* renamed from: b */
    public static void m1178b(Object info, CharSequence contentDescription) {
        ((AccessibilityNodeInfo) info).setContentDescription(contentDescription);
    }

    /* renamed from: b */
    public static void m1179b(Object info, boolean enabled) {
        ((AccessibilityNodeInfo) info).setEnabled(enabled);
    }

    /* renamed from: c */
    public static void m1184c(Object info, boolean focusable) {
        ((AccessibilityNodeInfo) info).setFocusable(focusable);
    }

    /* renamed from: d */
    public static void m1187d(Object info, boolean focused) {
        ((AccessibilityNodeInfo) info).setFocused(focused);
    }

    /* renamed from: e */
    public static void m1189e(Object info, boolean longClickable) {
        ((AccessibilityNodeInfo) info).setLongClickable(longClickable);
    }

    /* renamed from: c */
    public static void m1183c(Object info, CharSequence packageName) {
        ((AccessibilityNodeInfo) info).setPackageName(packageName);
    }

    /* renamed from: b */
    public static void m1177b(Object info, View parent) {
        ((AccessibilityNodeInfo) info).setParent(parent);
    }

    /* renamed from: f */
    public static void m1191f(Object info, boolean scrollable) {
        ((AccessibilityNodeInfo) info).setScrollable(scrollable);
    }

    /* renamed from: g */
    public static void m1192g(Object info, boolean selected) {
        ((AccessibilityNodeInfo) info).setSelected(selected);
    }

    /* renamed from: c */
    public static void m1182c(Object info, View source) {
        ((AccessibilityNodeInfo) info).setSource(source);
    }

    /* renamed from: q */
    public static void m1203q(Object info) {
        ((AccessibilityNodeInfo) info).recycle();
    }
}

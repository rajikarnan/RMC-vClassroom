package android.support.v4.view;

import android.os.Bundle;
import android.view.View;
import android.view.View.AccessibilityDelegate;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;

/* compiled from: AccessibilityDelegateCompatJellyBean */
/* renamed from: android.support.v4.view.c */
class C0353c {

    /* compiled from: AccessibilityDelegateCompatJellyBean */
    /* renamed from: android.support.v4.view.c$a */
    public interface C0258a {
        /* renamed from: a */
        Object mo176a(View view);

        /* renamed from: a */
        void mo177a(View view, int i);

        /* renamed from: a */
        void mo178a(View view, Object obj);

        /* renamed from: a */
        boolean mo179a(View view, int i, Bundle bundle);

        /* renamed from: a */
        boolean mo180a(View view, AccessibilityEvent accessibilityEvent);

        /* renamed from: a */
        boolean mo181a(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent);

        /* renamed from: b */
        void mo182b(View view, AccessibilityEvent accessibilityEvent);

        /* renamed from: c */
        void mo183c(View view, AccessibilityEvent accessibilityEvent);

        /* renamed from: d */
        void mo184d(View view, AccessibilityEvent accessibilityEvent);
    }

    /* renamed from: a */
    public static Object m1714a(final C0258a bridge) {
        return new AccessibilityDelegate() {
            public boolean dispatchPopulateAccessibilityEvent(View host, AccessibilityEvent event) {
                return bridge.mo180a(host, event);
            }

            public void onInitializeAccessibilityEvent(View host, AccessibilityEvent event) {
                bridge.mo182b(host, event);
            }

            public void onInitializeAccessibilityNodeInfo(View host, AccessibilityNodeInfo info) {
                bridge.mo178a(host, (Object) info);
            }

            public void onPopulateAccessibilityEvent(View host, AccessibilityEvent event) {
                bridge.mo183c(host, event);
            }

            public boolean onRequestSendAccessibilityEvent(ViewGroup host, View child, AccessibilityEvent event) {
                return bridge.mo181a(host, child, event);
            }

            public void sendAccessibilityEvent(View host, int eventType) {
                bridge.mo177a(host, eventType);
            }

            public void sendAccessibilityEventUnchecked(View host, AccessibilityEvent event) {
                bridge.mo184d(host, event);
            }

            public AccessibilityNodeProvider getAccessibilityNodeProvider(View host) {
                return (AccessibilityNodeProvider) bridge.mo176a(host);
            }

            public boolean performAccessibilityAction(View host, int action, Bundle args) {
                return bridge.mo179a(host, action, args);
            }
        };
    }

    /* renamed from: a */
    public static Object m1715a(Object delegate, View host) {
        return ((AccessibilityDelegate) delegate).getAccessibilityNodeProvider(host);
    }

    /* renamed from: a */
    public static boolean m1716a(Object delegate, View host, int action, Bundle args) {
        return ((AccessibilityDelegate) delegate).performAccessibilityAction(host, action, args);
    }
}

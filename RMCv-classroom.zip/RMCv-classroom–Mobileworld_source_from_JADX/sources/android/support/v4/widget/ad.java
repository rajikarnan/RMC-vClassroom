package android.support.v4.widget;

import android.content.Context;
import android.support.v4.view.C0398u;
import android.support.v4.view.ag;
import android.support.v4.view.ai;
import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import java.util.Arrays;

/* compiled from: ViewDragHelper */
public class ad {
    /* renamed from: v */
    private static final Interpolator f790v = new C04321();
    /* renamed from: a */
    private int f791a;
    /* renamed from: b */
    private int f792b;
    /* renamed from: c */
    private int f793c = -1;
    /* renamed from: d */
    private float[] f794d;
    /* renamed from: e */
    private float[] f795e;
    /* renamed from: f */
    private float[] f796f;
    /* renamed from: g */
    private float[] f797g;
    /* renamed from: h */
    private int[] f798h;
    /* renamed from: i */
    private int[] f799i;
    /* renamed from: j */
    private int[] f800j;
    /* renamed from: k */
    private int f801k;
    /* renamed from: l */
    private VelocityTracker f802l;
    /* renamed from: m */
    private float f803m;
    /* renamed from: n */
    private float f804n;
    /* renamed from: o */
    private int f805o;
    /* renamed from: p */
    private int f806p;
    /* renamed from: q */
    private C0484y f807q;
    /* renamed from: r */
    private final C0413a f808r;
    /* renamed from: s */
    private View f809s;
    /* renamed from: t */
    private boolean f810t;
    /* renamed from: u */
    private final ViewGroup f811u;
    /* renamed from: w */
    private final Runnable f812w = new C04332(this);

    /* compiled from: ViewDragHelper */
    /* renamed from: android.support.v4.widget.ad$a */
    public static abstract class C0413a {
        /* renamed from: a */
        public abstract boolean mo360a(View view, int i);

        /* renamed from: a */
        public void mo356a(int state) {
        }

        /* renamed from: a */
        public void mo359a(View changedView, int left, int top, int dx, int dy) {
        }

        /* renamed from: b */
        public void mo363b(View capturedChild, int activePointerId) {
        }

        /* renamed from: a */
        public void mo358a(View releasedChild, float xvel, float yvel) {
        }

        /* renamed from: a */
        public void mo357a(int edgeFlags, int pointerId) {
        }

        /* renamed from: b */
        public boolean mo364b(int edgeFlags) {
            return false;
        }

        /* renamed from: b */
        public void mo362b(int edgeFlags, int pointerId) {
        }

        /* renamed from: c */
        public int m1886c(int index) {
            return index;
        }

        /* renamed from: a */
        public int mo354a(View child) {
            return 0;
        }

        /* renamed from: b */
        public int m1881b(View child) {
            return 0;
        }

        /* renamed from: a */
        public int mo355a(View child, int left, int dx) {
            return 0;
        }

        /* renamed from: b */
        public int mo361b(View child, int top, int dy) {
            return 0;
        }
    }

    /* compiled from: ViewDragHelper */
    /* renamed from: android.support.v4.widget.ad$1 */
    static class C04321 implements Interpolator {
        C04321() {
        }

        public float getInterpolation(float t) {
            t -= 1.0f;
            return ((((t * t) * t) * t) * t) + 1.0f;
        }
    }

    /* compiled from: ViewDragHelper */
    /* renamed from: android.support.v4.widget.ad$2 */
    class C04332 implements Runnable {
        /* renamed from: a */
        final /* synthetic */ ad f789a;

        C04332(ad adVar) {
            this.f789a = adVar;
        }

        public void run() {
            this.f789a.m2107c(0);
        }
    }

    /* renamed from: a */
    public static ad m2075a(ViewGroup forParent, C0413a cb) {
        return new ad(forParent.getContext(), forParent, cb);
    }

    /* renamed from: a */
    public static ad m2074a(ViewGroup forParent, float sensitivity, C0413a cb) {
        ad helper = m2075a(forParent, cb);
        helper.f792b = (int) (((float) helper.f792b) * (1.0f / sensitivity));
        return helper;
    }

    private ad(Context context, ViewGroup forParent, C0413a cb) {
        if (forParent == null) {
            throw new IllegalArgumentException("Parent view may not be null");
        } else if (cb == null) {
            throw new IllegalArgumentException("Callback may not be null");
        } else {
            this.f811u = forParent;
            this.f808r = cb;
            ViewConfiguration vc = ViewConfiguration.get(context);
            this.f805o = (int) ((20.0f * context.getResources().getDisplayMetrics().density) + 0.5f);
            this.f792b = vc.getScaledTouchSlop();
            this.f803m = (float) vc.getScaledMaximumFlingVelocity();
            this.f804n = (float) vc.getScaledMinimumFlingVelocity();
            this.f807q = C0484y.m2313a(context, f790v);
        }
    }

    /* renamed from: a */
    public void m2093a(float minVel) {
        this.f804n = minVel;
    }

    /* renamed from: a */
    public int m2092a() {
        return this.f791a;
    }

    /* renamed from: a */
    public void m2094a(int edgeFlags) {
        this.f806p = edgeFlags;
    }

    /* renamed from: b */
    public int m2100b() {
        return this.f805o;
    }

    /* renamed from: a */
    public void m2095a(View childView, int activePointerId) {
        if (childView.getParent() != this.f811u) {
            throw new IllegalArgumentException("captureChildView: parameter must be a descendant of the ViewDragHelper's tracked parent view (" + this.f811u + ")");
        }
        this.f809s = childView;
        this.f793c = activePointerId;
        this.f808r.mo363b(childView, activePointerId);
        m2107c(1);
    }

    /* renamed from: c */
    public View m2106c() {
        return this.f809s;
    }

    /* renamed from: d */
    public int m2109d() {
        return this.f792b;
    }

    /* renamed from: e */
    public void m2112e() {
        this.f793c = -1;
        m2088f();
        if (this.f802l != null) {
            this.f802l.recycle();
            this.f802l = null;
        }
    }

    /* renamed from: a */
    public boolean m2098a(View child, int finalLeft, int finalTop) {
        this.f809s = child;
        this.f793c = -1;
        boolean continueSliding = m2079a(finalLeft, finalTop, 0, 0);
        if (!(continueSliding || this.f791a != 0 || this.f809s == null)) {
            this.f809s = null;
        }
        return continueSliding;
    }

    /* renamed from: a */
    public boolean m2096a(int finalLeft, int finalTop) {
        if (this.f810t) {
            return m2079a(finalLeft, finalTop, (int) ag.m1304a(this.f802l, this.f793c), (int) ag.m1305b(this.f802l, this.f793c));
        }
        throw new IllegalStateException("Cannot settleCapturedViewAt outside of a call to Callback#onViewReleased");
    }

    /* renamed from: a */
    private boolean m2079a(int finalLeft, int finalTop, int xvel, int yvel) {
        int startLeft = this.f809s.getLeft();
        int startTop = this.f809s.getTop();
        int dx = finalLeft - startLeft;
        int dy = finalTop - startTop;
        if (dx == 0 && dy == 0) {
            this.f807q.m2326h();
            m2107c(0);
            return false;
        }
        this.f807q.m2315a(startLeft, startTop, dx, dy, m2073a(this.f809s, dx, dy, xvel, yvel));
        m2107c(2);
        return true;
    }

    /* renamed from: a */
    private int m2073a(View child, int dx, int dy, int xvel, int yvel) {
        xvel = m2082b(xvel, (int) this.f804n, (int) this.f803m);
        yvel = m2082b(yvel, (int) this.f804n, (int) this.f803m);
        int absDx = Math.abs(dx);
        int absDy = Math.abs(dy);
        int absXVel = Math.abs(xvel);
        int absYVel = Math.abs(yvel);
        int addedVel = absXVel + absYVel;
        int addedDistance = absDx + absDy;
        return (int) ((((float) m2072a(dx, xvel, this.f808r.mo354a(child))) * (xvel != 0 ? ((float) absXVel) / ((float) addedVel) : ((float) absDx) / ((float) addedDistance))) + (((float) m2072a(dy, yvel, this.f808r.m1881b(child))) * (yvel != 0 ? ((float) absYVel) / ((float) addedVel) : ((float) absDy) / ((float) addedDistance))));
    }

    /* renamed from: a */
    private int m2072a(int delta, int velocity, int motionRange) {
        if (delta == 0) {
            return 0;
        }
        int duration;
        int width = this.f811u.getWidth();
        int halfWidth = width / 2;
        float distance = ((float) halfWidth) + (((float) halfWidth) * m2081b(Math.min(1.0f, ((float) Math.abs(delta)) / ((float) width))));
        velocity = Math.abs(velocity);
        if (velocity > 0) {
            duration = Math.round(1000.0f * Math.abs(distance / ((float) velocity))) * 4;
        } else {
            duration = (int) (((((float) Math.abs(delta)) / ((float) motionRange)) + 1.0f) * 256.0f);
        }
        return Math.min(duration, 600);
    }

    /* renamed from: b */
    private int m2082b(int value, int absMin, int absMax) {
        int absValue = Math.abs(value);
        if (absValue < absMin) {
            return 0;
        }
        if (absValue <= absMax) {
            return value;
        }
        if (value <= 0) {
            return -absMax;
        }
        return absMax;
    }

    /* renamed from: a */
    private float m2071a(float value, float absMin, float absMax) {
        float absValue = Math.abs(value);
        if (absValue < absMin) {
            return 0.0f;
        }
        if (absValue <= absMax) {
            return value;
        }
        if (value <= 0.0f) {
            return -absMax;
        }
        return absMax;
    }

    /* renamed from: b */
    private float m2081b(float f) {
        return (float) Math.sin((double) ((float) (((double) (f - 0.5f)) * 0.4712389167638204d)));
    }

    /* renamed from: a */
    public boolean m2099a(boolean deferCallbacks) {
        if (this.f791a == 2) {
            boolean keepGoing = this.f807q.m2325g();
            int x = this.f807q.m2320b();
            int y = this.f807q.m2321c();
            int dx = x - this.f809s.getLeft();
            int dy = y - this.f809s.getTop();
            if (dx != 0) {
                ai.m1493e(this.f809s, dx);
            }
            if (dy != 0) {
                ai.m1490d(this.f809s, dy);
            }
            if (!(dx == 0 && dy == 0)) {
                this.f808r.mo359a(this.f809s, x, y, dx, dy);
            }
            if (keepGoing && x == this.f807q.m2322d() && y == this.f807q.m2323e()) {
                this.f807q.m2326h();
                keepGoing = false;
            }
            if (!keepGoing) {
                if (deferCallbacks) {
                    this.f811u.post(this.f812w);
                } else {
                    m2107c(0);
                }
            }
        }
        return this.f791a == 2;
    }

    /* renamed from: a */
    private void m2076a(float xvel, float yvel) {
        this.f810t = true;
        this.f808r.mo358a(this.f809s, xvel, yvel);
        this.f810t = false;
        if (this.f791a == 1) {
            m2107c(0);
        }
    }

    /* renamed from: f */
    private void m2088f() {
        if (this.f794d != null) {
            Arrays.fill(this.f794d, 0.0f);
            Arrays.fill(this.f795e, 0.0f);
            Arrays.fill(this.f796f, 0.0f);
            Arrays.fill(this.f797g, 0.0f);
            Arrays.fill(this.f798h, 0);
            Arrays.fill(this.f799i, 0);
            Arrays.fill(this.f800j, 0);
            this.f801k = 0;
        }
    }

    /* renamed from: e */
    private void m2087e(int pointerId) {
        if (this.f794d != null) {
            this.f794d[pointerId] = 0.0f;
            this.f795e[pointerId] = 0.0f;
            this.f796f[pointerId] = 0.0f;
            this.f797g[pointerId] = 0.0f;
            this.f798h[pointerId] = 0;
            this.f799i[pointerId] = 0;
            this.f800j[pointerId] = 0;
            this.f801k &= (1 << pointerId) ^ -1;
        }
    }

    /* renamed from: f */
    private void m2089f(int pointerId) {
        if (this.f794d == null || this.f794d.length <= pointerId) {
            float[] imx = new float[(pointerId + 1)];
            float[] imy = new float[(pointerId + 1)];
            float[] lmx = new float[(pointerId + 1)];
            float[] lmy = new float[(pointerId + 1)];
            int[] iit = new int[(pointerId + 1)];
            int[] edip = new int[(pointerId + 1)];
            int[] edl = new int[(pointerId + 1)];
            if (this.f794d != null) {
                System.arraycopy(this.f794d, 0, imx, 0, this.f794d.length);
                System.arraycopy(this.f795e, 0, imy, 0, this.f795e.length);
                System.arraycopy(this.f796f, 0, lmx, 0, this.f796f.length);
                System.arraycopy(this.f797g, 0, lmy, 0, this.f797g.length);
                System.arraycopy(this.f798h, 0, iit, 0, this.f798h.length);
                System.arraycopy(this.f799i, 0, edip, 0, this.f799i.length);
                System.arraycopy(this.f800j, 0, edl, 0, this.f800j.length);
            }
            this.f794d = imx;
            this.f795e = imy;
            this.f796f = lmx;
            this.f797g = lmy;
            this.f798h = iit;
            this.f799i = edip;
            this.f800j = edl;
        }
    }

    /* renamed from: a */
    private void m2077a(float x, float y, int pointerId) {
        m2089f(pointerId);
        float[] fArr = this.f794d;
        this.f796f[pointerId] = x;
        fArr[pointerId] = x;
        fArr = this.f795e;
        this.f797g[pointerId] = y;
        fArr[pointerId] = y;
        this.f798h[pointerId] = m2086e((int) x, (int) y);
        this.f801k |= 1 << pointerId;
    }

    /* renamed from: c */
    private void m2085c(MotionEvent ev) {
        int pointerCount = C0398u.m1823c(ev);
        for (int i = 0; i < pointerCount; i++) {
            int pointerId = C0398u.m1821b(ev, i);
            float x = C0398u.m1822c(ev, i);
            float y = C0398u.m1824d(ev, i);
            this.f796f[pointerId] = x;
            this.f797g[pointerId] = y;
        }
    }

    /* renamed from: b */
    public boolean m2102b(int pointerId) {
        return (this.f801k & (1 << pointerId)) != 0;
    }

    /* renamed from: c */
    void m2107c(int state) {
        this.f811u.removeCallbacks(this.f812w);
        if (this.f791a != state) {
            this.f791a = state;
            this.f808r.mo356a(state);
            if (this.f791a == 0) {
                this.f809s = null;
            }
        }
    }

    /* renamed from: b */
    boolean m2104b(View toCapture, int pointerId) {
        if (toCapture == this.f809s && this.f793c == pointerId) {
            return true;
        }
        if (toCapture == null || !this.f808r.mo360a(toCapture, pointerId)) {
            return false;
        }
        this.f793c = pointerId;
        m2095a(toCapture, pointerId);
        return true;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: a */
    public boolean m2097a(android.view.MotionEvent r27) {
        /*
        r26 = this;
        r4 = android.support.v4.view.C0398u.m1818a(r27);
        r5 = android.support.v4.view.C0398u.m1820b(r27);
        if (r4 != 0) goto L_0x000d;
    L_0x000a:
        r26.m2112e();
    L_0x000d:
        r0 = r26;
        r0 = r0.f802l;
        r24 = r0;
        if (r24 != 0) goto L_0x001f;
    L_0x0015:
        r24 = android.view.VelocityTracker.obtain();
        r0 = r24;
        r1 = r26;
        r1.f802l = r0;
    L_0x001f:
        r0 = r26;
        r0 = r0.f802l;
        r24 = r0;
        r0 = r24;
        r1 = r27;
        r0.addMovement(r1);
        switch(r4) {
            case 0: goto L_0x0040;
            case 1: goto L_0x0255;
            case 2: goto L_0x0148;
            case 3: goto L_0x0255;
            case 4: goto L_0x002f;
            case 5: goto L_0x00bf;
            case 6: goto L_0x0246;
            default: goto L_0x002f;
        };
    L_0x002f:
        r0 = r26;
        r0 = r0.f791a;
        r24 = r0;
        r25 = 1;
        r0 = r24;
        r1 = r25;
        if (r0 != r1) goto L_0x025a;
    L_0x003d:
        r24 = 1;
    L_0x003f:
        return r24;
    L_0x0040:
        r22 = r27.getX();
        r23 = r27.getY();
        r24 = 0;
        r0 = r27;
        r1 = r24;
        r17 = android.support.v4.view.C0398u.m1821b(r0, r1);
        r0 = r26;
        r1 = r22;
        r2 = r23;
        r3 = r17;
        r0.m2077a(r1, r2, r3);
        r0 = r22;
        r0 = (int) r0;
        r24 = r0;
        r0 = r23;
        r0 = (int) r0;
        r25 = r0;
        r0 = r26;
        r1 = r24;
        r2 = r25;
        r20 = r0.m2110d(r1, r2);
        r0 = r26;
        r0 = r0.f809s;
        r24 = r0;
        r0 = r20;
        r1 = r24;
        if (r0 != r1) goto L_0x0094;
    L_0x007d:
        r0 = r26;
        r0 = r0.f791a;
        r24 = r0;
        r25 = 2;
        r0 = r24;
        r1 = r25;
        if (r0 != r1) goto L_0x0094;
    L_0x008b:
        r0 = r26;
        r1 = r20;
        r2 = r17;
        r0.m2104b(r1, r2);
    L_0x0094:
        r0 = r26;
        r0 = r0.f798h;
        r24 = r0;
        r8 = r24[r17];
        r0 = r26;
        r0 = r0.f806p;
        r24 = r0;
        r24 = r24 & r8;
        if (r24 == 0) goto L_0x002f;
    L_0x00a6:
        r0 = r26;
        r0 = r0.f808r;
        r24 = r0;
        r0 = r26;
        r0 = r0.f806p;
        r25 = r0;
        r25 = r25 & r8;
        r0 = r24;
        r1 = r25;
        r2 = r17;
        r0.mo357a(r1, r2);
        goto L_0x002f;
    L_0x00bf:
        r0 = r27;
        r17 = android.support.v4.view.C0398u.m1821b(r0, r5);
        r0 = r27;
        r22 = android.support.v4.view.C0398u.m1822c(r0, r5);
        r0 = r27;
        r23 = android.support.v4.view.C0398u.m1824d(r0, r5);
        r0 = r26;
        r1 = r22;
        r2 = r23;
        r3 = r17;
        r0.m2077a(r1, r2, r3);
        r0 = r26;
        r0 = r0.f791a;
        r24 = r0;
        if (r24 != 0) goto L_0x010f;
    L_0x00e4:
        r0 = r26;
        r0 = r0.f798h;
        r24 = r0;
        r8 = r24[r17];
        r0 = r26;
        r0 = r0.f806p;
        r24 = r0;
        r24 = r24 & r8;
        if (r24 == 0) goto L_0x002f;
    L_0x00f6:
        r0 = r26;
        r0 = r0.f808r;
        r24 = r0;
        r0 = r26;
        r0 = r0.f806p;
        r25 = r0;
        r25 = r25 & r8;
        r0 = r24;
        r1 = r25;
        r2 = r17;
        r0.mo357a(r1, r2);
        goto L_0x002f;
    L_0x010f:
        r0 = r26;
        r0 = r0.f791a;
        r24 = r0;
        r25 = 2;
        r0 = r24;
        r1 = r25;
        if (r0 != r1) goto L_0x002f;
    L_0x011d:
        r0 = r22;
        r0 = (int) r0;
        r24 = r0;
        r0 = r23;
        r0 = (int) r0;
        r25 = r0;
        r0 = r26;
        r1 = r24;
        r2 = r25;
        r20 = r0.m2110d(r1, r2);
        r0 = r26;
        r0 = r0.f809s;
        r24 = r0;
        r0 = r20;
        r1 = r24;
        if (r0 != r1) goto L_0x002f;
    L_0x013d:
        r0 = r26;
        r1 = r20;
        r2 = r17;
        r0.m2104b(r1, r2);
        goto L_0x002f;
    L_0x0148:
        r0 = r26;
        r0 = r0.f794d;
        r24 = r0;
        if (r24 == 0) goto L_0x002f;
    L_0x0150:
        r0 = r26;
        r0 = r0.f795e;
        r24 = r0;
        if (r24 == 0) goto L_0x002f;
    L_0x0158:
        r16 = android.support.v4.view.C0398u.m1823c(r27);
        r10 = 0;
    L_0x015d:
        r0 = r16;
        if (r10 >= r0) goto L_0x021b;
    L_0x0161:
        r0 = r27;
        r17 = android.support.v4.view.C0398u.m1821b(r0, r10);
        r0 = r26;
        r1 = r17;
        r24 = r0.m2091g(r1);
        if (r24 != 0) goto L_0x0174;
    L_0x0171:
        r10 = r10 + 1;
        goto L_0x015d;
    L_0x0174:
        r0 = r27;
        r22 = android.support.v4.view.C0398u.m1822c(r0, r10);
        r0 = r27;
        r23 = android.support.v4.view.C0398u.m1824d(r0, r10);
        r0 = r26;
        r0 = r0.f794d;
        r24 = r0;
        r24 = r24[r17];
        r6 = r22 - r24;
        r0 = r26;
        r0 = r0.f795e;
        r24 = r0;
        r24 = r24[r17];
        r7 = r23 - r24;
        r0 = r22;
        r0 = (int) r0;
        r24 = r0;
        r0 = r23;
        r0 = (int) r0;
        r25 = r0;
        r0 = r26;
        r1 = r24;
        r2 = r25;
        r20 = r0.m2110d(r1, r2);
        if (r20 == 0) goto L_0x0220;
    L_0x01aa:
        r0 = r26;
        r1 = r20;
        r24 = r0.m2080a(r1, r6, r7);
        if (r24 == 0) goto L_0x0220;
    L_0x01b4:
        r15 = 1;
    L_0x01b5:
        if (r15 == 0) goto L_0x0222;
    L_0x01b7:
        r13 = r20.getLeft();
        r0 = (int) r6;
        r24 = r0;
        r18 = r13 + r24;
        r0 = r26;
        r0 = r0.f808r;
        r24 = r0;
        r0 = (int) r6;
        r25 = r0;
        r0 = r24;
        r1 = r20;
        r2 = r18;
        r3 = r25;
        r11 = r0.mo355a(r1, r2, r3);
        r14 = r20.getTop();
        r0 = (int) r7;
        r24 = r0;
        r19 = r14 + r24;
        r0 = r26;
        r0 = r0.f808r;
        r24 = r0;
        r0 = (int) r7;
        r25 = r0;
        r0 = r24;
        r1 = r20;
        r2 = r19;
        r3 = r25;
        r12 = r0.mo361b(r1, r2, r3);
        r0 = r26;
        r0 = r0.f808r;
        r24 = r0;
        r0 = r24;
        r1 = r20;
        r9 = r0.mo354a(r1);
        r0 = r26;
        r0 = r0.f808r;
        r24 = r0;
        r0 = r24;
        r1 = r20;
        r21 = r0.m1881b(r1);
        if (r9 == 0) goto L_0x0215;
    L_0x0211:
        if (r9 <= 0) goto L_0x0222;
    L_0x0213:
        if (r11 != r13) goto L_0x0222;
    L_0x0215:
        if (r21 == 0) goto L_0x021b;
    L_0x0217:
        if (r21 <= 0) goto L_0x0222;
    L_0x0219:
        if (r12 != r14) goto L_0x0222;
    L_0x021b:
        r26.m2085c(r27);
        goto L_0x002f;
    L_0x0220:
        r15 = 0;
        goto L_0x01b5;
    L_0x0222:
        r0 = r26;
        r1 = r17;
        r0.m2083b(r6, r7, r1);
        r0 = r26;
        r0 = r0.f791a;
        r24 = r0;
        r25 = 1;
        r0 = r24;
        r1 = r25;
        if (r0 == r1) goto L_0x021b;
    L_0x0237:
        if (r15 == 0) goto L_0x0171;
    L_0x0239:
        r0 = r26;
        r1 = r20;
        r2 = r17;
        r24 = r0.m2104b(r1, r2);
        if (r24 == 0) goto L_0x0171;
    L_0x0245:
        goto L_0x021b;
    L_0x0246:
        r0 = r27;
        r17 = android.support.v4.view.C0398u.m1821b(r0, r5);
        r0 = r26;
        r1 = r17;
        r0.m2087e(r1);
        goto L_0x002f;
    L_0x0255:
        r26.m2112e();
        goto L_0x002f;
    L_0x025a:
        r24 = 0;
        goto L_0x003f;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.widget.ad.a(android.view.MotionEvent):boolean");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    /* renamed from: b */
    public void m2101b(android.view.MotionEvent r22) {
        /*
        r21 = this;
        r3 = android.support.v4.view.C0398u.m1818a(r22);
        r4 = android.support.v4.view.C0398u.m1820b(r22);
        if (r3 != 0) goto L_0x000d;
    L_0x000a:
        r21.m2112e();
    L_0x000d:
        r0 = r21;
        r0 = r0.f802l;
        r19 = r0;
        if (r19 != 0) goto L_0x001f;
    L_0x0015:
        r19 = android.view.VelocityTracker.obtain();
        r0 = r19;
        r1 = r21;
        r1.f802l = r0;
    L_0x001f:
        r0 = r21;
        r0 = r0.f802l;
        r19 = r0;
        r0 = r19;
        r1 = r22;
        r0.addMovement(r1);
        switch(r3) {
            case 0: goto L_0x0030;
            case 1: goto L_0x02a0;
            case 2: goto L_0x011a;
            case 3: goto L_0x02b6;
            case 4: goto L_0x002f;
            case 5: goto L_0x008e;
            case 6: goto L_0x0217;
            default: goto L_0x002f;
        };
    L_0x002f:
        return;
    L_0x0030:
        r17 = r22.getX();
        r18 = r22.getY();
        r19 = 0;
        r0 = r22;
        r1 = r19;
        r15 = android.support.v4.view.C0398u.m1821b(r0, r1);
        r0 = r17;
        r0 = (int) r0;
        r19 = r0;
        r0 = r18;
        r0 = (int) r0;
        r20 = r0;
        r0 = r21;
        r1 = r19;
        r2 = r20;
        r16 = r0.m2110d(r1, r2);
        r0 = r21;
        r1 = r17;
        r2 = r18;
        r0.m2077a(r1, r2, r15);
        r0 = r21;
        r1 = r16;
        r0.m2104b(r1, r15);
        r0 = r21;
        r0 = r0.f798h;
        r19 = r0;
        r7 = r19[r15];
        r0 = r21;
        r0 = r0.f806p;
        r19 = r0;
        r19 = r19 & r7;
        if (r19 == 0) goto L_0x002f;
    L_0x0078:
        r0 = r21;
        r0 = r0.f808r;
        r19 = r0;
        r0 = r21;
        r0 = r0.f806p;
        r20 = r0;
        r20 = r20 & r7;
        r0 = r19;
        r1 = r20;
        r0.mo357a(r1, r15);
        goto L_0x002f;
    L_0x008e:
        r0 = r22;
        r15 = android.support.v4.view.C0398u.m1821b(r0, r4);
        r0 = r22;
        r17 = android.support.v4.view.C0398u.m1822c(r0, r4);
        r0 = r22;
        r18 = android.support.v4.view.C0398u.m1824d(r0, r4);
        r0 = r21;
        r1 = r17;
        r2 = r18;
        r0.m2077a(r1, r2, r15);
        r0 = r21;
        r0 = r0.f791a;
        r19 = r0;
        if (r19 != 0) goto L_0x00f5;
    L_0x00b1:
        r0 = r17;
        r0 = (int) r0;
        r19 = r0;
        r0 = r18;
        r0 = (int) r0;
        r20 = r0;
        r0 = r21;
        r1 = r19;
        r2 = r20;
        r16 = r0.m2110d(r1, r2);
        r0 = r21;
        r1 = r16;
        r0.m2104b(r1, r15);
        r0 = r21;
        r0 = r0.f798h;
        r19 = r0;
        r7 = r19[r15];
        r0 = r21;
        r0 = r0.f806p;
        r19 = r0;
        r19 = r19 & r7;
        if (r19 == 0) goto L_0x002f;
    L_0x00de:
        r0 = r21;
        r0 = r0.f808r;
        r19 = r0;
        r0 = r21;
        r0 = r0.f806p;
        r20 = r0;
        r20 = r20 & r7;
        r0 = r19;
        r1 = r20;
        r0.mo357a(r1, r15);
        goto L_0x002f;
    L_0x00f5:
        r0 = r17;
        r0 = (int) r0;
        r19 = r0;
        r0 = r18;
        r0 = (int) r0;
        r20 = r0;
        r0 = r21;
        r1 = r19;
        r2 = r20;
        r19 = r0.m2108c(r1, r2);
        if (r19 == 0) goto L_0x002f;
    L_0x010b:
        r0 = r21;
        r0 = r0.f809s;
        r19 = r0;
        r0 = r21;
        r1 = r19;
        r0.m2104b(r1, r15);
        goto L_0x002f;
    L_0x011a:
        r0 = r21;
        r0 = r0.f791a;
        r19 = r0;
        r20 = 1;
        r0 = r19;
        r1 = r20;
        if (r0 != r1) goto L_0x019e;
    L_0x0128:
        r0 = r21;
        r0 = r0.f793c;
        r19 = r0;
        r0 = r21;
        r1 = r19;
        r19 = r0.m2091g(r1);
        if (r19 == 0) goto L_0x002f;
    L_0x0138:
        r0 = r21;
        r0 = r0.f793c;
        r19 = r0;
        r0 = r22;
        r1 = r19;
        r12 = android.support.v4.view.C0398u.m1819a(r0, r1);
        r0 = r22;
        r17 = android.support.v4.view.C0398u.m1822c(r0, r12);
        r0 = r22;
        r18 = android.support.v4.view.C0398u.m1824d(r0, r12);
        r0 = r21;
        r0 = r0.f796f;
        r19 = r0;
        r0 = r21;
        r0 = r0.f793c;
        r20 = r0;
        r19 = r19[r20];
        r19 = r17 - r19;
        r0 = r19;
        r10 = (int) r0;
        r0 = r21;
        r0 = r0.f797g;
        r19 = r0;
        r0 = r21;
        r0 = r0.f793c;
        r20 = r0;
        r19 = r19[r20];
        r19 = r18 - r19;
        r0 = r19;
        r11 = (int) r0;
        r0 = r21;
        r0 = r0.f809s;
        r19 = r0;
        r19 = r19.getLeft();
        r19 = r19 + r10;
        r0 = r21;
        r0 = r0.f809s;
        r20 = r0;
        r20 = r20.getTop();
        r20 = r20 + r11;
        r0 = r21;
        r1 = r19;
        r2 = r20;
        r0.m2084b(r1, r2, r10, r11);
        r21.m2085c(r22);
        goto L_0x002f;
    L_0x019e:
        r14 = android.support.v4.view.C0398u.m1823c(r22);
        r8 = 0;
    L_0x01a3:
        if (r8 >= r14) goto L_0x01e9;
    L_0x01a5:
        r0 = r22;
        r15 = android.support.v4.view.C0398u.m1821b(r0, r8);
        r0 = r21;
        r19 = r0.m2091g(r15);
        if (r19 != 0) goto L_0x01b6;
    L_0x01b3:
        r8 = r8 + 1;
        goto L_0x01a3;
    L_0x01b6:
        r0 = r22;
        r17 = android.support.v4.view.C0398u.m1822c(r0, r8);
        r0 = r22;
        r18 = android.support.v4.view.C0398u.m1824d(r0, r8);
        r0 = r21;
        r0 = r0.f794d;
        r19 = r0;
        r19 = r19[r15];
        r5 = r17 - r19;
        r0 = r21;
        r0 = r0.f795e;
        r19 = r0;
        r19 = r19[r15];
        r6 = r18 - r19;
        r0 = r21;
        r0.m2083b(r5, r6, r15);
        r0 = r21;
        r0 = r0.f791a;
        r19 = r0;
        r20 = 1;
        r0 = r19;
        r1 = r20;
        if (r0 != r1) goto L_0x01ee;
    L_0x01e9:
        r21.m2085c(r22);
        goto L_0x002f;
    L_0x01ee:
        r0 = r17;
        r0 = (int) r0;
        r19 = r0;
        r0 = r18;
        r0 = (int) r0;
        r20 = r0;
        r0 = r21;
        r1 = r19;
        r2 = r20;
        r16 = r0.m2110d(r1, r2);
        r0 = r21;
        r1 = r16;
        r19 = r0.m2080a(r1, r5, r6);
        if (r19 == 0) goto L_0x01b3;
    L_0x020c:
        r0 = r21;
        r1 = r16;
        r19 = r0.m2104b(r1, r15);
        if (r19 == 0) goto L_0x01b3;
    L_0x0216:
        goto L_0x01e9;
    L_0x0217:
        r0 = r22;
        r15 = android.support.v4.view.C0398u.m1821b(r0, r4);
        r0 = r21;
        r0 = r0.f791a;
        r19 = r0;
        r20 = 1;
        r0 = r19;
        r1 = r20;
        if (r0 != r1) goto L_0x0299;
    L_0x022b:
        r0 = r21;
        r0 = r0.f793c;
        r19 = r0;
        r0 = r19;
        if (r15 != r0) goto L_0x0299;
    L_0x0235:
        r13 = -1;
        r14 = android.support.v4.view.C0398u.m1823c(r22);
        r8 = 0;
    L_0x023b:
        if (r8 >= r14) goto L_0x0290;
    L_0x023d:
        r0 = r22;
        r9 = android.support.v4.view.C0398u.m1821b(r0, r8);
        r0 = r21;
        r0 = r0.f793c;
        r19 = r0;
        r0 = r19;
        if (r9 != r0) goto L_0x0250;
    L_0x024d:
        r8 = r8 + 1;
        goto L_0x023b;
    L_0x0250:
        r0 = r22;
        r17 = android.support.v4.view.C0398u.m1822c(r0, r8);
        r0 = r22;
        r18 = android.support.v4.view.C0398u.m1824d(r0, r8);
        r0 = r17;
        r0 = (int) r0;
        r19 = r0;
        r0 = r18;
        r0 = (int) r0;
        r20 = r0;
        r0 = r21;
        r1 = r19;
        r2 = r20;
        r19 = r0.m2110d(r1, r2);
        r0 = r21;
        r0 = r0.f809s;
        r20 = r0;
        r0 = r19;
        r1 = r20;
        if (r0 != r1) goto L_0x024d;
    L_0x027c:
        r0 = r21;
        r0 = r0.f809s;
        r19 = r0;
        r0 = r21;
        r1 = r19;
        r19 = r0.m2104b(r1, r9);
        if (r19 == 0) goto L_0x024d;
    L_0x028c:
        r0 = r21;
        r13 = r0.f793c;
    L_0x0290:
        r19 = -1;
        r0 = r19;
        if (r13 != r0) goto L_0x0299;
    L_0x0296:
        r21.m2090g();
    L_0x0299:
        r0 = r21;
        r0.m2087e(r15);
        goto L_0x002f;
    L_0x02a0:
        r0 = r21;
        r0 = r0.f791a;
        r19 = r0;
        r20 = 1;
        r0 = r19;
        r1 = r20;
        if (r0 != r1) goto L_0x02b1;
    L_0x02ae:
        r21.m2090g();
    L_0x02b1:
        r21.m2112e();
        goto L_0x002f;
    L_0x02b6:
        r0 = r21;
        r0 = r0.f791a;
        r19 = r0;
        r20 = 1;
        r0 = r19;
        r1 = r20;
        if (r0 != r1) goto L_0x02d1;
    L_0x02c4:
        r19 = 0;
        r20 = 0;
        r0 = r21;
        r1 = r19;
        r2 = r20;
        r0.m2076a(r1, r2);
    L_0x02d1:
        r21.m2112e();
        goto L_0x002f;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.widget.ad.b(android.view.MotionEvent):void");
    }

    /* renamed from: b */
    private void m2083b(float dx, float dy, int pointerId) {
        int dragsStarted = 0;
        if (m2078a(dx, dy, pointerId, 1)) {
            dragsStarted = 0 | 1;
        }
        if (m2078a(dy, dx, pointerId, 4)) {
            dragsStarted |= 4;
        }
        if (m2078a(dx, dy, pointerId, 2)) {
            dragsStarted |= 2;
        }
        if (m2078a(dy, dx, pointerId, 8)) {
            dragsStarted |= 8;
        }
        if (dragsStarted != 0) {
            int[] iArr = this.f799i;
            iArr[pointerId] = iArr[pointerId] | dragsStarted;
            this.f808r.mo362b(dragsStarted, pointerId);
        }
    }

    /* renamed from: a */
    private boolean m2078a(float delta, float odelta, int pointerId, int edge) {
        float absDelta = Math.abs(delta);
        float absODelta = Math.abs(odelta);
        if ((this.f798h[pointerId] & edge) != edge || (this.f806p & edge) == 0 || (this.f800j[pointerId] & edge) == edge || (this.f799i[pointerId] & edge) == edge) {
            return false;
        }
        if (absDelta <= ((float) this.f792b) && absODelta <= ((float) this.f792b)) {
            return false;
        }
        if (absDelta < 0.5f * absODelta && this.f808r.mo364b(edge)) {
            int[] iArr = this.f800j;
            iArr[pointerId] = iArr[pointerId] | edge;
            return false;
        } else if ((this.f799i[pointerId] & edge) != 0 || absDelta <= ((float) this.f792b)) {
            return false;
        } else {
            return true;
        }
    }

    /* renamed from: a */
    private boolean m2080a(View child, float dx, float dy) {
        if (child == null) {
            return false;
        }
        boolean checkHorizontal;
        boolean checkVertical;
        if (this.f808r.mo354a(child) > 0) {
            checkHorizontal = true;
        } else {
            checkHorizontal = false;
        }
        if (this.f808r.m1881b(child) > 0) {
            checkVertical = true;
        } else {
            checkVertical = false;
        }
        if (checkHorizontal && checkVertical) {
            if ((dx * dx) + (dy * dy) <= ((float) (this.f792b * this.f792b))) {
                return false;
            }
            return true;
        } else if (checkHorizontal) {
            if (Math.abs(dx) <= ((float) this.f792b)) {
                return false;
            }
            return true;
        } else if (!checkVertical) {
            return false;
        } else {
            if (Math.abs(dy) <= ((float) this.f792b)) {
                return false;
            }
            return true;
        }
    }

    /* renamed from: d */
    public boolean m2111d(int directions) {
        int count = this.f794d.length;
        for (int i = 0; i < count; i++) {
            if (m2103b(directions, i)) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: b */
    public boolean m2103b(int directions, int pointerId) {
        if (!m2102b(pointerId)) {
            return false;
        }
        boolean checkHorizontal;
        boolean checkVertical;
        if ((directions & 1) == 1) {
            checkHorizontal = true;
        } else {
            checkHorizontal = false;
        }
        if ((directions & 2) == 2) {
            checkVertical = true;
        } else {
            checkVertical = false;
        }
        float dx = this.f796f[pointerId] - this.f794d[pointerId];
        float dy = this.f797g[pointerId] - this.f795e[pointerId];
        if (checkHorizontal && checkVertical) {
            if ((dx * dx) + (dy * dy) <= ((float) (this.f792b * this.f792b))) {
                return false;
            }
            return true;
        } else if (checkHorizontal) {
            if (Math.abs(dx) <= ((float) this.f792b)) {
                return false;
            }
            return true;
        } else if (!checkVertical) {
            return false;
        } else {
            if (Math.abs(dy) <= ((float) this.f792b)) {
                return false;
            }
            return true;
        }
    }

    /* renamed from: g */
    private void m2090g() {
        this.f802l.computeCurrentVelocity(1000, this.f803m);
        m2076a(m2071a(ag.m1304a(this.f802l, this.f793c), this.f804n, this.f803m), m2071a(ag.m1305b(this.f802l, this.f793c), this.f804n, this.f803m));
    }

    /* renamed from: b */
    private void m2084b(int left, int top, int dx, int dy) {
        int clampedX = left;
        int clampedY = top;
        int oldLeft = this.f809s.getLeft();
        int oldTop = this.f809s.getTop();
        if (dx != 0) {
            clampedX = this.f808r.mo355a(this.f809s, left, dx);
            ai.m1493e(this.f809s, clampedX - oldLeft);
        }
        if (dy != 0) {
            clampedY = this.f808r.mo361b(this.f809s, top, dy);
            ai.m1490d(this.f809s, clampedY - oldTop);
        }
        if (dx != 0 || dy != 0) {
            this.f808r.mo359a(this.f809s, clampedX, clampedY, clampedX - oldLeft, clampedY - oldTop);
        }
    }

    /* renamed from: c */
    public boolean m2108c(int x, int y) {
        return m2105b(this.f809s, x, y);
    }

    /* renamed from: b */
    public boolean m2105b(View view, int x, int y) {
        if (view != null && x >= view.getLeft() && x < view.getRight() && y >= view.getTop() && y < view.getBottom()) {
            return true;
        }
        return false;
    }

    /* renamed from: d */
    public View m2110d(int x, int y) {
        for (int i = this.f811u.getChildCount() - 1; i >= 0; i--) {
            View child = this.f811u.getChildAt(this.f808r.m1886c(i));
            if (x >= child.getLeft() && x < child.getRight() && y >= child.getTop() && y < child.getBottom()) {
                return child;
            }
        }
        return null;
    }

    /* renamed from: e */
    private int m2086e(int x, int y) {
        int result = 0;
        if (x < this.f811u.getLeft() + this.f805o) {
            result = 0 | 1;
        }
        if (y < this.f811u.getTop() + this.f805o) {
            result |= 4;
        }
        if (x > this.f811u.getRight() - this.f805o) {
            result |= 2;
        }
        if (y > this.f811u.getBottom() - this.f805o) {
            return result | 8;
        }
        return result;
    }

    /* renamed from: g */
    private boolean m2091g(int pointerId) {
        if (m2102b(pointerId)) {
            return true;
        }
        Log.e("ViewDragHelper", "Ignoring pointerId=" + pointerId + " because ACTION_DOWN was not received " + "for this pointer before ACTION_MOVE. It likely happened because " + " ViewDragHelper did not receive all the events in the event stream.");
        return false;
    }
}

package android.support.v4.widget;

import android.content.Context;
import android.os.Build.VERSION;
import android.view.animation.Interpolator;
import android.widget.Scroller;

/* compiled from: ScrollerCompat */
/* renamed from: android.support.v4.widget.y */
public final class C0484y {
    /* renamed from: a */
    Object f876a;
    /* renamed from: b */
    C0480a f877b;

    /* compiled from: ScrollerCompat */
    /* renamed from: android.support.v4.widget.y$a */
    interface C0480a {
        /* renamed from: a */
        Object mo406a(Context context, Interpolator interpolator);

        /* renamed from: a */
        void mo407a(Object obj, int i, int i2, int i3, int i4);

        /* renamed from: a */
        void mo408a(Object obj, int i, int i2, int i3, int i4, int i5);

        /* renamed from: a */
        void mo409a(Object obj, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8);

        /* renamed from: a */
        void mo410a(Object obj, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10);

        /* renamed from: a */
        boolean mo411a(Object obj);

        /* renamed from: a */
        boolean mo412a(Object obj, int i, int i2, int i3, int i4, int i5, int i6);

        /* renamed from: b */
        int mo413b(Object obj);

        /* renamed from: c */
        int mo414c(Object obj);

        /* renamed from: d */
        float mo415d(Object obj);

        /* renamed from: e */
        boolean mo416e(Object obj);

        /* renamed from: f */
        void mo417f(Object obj);

        /* renamed from: g */
        int mo418g(Object obj);

        /* renamed from: h */
        int mo419h(Object obj);
    }

    /* compiled from: ScrollerCompat */
    /* renamed from: android.support.v4.widget.y$b */
    static class C0481b implements C0480a {
        C0481b() {
        }

        /* renamed from: a */
        public Object mo406a(Context context, Interpolator interpolator) {
            return interpolator != null ? new Scroller(context, interpolator) : new Scroller(context);
        }

        /* renamed from: a */
        public boolean mo411a(Object scroller) {
            return ((Scroller) scroller).isFinished();
        }

        /* renamed from: b */
        public int mo413b(Object scroller) {
            return ((Scroller) scroller).getCurrX();
        }

        /* renamed from: c */
        public int mo414c(Object scroller) {
            return ((Scroller) scroller).getCurrY();
        }

        /* renamed from: d */
        public float mo415d(Object scroller) {
            return 0.0f;
        }

        /* renamed from: e */
        public boolean mo416e(Object scroller) {
            return ((Scroller) scroller).computeScrollOffset();
        }

        /* renamed from: a */
        public void mo407a(Object scroller, int startX, int startY, int dx, int dy) {
            ((Scroller) scroller).startScroll(startX, startY, dx, dy);
        }

        /* renamed from: a */
        public void mo408a(Object scroller, int startX, int startY, int dx, int dy, int duration) {
            ((Scroller) scroller).startScroll(startX, startY, dx, dy, duration);
        }

        /* renamed from: a */
        public void mo409a(Object scroller, int startX, int startY, int velX, int velY, int minX, int maxX, int minY, int maxY) {
            ((Scroller) scroller).fling(startX, startY, velX, velY, minX, maxX, minY, maxY);
        }

        /* renamed from: a */
        public void mo410a(Object scroller, int startX, int startY, int velX, int velY, int minX, int maxX, int minY, int maxY, int overX, int overY) {
            ((Scroller) scroller).fling(startX, startY, velX, velY, minX, maxX, minY, maxY);
        }

        /* renamed from: f */
        public void mo417f(Object scroller) {
            ((Scroller) scroller).abortAnimation();
        }

        /* renamed from: g */
        public int mo418g(Object scroller) {
            return ((Scroller) scroller).getFinalX();
        }

        /* renamed from: h */
        public int mo419h(Object scroller) {
            return ((Scroller) scroller).getFinalY();
        }

        /* renamed from: a */
        public boolean mo412a(Object scroller, int startX, int startY, int minX, int maxX, int minY, int maxY) {
            return false;
        }
    }

    /* compiled from: ScrollerCompat */
    /* renamed from: android.support.v4.widget.y$c */
    static class C0482c implements C0480a {
        C0482c() {
        }

        /* renamed from: a */
        public Object mo406a(Context context, Interpolator interpolator) {
            return C0485z.m2327a(context, interpolator);
        }

        /* renamed from: a */
        public boolean mo411a(Object scroller) {
            return C0485z.m2332a(scroller);
        }

        /* renamed from: b */
        public int mo413b(Object scroller) {
            return C0485z.m2334b(scroller);
        }

        /* renamed from: c */
        public int mo414c(Object scroller) {
            return C0485z.m2335c(scroller);
        }

        /* renamed from: d */
        public float mo415d(Object scroller) {
            return 0.0f;
        }

        /* renamed from: e */
        public boolean mo416e(Object scroller) {
            return C0485z.m2336d(scroller);
        }

        /* renamed from: a */
        public void mo407a(Object scroller, int startX, int startY, int dx, int dy) {
            C0485z.m2328a(scroller, startX, startY, dx, dy);
        }

        /* renamed from: a */
        public void mo408a(Object scroller, int startX, int startY, int dx, int dy, int duration) {
            C0485z.m2329a(scroller, startX, startY, dx, dy, duration);
        }

        /* renamed from: a */
        public void mo409a(Object scroller, int startX, int startY, int velX, int velY, int minX, int maxX, int minY, int maxY) {
            C0485z.m2330a(scroller, startX, startY, velX, velY, minX, maxX, minY, maxY);
        }

        /* renamed from: a */
        public void mo410a(Object scroller, int startX, int startY, int velX, int velY, int minX, int maxX, int minY, int maxY, int overX, int overY) {
            C0485z.m2331a(scroller, startX, startY, velX, velY, minX, maxX, minY, maxY, overX, overY);
        }

        /* renamed from: f */
        public void mo417f(Object scroller) {
            C0485z.m2337e(scroller);
        }

        /* renamed from: g */
        public int mo418g(Object scroller) {
            return C0485z.m2338f(scroller);
        }

        /* renamed from: h */
        public int mo419h(Object scroller) {
            return C0485z.m2339g(scroller);
        }

        /* renamed from: a */
        public boolean mo412a(Object scroller, int startX, int startY, int minX, int maxX, int minY, int maxY) {
            return C0485z.m2333a(scroller, startX, startY, minX, maxX, minY, maxY);
        }
    }

    /* compiled from: ScrollerCompat */
    /* renamed from: android.support.v4.widget.y$d */
    static class C0483d extends C0482c {
        C0483d() {
        }

        /* renamed from: d */
        public float mo415d(Object scroller) {
            return aa.m2033a(scroller);
        }
    }

    /* renamed from: a */
    public static C0484y m2312a(Context context) {
        return C0484y.m2313a(context, null);
    }

    /* renamed from: a */
    public static C0484y m2313a(Context context, Interpolator interpolator) {
        return new C0484y(VERSION.SDK_INT, context, interpolator);
    }

    private C0484y(int apiVersion, Context context, Interpolator interpolator) {
        if (apiVersion >= 14) {
            this.f877b = new C0483d();
        } else if (apiVersion >= 9) {
            this.f877b = new C0482c();
        } else {
            this.f877b = new C0481b();
        }
        this.f876a = this.f877b.mo406a(context, interpolator);
    }

    /* renamed from: a */
    public boolean m2318a() {
        return this.f877b.mo411a(this.f876a);
    }

    /* renamed from: b */
    public int m2320b() {
        return this.f877b.mo413b(this.f876a);
    }

    /* renamed from: c */
    public int m2321c() {
        return this.f877b.mo414c(this.f876a);
    }

    /* renamed from: d */
    public int m2322d() {
        return this.f877b.mo418g(this.f876a);
    }

    /* renamed from: e */
    public int m2323e() {
        return this.f877b.mo419h(this.f876a);
    }

    /* renamed from: f */
    public float m2324f() {
        return this.f877b.mo415d(this.f876a);
    }

    /* renamed from: g */
    public boolean m2325g() {
        return this.f877b.mo416e(this.f876a);
    }

    /* renamed from: a */
    public void m2314a(int startX, int startY, int dx, int dy) {
        this.f877b.mo407a(this.f876a, startX, startY, dx, dy);
    }

    /* renamed from: a */
    public void m2315a(int startX, int startY, int dx, int dy, int duration) {
        this.f877b.mo408a(this.f876a, startX, startY, dx, dy, duration);
    }

    /* renamed from: a */
    public void m2316a(int startX, int startY, int velocityX, int velocityY, int minX, int maxX, int minY, int maxY) {
        this.f877b.mo409a(this.f876a, startX, startY, velocityX, velocityY, minX, maxX, minY, maxY);
    }

    /* renamed from: a */
    public void m2317a(int startX, int startY, int velocityX, int velocityY, int minX, int maxX, int minY, int maxY, int overX, int overY) {
        this.f877b.mo410a(this.f876a, startX, startY, velocityX, velocityY, minX, maxX, minY, maxY, overX, overY);
    }

    /* renamed from: a */
    public boolean m2319a(int startX, int startY, int minX, int maxX, int minY, int maxY) {
        return this.f877b.mo412a(this.f876a, startX, startY, minX, maxX, minY, maxY);
    }

    /* renamed from: h */
    public void m2326h() {
        this.f877b.mo417f(this.f876a);
    }
}

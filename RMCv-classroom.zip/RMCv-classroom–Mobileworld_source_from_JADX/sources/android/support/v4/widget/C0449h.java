package android.support.v4.widget;

import android.database.Cursor;
import android.widget.Filter;
import android.widget.Filter.FilterResults;

/* compiled from: CursorFilter */
/* renamed from: android.support.v4.widget.h */
class C0449h extends Filter {
    /* renamed from: a */
    C0447a f824a;

    /* compiled from: CursorFilter */
    /* renamed from: android.support.v4.widget.h$a */
    interface C0447a {
        void changeCursor(Cursor cursor);

        CharSequence convertToString(Cursor cursor);

        Cursor getCursor();

        Cursor runQueryOnBackgroundThread(CharSequence charSequence);
    }

    C0449h(C0447a client) {
        this.f824a = client;
    }

    public CharSequence convertResultToString(Object resultValue) {
        return this.f824a.convertToString((Cursor) resultValue);
    }

    protected FilterResults performFiltering(CharSequence constraint) {
        Cursor cursor = this.f824a.runQueryOnBackgroundThread(constraint);
        FilterResults results = new FilterResults();
        if (cursor != null) {
            results.count = cursor.getCount();
            results.values = cursor;
        } else {
            results.count = 0;
            results.values = null;
        }
        return results;
    }

    protected void publishResults(CharSequence constraint, FilterResults results) {
        Cursor oldCursor = this.f824a.getCursor();
        if (results.values != null && results.values != oldCursor) {
            this.f824a.changeCursor((Cursor) results.values);
        }
    }
}

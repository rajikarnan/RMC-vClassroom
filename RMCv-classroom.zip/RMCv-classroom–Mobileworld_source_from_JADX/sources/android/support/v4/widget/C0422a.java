package android.support.v4.widget;

import android.content.res.Resources;
import android.os.SystemClock;
import android.support.v4.view.C0398u;
import android.support.v4.view.ai;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewConfiguration;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;

/* compiled from: AutoScrollHelper */
/* renamed from: android.support.v4.widget.a */
public abstract class C0422a implements OnTouchListener {
    /* renamed from: r */
    private static final int f719r = ViewConfiguration.getTapTimeout();
    /* renamed from: a */
    private final C0420a f720a = new C0420a();
    /* renamed from: b */
    private final Interpolator f721b = new AccelerateInterpolator();
    /* renamed from: c */
    private final View f722c;
    /* renamed from: d */
    private Runnable f723d;
    /* renamed from: e */
    private float[] f724e = new float[]{0.0f, 0.0f};
    /* renamed from: f */
    private float[] f725f = new float[]{Float.MAX_VALUE, Float.MAX_VALUE};
    /* renamed from: g */
    private int f726g;
    /* renamed from: h */
    private int f727h;
    /* renamed from: i */
    private float[] f728i = new float[]{0.0f, 0.0f};
    /* renamed from: j */
    private float[] f729j = new float[]{0.0f, 0.0f};
    /* renamed from: k */
    private float[] f730k = new float[]{Float.MAX_VALUE, Float.MAX_VALUE};
    /* renamed from: l */
    private boolean f731l;
    /* renamed from: m */
    private boolean f732m;
    /* renamed from: n */
    private boolean f733n;
    /* renamed from: o */
    private boolean f734o;
    /* renamed from: p */
    private boolean f735p;
    /* renamed from: q */
    private boolean f736q;

    /* compiled from: AutoScrollHelper */
    /* renamed from: android.support.v4.widget.a$a */
    private static class C0420a {
        /* renamed from: a */
        private int f707a;
        /* renamed from: b */
        private int f708b;
        /* renamed from: c */
        private float f709c;
        /* renamed from: d */
        private float f710d;
        /* renamed from: e */
        private long f711e = Long.MIN_VALUE;
        /* renamed from: f */
        private long f712f = 0;
        /* renamed from: g */
        private int f713g = 0;
        /* renamed from: h */
        private int f714h = 0;
        /* renamed from: i */
        private long f715i = -1;
        /* renamed from: j */
        private float f716j;
        /* renamed from: k */
        private int f717k;

        /* renamed from: a */
        public void m1990a(int durationMillis) {
            this.f707a = durationMillis;
        }

        /* renamed from: b */
        public void m1992b(int durationMillis) {
            this.f708b = durationMillis;
        }

        /* renamed from: a */
        public void m1988a() {
            this.f711e = AnimationUtils.currentAnimationTimeMillis();
            this.f715i = -1;
            this.f712f = this.f711e;
            this.f716j = 0.5f;
            this.f713g = 0;
            this.f714h = 0;
        }

        /* renamed from: b */
        public void m1991b() {
            long currentTime = AnimationUtils.currentAnimationTimeMillis();
            this.f717k = C0422a.m2007b((int) (currentTime - this.f711e), 0, this.f708b);
            this.f716j = m1987a(currentTime);
            this.f715i = currentTime;
        }

        /* renamed from: c */
        public boolean m1993c() {
            return this.f715i > 0 && AnimationUtils.currentAnimationTimeMillis() > this.f715i + ((long) this.f717k);
        }

        /* renamed from: a */
        private float m1987a(long currentTime) {
            if (currentTime < this.f711e) {
                return 0.0f;
            }
            if (this.f715i < 0 || currentTime < this.f715i) {
                return C0422a.m2006b(((float) (currentTime - this.f711e)) / ((float) this.f707a), 0.0f, 1.0f) * 0.5f;
            }
            long elapsedSinceEnd = currentTime - this.f715i;
            return (C0422a.m2006b(((float) elapsedSinceEnd) / ((float) this.f717k), 0.0f, 1.0f) * this.f716j) + (1.0f - this.f716j);
        }

        /* renamed from: a */
        private float m1986a(float value) {
            return ((-4.0f * value) * value) + (4.0f * value);
        }

        /* renamed from: d */
        public void m1994d() {
            if (this.f712f == 0) {
                throw new RuntimeException("Cannot compute scroll delta before calling start()");
            }
            long currentTime = AnimationUtils.currentAnimationTimeMillis();
            float scale = m1986a(m1987a(currentTime));
            long elapsedSinceDelta = currentTime - this.f712f;
            this.f712f = currentTime;
            this.f713g = (int) ((((float) elapsedSinceDelta) * scale) * this.f709c);
            this.f714h = (int) ((((float) elapsedSinceDelta) * scale) * this.f710d);
        }

        /* renamed from: a */
        public void m1989a(float x, float y) {
            this.f709c = x;
            this.f710d = y;
        }

        /* renamed from: e */
        public int m1995e() {
            return (int) (this.f709c / Math.abs(this.f709c));
        }

        /* renamed from: f */
        public int m1996f() {
            return (int) (this.f710d / Math.abs(this.f710d));
        }

        /* renamed from: g */
        public int m1997g() {
            return this.f713g;
        }

        /* renamed from: h */
        public int m1998h() {
            return this.f714h;
        }
    }

    /* compiled from: AutoScrollHelper */
    /* renamed from: android.support.v4.widget.a$b */
    private class C0421b implements Runnable {
        /* renamed from: a */
        final /* synthetic */ C0422a f718a;

        private C0421b(C0422a c0422a) {
            this.f718a = c0422a;
        }

        public void run() {
            if (this.f718a.f734o) {
                if (this.f718a.f732m) {
                    this.f718a.f732m = false;
                    this.f718a.f720a.m1988a();
                }
                C0420a scroller = this.f718a.f720a;
                if (scroller.m1993c() || !this.f718a.m2003a()) {
                    this.f718a.f734o = false;
                    return;
                }
                if (this.f718a.f733n) {
                    this.f718a.f733n = false;
                    this.f718a.m2014d();
                }
                scroller.m1994d();
                this.f718a.mo397a(scroller.m1997g(), scroller.m1998h());
                ai.m1475a(this.f718a.f722c, (Runnable) this);
            }
        }
    }

    /* renamed from: a */
    public abstract void mo397a(int i, int i2);

    /* renamed from: e */
    public abstract boolean mo398e(int i);

    /* renamed from: f */
    public abstract boolean mo399f(int i);

    public C0422a(View target) {
        this.f722c = target;
        DisplayMetrics metrics = Resources.getSystem().getDisplayMetrics();
        int maxVelocity = (int) ((1575.0f * metrics.density) + 0.5f);
        int minVelocity = (int) ((315.0f * metrics.density) + 0.5f);
        m2020a((float) maxVelocity, (float) maxVelocity);
        m2024b((float) minVelocity, (float) minVelocity);
        m2021a(1);
        m2030e(Float.MAX_VALUE, Float.MAX_VALUE);
        m2028d(0.2f, 0.2f);
        m2026c(1.0f, 1.0f);
        m2025b(f719r);
        m2027c(500);
        m2029d(500);
    }

    /* renamed from: a */
    public C0422a m2022a(boolean enabled) {
        if (this.f735p && !enabled) {
            m2012c();
        }
        this.f735p = enabled;
        return this;
    }

    /* renamed from: a */
    public C0422a m2020a(float horizontalMax, float verticalMax) {
        this.f730k[0] = horizontalMax / 1000.0f;
        this.f730k[1] = verticalMax / 1000.0f;
        return this;
    }

    /* renamed from: b */
    public C0422a m2024b(float horizontalMin, float verticalMin) {
        this.f729j[0] = horizontalMin / 1000.0f;
        this.f729j[1] = verticalMin / 1000.0f;
        return this;
    }

    /* renamed from: c */
    public C0422a m2026c(float horizontal, float vertical) {
        this.f728i[0] = horizontal / 1000.0f;
        this.f728i[1] = vertical / 1000.0f;
        return this;
    }

    /* renamed from: a */
    public C0422a m2021a(int type) {
        this.f726g = type;
        return this;
    }

    /* renamed from: d */
    public C0422a m2028d(float horizontal, float vertical) {
        this.f724e[0] = horizontal;
        this.f724e[1] = vertical;
        return this;
    }

    /* renamed from: e */
    public C0422a m2030e(float horizontalMax, float verticalMax) {
        this.f725f[0] = horizontalMax;
        this.f725f[1] = verticalMax;
        return this;
    }

    /* renamed from: b */
    public C0422a m2025b(int delayMillis) {
        this.f727h = delayMillis;
        return this;
    }

    /* renamed from: c */
    public C0422a m2027c(int durationMillis) {
        this.f720a.m1990a(durationMillis);
        return this;
    }

    /* renamed from: d */
    public C0422a m2029d(int durationMillis) {
        this.f720a.m1992b(durationMillis);
        return this;
    }

    public boolean onTouch(View v, MotionEvent event) {
        boolean z = true;
        if (!this.f735p) {
            return false;
        }
        switch (C0398u.m1818a(event)) {
            case 0:
                this.f733n = true;
                this.f731l = false;
                break;
            case 1:
            case 3:
                m2012c();
                break;
            case 2:
                break;
        }
        this.f720a.m1989a(m2001a(0, event.getX(), (float) v.getWidth(), (float) this.f722c.getWidth()), m2001a(1, event.getY(), (float) v.getHeight(), (float) this.f722c.getHeight()));
        if (!this.f734o && m2003a()) {
            m2008b();
        }
        if (!(this.f736q && this.f734o)) {
            z = false;
        }
        return z;
    }

    /* renamed from: a */
    private boolean m2003a() {
        C0420a scroller = this.f720a;
        int verticalDirection = scroller.m1996f();
        int horizontalDirection = scroller.m1995e();
        return (verticalDirection != 0 && mo399f(verticalDirection)) || (horizontalDirection != 0 && mo398e(horizontalDirection));
    }

    /* renamed from: b */
    private void m2008b() {
        if (this.f723d == null) {
            this.f723d = new C0421b();
        }
        this.f734o = true;
        this.f732m = true;
        if (this.f731l || this.f727h <= 0) {
            this.f723d.run();
        } else {
            ai.m1476a(this.f722c, this.f723d, (long) this.f727h);
        }
        this.f731l = true;
    }

    /* renamed from: c */
    private void m2012c() {
        if (this.f732m) {
            this.f734o = false;
        } else {
            this.f720a.m1991b();
        }
    }

    /* renamed from: a */
    private float m2001a(int direction, float coordinate, float srcSize, float dstSize) {
        float value = m2000a(this.f724e[direction], srcSize, this.f725f[direction], coordinate);
        if (value == 0.0f) {
            return 0.0f;
        }
        float relativeVelocity = this.f728i[direction];
        float minimumVelocity = this.f729j[direction];
        float maximumVelocity = this.f730k[direction];
        float targetVelocity = relativeVelocity * dstSize;
        if (value > 0.0f) {
            return C0422a.m2006b(value * targetVelocity, minimumVelocity, maximumVelocity);
        }
        return -C0422a.m2006b((-value) * targetVelocity, minimumVelocity, maximumVelocity);
    }

    /* renamed from: a */
    private float m2000a(float relativeValue, float size, float maxValue, float current) {
        float interpolated;
        float edgeSize = C0422a.m2006b(relativeValue * size, 0.0f, maxValue);
        float value = m2017f(size - current, edgeSize) - m2017f(current, edgeSize);
        if (value < 0.0f) {
            interpolated = -this.f721b.getInterpolation(-value);
        } else if (value <= 0.0f) {
            return 0.0f;
        } else {
            interpolated = this.f721b.getInterpolation(value);
        }
        return C0422a.m2006b(interpolated, -1.0f, 1.0f);
    }

    /* renamed from: f */
    private float m2017f(float current, float leading) {
        if (leading == 0.0f) {
            return 0.0f;
        }
        switch (this.f726g) {
            case 0:
            case 1:
                if (current >= leading) {
                    return 0.0f;
                }
                if (current >= 0.0f) {
                    return 1.0f - (current / leading);
                }
                if (this.f734o && this.f726g == 1) {
                    return 1.0f;
                }
                return 0.0f;
            case 2:
                if (current < 0.0f) {
                    return current / (-leading);
                }
                return 0.0f;
            default:
                return 0.0f;
        }
    }

    /* renamed from: b */
    private static int m2007b(int value, int min, int max) {
        if (value > max) {
            return max;
        }
        if (value < min) {
            return min;
        }
        return value;
    }

    /* renamed from: b */
    private static float m2006b(float value, float min, float max) {
        if (value > max) {
            return max;
        }
        if (value < min) {
            return min;
        }
        return value;
    }

    /* renamed from: d */
    private void m2014d() {
        long eventTime = SystemClock.uptimeMillis();
        MotionEvent cancel = MotionEvent.obtain(eventTime, eventTime, 3, 0.0f, 0.0f, 0);
        this.f722c.onTouchEvent(cancel);
        cancel.recycle();
    }
}

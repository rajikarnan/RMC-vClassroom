package android.support.v4.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.widget.CompoundButton;

/* compiled from: CompoundButtonCompat */
/* renamed from: android.support.v4.widget.c */
public final class C0440c {
    /* renamed from: a */
    private static final C0436c f819a;

    /* compiled from: CompoundButtonCompat */
    /* renamed from: android.support.v4.widget.c$c */
    interface C0436c {
        /* renamed from: a */
        Drawable mo381a(CompoundButton compoundButton);

        /* renamed from: a */
        void mo382a(CompoundButton compoundButton, ColorStateList colorStateList);

        /* renamed from: a */
        void mo383a(CompoundButton compoundButton, Mode mode);
    }

    /* compiled from: CompoundButtonCompat */
    /* renamed from: android.support.v4.widget.c$b */
    static class C0437b implements C0436c {
        C0437b() {
        }

        /* renamed from: a */
        public void mo382a(CompoundButton button, ColorStateList tint) {
            C0442e.m2131a(button, tint);
        }

        /* renamed from: a */
        public void mo383a(CompoundButton button, Mode tintMode) {
            C0442e.m2132a(button, tintMode);
        }

        /* renamed from: a */
        public Drawable mo381a(CompoundButton button) {
            return C0442e.m2130a(button);
        }
    }

    /* compiled from: CompoundButtonCompat */
    /* renamed from: android.support.v4.widget.c$d */
    static class C0438d extends C0437b {
        C0438d() {
        }

        /* renamed from: a */
        public void mo382a(CompoundButton button, ColorStateList tint) {
            C0443f.m2133a(button, tint);
        }

        /* renamed from: a */
        public void mo383a(CompoundButton button, Mode tintMode) {
            C0443f.m2134a(button, tintMode);
        }
    }

    /* compiled from: CompoundButtonCompat */
    /* renamed from: android.support.v4.widget.c$a */
    static class C0439a extends C0438d {
        C0439a() {
        }

        /* renamed from: a */
        public Drawable mo381a(CompoundButton button) {
            return C0441d.m2129a(button);
        }
    }

    static {
        int sdk = VERSION.SDK_INT;
        if (sdk >= 23) {
            f819a = new C0439a();
        } else if (sdk >= 21) {
            f819a = new C0438d();
        } else {
            f819a = new C0437b();
        }
    }

    /* renamed from: a */
    public static void m2127a(CompoundButton button, ColorStateList tint) {
        f819a.mo382a(button, tint);
    }

    /* renamed from: a */
    public static void m2128a(CompoundButton button, Mode tintMode) {
        f819a.mo383a(button, tintMode);
    }

    /* renamed from: a */
    public static Drawable m2126a(CompoundButton button) {
        return f819a.mo381a(button);
    }
}

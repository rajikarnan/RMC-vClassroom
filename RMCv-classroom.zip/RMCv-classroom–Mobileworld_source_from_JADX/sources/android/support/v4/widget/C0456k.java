package android.support.v4.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.os.Build.VERSION;

/* compiled from: EdgeEffectCompat */
/* renamed from: android.support.v4.widget.k */
public final class C0456k {
    /* renamed from: b */
    private static final C0452c f826b;
    /* renamed from: a */
    private Object f827a;

    /* compiled from: EdgeEffectCompat */
    /* renamed from: android.support.v4.widget.k$c */
    interface C0452c {
        /* renamed from: a */
        Object mo388a(Context context);

        /* renamed from: a */
        void mo389a(Object obj, int i, int i2);

        /* renamed from: a */
        boolean mo390a(Object obj);

        /* renamed from: a */
        boolean mo391a(Object obj, float f);

        /* renamed from: a */
        boolean mo392a(Object obj, float f, float f2);

        /* renamed from: a */
        boolean mo393a(Object obj, int i);

        /* renamed from: a */
        boolean mo394a(Object obj, Canvas canvas);

        /* renamed from: b */
        void mo395b(Object obj);

        /* renamed from: c */
        boolean mo396c(Object obj);
    }

    /* compiled from: EdgeEffectCompat */
    /* renamed from: android.support.v4.widget.k$a */
    static class C0453a implements C0452c {
        C0453a() {
        }

        /* renamed from: a */
        public Object mo388a(Context context) {
            return null;
        }

        /* renamed from: a */
        public void mo389a(Object edgeEffect, int width, int height) {
        }

        /* renamed from: a */
        public boolean mo390a(Object edgeEffect) {
            return true;
        }

        /* renamed from: b */
        public void mo395b(Object edgeEffect) {
        }

        /* renamed from: a */
        public boolean mo391a(Object edgeEffect, float deltaDistance) {
            return false;
        }

        /* renamed from: c */
        public boolean mo396c(Object edgeEffect) {
            return false;
        }

        /* renamed from: a */
        public boolean mo393a(Object edgeEffect, int velocity) {
            return false;
        }

        /* renamed from: a */
        public boolean mo394a(Object edgeEffect, Canvas canvas) {
            return false;
        }

        /* renamed from: a */
        public boolean mo392a(Object edgeEffect, float deltaDistance, float displacement) {
            return false;
        }
    }

    /* compiled from: EdgeEffectCompat */
    /* renamed from: android.support.v4.widget.k$b */
    static class C0454b implements C0452c {
        C0454b() {
        }

        /* renamed from: a */
        public Object mo388a(Context context) {
            return C0457l.m2176a(context);
        }

        /* renamed from: a */
        public void mo389a(Object edgeEffect, int width, int height) {
            C0457l.m2177a(edgeEffect, width, height);
        }

        /* renamed from: a */
        public boolean mo390a(Object edgeEffect) {
            return C0457l.m2178a(edgeEffect);
        }

        /* renamed from: b */
        public void mo395b(Object edgeEffect) {
            C0457l.m2182b(edgeEffect);
        }

        /* renamed from: a */
        public boolean mo391a(Object edgeEffect, float deltaDistance) {
            return C0457l.m2179a(edgeEffect, deltaDistance);
        }

        /* renamed from: c */
        public boolean mo396c(Object edgeEffect) {
            return C0457l.m2183c(edgeEffect);
        }

        /* renamed from: a */
        public boolean mo393a(Object edgeEffect, int velocity) {
            return C0457l.m2180a(edgeEffect, velocity);
        }

        /* renamed from: a */
        public boolean mo394a(Object edgeEffect, Canvas canvas) {
            return C0457l.m2181a(edgeEffect, canvas);
        }

        /* renamed from: a */
        public boolean mo392a(Object edgeEffect, float deltaDistance, float displacement) {
            return C0457l.m2179a(edgeEffect, deltaDistance);
        }
    }

    /* compiled from: EdgeEffectCompat */
    /* renamed from: android.support.v4.widget.k$d */
    static class C0455d extends C0454b {
        C0455d() {
        }

        /* renamed from: a */
        public boolean mo392a(Object edgeEffect, float deltaDistance, float displacement) {
            return C0458m.m2184a(edgeEffect, deltaDistance, displacement);
        }
    }

    static {
        if (VERSION.SDK_INT >= 21) {
            f826b = new C0455d();
        } else if (VERSION.SDK_INT >= 14) {
            f826b = new C0454b();
        } else {
            f826b = new C0453a();
        }
    }

    public C0456k(Context context) {
        this.f827a = f826b.mo388a(context);
    }

    /* renamed from: a */
    public void m2168a(int width, int height) {
        f826b.mo389a(this.f827a, width, height);
    }

    /* renamed from: a */
    public boolean m2169a() {
        return f826b.mo390a(this.f827a);
    }

    /* renamed from: b */
    public void m2174b() {
        f826b.mo395b(this.f827a);
    }

    /* renamed from: a */
    public boolean m2170a(float deltaDistance) {
        return f826b.mo391a(this.f827a, deltaDistance);
    }

    /* renamed from: a */
    public boolean m2171a(float deltaDistance, float displacement) {
        return f826b.mo392a(this.f827a, deltaDistance, displacement);
    }

    /* renamed from: c */
    public boolean m2175c() {
        return f826b.mo396c(this.f827a);
    }

    /* renamed from: a */
    public boolean m2172a(int velocity) {
        return f826b.mo393a(this.f827a, velocity);
    }

    /* renamed from: a */
    public boolean m2173a(Canvas canvas) {
        return f826b.mo394a(this.f827a, canvas);
    }
}

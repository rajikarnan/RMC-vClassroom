package android.support.v4.widget;

import android.os.Build.VERSION;
import android.view.View;
import android.widget.PopupWindow;

/* compiled from: PopupWindowCompat */
/* renamed from: android.support.v4.widget.s */
public final class C0474s {
    /* renamed from: a */
    static final C0468f f872a;

    /* compiled from: PopupWindowCompat */
    /* renamed from: android.support.v4.widget.s$f */
    interface C0468f {
        /* renamed from: a */
        void mo400a(PopupWindow popupWindow, int i);

        /* renamed from: a */
        void mo401a(PopupWindow popupWindow, View view, int i, int i2, int i3);

        /* renamed from: a */
        void mo402a(PopupWindow popupWindow, boolean z);

        /* renamed from: a */
        boolean mo403a(PopupWindow popupWindow);
    }

    /* compiled from: PopupWindowCompat */
    /* renamed from: android.support.v4.widget.s$c */
    static class C0469c implements C0468f {
        C0469c() {
        }

        /* renamed from: a */
        public void mo401a(PopupWindow popup, View anchor, int xoff, int yoff, int gravity) {
            popup.showAsDropDown(anchor, xoff, yoff);
        }

        /* renamed from: a */
        public void mo402a(PopupWindow popupWindow, boolean overlapAnchor) {
        }

        /* renamed from: a */
        public boolean mo403a(PopupWindow popupWindow) {
            return false;
        }

        /* renamed from: a */
        public void mo400a(PopupWindow popupWindow, int layoutType) {
        }
    }

    /* compiled from: PopupWindowCompat */
    /* renamed from: android.support.v4.widget.s$d */
    static class C0470d extends C0469c {
        C0470d() {
        }

        /* renamed from: a */
        public void mo400a(PopupWindow popupWindow, int layoutType) {
            C0477v.m2267a(popupWindow, layoutType);
        }
    }

    /* compiled from: PopupWindowCompat */
    /* renamed from: android.support.v4.widget.s$e */
    static class C0471e extends C0470d {
        C0471e() {
        }

        /* renamed from: a */
        public void mo401a(PopupWindow popup, View anchor, int xoff, int yoff, int gravity) {
            C0478w.m2268a(popup, anchor, xoff, yoff, gravity);
        }
    }

    /* compiled from: PopupWindowCompat */
    /* renamed from: android.support.v4.widget.s$a */
    static class C0472a extends C0471e {
        C0472a() {
        }

        /* renamed from: a */
        public void mo402a(PopupWindow popupWindow, boolean overlapAnchor) {
            C0475t.m2262a(popupWindow, overlapAnchor);
        }

        /* renamed from: a */
        public boolean mo403a(PopupWindow popupWindow) {
            return C0475t.m2263a(popupWindow);
        }
    }

    /* compiled from: PopupWindowCompat */
    /* renamed from: android.support.v4.widget.s$b */
    static class C0473b extends C0472a {
        C0473b() {
        }

        /* renamed from: a */
        public void mo402a(PopupWindow popupWindow, boolean overlapAnchor) {
            C0476u.m2265a(popupWindow, overlapAnchor);
        }

        /* renamed from: a */
        public boolean mo403a(PopupWindow popupWindow) {
            return C0476u.m2266a(popupWindow);
        }

        /* renamed from: a */
        public void mo400a(PopupWindow popupWindow, int layoutType) {
            C0476u.m2264a(popupWindow, layoutType);
        }
    }

    static {
        int version = VERSION.SDK_INT;
        if (version >= 23) {
            f872a = new C0473b();
        } else if (version >= 21) {
            f872a = new C0472a();
        } else if (version >= 19) {
            f872a = new C0471e();
        } else if (version >= 9) {
            f872a = new C0470d();
        } else {
            f872a = new C0469c();
        }
    }

    /* renamed from: a */
    public static void m2259a(PopupWindow popup, View anchor, int xoff, int yoff, int gravity) {
        f872a.mo401a(popup, anchor, xoff, yoff, gravity);
    }

    /* renamed from: a */
    public static void m2260a(PopupWindow popupWindow, boolean overlapAnchor) {
        f872a.mo402a(popupWindow, overlapAnchor);
    }

    /* renamed from: a */
    public static boolean m2261a(PopupWindow popupWindow) {
        return f872a.mo403a(popupWindow);
    }

    /* renamed from: a */
    public static void m2258a(PopupWindow popupWindow, int layoutType) {
        f872a.mo400a(popupWindow, layoutType);
    }
}

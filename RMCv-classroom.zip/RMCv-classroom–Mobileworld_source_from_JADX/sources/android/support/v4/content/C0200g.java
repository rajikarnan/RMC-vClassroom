package android.support.v4.content;

import android.support.v4.p011e.C0224c;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* compiled from: Loader */
/* renamed from: android.support.v4.content.g */
public class C0200g<D> {
    /* renamed from: a */
    int f385a;
    /* renamed from: b */
    C0070b<D> f386b;
    /* renamed from: c */
    C0069a<D> f387c;
    /* renamed from: d */
    boolean f388d;
    /* renamed from: e */
    boolean f389e;
    /* renamed from: f */
    boolean f390f;
    /* renamed from: g */
    boolean f391g;
    /* renamed from: h */
    boolean f392h;

    /* compiled from: Loader */
    /* renamed from: android.support.v4.content.g$a */
    public interface C0069a<D> {
    }

    /* compiled from: Loader */
    /* renamed from: android.support.v4.content.g$b */
    public interface C0070b<D> {
    }

    /* renamed from: a */
    public void m748a(int id, C0070b<D> listener) {
        if (this.f386b != null) {
            throw new IllegalStateException("There is already a listener registered");
        }
        this.f386b = listener;
        this.f385a = id;
    }

    /* renamed from: a */
    public void m750a(C0070b<D> listener) {
        if (this.f386b == null) {
            throw new IllegalStateException("No listener register");
        } else if (this.f386b != listener) {
            throw new IllegalArgumentException("Attempting to unregister the wrong listener");
        } else {
            this.f386b = null;
        }
    }

    /* renamed from: a */
    public void m749a(C0069a<D> listener) {
        if (this.f387c != null) {
            throw new IllegalStateException("There is already a listener registered");
        }
        this.f387c = listener;
    }

    /* renamed from: b */
    public void m753b(C0069a<D> listener) {
        if (this.f387c == null) {
            throw new IllegalStateException("No listener register");
        } else if (this.f387c != listener) {
            throw new IllegalArgumentException("Attempting to unregister the wrong listener");
        } else {
            this.f387c = null;
        }
    }

    /* renamed from: a */
    public final void m747a() {
        this.f388d = true;
        this.f390f = false;
        this.f389e = false;
        m752b();
    }

    /* renamed from: b */
    protected void m752b() {
    }

    /* renamed from: c */
    public void m754c() {
        this.f388d = false;
        m755d();
    }

    /* renamed from: d */
    protected void m755d() {
    }

    /* renamed from: e */
    public void m756e() {
        m757f();
        this.f390f = true;
        this.f388d = false;
        this.f389e = false;
        this.f391g = false;
        this.f392h = false;
    }

    /* renamed from: f */
    protected void m757f() {
    }

    /* renamed from: a */
    public String m746a(D data) {
        StringBuilder sb = new StringBuilder(64);
        C0224c.m831a(data, sb);
        sb.append("}");
        return sb.toString();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(64);
        C0224c.m831a(this, sb);
        sb.append(" id=");
        sb.append(this.f385a);
        sb.append("}");
        return sb.toString();
    }

    /* renamed from: a */
    public void m751a(String prefix, FileDescriptor fd, PrintWriter writer, String[] args) {
        writer.print(prefix);
        writer.print("mId=");
        writer.print(this.f385a);
        writer.print(" mListener=");
        writer.println(this.f386b);
        if (this.f388d || this.f391g || this.f392h) {
            writer.print(prefix);
            writer.print("mStarted=");
            writer.print(this.f388d);
            writer.print(" mContentChanged=");
            writer.print(this.f391g);
            writer.print(" mProcessingChange=");
            writer.println(this.f392h);
        }
        if (this.f389e || this.f390f) {
            writer.print(prefix);
            writer.print("mAbandoned=");
            writer.print(this.f389e);
            writer.print(" mReset=");
            writer.println(this.f390f);
        }
    }
}

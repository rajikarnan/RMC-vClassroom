package android.support.v4.content;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Build.VERSION;

/* compiled from: IntentCompat */
/* renamed from: android.support.v4.content.e */
public final class C0198e {
    /* renamed from: a */
    private static final C0194a f384a;

    /* compiled from: IntentCompat */
    /* renamed from: android.support.v4.content.e$a */
    interface C0194a {
        /* renamed from: a */
        Intent mo140a(ComponentName componentName);
    }

    /* compiled from: IntentCompat */
    /* renamed from: android.support.v4.content.e$b */
    static class C0195b implements C0194a {
        C0195b() {
        }

        /* renamed from: a */
        public Intent mo140a(ComponentName componentName) {
            Intent intent = new Intent("android.intent.action.MAIN");
            intent.setComponent(componentName);
            intent.addCategory("android.intent.category.LAUNCHER");
            return intent;
        }
    }

    /* compiled from: IntentCompat */
    /* renamed from: android.support.v4.content.e$c */
    static class C0196c extends C0195b {
        C0196c() {
        }

        /* renamed from: a */
        public Intent mo140a(ComponentName componentName) {
            return C0199f.m745a(componentName);
        }
    }

    /* compiled from: IntentCompat */
    /* renamed from: android.support.v4.content.e$d */
    static class C0197d extends C0196c {
        C0197d() {
        }
    }

    static {
        int version = VERSION.SDK_INT;
        if (version >= 15) {
            f384a = new C0197d();
        } else if (version >= 11) {
            f384a = new C0196c();
        } else {
            f384a = new C0195b();
        }
    }

    /* renamed from: a */
    public static Intent m744a(ComponentName mainActivity) {
        return f384a.mo140a(mainActivity);
    }
}

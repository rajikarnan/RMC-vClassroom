package android.support.v4.content.p009a;

import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.content.res.Resources.Theme;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;

/* compiled from: ResourcesCompat */
/* renamed from: android.support.v4.content.a.a */
public final class C0189a {
    /* renamed from: a */
    public static Drawable m736a(Resources res, int id, Theme theme) throws NotFoundException {
        if (VERSION.SDK_INT >= 21) {
            return C0190b.m737a(res, id, theme);
        }
        return res.getDrawable(id);
    }
}

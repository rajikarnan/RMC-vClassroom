package android.support.v4.content.p009a;

import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.content.res.Resources.Theme;
import android.graphics.drawable.Drawable;

/* compiled from: ResourcesCompatApi21 */
/* renamed from: android.support.v4.content.a.b */
class C0190b {
    /* renamed from: a */
    public static Drawable m737a(Resources res, int id, Theme theme) throws NotFoundException {
        return res.getDrawable(id, theme);
    }
}

package android.support.v4.content;

import android.content.Context;
import android.graphics.drawable.Drawable;

/* compiled from: ContextCompatApi21 */
/* renamed from: android.support.v4.content.b */
class C0191b {
    /* renamed from: a */
    public static Drawable m738a(Context context, int id) {
        return context.getDrawable(id);
    }
}

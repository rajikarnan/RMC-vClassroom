package android.support.v4.content;

import android.content.Context;
import android.content.Intent;

/* compiled from: ContextCompatHoneycomb */
/* renamed from: android.support.v4.content.c */
class C0192c {
    /* renamed from: a */
    static void m739a(Context context, Intent[] intents) {
        context.startActivities(intents);
    }
}

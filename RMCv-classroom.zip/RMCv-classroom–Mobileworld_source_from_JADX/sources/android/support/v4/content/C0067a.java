package android.support.v4.content;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Process;

/* compiled from: ContextCompat */
/* renamed from: android.support.v4.content.a */
public class C0067a {
    /* renamed from: a */
    public static boolean m224a(Context context, Intent[] intents, Bundle options) {
        int version = VERSION.SDK_INT;
        if (version >= 16) {
            C0193d.m740a(context, intents, options);
            return true;
        } else if (version < 11) {
            return false;
        } else {
            C0192c.m739a(context, intents);
            return true;
        }
    }

    /* renamed from: a */
    public static final Drawable m223a(Context context, int id) {
        if (VERSION.SDK_INT >= 21) {
            return C0191b.m738a(context, id);
        }
        return context.getResources().getDrawable(id);
    }

    /* renamed from: a */
    public static int m222a(Context context, String permission) {
        if (permission != null) {
            return context.checkPermission(permission, Process.myPid(), Process.myUid());
        }
        throw new IllegalArgumentException("permission is null");
    }
}

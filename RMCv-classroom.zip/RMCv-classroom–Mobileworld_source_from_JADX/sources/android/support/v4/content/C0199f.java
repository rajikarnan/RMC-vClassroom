package android.support.v4.content;

import android.content.ComponentName;
import android.content.Intent;

/* compiled from: IntentCompatHoneycomb */
/* renamed from: android.support.v4.content.f */
class C0199f {
    /* renamed from: a */
    public static Intent m745a(ComponentName mainActivity) {
        return Intent.makeMainActivity(mainActivity);
    }
}

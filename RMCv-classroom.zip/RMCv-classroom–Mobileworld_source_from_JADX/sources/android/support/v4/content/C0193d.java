package android.support.v4.content;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

/* compiled from: ContextCompatJellybean */
/* renamed from: android.support.v4.content.d */
class C0193d {
    /* renamed from: a */
    public static void m740a(Context context, Intent[] intents, Bundle options) {
        context.startActivities(intents, options);
    }
}

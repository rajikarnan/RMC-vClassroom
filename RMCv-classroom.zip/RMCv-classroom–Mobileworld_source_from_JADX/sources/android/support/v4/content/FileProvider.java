package android.support.v4.content;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ProviderInfo;
import android.content.res.XmlResourceParser;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.support.v4.app.ag;
import android.text.TextUtils;
import android.webkit.MimeTypeMap;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map.Entry;
import org.xmlpull.v1.XmlPullParserException;

public class FileProvider extends ContentProvider {
    /* renamed from: a */
    private static final String[] f380a = new String[]{"_display_name", "_size"};
    /* renamed from: b */
    private static final File f381b = new File("/");
    /* renamed from: c */
    private static HashMap<String, C0187a> f382c = new HashMap();
    /* renamed from: d */
    private C0187a f383d;

    /* renamed from: android.support.v4.content.FileProvider$a */
    interface C0187a {
        /* renamed from: a */
        Uri mo138a(File file);

        /* renamed from: a */
        File mo139a(Uri uri);
    }

    /* renamed from: android.support.v4.content.FileProvider$b */
    static class C0188b implements C0187a {
        /* renamed from: a */
        private final String f378a;
        /* renamed from: b */
        private final HashMap<String, File> f379b = new HashMap();

        public C0188b(String authority) {
            this.f378a = authority;
        }

        /* renamed from: a */
        public void m728a(String name, File root) {
            if (TextUtils.isEmpty(name)) {
                throw new IllegalArgumentException("Name must not be empty");
            }
            try {
                this.f379b.put(name, root.getCanonicalFile());
            } catch (IOException e) {
                throw new IllegalArgumentException("Failed to resolve canonical path for " + root, e);
            }
        }

        /* renamed from: a */
        public Uri mo138a(File file) {
            try {
                String rootPath;
                String path = file.getCanonicalPath();
                Entry<String, File> mostSpecific = null;
                for (Entry<String, File> root : this.f379b.entrySet()) {
                    rootPath = ((File) root.getValue()).getPath();
                    if (path.startsWith(rootPath) && (mostSpecific == null || rootPath.length() > ((File) mostSpecific.getValue()).getPath().length())) {
                        mostSpecific = root;
                    }
                }
                if (mostSpecific == null) {
                    throw new IllegalArgumentException("Failed to find configured root that contains " + path);
                }
                rootPath = ((File) mostSpecific.getValue()).getPath();
                if (rootPath.endsWith("/")) {
                    path = path.substring(rootPath.length());
                } else {
                    path = path.substring(rootPath.length() + 1);
                }
                return new Builder().scheme("content").authority(this.f378a).encodedPath(Uri.encode((String) mostSpecific.getKey()) + '/' + Uri.encode(path, "/")).build();
            } catch (IOException e) {
                throw new IllegalArgumentException("Failed to resolve canonical path for " + file);
            }
        }

        /* renamed from: a */
        public File mo139a(Uri uri) {
            String path = uri.getEncodedPath();
            int splitIndex = path.indexOf(47, 1);
            String tag = Uri.decode(path.substring(1, splitIndex));
            path = Uri.decode(path.substring(splitIndex + 1));
            File root = (File) this.f379b.get(tag);
            if (root == null) {
                throw new IllegalArgumentException("Unable to find configured root for " + uri);
            }
            File file = new File(root, path);
            try {
                file = file.getCanonicalFile();
                if (file.getPath().startsWith(root.getPath())) {
                    return file;
                }
                throw new SecurityException("Resolved path jumped beyond configured root");
            } catch (IOException e) {
                throw new IllegalArgumentException("Failed to resolve canonical path for " + file);
            }
        }
    }

    public boolean onCreate() {
        return true;
    }

    public void attachInfo(Context context, ProviderInfo info) {
        super.attachInfo(context, info);
        if (info.exported) {
            throw new SecurityException("Provider must not be exported");
        } else if (info.grantUriPermissions) {
            this.f383d = m731a(context, info.authority);
        } else {
            throw new SecurityException("Provider must grant uri permissions");
        }
    }

    /* renamed from: a */
    public static Uri m730a(Context context, String authority, File file) {
        return m731a(context, authority).mo138a(file);
    }

    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        File file = this.f383d.mo139a(uri);
        if (projection == null) {
            projection = f380a;
        }
        String[] cols = new String[projection.length];
        Object[] values = new Object[projection.length];
        String[] arr$ = projection;
        int len$ = arr$.length;
        int i$ = 0;
        int i = 0;
        while (i$ < len$) {
            int i2;
            String col = arr$[i$];
            if ("_display_name".equals(col)) {
                cols[i] = "_display_name";
                i2 = i + 1;
                values[i] = file.getName();
            } else if ("_size".equals(col)) {
                cols[i] = "_size";
                i2 = i + 1;
                values[i] = Long.valueOf(file.length());
            } else {
                i2 = i;
            }
            i$++;
            i = i2;
        }
        cols = m734a(cols, i);
        values = m733a(values, i);
        MatrixCursor cursor = new MatrixCursor(cols, 1);
        cursor.addRow(values);
        return cursor;
    }

    public String getType(Uri uri) {
        File file = this.f383d.mo139a(uri);
        int lastDot = file.getName().lastIndexOf(46);
        if (lastDot >= 0) {
            String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.getName().substring(lastDot + 1));
            if (mime != null) {
                return mime;
            }
        }
        return "application/octet-stream";
    }

    public Uri insert(Uri uri, ContentValues values) {
        throw new UnsupportedOperationException("No external inserts");
    }

    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        throw new UnsupportedOperationException("No external updates");
    }

    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return this.f383d.mo139a(uri).delete() ? 1 : 0;
    }

    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        return ParcelFileDescriptor.open(this.f383d.mo139a(uri), m729a(mode));
    }

    /* renamed from: a */
    private static C0187a m731a(Context context, String authority) {
        C0187a strat;
        synchronized (f382c) {
            strat = (C0187a) f382c.get(authority);
            if (strat == null) {
                try {
                    strat = m735b(context, authority);
                    f382c.put(authority, strat);
                } catch (IOException e) {
                    throw new IllegalArgumentException("Failed to parse android.support.FILE_PROVIDER_PATHS meta-data", e);
                } catch (XmlPullParserException e2) {
                    throw new IllegalArgumentException("Failed to parse android.support.FILE_PROVIDER_PATHS meta-data", e2);
                }
            }
        }
        return strat;
    }

    /* renamed from: b */
    private static C0187a m735b(Context context, String authority) throws IOException, XmlPullParserException {
        C0188b strat = new C0188b(authority);
        XmlResourceParser in = context.getPackageManager().resolveContentProvider(authority, ag.FLAG_HIGH_PRIORITY).loadXmlMetaData(context.getPackageManager(), "android.support.FILE_PROVIDER_PATHS");
        if (in == null) {
            throw new IllegalArgumentException("Missing android.support.FILE_PROVIDER_PATHS meta-data");
        }
        while (true) {
            int type = in.next();
            if (type == 1) {
                return strat;
            }
            if (type == 2) {
                String tag = in.getName();
                String name = in.getAttributeValue(null, "name");
                String path = in.getAttributeValue(null, "path");
                File target = null;
                if ("root-path".equals(tag)) {
                    target = m732a(f381b, path);
                } else if ("files-path".equals(tag)) {
                    target = m732a(context.getFilesDir(), path);
                } else if ("cache-path".equals(tag)) {
                    target = m732a(context.getCacheDir(), path);
                } else if ("external-path".equals(tag)) {
                    target = m732a(Environment.getExternalStorageDirectory(), path);
                }
                if (target != null) {
                    strat.m728a(name, target);
                }
            }
        }
    }

    /* renamed from: a */
    private static int m729a(String mode) {
        if ("r".equals(mode)) {
            return 268435456;
        }
        if ("w".equals(mode) || "wt".equals(mode)) {
            return 738197504;
        }
        if ("wa".equals(mode)) {
            return 704643072;
        }
        if ("rw".equals(mode)) {
            return 939524096;
        }
        if ("rwt".equals(mode)) {
            return 1006632960;
        }
        throw new IllegalArgumentException("Invalid mode: " + mode);
    }

    /* renamed from: a */
    private static File m732a(File base, String... segments) {
        File cur = base;
        String[] arr$ = segments;
        int len$ = arr$.length;
        int i$ = 0;
        File cur2 = cur;
        while (i$ < len$) {
            String segment = arr$[i$];
            if (segment != null) {
                cur = new File(cur2, segment);
            } else {
                cur = cur2;
            }
            i$++;
            cur2 = cur;
        }
        return cur2;
    }

    /* renamed from: a */
    private static String[] m734a(String[] original, int newLength) {
        String[] result = new String[newLength];
        System.arraycopy(original, 0, result, 0, newLength);
        return result;
    }

    /* renamed from: a */
    private static Object[] m733a(Object[] original, int newLength) {
        Object[] result = new Object[newLength];
        System.arraycopy(original, 0, result, 0, newLength);
        return result;
    }
}

package android.support.v4.content;

import android.content.Context;
import android.os.Process;
import android.support.v4.app.C0132f;

/* compiled from: PermissionChecker */
/* renamed from: android.support.v4.content.i */
public final class C0205i {
    /* renamed from: a */
    public static int m765a(Context context, String permission, int pid, int uid, String packageName) {
        if (context.checkPermission(permission, pid, uid) == -1) {
            return -1;
        }
        String op = C0132f.m481a(permission);
        if (op == null) {
            return 0;
        }
        if (packageName == null) {
            String[] packageNames = context.getPackageManager().getPackagesForUid(uid);
            if (packageNames == null || packageNames.length <= 0) {
                return -1;
            }
            packageName = packageNames[0];
        }
        return C0132f.m480a(context, op, packageName) != 0 ? -2 : 0;
    }

    /* renamed from: a */
    public static int m764a(Context context, String permission) {
        return C0205i.m765a(context, permission, Process.myPid(), Process.myUid(), context.getPackageName());
    }
}

package android.support.p001a;

import android.os.IInterface;

/* compiled from: ICustomTabsCallback */
/* renamed from: android.support.a.c */
public interface C0005c extends IInterface {
}

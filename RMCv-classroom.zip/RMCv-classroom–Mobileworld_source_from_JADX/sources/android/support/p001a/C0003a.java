package android.support.p001a;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v4.app.C0068a;
import android.support.v4.app.C0145l;
import java.util.ArrayList;

/* compiled from: CustomTabsIntent */
/* renamed from: android.support.a.a */
public final class C0003a {
    /* renamed from: a */
    public final Intent f4a;
    /* renamed from: b */
    public final Bundle f5b;

    /* compiled from: CustomTabsIntent */
    /* renamed from: android.support.a.a$a */
    public static final class C0002a {
        /* renamed from: a */
        private final Intent f0a;
        /* renamed from: b */
        private ArrayList<Bundle> f1b;
        /* renamed from: c */
        private Bundle f2c;
        /* renamed from: d */
        private ArrayList<Bundle> f3d;

        public C0002a() {
            this(null);
        }

        public C0002a(C0004b session) {
            IBinder iBinder = null;
            this.f0a = new Intent("android.intent.action.VIEW");
            this.f1b = null;
            this.f2c = null;
            this.f3d = null;
            if (session != null) {
                this.f0a.setPackage(session.m4b().getPackageName());
            }
            Bundle bundle = new Bundle();
            String str = "android.support.customtabs.extra.SESSION";
            if (session != null) {
                iBinder = session.m3a();
            }
            C0145l.m535a(bundle, str, iBinder);
            this.f0a.putExtras(bundle);
        }

        /* renamed from: a */
        public C0003a m1a() {
            if (this.f1b != null) {
                this.f0a.putParcelableArrayListExtra("android.support.customtabs.extra.MENU_ITEMS", this.f1b);
            }
            if (this.f3d != null) {
                this.f0a.putParcelableArrayListExtra("android.support.customtabs.extra.TOOLBAR_ITEMS", this.f3d);
            }
            return new C0003a(this.f0a, this.f2c);
        }
    }

    /* renamed from: a */
    public void m2a(Activity context, Uri url) {
        this.f4a.setData(url);
        C0068a.m228a(context, this.f4a, this.f5b);
    }

    private C0003a(Intent intent, Bundle startAnimationBundle) {
        this.f4a = intent;
        this.f5b = startAnimationBundle;
    }
}

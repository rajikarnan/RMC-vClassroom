package android.support.p001a;

import android.content.ComponentName;
import android.os.IBinder;

/* compiled from: CustomTabsSession */
/* renamed from: android.support.a.b */
public final class C0004b {
    /* renamed from: a */
    private final C0005c f6a;
    /* renamed from: b */
    private final ComponentName f7b;

    /* renamed from: a */
    IBinder m3a() {
        return this.f6a.asBinder();
    }

    /* renamed from: b */
    ComponentName m4b() {
        return this.f7b;
    }
}
